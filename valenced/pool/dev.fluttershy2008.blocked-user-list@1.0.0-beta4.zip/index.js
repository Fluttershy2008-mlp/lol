(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Valenced API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const hostId = 'valenced';
    const product = 'Valenced';
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the ' + product + ' plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const pathFinders = safe(() => U.discord.utils.modules.finders);
        const source = safe(() => pathFinders.lookupModuleWithImportedPath('../discord_common/js/packages/http-utils/HTTPUtils.tsx')[0])
            ?? rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update ' + product + ' to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        if (props.length && props.every(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL', 'HTTP'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        const found = rawFind(...props);
        if (found) return found;
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.valenced.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    const importedPaths = safe(() => U.discord.utils.modules.finders);
    if (importedPaths?.getModuleWithImportedPath) {
        metro.findByImportedPath = path => safe(() => importedPaths.lookupModuleWithImportedPath(path)[0]);
        metro.getModuleWithImportedPath = (path, callback) => own(importedPaths.getModuleWithImportedPath(path,
            (module, id) => { if (active) callback(module, id); }));
    }
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod(hostId + '.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from ' + product + '.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.[hostId + '.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        // The external plugin receives a scoped API, not a global "valenced".
        // Expose the runtime lookup only for More Alts and only while loaded.
        host: { id: 'valenced',
            getQrRuntimeClient: metadata.id === 'dev.fluttershy2008.more-alts'
                ? () => active ? U : undefined : undefined },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage, version: metadata.version },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createValencedPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


// SPDX-License-Identifier: MIT
'use strict';

// Add a native Valenced overview row while retaining the plugin-manager settings
// entry. Included only in the four packages configured for these shortcuts.
function withValencedSettingsShortcut(options, config) {
    let current;
    function dispose(session) {
        if (!session?.active) return;
        session.active = false;
        if (current === session) current = undefined;
        for (const notify of [...session.listeners]) {
            try { notify(); } catch (error) { session.warn(error); }
        }
        for (const remove of session.disposers.splice(0).reverse()) {
            try { remove(); } catch (error) { session.warn(error); }
        }
        session.refresh?.();
    }
    return {
        ...options,
        async start(api) {
            if (current?.active) return;
            const session = { active: true, registered: false, listeners: new Set(), disposers: [],
                warn: error => api.logger?.warn?.('Could not add ' + config.title + ' to Valenced settings.', error?.message ?? String(error)),
                refresh: undefined };
            current = session;
            const live = () => session.active && current === session;
            api.cleanup(() => dispose(session));
            try { await options.start?.call(this, api); }
            catch (error) { dispose(session); throw error; }
            if (!live()) return;
            const U = api.unscoped, { React, ReactNative: RN } = U.react;
            const settings = U.discord.modules?.settings;
            if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem || !settings.addSettingsItemToSection) {
                session.warn('Native settings registration is unavailable; use the plugin settings button.');
                return;
            }
            session.refresh = () => { try { settings.refreshSettings?.(); } catch (error) { session.warn(error); } };
            const subscribe = listener => { session.listeners.add(listener); return () => session.listeners.delete(listener); };
            function SettingsPage({ navigation } = {}) {
                const enabled = React.useSyncExternalStore(subscribe, live, live);
                React.useLayoutEffect(() => { navigation?.setOptions?.({ title: config.title }); }, [navigation]);
                return enabled ? React.createElement(options.SettingsComponent, { api })
                    : React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen ' + config.title + ' from Valenced settings.');
            }
            function Icon(props) {
                let id;
                try { id = U.assets.getAssetIdByName(config.icon) ?? U.assets.getAssetIdByName('PuzzlePieceIcon'); } catch {}
                if (id == null) return null;
                return U.components?.TableRowAssetIcon
                    ? React.createElement(U.components.TableRowAssetIcon, { ...props, id })
                    : React.createElement(RN.Image, { source: id, style: { width: 24, height: 24 } });
            }
            const key = config.id + '.valenced-settings';
            const register = () => {
                if (!live() || session.registered) return;
                const added = [];
                try {
                    added.push(settings.registerSettingsItem(key, {
                        type: 'route', parent: null, IconComponent: Icon,
                        useTitle: () => config.title, usePredicate: live,
                        screen: { route: key, getComponent: () => SettingsPage },
                    }));
                    // Publish the renderer before making its row visible.
                    if (live()) added.push(settings.addSettingsItemToSection('VALENCED', key));
                    if (!live()) {
                        for (const remove of added.reverse()) remove?.();
                        return;
                    }
                    session.disposers.push(...added);
                    session.registered = true;
                    session.refresh();
                } catch (error) {
                    for (const remove of added.reverse()) { try { remove?.(); } catch {} }
                    session.warn(error);
                }
            };
            // The core settings callback installs the VALENCED section. Register
            // after those callbacks finish, including on the first settings open.
            try {
                const unsubscribe = settings.onSettingsModulesLoaded(() => { Promise.resolve().then(register); });
                if (typeof unsubscribe === 'function') {
                    if (live()) session.disposers.push(unsubscribe);
                    else unsubscribe();
                }
            } catch (error) { session.warn(error); }
        },
        stop(...args) {
            dispose(current);
            return options.stop?.apply(this, args);
        },
    };
}


return { default: withValencedSettingsShortcut(createValencedPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}

return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
// SPDX-License-Identifier: MIT
const USER_PROFILE_MODULE_PATH = 'modules/user_profile/native/showUserProfileActionSheet.tsx';
const profileTry = callback => { try { return callback(); } catch { return undefined; } };

function profileClientAPI() {
    const valencedAPI = profileTry(() => typeof valenced !== 'undefined' ? valenced : undefined);
    if (valencedAPI?.modules?.finders) return valencedAPI;
    return profileTry(() => typeof revenge !== 'undefined' && revenge.modules?.finders ? revenge : undefined);
}

function profileCallable(module) {
    if (typeof module === 'function') return { owner: undefined, call: module };
    if (typeof module?.showUserProfileActionSheet === 'function')
        return { owner: module, call: module.showUserProfileActionSheet };
    if (typeof module?.default === 'function') return { owner: module, call: module.default };
}

function findUserProfileOpener(legacy, client = profileClientAPI()) {
    const metro = legacy?.metro;
    const imported = profileTry(() => metro?.findByImportedPath?.(USER_PROFILE_MODULE_PATH))
        ?? profileTry(() => client?.discord?.utils?.modules?.finders?.lookupModuleWithImportedPath(USER_PROFILE_MODULE_PATH)?.[0]);
    let opener = profileCallable(imported);
    if (opener) return opener;

    const { finders } = client?.modules ?? {};
    const filters = finders?.filters;
    const namespace = profileTry(() => metro?.findByProps?.('USER_PROFILE_ACTION_SHEET_KEY_PREFIX', 'getUserProfileActionSheetKey'))
        ?? profileTry(() => finders?.lookupModule(filters.withProps('USER_PROFILE_ACTION_SHEET_KEY_PREFIX', 'getUserProfileActionSheetKey'),
            { initialize: false, returnNamespace: true })?.[0]);
    opener = profileCallable(namespace);
    if (opener) return opener;

    // Valenced's own profile action uses this dependency fingerprint to load
    // the opener on demand. Do not initialize unrelated Metro factories.
    const cold = profileTry(() => {
        if (!filters?.withDependencies || !client.discord?.flux?.withStoreName) return;
        const loggerId = client.discord.common?.logger?.LoggerModuleId;
        const trackerId = client.discord.common?.importTracker?.ImportTrackerModuleId;
        const userStoreId = finders.lookupModule(client.discord.flux.withStoreName('UserStore'), { initialize: false })[1];
        if (![loggerId, trackerId, userStoreId].every(id => Number.isInteger(id) && id >= 0)) return;
        const { ordered, relative } = filters.withDependencies;
        const named = filters.withName('showUserProfileActionSheet');
        const marked = filters.withProps('USER_PROFILE_ACTION_SHEET_KEY_PREFIX', 'getUserProfileActionSheetKey');
        const identity = typeof named.or === 'function' ? named.or(marked) : named;
        const fingerprint = filters.withDependencies(ordered([
            loggerId, userStoreId, relative(1), relative(2), relative(3), trackerId,
        ]));
        return finders.lookupModule(identity.and(fingerprint), { initialize: true, returnNamespace: true })[0];
    });
    opener = profileCallable(cold);
    if (opener) return opener;

    const named = profileTry(() => metro?.findByName?.('showUserProfileActionSheet'));
    if (typeof named === 'function') return { owner: undefined, call: named };
    for (const method of ['showUserProfileActionSheet', 'openUserProfileModal', 'openUserProfile', 'showUserProfile']) {
        const module = profileTry(() => metro?.findByProps?.(method));
        if (typeof module?.[method] === 'function') return { owner: module, call: module[method] };
    }
}

async function openUserProfile(legacy, options, isCurrent = () => true) {
    if (!isCurrent()) return false;
    const opener = findUserProfileOpener(legacy);
    if (!opener || !isCurrent()) return false;
    await Reflect.apply(opener.call, opener.owner, [options, 'stack']);
    return true;
}

const BLOCKED = 2;
const validID = value => typeof value === 'string' && /^\d{17,20}$/.test(value);

function entries(value) {
  if (value instanceof Map || (value && typeof value.entries === 'function' && !Array.isArray(value))) {
    return Array.from(value.entries());
  }
  if (Array.isArray(value)) return value.map(item => [item?.id ?? item?.user?.id, item?.type]);
  if (value && typeof value === 'object') return Object.entries(value);
  return null;
}

function blockedIDs(store) {
  if (!store) throw new Error('Discord’s blocked-user list is not ready. Tap Refresh to try again.');
  for (const method of ['getRelationships', 'getMutableRelationships']) {
    if (typeof store[method] !== 'function') continue;
    const pairs = entries(store[method]());
    if (pairs) return [...new Set(pairs.filter(([id, value]) => validID(id)
      && Number(value?.type ?? value) === BLOCKED).map(([id]) => id))];
  }
  for (const method of ['getBlockedIDs', 'getBlockedIds']) {
    if (typeof store[method] !== 'function') continue;
    const ids = store[method]();
    if (Array.isArray(ids) || ids instanceof Set) return [...new Set([...ids].filter(validID))];
  }
  throw new Error('This Discord version does not expose its blocked-user list.');
}

function isBlocked(store, id) {
  if (!validID(id)) return false;
  if (typeof store?.isBlocked === 'function') return Boolean(store.isBlocked(id));
  if (typeof store?.getRelationshipType === 'function') return Number(store.getRelationshipType(id)) === BLOCKED;
  return blockedIDs(store).includes(id);
}

function makeRows(ids, getUser) {
  return ids.map(id => {
    let user;
    try { user = getUser?.(id); } catch {}
    const username = typeof user?.username === 'string' ? user.username : '';
    const name = user?.globalName || user?.global_name || username || 'Unknown user';
    const tag = username ? (user.discriminator && user.discriminator !== '0'
      ? `${username}#${user.discriminator}` : `@${username}`) : 'Profile not cached yet';
    const avatar = typeof user?.avatar === 'string' && /^[a-zA-Z0-9_]+$/.test(user.avatar)
      ? `https://cdn.discordapp.com/avatars/${id}/${user.avatar}.png?size=128` : null;
    return { id, name: String(name), tag, avatar };
  }).sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()) || a.id.localeCompare(b.id));
}

function searchRows(rows, query) {
  const needle = String(query ?? '').trim().toLowerCase();
  return needle ? rows.filter(row => `${row.name}\n${row.tag}\n${row.id}`.toLowerCase().includes(needle)) : rows;
}

// Webhook authors are not Discord user accounts. These rules only hide local chat rows.
function normalizeID(value) {
  if (typeof value !== 'string') return '';
  const text = value.trim();
  return validID(text) ? text : (text.match(/^<@!?(\d{17,20})>$/)?.[1] ?? '');
}

const appEntryKey = entry => `app:${entry.id}:${entry.name}`;

function appEntries(storage, account) {
  const entries = storage?.appBlocksByAccount?.[account];
  return Array.isArray(entries) ? entries.filter(entry => validID(entry?.id)
    && typeof entry.name === 'string' && entry.name.length <= 128) : [];
}

function shouldHideAppMessage(message, entries) {
  if (!message || !entries.length) return false;
  // Match only the message's own identity, never mentions, replies or command users.
  const ids = [message.author?.id, message.authorId, message.author_id,
    message.webhookId, message.webhook_id, message.applicationId, message.application_id,
    message.application?.id].filter(validID);
  const name = message.author?.username ?? message.username;
  return entries.some(entry => ids.includes(entry.id) && (!entry.name || name === entry.name));
}

// Collection projection reused from ../hide-blocked-and-ignored-messages (CC0-1.0).
/* SPDX-License-Identifier: CC0-1.0 */
const sameItems = (a, b) => a.length === b.length && a.every((item, i) => item === b[i]);

// Project the list BEFORE Discord groups blocked messages or generates native
// rows. Leave MessageStore.getMessage and the real channel cache untouched.
// Pagination/loading flags and the ChannelMessages prototype are preserved.
function createCollectionFilter(shouldHide, reportUnsupported = () => {}) {
  let cache = new WeakMap();

  function project(collection) {
    if (!collection || typeof collection !== 'object') return collection;
    const raw = Array.isArray(collection) ? collection : collection._array;
    if (!Array.isArray(raw)) {
      reportUnsupported();
      return collection;
    }
    const visible = raw.filter(message => !shouldHide(message));
    if (visible.length === raw.length) return collection;
    if (Array.isArray(collection)) {
      const previous = cache.get(collection);
      if (previous && sameItems(previous.visible, visible)) return previous.view;
      cache.set(collection, { visible, view: visible });
      return visible;
    }

    const descriptors = Object.getOwnPropertyDescriptors(collection);
    const keys = Reflect.ownKeys(descriptors);
    const previous = cache.get(collection);
    // Discord usually replaces a ChannelMessages instance on changes, but some
    // builds mutate it. Compare visible rows and descriptor values on each read.
    if (previous && sameItems(previous.visible, visible)
      && keys.length === previous.keys.length
      && keys.every(key => {
        const a = descriptors[key], b = previous.descriptors[key];
        return b && a.value === b.value && a.get === b.get && a.set === b.set;
      })) return previous.view;

    const projected = { ...descriptors };
    projected._array = { value: visible, writable: true, enumerable: true, configurable: true };
    // Keep indexed lookups consistent with the displayed collection. Native
    // MessageStore.getMessage still uses the complete original map for replies.
    if (collection._map instanceof Map) {
      const visibleIds = new Set(visible.map(message => message?.id));
      projected._map = { value: new Map([...collection._map].filter(([id]) => visibleIds.has(id))),
        writable: true, enumerable: true, configurable: true };
    } else if (collection._map && typeof collection._map === 'object') {
      const map = Object.create(Object.getPrototypeOf(collection._map));
      for (const message of visible) {
        if (message?.id && Object.prototype.hasOwnProperty.call(collection._map, message.id)) {
          Object.defineProperty(map, message.id, { value: collection._map[message.id],
            writable: true, enumerable: true, configurable: true });
        }
      }
      projected._map = { value: map, writable: true, enumerable: true, configurable: true };
    }
    const view = Object.create(Object.getPrototypeOf(collection), projected);
    cache.set(collection, { visible, view, descriptors, keys });
    return view;
  }
  return { project, clear: () => { cache = new WeakMap(); } };
}

const SHORTCUT_KEY = 'FLUTTERSHY_BLOCKED_USERS';
const SETTINGS_CONFIG = 'SETTING_RENDERER_CONFIG';
const SHORTCUT_LAYER = Symbol.for('blocked-user-list.settings-layer.v1');

// Settings screens can retain an old list of row keys after a plugin is disabled.
// A hidden renderer keeps those keys valid until Discord recreates the screen.
function hiddenShortcut() {
  return { type: 'pressable', parent: null, title: () => 'Blocked Users',
    useTitle: () => 'Blocked Users', usePredicate: () => false, onPress: () => {}, withArrow: true };
}

function publishRenderer(constants, layer) {
  if (constants[SETTINGS_CONFIG]?.[SHORTCUT_KEY] === layer.record) return true;
  const descriptor = Object.getOwnPropertyDescriptor(constants, SETTINGS_CONFIG);
  if (!descriptor || descriptor.configurable === false) return false;

  let fallback = descriptor.value, hasAssignment = false;
  const readBase = () => descriptor.get && !hasAssignment ? descriptor.get.call(constants) : fallback;
  Object.defineProperty(constants, SETTINGS_CONFIG, {
    configurable: true, enumerable: descriptor.enumerable,
    get: () => ({ ...readBase(), [SHORTCUT_KEY]: layer.record }),
    set(value) {
      if (descriptor.set) descriptor.set.call(constants, value);
      else { fallback = value; hasAssignment = true; }
    },
  });
  return constants[SETTINGS_CONFIG]?.[SHORTCUT_KEY] === layer.record;
}

function attachSettingsShortcut({ api, constants, Settings, open, getAsset, renderIcon,
  patcher, tree, log = () => {} }) {
  const sections = api?.registeredSections;
  const rows = sections && Object.values(sections).find(items => Array.isArray(items)
    && items.some(row => row?.key === 'BUNNY_PLUGINS'));
  if (!rows || !constants) {
    log('Blocked Users shortcut is unavailable; the plugin settings page is still accessible.');
    return () => {};
  }

  let enabled = true, removeGuard, layer, row;
  let icon;
  for (const name of ['UserXIcon', 'FriendsIcon', 'WrenchIcon']) {
    try { icon = getAsset?.(name); if (icon != null) break; } catch {}
  }
  const record = { type: 'pressable', parent: null, title: () => 'Blocked Users',
    useTitle: () => 'Blocked Users', usePredicate: () => enabled,
    icon, IconComponent: icon != null && renderIcon ? () => renderIcon(icon) : undefined,
    onPress: () => { if (enabled) open(); }, withArrow: true };

  try {
    layer = constants[SHORTCUT_LAYER];
    if (!layer) {
      layer = { record };
      Object.defineProperty(constants, SHORTCUT_LAYER, { value: layer, configurable: true });
    } else layer.record = record;
    // Define the native renderer before exposing its key to the settings list.
    if (!publishRenderer(constants, layer)) throw new Error('Native settings renderer cannot be extended.');
    if (typeof patcher?.before === 'function' && typeof tree?.getAncestors === 'function') {
      removeGuard = patcher.before('getAncestors', tree, args => {
        if (enabled && args[0] === SHORTCUT_KEY) {
          try { publishRenderer(constants, layer); } catch (error) { log(error); }
        }
      });
    }
    row = { key: SHORTCUT_KEY, title: record.title, icon, usePredicate: record.usePredicate,
      rawTabsConfig: record, onPress: record.onPress, render: async () => ({ default: Settings }) };
    const previous = rows.findIndex(item => item?.key === SHORTCUT_KEY);
    if (previous >= 0) rows.splice(previous, 1);
    const plugins = rows.findIndex(item => item?.key === 'BUNNY_PLUGINS');
    rows.splice(plugins + 1, 0, row);
  } catch (error) {
    enabled = false;
    if (layer?.record === record) layer.record = hiddenShortcut();
    try { removeGuard?.(); } catch {}
    log(error);
    return () => {};
  }

  let disposed = false;
  return () => {
    if (disposed) return;
    disposed = true; enabled = false;
    if (layer.record === record) layer.record = hiddenShortcut();
    for (const items of new Set([rows, ...Object.values(sections)])) {
      if (!Array.isArray(items)) continue;
      const index = items.indexOf(row);
      if (index >= 0) { try { items.splice(index, 1); } catch {} }
    }
    try { removeGuard?.(); } catch (error) { log(error); }
  };
}


function createPlugin(V, host = globalThis) {
  const { React, ReactNative: RN } = V.metro.common;
  const h = React.createElement;
  const optional = fn => { try { return fn(); } catch { return undefined; } };
  const byProps = (...keys) => optional(() => V.metro.findByProps(...keys));
  const byStore = name => optional(() => V.metro.findByStoreName?.(name));
  const log = error => optional(() => V.logger?.error?.('Blocked User List', error));
  const toast = message => optional(() => V.ui?.toasts?.showToast?.(message));
  const listeners = new Set();
  const subscriptions = new Set();
  const pending = new Set();
  let active = false, generation = 0;
  let removeShortcut;
  let userStore, relationshipStore, themeStore, relationshipActions, blockActions;
  let messageStore, appLists, removeAppFilter, appFilterError;
  const storage = V.plugin?.storage;

  function resolveStores() {
    userStore = byStore('UserStore') ?? byProps('getUser', 'getCurrentUser');
    relationshipStore = byStore('RelationshipStore') ?? byProps('getRelationships', 'isBlocked');
    themeStore = byStore('ThemeStore');
  }
  function currentAccount() { return optional(() => userStore?.getCurrentUser?.()?.id); }
  function token() { return { generation, account: currentAccount() }; }
  function live(value) { return active && value.generation === generation && validID(value.account)
    && currentAccount() === value.account; }
  function emit() { for (const listener of listeners) optional(listener); }
  function key(id, value) { return `${value.generation}:${value.account}:${id}`; }

  function refreshAppMessages() {
    appLists?.clear();
    optional(() => messageStore?.emitChange?.());
    emit();
  }

  function ensureAppFilter() {
    if (removeAppFilter) return true;
    try {
      messageStore = byStore('MessageStore') ?? byProps('getMessages', 'getMessage');
      if (typeof messageStore?.getMessages !== 'function' || typeof V.patcher?.after !== 'function') {
        throw new Error('APP message hiding is unavailable on this Discord build.');
      }
      appLists = createCollectionFilter(message => shouldHideAppMessage(message, appEntries(storage, currentAccount())), () => {
        if (appFilterError) return;
        appFilterError = 'This Discord build uses an unsupported message-list format.';
        log(new Error(appFilterError)); emit();
      });
      const remove = V.patcher.after('getMessages', messageStore, (_args, result) => {
        if (!active) return result;
        try { return appEntries(storage, currentAccount()).length ? appLists.project(result) : result; }
        catch (error) { log(error); return result; }
      });
      if (typeof remove !== 'function') throw new Error('APP message hiding could not be installed.');
      removeAppFilter = remove;
      appFilterError = null;
      return true;
    } catch (error) {
      appFilterError = error?.message ?? String(error); log(error);
      return false;
    }
  }

  function blockApp(rawID, name, value) {
    if (!live(value)) return false;
    try {
      const id = normalizeID(rawID);
      const scopeName = typeof name === 'string' ? name.trim() : '';
      if (!id) throw new Error('Paste the copied APP/webhook user ID (17–20 digits).');
      if (id === value.account) throw new Error('You cannot block your own account.');
      if (scopeName.length > 128) throw new Error('The character name must be 128 characters or fewer.');
      if (!storage) throw new Error('Plugin storage is unavailable. Please restart Revenge.');
      if (!ensureAppFilter()) throw new Error(appFilterError);
      const entry = { id, name: scopeName };
      const entries = appEntries(storage, value.account);
      if (entries.some(item => appEntryKey(item) === appEntryKey(entry))) {
        toast('This APP/webhook is already blocked locally.'); return false;
      }
      // Assign serializable objects so Revenge persists changes across restarts.
      storage.appBlocksByAccount = { ...(storage.appBlocksByAccount ?? {}), [value.account]: [...entries, entry] };
      refreshAppMessages();
      toast('APP/webhook messages hidden on this device');
      return true;
    } catch (error) {
      log(error);
      if (live(value)) RN.Alert.alert('Could not block APP/webhook', error?.message ?? 'Please try again.');
      return false;
    }
  }

  function unblockApp(row, value) {
    if (!live(value) || row.kind !== 'app' || !storage) return false;
    const entries = appEntries(storage, value.account);
    if (!entries.some(entry => appEntryKey(entry) === row.localKey)) return false;
    storage.appBlocksByAccount = { ...(storage.appBlocksByAccount ?? {}),
      [value.account]: entries.filter(entry => appEntryKey(entry) !== row.localKey) };
    refreshAppMessages(); toast('APP/webhook unblocked locally');
    return true;
  }

  function snapshot() {
    resolveStores();
    const value = token();
    try {
      if (!active) throw new Error('Enable Blocked User List from the Plugins page to use it.');
      if (!validID(value.account)) throw new Error('Discord is still loading your account. Tap Refresh to try again.');
      const localRows = appEntries(storage, value.account).map(entry => ({
        id: entry.id, kind: 'app', localKey: appEntryKey(entry), name: entry.name || 'APP / webhook',
        tag: entry.name ? 'Local block · exact character name' : 'Local block · all messages from this ID', avatar: null,
      }));
      return { token: value, rows: [...localRows, ...makeRows(blockedIDs(relationshipStore), id => userStore?.getUser?.(id))],
        appFilterError, error: null };
    } catch (error) { return { token: value, rows: [], error: error?.message ?? String(error) }; }
  }

  function subscribe(listener) {
    if (!active) return () => {};
    resolveStores();
    listeners.add(listener);
    const cleanup = [];
    for (const store of new Set([relationshipStore, userStore, themeStore])) {
      if (typeof store?.addChangeListener !== 'function' || typeof store?.removeChangeListener !== 'function') continue;
      optional(() => {
        store.addChangeListener(listener);
        cleanup.push(() => store.removeChangeListener(listener));
      });
    }
    const dispatcher = V.metro.common.FluxDispatcher;
    if (typeof dispatcher?.subscribe === 'function' && typeof dispatcher?.unsubscribe === 'function') {
      for (const type of ['RELATIONSHIP_ADD', 'RELATIONSHIP_REMOVE', 'CONNECTION_OPEN', 'LOGOUT', 'LOGIN_SUCCESS']) {
        optional(() => {
          dispatcher.subscribe(type, listener);
          cleanup.push(() => dispatcher.unsubscribe(type, listener));
        });
      }
    }
    const app = optional(() => RN.AppState?.addEventListener?.('change', state => {
      if (state === 'active') listener();
    }));
    if (app?.remove) cleanup.push(() => app.remove());
    let disposed = false;
    const dispose = () => {
      if (disposed) return;
      disposed = true;
      listeners.delete(listener);
      subscriptions.delete(dispose);
      for (const fn of cleanup.reverse()) optional(fn);
    };
    subscriptions.add(dispose);
    return dispose;
  }

  async function openProfile(id, value) {
    if (!validID(id) || !live(value)) return;
    try {
      // Use Discord’s native profile UI, which loads the current profile itself.
      const opened = await openUserProfile(V, { userId: id }, () => live(value));
      if (!opened && live(value)) throw new Error('Profile buttons are unavailable on this Discord version.');
    } catch (error) {
      if (!live(value)) return;
      log(error);
      RN.Alert.alert('Could not open profile', error?.message ?? 'Please try again.');
    }
  }

  async function unblock(id, value) {
    if (!validID(id) || !live(value)) return false;
    const idKey = key(id, value);
    if (pending.has(idKey)) return false;
    try {
      // Recheck at confirmation time: the account or relationship may have changed.
      if (!isBlocked(relationshipStore, id)) { emit(); return false; }
      relationshipActions ??= byProps('removeRelationship', 'addRelationship') ?? byProps('removeRelationship');
      if (typeof relationshipActions?.removeRelationship !== 'function') {
        throw new Error('Unblocking is unavailable on this Discord version. You can still open the profile.');
      }
      pending.add(idKey); emit();
      const result = await relationshipActions.removeRelationship(id, { location: 'Blocked User List' });
      if (result === false || result?.ok === false || Number(result?.status) >= 400) throw new Error('Discord could not unblock this user. Please try again.');
      if (live(value)) {
        // Keep the row until Discord’s store actually reports the unblock.
        toast(isBlocked(relationshipStore, id) ? 'Unblock requested. Tap Refresh if the list has not updated.' : 'User unblocked');
        emit();
      }
      return true;
    } catch (error) {
      log(error);
      if (live(value)) RN.Alert.alert('Could not unblock user', error?.message ?? 'Please try again.');
      return false;
    } finally { pending.delete(idKey); if (live(value)) emit(); }
  }

  function requestUnblock(row, value) {
    if (!live(value) || !validID(row.id) || pending.has(key(row.id, value))) return;
    if (row.kind === 'app') {
      RN.Alert.alert('Unblock this APP/webhook?', `${row.name}\n${row.id}\n\nIts messages will appear again on this device.`, [
        { text: 'Cancel', style: 'cancel' }, { text: 'Unblock', onPress: () => unblockApp(row, value) },
      ]);
      return;
    }
    RN.Alert.alert('Unblock this user?', `${row.name}\n${row.tag}\n${row.id}\n\nThis removes them from your blocked-user list.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Unblock', onPress: () => { void unblock(row.id, value); } },
    ]);
  }

  async function block(rawID, value) {
    if (!live(value)) return false;
    const id = normalizeID(rawID);
    const idKey = key(id, value);
    if (pending.has(idKey)) return false;
    try {
      if (!validID(id)) throw new Error('Paste a Discord user ID containing 17–20 digits.');
      if (id === value.account) throw new Error('You cannot block your own account.');
      resolveStores();
      if (isBlocked(relationshipStore, id)) {
        toast('This user is already blocked.');
        return false;
      }
      blockActions ??= byProps('addRelationship', 'removeRelationship') ?? byProps('addRelationship');
      if (typeof blockActions?.addRelationship !== 'function') {
        throw new Error('Blocking by ID is unavailable on this Discord version.');
      }
      pending.add(idKey); emit();
      // Discord mobile takes an options object. Type 2 is a block, never a friend request.
      const result = await blockActions.addRelationship({ userId: id, type: BLOCKED, location: 'Blocked User List' });
      if (result === false || result?.ok === false || Number(result?.status) >= 400) {
        throw new Error('Discord could not block this user. Check the ID and try again.');
      }
      if (live(value)) {
        // Only Discord's relationship store decides when the new row appears.
        toast(isBlocked(relationshipStore, id) ? 'User blocked' : 'Block requested. Tap Refresh if the list has not updated.');
        emit();
      }
      return true;
    } catch (error) {
      log(error);
      if (live(value)) RN.Alert.alert('Could not block user', error?.message ?? 'Please try again.');
      return false;
    } finally { pending.delete(idKey); if (live(value)) emit(); }
  }

  function Settings() {
    const [query, setQuery] = React.useState('');
    const [revision, update] = React.useState(0);
    const [blockForm, setBlockForm] = React.useState(null);
    const refresh = React.useCallback(() => update(value => value + 1), []);
    const data = snapshot();
    React.useEffect(() => subscribe(refresh), [refresh, data.token.account, generation, userStore, relationshipStore, themeStore]);
    const scheme = typeof RN.useColorScheme === 'function' ? RN.useColorScheme() : 'dark';
    const dark = (optional(() => themeStore?.theme) ?? scheme) !== 'light';
    const c = dark
      ? { bg: '#111214', card: '#202226', text: '#f2f3f5', muted: '#b5bac1', border: '#383a40', accent: '#a7afff', button: '#323743' }
      : { bg: '#f2f3f5', card: '#fff', text: '#1e1f22', muted: '#5c6068', border: '#d4d7dc', accent: '#4752c4', button: '#eef0ff' };
    const Pressable = RN.Pressable ?? RN.TouchableOpacity;
    const text = (value, style = {}, props = {}) => h(RN.Text, { style: { color: c.text, fontSize: 15, lineHeight: 21, ...style }, ...props }, value);
    const button = (label, onPress, disabled = false, extra = {}) => h(Pressable, {
      accessibilityRole: 'button', accessibilityLabel: label,
      accessibilityState: { disabled }, disabled, onPress,
      style: { minHeight: 44, paddingVertical: 11, paddingHorizontal: 14, borderRadius: 8,
        backgroundColor: c.button, opacity: disabled ? 0.5 : 1, alignItems: 'center', justifyContent: 'center', ...extra },
    }, text(label, { color: c.accent, fontWeight: '700' }));
    const rows = searchRows(data.rows, query);
    const form = blockForm && live(blockForm.token) ? blockForm : null;
    const blocking = Boolean(form && pending.has(key(normalizeID(form.id), form.token)));
    const submitBlock = () => {
      if (!form || blocking) return;
      const work = form.mode === 'app' ? Promise.resolve(blockApp(form.id, form.name, form.token)) : block(form.id, form.token);
      void work.then(success => {
        if (success && live(form.token)) setBlockForm(current => current === form ? null : current);
      });
    };
    const header = h(RN.View, { style: { paddingBottom: 14 } },
      text('Blocked User List', { fontSize: 25, lineHeight: 32, fontWeight: '800' }),
      text('Manage blocked users and locally hidden APP/webhook messages.', { color: c.muted, marginTop: 6 }),
      data.appFilterError ? text(data.appFilterError, { color: c.muted, marginTop: 8 }) : null,
      h(RN.View, { style: { flexDirection: 'row', alignItems: 'center', marginVertical: 16 } },
        text(data.error ? 'List unavailable' : `${data.rows.length} blocked ${data.rows.length === 1 ? 'entry' : 'entries'}`, { flex: 1, fontWeight: '700' }),
        button('Refresh', () => { ensureAppFilter(); refreshAppMessages(); refresh(); })),
      h(RN.TextInput, {
        accessibilityLabel: 'Search blocked users by name, username or user ID', value: query, onChangeText: setQuery,
        placeholder: 'Search name, username or ID', placeholderTextColor: c.muted,
        autoCorrect: false, autoCapitalize: 'none', returnKeyType: 'search',
        style: { color: c.text, backgroundColor: c.card, borderColor: c.border, borderWidth: 1, borderRadius: 10, padding: 12, minHeight: 46 },
      }),
      h(RN.View, { style: { marginTop: 12 } },
        button('Block APP / Webhook ID', () => setBlockForm({ id: '', name: '', mode: 'app', token: data.token }), Boolean(data.error) || Boolean(form)),
        h(RN.View, { style: { marginTop: 8 } },
          button('Block User ID', () => setBlockForm({ id: '', mode: 'user', token: data.token }), Boolean(data.error) || Boolean(form))),
        form ? h(RN.View, { style: { backgroundColor: c.card, borderRadius: 10, padding: 12, marginTop: 10 } },
          text(form.mode === 'app' ? 'Block an APP or Tupperbox webhook' : 'Block someone by their user ID', { fontWeight: '700' }),
          text(form.mode === 'app'
            ? 'Copy User ID from the APP/proxy message and paste it here. This hides matching chat messages on this device while this plugin is enabled.'
            : 'Paste their copied Discord user ID below, then tap Block.', { color: c.muted, marginVertical: 8 }),
          h(RN.TextInput, {
            accessibilityLabel: 'User ID to block', value: form.id,
            onChangeText: id => {
              if (live(form.token) && !blocking) setBlockForm(current => current?.token === form.token ? { ...current, id } : current);
            },
            placeholder: 'Paste user ID here', placeholderTextColor: c.muted,
            autoCorrect: false, autoCapitalize: 'none', keyboardType: 'number-pad',
            editable: !blocking, maxLength: 64, returnKeyType: 'done', onSubmitEditing: submitBlock,
            style: { color: c.text, borderColor: c.border, borderWidth: 1, borderRadius: 8, padding: 12, minHeight: 46 },
          }),
          form.mode === 'app' ? h(RN.View, { style: { marginTop: 10 } },
            text('Optional: exact character name', { fontWeight: '700' }),
            text('Tupperbox characters can share an ID. Enter a name such as Allo to hide only that character. Leave blank to hide every message from this ID.', { color: c.muted, marginVertical: 8 }),
            h(RN.TextInput, {
              accessibilityLabel: 'Exact APP character name (optional)', value: form.name,
              onChangeText: name => {
                if (live(form.token)) setBlockForm(current => current?.token === form.token ? { ...current, name } : current);
              },
              placeholder: 'e.g. Allo', placeholderTextColor: c.muted, autoCorrect: false,
              autoCapitalize: 'none', maxLength: 128,
              style: { color: c.text, borderColor: c.border, borderWidth: 1, borderRadius: 8, padding: 12, minHeight: 46 },
            })) : null,
          h(RN.View, { style: { flexDirection: 'row', marginTop: 10 } },
            button('Cancel', () => setBlockForm(null), blocking, { flex: 1, marginRight: 10 }),
            button(blocking ? 'Blocking…' : 'Block', submitBlock, blocking || !form.id.trim(), { flex: 1 })),
        ) : null),
      query.trim() && !data.error ? text(`${rows.length} matching ${rows.length === 1 ? 'user' : 'users'}`, { color: c.muted, marginTop: 10 }) : null,
    );
    return h(RN.FlatList, {
      style: { flex: 1, backgroundColor: c.bg }, contentContainerStyle: { padding: 16, paddingBottom: 60 },
      data: rows, keyExtractor: row => row.localKey ?? row.id, extraData: `${revision}:${query}:${data.token.account}:${generation}`,
      keyboardShouldPersistTaps: 'handled', keyboardDismissMode: 'on-drag',
      initialNumToRender: 12, maxToRenderPerBatch: 12, windowSize: 7,
      ListHeaderComponent: header,
      ListEmptyComponent: text(data.error ?? (query.trim() ? 'No blocked users match your search.' : 'You have no blocked users.'), { color: c.muted, paddingVertical: 20 }),
      renderItem: ({ item: row }) => {
        const busy = pending.has(key(row.id, data.token));
        return h(RN.View, { style: { backgroundColor: c.card, borderRadius: 12, padding: 14, marginBottom: 12 } },
          h(Pressable, { accessibilityRole: 'button', accessibilityLabel: row.kind === 'app' ? `Local APP block ${row.name}` : `Open ${row.name}’s profile`,
            disabled: row.kind === 'app', onPress: () => { void openProfile(row.id, data.token); }, style: { flexDirection: 'row', alignItems: 'center', paddingBottom: 12 } },
            row.avatar ? h(RN.Image, { source: { uri: row.avatar }, style: { width: 46, height: 46, borderRadius: 23, marginRight: 12 } })
              : h(RN.View, { style: { width: 46, height: 46, borderRadius: 23, marginRight: 12, backgroundColor: c.button, alignItems: 'center', justifyContent: 'center' } },
                text(row.name === 'Unknown user' ? '?' : row.name.slice(0, 1).toUpperCase(), { fontSize: 22, fontWeight: '700' })),
            h(RN.View, { style: { flex: 1 } },
              text(row.name, { fontWeight: '700' }, { numberOfLines: 2 }),
              text(row.tag, { color: c.muted, fontSize: 13 }, { numberOfLines: 1 }),
              text(row.id, { color: c.muted, fontSize: 12 }, { selectable: true }))),
          h(RN.View, { style: { flexDirection: 'row' } },
            row.kind !== 'app' ? button('Profile', () => { void openProfile(row.id, data.token); }, false, { flex: 1, marginRight: 10 }) : null,
            button(busy ? 'Updating…' : 'Unblock', () => requestUnblock(row, data.token), busy, { flex: 1 })),
        );
      },
    });
  }

  function openSettings() {
    if (!active) return;
    try {
      const navigation = byProps('getRootNavigationRef')?.getRootNavigationRef?.();
      if (typeof navigation?.navigate !== 'function') throw new Error('Please open Blocked User List’s Configure button on the Plugins page.');
      navigation.navigate('BUNNY_CUSTOM_PAGE', { title: 'Blocked Users', render: Settings });
    } catch (error) { log(error); RN.Alert.alert('Blocked Users', error?.message ?? 'Could not open the list.'); }
  }

  return {
    onLoad() {
      if (active) return;
      active = true; generation++; emit();
      resolveStores(); ensureAppFilter(); refreshAppMessages();
      // Revenge exposes its native settings registry on bunny.ui.settings.
      // Extend the existing section without replacing Plugins, Themes or Account Switcher.
      try {
        removeShortcut = attachSettingsShortcut({
          api: host.bunny?.ui?.settings ?? host.window?.bunny?.ui?.settings,
          constants: byProps('SETTING_RENDERER_CONFIG'), Settings, open: openSettings,
          getAsset: name => V.ui?.assets?.getAssetIDByName?.(name),
          renderIcon: source => {
            const Icon = byProps('TableRowIcon')?.TableRowIcon;
            return Icon ? h(Icon, { source }) : h(RN.Image, { source, style: { width: 24, height: 24 } });
          },
          patcher: V.patcher, tree: byProps('getAncestors', 'isBlocked'), log,
        });
      } catch (error) { log(error); }
    },
    onUnload() {
      active = false; generation++; emit();
      optional(() => removeAppFilter?.()); removeAppFilter = undefined;
      appLists?.clear(); appLists = undefined;
      optional(() => messageStore?.emitChange?.()); messageStore = undefined; appFilterError = null;
      optional(() => removeShortcut?.()); removeShortcut = undefined;
      for (const dispose of [...subscriptions]) dispose();
      listeners.clear(); pending.clear();
      userStore = relationshipStore = themeStore = relationshipActions = blockActions = undefined;
    },
    settings: Settings,
    // Kept internal to the evaluated plugin object; Revenge only uses lifecycle/settings.
    controller: { snapshot, subscribe, openProfile, requestUnblock, unblock, block, blockApp, unblockApp, isPending: (id, value) => pending.has(key(id, value)) },
  };
}

return createPlugin(vendetta);
})()
}, "Blocked User List");
})()
); }, {"id": "dev.fluttershy2008.blocked-user-list", "legacyManifest": {"name": "Blocked User List", "description": "Manage blocked users and locally hide APP, bot and Tupperbox/webhook messages by ID, with optional exact character names.", "version": "1.3.3", "authors": [{"name": "fluttershy_simper"}], "main": "index.js", "vendetta": {"icon": "WrenchIcon"}, "hash": "70d7b93db46c53c7f4b2edd7d7f640c856ab03cdc4441ebb5e7bb545b9ebcd13"}, "repository": "https://fluttershy2008-mlp.github.io/lol/valenced/index.json", "host": "valenced", "version": "1.0.0-beta4"}), {"id": "dev.fluttershy2008.blocked-user-list", "title": "Blocked User List", "icon": "WrenchIcon"}) };
})()
