(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Valenced API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const hostId = 'valenced';
    const product = 'Valenced';
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the ' + product + ' plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const source = rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update ' + product + ' to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        const found = rawFind(...props);
        if (found) return found;
        if (props.some(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.valenced.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod(hostId + '.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from ' + product + '.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.[hostId + '.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createValencedPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createValencedPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}
return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
'use strict';
// Stealmoji Revenge adaptation, GPL-3.0. See LICENSE and NOTICE.
function createCore(env = globalThis) {
  const LIMIT = 256 * 1024;
  const idPattern = /^\d{17,20}$/;
  function name(value) {
    const clean = String(value || 'emoji').replace(/^:+|:+$/g, '').split('~')[0].replace(/[^A-Za-z0-9_]/g, '_').slice(0, 32);
    return clean.length >= 2 ? clean : 'emoji_' + clean;
  }
  const validName = value => /^[A-Za-z0-9_]{2,32}$/.test(value);
  function parse(value) {
    if (!value) return null;
    if (typeof value === 'string') {
      const text = value.trim();
      const mention = /^<(a?):([A-Za-z0-9_]+):(\d{17,20})>$/.exec(text);
      if (mention) return { id: mention[3], name: name(mention[2]), animated: mention[1] === 'a' };
      const url = /^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/emojis\/(\d{17,20})\.(png|gif|webp|jpe?g|avif)(?:[?#].*)?$/i.exec(text);
      if (url) return { id: url[1], name: 'emoji', animated: url[2].toLowerCase() === 'gif' || /[?&]animated=true(?:&|$)/i.test(text) };
      return idPattern.test(text) ? { id: text, name: 'emoji', animated: false } : null;
    }
    if (typeof value !== 'object') return null;
    const fromURL = typeof value.src === 'string' ? parse(value.src) : null;
    const id = String(value.id ?? fromURL?.id ?? '');
    if (!idPattern.test(id)) return null;
    return { id, name: name(value.name ?? value.alt), animated: Boolean(value.animated || fromURL?.animated) };
  }
  const url = (emoji, size = 128) => `https://cdn.discordapp.com/emojis/${emoji.id}.${emoji.animated ? 'gif' : 'png'}?size=${size}&quality=lossless`;
  function errorMessage(error) {
    const status = error?.status ?? error?.statusCode ?? error?.response?.status;
    const code = error?.body?.code;
    if (status === 429) return 'Discord is rate limiting emoji uploads. Wait before trying again.';
    if (status === 403 || code === 50013) return 'You no longer have permission to add emoji to this server.';
    if (code === 30008) return 'This server has no free slots for this emoji type.';
    if (status === 413) return 'The emoji is too large to upload.';
    return String(error?.body?.message ?? error?.message ?? 'The action failed. Please try again.').slice(0, 260);
  }
  function slots(guild, animated, emojiStore, slotModule) {
    try {
      const max = guild.getMaxEmojiSlots?.() ?? slotModule?.getMaxEmojiSlots?.(guild);
      const entry = emojiStore?.getGuilds?.()?.[guild.id];
      const raw = entry?.emojis ?? emojiStore?.getGuildEmoji?.(guild.id);
      if (!raw || !Number.isFinite(max) || max <= 0) return { full: false, used: null, max: null };
      const list = Array.isArray(raw) ? raw : Object.values(raw);
      const used = list.filter(e => e && !e.managed && Boolean(e.animated) === animated).length;
      return { used, max, full: used >= max };
    } catch { return { full: false, used: null, max: null }; }
  }
  function canCreate(guild, user, permissions, constants) {
    if (!guild?.id) return false;
    if (user?.id && (guild.ownerId === user.id || guild.owner_id === user.id)) return true;
    const P = constants?.Permissions ?? {};
    // Old builds used Manage Emojis; only use that alias if Create Expressions is absent.
    const create = P.CREATE_GUILD_EXPRESSIONS ?? P.MANAGE_GUILD_EXPRESSIONS ?? P.MANAGE_EMOJIS_AND_STICKERS;
    for (const permission of [create, P.ADMINISTRATOR]) {
      if (permission == null) continue;
      try { if (permissions?.can?.(permission, guild)) return true; } catch {}
    }
    return false;
  }
  async function imageData(emoji, isCurrent = () => true) {
    let oversized = false;
    for (const size of [128, 64, 32]) {
      if (!isCurrent()) throw new Error('Stealmoji was disabled.');
      const controller = env.AbortController ? new env.AbortController() : null;
      let reader, timer, expired = false;
      try {
        const operation = (async () => {
          const response = await env.fetch(url(emoji, size), controller ? { signal: controller.signal } : undefined);
          if (!response.ok) throw Object.assign(new Error(`Could not download emoji (HTTP ${response.status}).`), { status: response.status });
          const length = Number(response.headers?.get?.('content-length'));
          if (length > LIMIT) return null;
          const blob = await response.blob();
          if (expired || !isCurrent()) throw new Error('Download cancelled.');
          if (blob.size > LIMIT) return null;
          if (!blob.size) throw new Error('Discord returned an empty image.');
          if (blob.type && blob.type !== 'application/octet-stream' && !/^image\/(png|gif|webp|jpe?g|avif)(?:;|$)/i.test(blob.type)) throw new Error('Discord did not return an emoji image.');
          const data = await new Promise((resolve, reject) => {
            reader = new env.FileReader();
            const done = () => typeof reader.result === 'string' && reader.result.startsWith('data:')
              ? resolve(reader.result) : reject(new Error('Could not read emoji image.'));
            reader.onload = done;
            reader.onloadend = done;
            reader.onerror = () => reject(new Error('Could not read emoji image.'));
            reader.onabort = () => reject(new Error('Image download cancelled.'));
            reader.readAsDataURL(blob);
          });
          // Some RN builds label Blob data as application/octet-stream.
          const match = /^data:[^,]*;base64,([A-Za-z0-9+/=\r\n]+)$/.exec(data);
          if (!match) throw new Error('Could not encode the emoji image.');
          const payload = match[1].replace(/[\r\n]/g, '');
          const bytes = payload.length * 3 / 4 - (payload.endsWith('==') ? 2 : payload.endsWith('=') ? 1 : 0);
          if (bytes > LIMIT) return null;
          const mime = payload.startsWith('R0lGOD') ? 'image/gif' : payload.startsWith('iVBORw0KGgo') ? 'image/png'
            : payload.startsWith('/9j/') ? 'image/jpeg' : payload.startsWith('UklGR') ? 'image/webp' : null;
          if (!mime) throw new Error('Discord did not return a supported emoji image.');
          // Animated downloads must never silently become still images.
          if (emoji.animated && mime !== 'image/gif') throw new Error('Discord returned a still image for this animated emoji.');
          return `data:${mime};base64,${payload}`;
        })();
        const timeout = new Promise((_, reject) => {
          timer = env.setTimeout(() => {
            expired = true;
            try { controller?.abort(); reader?.abort(); } catch {}
            reject(new Error('Emoji download timed out. Please try again.'));
          }, 15000);
        });
        const data = await Promise.race([operation, timeout]);
        if (data) return data;
        oversized = true;
      } finally { env.clearTimeout(timer); }
    }
    throw new Error(oversized ? 'This emoji is still larger than 256 KiB at the smallest size.' : 'Could not download emoji.');
  }
  return { LIMIT, name, validName, parse, url, errorMessage, slots, canCreate, imageData };
}



function createPlugin(V, env = globalThis) {
  const { React, ReactNative: RN, constants } = V.metro.common;
  const h = React.createElement, core = createCore(env);
  const KEY = 'StealmojiPicker', ROW = 'stealmoji-actions';
  let active = false, generation = 0, pending = false, hooked = false, retryTimer, resume, pickerOpening;
  const unpatches = [], dialogs = new Set();
  const byProps = (...keys) => { try { return V.metro.findByProps(...keys); } catch {} };
  const byStore = key => { try { return V.metro.findByStoreName(key); } catch {} };
  const toast = message => { try { V.ui?.toasts?.showToast?.(message); } catch {} };
  const host = () => byProps('openLazy', 'hideActionSheet') ?? byProps('openLazy');
  const canCreate = guild => core.canCreate(guild, byStore('UserStore')?.getCurrentUser?.(), byStore('PermissionStore'), constants);
  const slots = (guild, emoji) => core.slots(guild, emoji.animated, byStore('EmojiStore'), byProps('getMaxEmojiSlots'));
  const currentGuild = id => byStore('GuildStore')?.getGuild?.(id) ?? byStore('GuildStore')?.getGuilds?.()?.[id];
  const safe = fn => () => { if (active) Promise.resolve().then(fn).catch(error => toast(core.errorMessage(error))); };
  function colors() {
    const dark = RN.Appearance?.getColorScheme?.() !== 'light';
    return { text: dark ? '#f2f3f5' : '#202127', muted: dark ? '#b5bac1' : '#50535c', input: dark ? '#25262c' : '#e5e7ec' };
  }
  function text(value, style = {}) { return h(RN.Text, { style: { color: colors().text, fontSize: 15, ...style } }, value); }
  function button(label, onPress, disabled = false, key = label) {
    return h(RN.Pressable ?? RN.TouchableOpacity, {
      key, onPress, disabled, accessibilityRole: 'button', accessibilityLabel: label,
      accessibilityState: { disabled },
      style: { padding: 12, marginTop: 8, borderRadius: 8, backgroundColor: disabled ? '#626775' : '#5865f2' },
    }, text(label, { color: '#fff', fontWeight: '600', textAlign: 'center' }));
  }
  function input(value, onChangeText, placeholder, extra = {}) {
    return h(RN.TextInput, { value, onChangeText, placeholder, autoCapitalize: 'none', autoCorrect: false,
      placeholderTextColor: colors().muted, accessibilityLabel: placeholder,
      style: { color: colors().text, backgroundColor: colors().input, padding: 12, marginTop: 8, borderRadius: 8 }, ...extra });
  }
  function knownEmoji(value) {
    const parsed = core.parse(value);
    if (!parsed) return null;
    try {
      const store = byStore('EmojiStore');
      const cached = store?.getCustomEmojiById?.(parsed.id) ?? store?.getEmojiById?.(parsed.id);
      if (cached) return { ...parsed, name: core.name(cached.name ?? parsed.name), animated: Boolean(parsed.animated || cached.animated) };
    } catch {}
    return parsed;
  }
  function resolveEmoji(...values) {
    for (const value of values) {
      for (const candidate of [value?.emojiNode, value?.emoji, value?.reaction?.emoji, value?.nativeEvent?.node]) {
        const emoji = knownEmoji(candidate);
        if (emoji) return emoji;
      }
    }
    return null;
  }
  function messageEmojis(...values) {
    const result = [], seen = new Set();
    for (const value of values) {
      const message = value?.message;
      if (!message) continue;
      const matches = String(message.content ?? '').match(/<a?:[A-Za-z0-9_]+:\d{17,20}>/g) ?? [];
      for (const match of [...matches, ...(message.reactions ?? []).map(r => r.emoji)]) {
        const emoji = knownEmoji(match);
        if (emoji && !seen.has(emoji.id)) { seen.add(emoji.id); result.push(emoji); }
        if (result.length >= 25) return result;
      }
    }
    return result;
  }
  async function copyURL(emoji) {
    const clipboard = V.metro.common.clipboard ?? byProps('setString', 'getString');
    if (!clipboard?.setString) throw new Error('Clipboard is unavailable on this Discord build.');
    await clipboard.setString(core.url(emoji));
    if (active) toast('Emoji link copied.');
  }
  async function saveImage(emoji) {
    const media = byProps('downloadMediaAsset');
    if (!media?.downloadMediaAsset) throw new Error('Saving is unavailable on this build. Use Copy emoji link.');
    const result = media.downloadMediaAsset(core.url(emoji, 256), emoji.animated ? 1 : 0);
    if (result?.then) { await result; if (active) toast('Emoji saved.'); }
    else toast('Save requested. Check Downloads or Photos.');
  }
  function viewImage(emoji) {
    const media = byProps('openMediaModal');
    if (!media?.openMediaModal) throw new Error('Image viewer is unavailable. Use Save image or Copy emoji link.');
    const uri = core.url(emoji, 256);
    host()?.hideActionSheet?.(KEY);
    media.openMediaModal({ initialSources: [{ uri, sourceURI: uri, width: 256, height: 256 }], initialIndex: 0,
      originLayout: { width: 100, height: 100, x: 0, y: 0, resizeMode: 'contain' } });
  }
  async function copyImage(emoji) {
    const clipboard = V.metro.common.clipboard;
    if (!clipboard?.setImage) throw new Error('Copy image is unavailable. Use Copy emoji link.');
    const session = generation;
    const data = await core.imageData(emoji, () => active && generation === session);
    if (!active || generation !== session) return;
    await clipboard.setImage(data.split(',')[1]);
    toast('Emoji image copied.');
  }
  async function upload(emoji, guildId, name) {
    if (!active) throw new Error('Enable Stealmoji before uploading.');
    if (pending) throw new Error('An emoji upload is already in progress.');
    if (!core.validName(name)) throw new Error('Use 2–32 letters, numbers, or underscores.');
    const guild = currentGuild(guildId);
    if (!guild || !canCreate(guild)) throw new Error('You need Create Expressions permission in this server.');
    if (slots(guild, emoji).full) throw new Error('This server has no free slots for this emoji type.');
    const actions = byProps('uploadEmoji');
    if (typeof actions?.uploadEmoji !== 'function') throw new Error('Discord’s emoji upload module is unavailable.');
    const session = generation;
    pending = true;
    try {
      const data = await core.imageData(emoji, () => active && generation === session);
      if (!active || generation !== session) throw new Error('Stealmoji was disabled before upload.');
      const latest = currentGuild(guildId);
      if (!latest || !canCreate(latest)) throw new Error('Your permission to upload has changed.');
      if (slots(latest, emoji).full) throw new Error('This server has no free slots for this emoji type.');
      // Exactly one write; never retry a POST with an uncertain result.
      await actions.uploadEmoji({ guildId, name, image: data, roles: undefined });
      return `${name} added to ${latest.name}.`;
    } finally { pending = false; }
  }
  function guildIcon(guild) {
    const style = { width: 44, height: 44, borderRadius: 14 };
    if (guild.icon) return h(RN.Image, { source: { uri: `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png?size=96` },
      resizeMode: 'cover', style, accessible: false });
    const initials = String(guild.name ?? '?').trim().split(/\s+/).map(word => word[0]).join('').slice(0, 3);
    return h(RN.View, { style: { ...style, backgroundColor: '#5865f2', alignItems: 'center', justifyContent: 'center' } },
      text(initials, { color: '#fff', fontWeight: '600' }));
  }
  function Picker({ emojis = [], close, settings = false, inSheet = false }) {
    const [emoji, setEmoji] = React.useState(emojis.length === 1 ? emojis[0] : null);
    const [source, setSource] = React.useState(''), [name, setName] = React.useState(emojis[0]?.name ?? 'emoji');
    const [guildId, setGuild] = React.useState(null), [search, setSearch] = React.useState('');
    const [error, setError] = React.useState(''), [busy, setBusy] = React.useState(false), [success, setSuccess] = React.useState('');
    const [toolsOpen, setToolsOpen] = React.useState(false);
    const [revision, refresh] = React.useState(0), mounted = React.useRef(true), lock = React.useRef(false);
    React.useEffect(() => {
      mounted.current = true;
      const cleanups = [];
      const changed = () => { if (mounted.current) refresh(n => n + 1); };
      for (const key of ['GuildStore', 'PermissionStore', 'EmojiStore']) {
        try { const store = byStore(key); store?.addChangeListener?.(changed); cleanups.push(() => store?.removeChangeListener?.(changed)); } catch {}
      }
      return () => { mounted.current = false; cleanups.forEach(fn => { try { fn(); } catch {} }); };
    }, []);
    const choose = next => { setEmoji(next); setName(next.name); setGuild(null); setToolsOpen(false); setSearch(''); setError(''); setSuccess(''); };
    const submit = async () => {
      if (lock.current) return;
      lock.current = true; setBusy(true); setError(''); setSuccess('');
      const session = generation;
      try {
        const message = await upload(emoji, guildId, name.trim());
        if (mounted.current && active && generation === session) { setSuccess(message); setGuild(null); toast(message); }
      } catch (e) { if (mounted.current && active && generation === session) setError(core.errorMessage(e)); }
      finally { lock.current = false; if (mounted.current) setBusy(false); }
    };
    if (emoji && !guildId && !toolsOpen) {
      const palette = colors();
      const guilds = Object.values(byStore('GuildStore')?.getGuilds?.() ?? {}).filter(canCreate)
        .filter(g => String(g.name ?? '').toLowerCase().includes(search.trim().toLowerCase()))
        .sort((a, b) => String(a.name).localeCompare(String(b.name)));
      // Use the sheet's gesture-aware list inside a sheet, and a normal list in settings/alerts.
      const List = (inSheet ? byProps('BottomSheetFlatList')?.BottomSheetFlatList
        ?? byProps('BottomSheetScrollView')?.BottomSheetFlatList : null) ?? RN.FlatList;
      const row = guild => {
        const capacity = slots(guild, emoji), disabled = capacity.full || busy;
        const select = () => {
          if (!active || busy || pending) return;
          const latest = currentGuild(guild.id);
          if (!latest || !canCreate(latest)) { setError('You no longer have permission to add emoji to this server.'); return; }
          if (slots(latest, emoji).full) { setError('This server has no slots available for this emoji type.'); return; }
          RN.Keyboard?.dismiss?.(); setGuild(guild.id); setError(''); setSuccess('');
        };
        return h(RN.Pressable ?? RN.TouchableOpacity, { key: guild.id, onPress: select, disabled,
          accessibilityRole: 'button', accessibilityLabel: guild.name,
          accessibilityHint: capacity.full ? 'No slots available' : 'Choose emoji name and add to this server',
          accessibilityState: { disabled }, style: { minHeight: 80, paddingHorizontal: 28, paddingVertical: 14,
            flexDirection: 'row', alignItems: 'center', opacity: disabled ? 0.4 : 1 } },
          guildIcon(guild), h(RN.View, { style: { flex: 1, marginLeft: 18, marginRight: 16 } },
            h(RN.Text, { numberOfLines: 2, style: { color: palette.text, fontSize: 17, fontWeight: '600' } }, guild.name),
            capacity.full ? text('No slots available', { color: palette.muted, fontSize: 13, marginTop: 3 }) : null),
          text('+', { color: palette.muted, fontSize: 30, fontWeight: '300' }));
      };
      const empty = h(RN.View, { style: { padding: 24 } }, text(search.trim() ? 'No servers match your search.'
        : 'No servers available. You need Create Expressions permission to add emoji.', { color: palette.muted }));
      const listProps = { style: { flex: 1, minHeight: 0 }, contentContainerStyle: { paddingBottom: 36 },
        keyboardShouldPersistTaps: 'handled', keyboardDismissMode: 'on-drag', nestedScrollEnabled: true,
        showsVerticalScrollIndicator: true };
      const list = List ? h(List, { ...listProps, data: guilds, keyExtractor: guild => guild.id,
        renderItem: ({ item }) => row(item), extraData: `${revision}:${emoji.id}:${emoji.animated}:${busy}`,
        initialNumToRender: 8, maxToRenderPerBatch: 8, windowSize: 5, ListEmptyComponent: empty })
        : h(RN.ScrollView, listProps, ...(guilds.length ? guilds.map(row) : [empty]));
      const link = (label, onPress) => h(RN.Pressable ?? RN.TouchableOpacity, { onPress, accessibilityRole: 'button',
        accessibilityLabel: label, style: { paddingVertical: 12, paddingHorizontal: 16 } },
        text(label, { color: palette.muted, fontSize: 14, fontWeight: '600' }));
      const height = Math.min(680, (RN.Dimensions?.get?.('window')?.height ?? 800) * 0.72);
      // The list owns scrolling. A surrounding ScrollView would compete with the sheet gesture.
      return h(RN.View, { style: settings ? { flex: 1, minHeight: 0 } : { height } },
        h(RN.View, { style: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 28, minHeight: 72 } },
          h(RN.Image, { source: { uri: core.url(emoji) }, resizeMode: 'contain', accessible: false, style: { width: 30, height: 30 } }),
          h(RN.Text, { numberOfLines: 1, style: { flex: 1, color: palette.text, fontSize: 20, fontWeight: '700',
            textAlign: 'center', marginHorizontal: 12 } }, `Stealing ${emoji.name}`),
          close ? h(RN.Pressable ?? RN.TouchableOpacity, { onPress: close, accessibilityRole: 'button', accessibilityLabel: 'Close',
            hitSlop: 8, style: { width: 36, height: 44, justifyContent: 'center', alignItems: 'center' } },
            text('×', { fontSize: 32, lineHeight: 36 })) : h(RN.View, { style: { width: 30 } })),
        h(RN.View, { style: { paddingHorizontal: 24, paddingBottom: 10 } }, input(search, setSearch, 'Search servers'),
          success ? text(success, { marginTop: 8 }) : null,
          error ? text(error, { color: '#e66b70', marginTop: 8 }) : null),
        list,
        h(RN.View, { style: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 12, paddingBottom: 12 } },
          link('Emoji tools', () => { setToolsOpen(true); setError(''); }),
          link('Use another emoji', () => { setEmoji(null); setSearch(''); setError(''); })));
    }
    const content = [text('Stealmoji', { fontSize: 22, fontWeight: '700' })];
    if (close) content.push(button('Close', close, busy));
    if (settings) content.push(text(hooked ? 'Emoji menu hook connected.' : 'Menu hook unavailable. Paste an emoji below.', { color: colors().muted, marginTop: 8 }));
    if (success) content.push(text(success, { marginTop: 12 }));
    if (!emoji) {
      content.push(text('Paste a custom emoji, Discord emoji link, or emoji ID.', { marginTop: 12 }));
      content.push(input(source, setSource, '<:emoji:123456789012345678>'));
      content.push(button('Use emoji', () => {
        const next = knownEmoji(source);
        if (!next) { setError('Enter a custom Discord emoji, emoji CDN link, or 17–20 digit emoji ID.'); return; }
        choose(next);
      }));
      emojis.forEach(item => content.push(button((item.animated ? 'GIF · ' : '') + item.name, () => choose(item), false, item.id)));
    } else {
      content.push(h(RN.Image, { key: 'preview', source: { uri: core.url(emoji) }, resizeMode: 'contain',
        accessibilityLabel: 'Emoji preview', style: { height: 100, width: '100%', marginTop: 16 } }));
      content.push(text(emoji.name, { textAlign: 'center', marginTop: 6 }));
      if (!guildId) {
        content.push(button('View emoji', safe(() => viewImage(emoji)), busy));
        content.push(button('Copy emoji link', safe(() => copyURL(emoji)), busy));
        content.push(button('Save ' + (emoji.animated ? 'GIF' : 'image'), safe(() => saveImage(emoji)), busy));
        if (RN.Platform?.OS === 'ios' && !emoji.animated) content.push(button('Copy image', safe(() => copyImage(emoji)), busy));
        content.push(h(RN.View, { key: 'animated', style: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12 } },
          text('Animated emoji (GIF)'), h(RN.Switch, { value: emoji.animated, disabled: busy, accessibilityLabel: 'Animated emoji',
            onValueChange: value => setEmoji({ ...emoji, animated: value }) })));
        content.push(button('Browse servers', () => { setToolsOpen(false); setError(''); }, busy));
        content.push(button('Use another emoji', () => { setEmoji(null); setError(''); }, busy));
      } else {
        content.push(text('Server: ' + (currentGuild(guildId)?.name ?? 'Unavailable'), { fontWeight: '600', marginTop: 12 }));
        content.push(input(name, setName, 'Emoji name', { maxLength: 32, editable: !busy }));
        content.push(text('Use 2–32 letters, numbers, or underscores.', { color: colors().muted, marginTop: 6 }));
        content.push(button(busy ? 'Uploading…' : 'Add emoji', submit, busy || !core.validName(name.trim())));
        content.push(button('Choose another server', () => setGuild(null), busy));
      }
    }
    if (error) content.push(text(error, { color: '#e66b70', marginTop: 12 }));
    return h(RN.ScrollView, { keyboardShouldPersistTaps: 'handled',
      style: settings ? { flex: 1 } : { maxHeight: (RN.Dimensions?.get?.('window')?.height ?? 800) * 0.66 },
      contentContainerStyle: { padding: 20, paddingBottom: 40 } }, ...content);
  }
  function guarded(element) {
    const Boundary = V.ui?.components?.ErrorBoundary;
    return Boundary ? h(Boundary, null, element) : element;
  }
  function openPicker(emojis, fromKey) {
    if (!active || pickerOpening) return;
    const opening = { session: generation };
    pickerOpening = opening;
    const release = () => { if (pickerOpening === opening) pickerOpening = undefined; };
    const live = () => active && generation === opening.session && pickerOpening === opening;
    function Content(props) {
      React.useEffect(() => release, []);
      return live() ? h(Picker, props) : null;
    }
    try {
      const sheetHost = host();
      let Sheet = byProps('ActionSheet')?.ActionSheet;
      if (!Sheet) { try { Sheet = V.metro.find(m => m?.render?.name === 'ActionSheet'); } catch {} }
      if (sheetHost?.openLazy && Sheet) {
        const close = () => { if (!live()) return; try { sheetHost.hideActionSheet?.(KEY); } finally { release(); } };
        const component = () => live() ? guarded(h(Sheet, { scrollable: true }, h(Content, { emojis, close, inSheet: true }))) : null;
        sheetHost.hideActionSheet?.(fromKey);
        sheetHost.openLazy(Promise.resolve({ default: component }), KEY, {});
        return;
      }
      const manager = byProps('openAlert', 'dismissAlert'), alerts = byProps('AlertModal', 'AlertActions');
      if (manager?.openAlert && alerts?.AlertModal) {
        const close = () => { if (!live()) return; try { manager.dismissAlert(KEY); } finally { dialogs.delete(KEY); release(); } };
        dialogs.add(KEY);
        manager.openAlert(KEY, guarded(h(alerts.AlertModal, { title: 'Emoji tools', content: h(Content, { emojis, close }) })));
        return;
      }
      release();
      toast('Open Stealmoji’s plugin settings to paste and add this emoji.');
    } catch (error) { release(); throw error; }
  }
  function action(emojis, key) {
    const Row = byProps('ActionSheetRow')?.ActionSheetRow;
    if (Row) return h(Row, { key: ROW, label: 'Stealmoji · Add / save emoji', onPress: safe(() => openPicker(emojis, key)) });
    return h(RN.View, { key: ROW, style: { paddingHorizontal: 16, paddingBottom: 8 } },
      button('Stealmoji · Add / save emoji', safe(() => openPicker(emojis, key))));
  }
  // Clone arrays/elements. Discord development builds freeze React elements.
  function inject(tree, emojis, key, allowContainer) {
    let best, score = -1, duplicate = false, visited = 0;
    const isAction = node => node?.props && (typeof node.props.onPress === 'function')
      && (node.props.label != null || node.props.text != null || node.props.accessibilityRole === 'button');
    function scan(node, depth = 0) {
      if (!node || depth > 24 || ++visited > 1000) return;
      if (Array.isArray(node)) {
        const count = node.filter(isAction).length;
        if (count && count + 100 > score) { best = node; score = count + 100; }
        node.forEach(item => scan(item, depth + 1));
      } else if (node.props) {
        if (node.key === ROW) duplicate = true;
        if (allowContainer && Array.isArray(node.props.children) && (node.type === RN.View || node.type === RN.ScrollView) && depth > score) {
          best = node.props.children; score = depth;
        }
        scan(node.props.children, depth + 1);
      }
    }
    scan(tree);
    if (duplicate) return { tree, done: true };
    if (!best) return { tree, done: false };
    let replacements = 0;
    function replace(node, depth = 0) {
      if (!node || depth > 24 || ++replacements > 1000) return node;
      if (node === best) return [...best, action(emojis, key)];
      if (Array.isArray(node)) {
        const children = node.map(item => replace(item, depth + 1));
        return children.some((child, i) => child !== node[i]) ? children : node;
      }
      if (node.props?.children != null) {
        const children = replace(node.props.children, depth + 1);
        return children === node.props.children ? node : React.cloneElement(node, { children });
      }
      return node;
    }
    return { tree: replace(tree), done: true };
  }
  function wrapSheet(component, context, key, session) {
    const caches = Array.from({ length: 6 }, () => new WeakMap());
    const nativeTypes = new Set([RN.View, RN.ScrollView, RN.Text, RN.Image, RN.Pressable,
      RN.TouchableOpacity, RN.TextInput, RN.FlatList, RN.Switch]);
    let visited = 0;
    let openingEmoji = resolveEmoji(context), openingEmojis = messageEmojis(context);
    const live = () => active && generation === session;
    function walk(node, props, level, depth = 0) {
      if (!node || depth > 24 || ++visited > 1000) return node;
      if (Array.isArray(node)) return node.map(child => walk(child, props, level, depth + 1));
      if (!node.props) return node;
      const next = { ...node.props };
      if (key === 'MessageReactions' && Array.isArray(next.tabs)) {
        next.tabs = next.tabs.map((tab, i) => {
          const emoji = resolveEmoji(tab?.props);
          if (!emoji) return tab;
          return h(RN.Pressable ?? RN.TouchableOpacity, { key: tab.key ?? String(i),
            onPress: () => next.onSelect?.(tab.props.index ?? i),
            onLongPress: safe(() => openPicker([emoji], key)), delayLongPress: 350,
            accessibilityRole: 'button', accessibilityLabel: 'Emoji ' + emoji.name }, tab);
        });
      }
      for (const field of ['children', 'header']) if (next[field] != null) next[field] = walk(next[field], props, level, depth + 1);
      if (level < 5 && !nativeTypes.has(node.type)) {
        const wrapped = wrap(node.type, level + 1);
        if (wrapped !== node.type) return h(wrapped, { ...next, key: node.key, ...(node.ref != null ? { ref: node.ref } : {}) });
      }
      return React.cloneElement(node, next);
    }
    function transform(props, tree, level) {
      if (!live()) return tree;
      try {
        const direct = resolveEmoji(props, context);
        if (direct) openingEmoji = direct;
        const messages = key === 'MessageLongPressActionSheet' ? messageEmojis(props, context) : [];
        if (messages.length) openingEmojis = messages;
        const emojis = openingEmoji ? [openingEmoji] : key === 'MessageLongPressActionSheet' ? openingEmojis : [];
        // Plain text menus need no Stealmoji component wrappers or tree edits.
        if (key === 'MessageLongPressActionSheet' && !emojis.length && (props?.message || context?.message)) return tree;
        if (emojis.length) {
          const changed = inject(tree, emojis, key, key !== 'MessageLongPressActionSheet');
          if (changed.done) return changed.tree;
        }
        visited = 0;
        return walk(tree, props, level);
      } catch { return tree; }
    }
    function wrap(original, level = 0) {
      if ((!original || !['function', 'object'].includes(typeof original)) || level > 5) return original;
      const cache = caches[level];
      if (cache.has(original)) return cache.get(original);
      let wrapped = original;
      if (typeof original === 'function' && !original.prototype?.isReactComponent) {
        wrapped = function StealmojiSheet(...args) { return transform(args[0], original.apply(this, args), level); };
      } else if (original.$$typeof === Symbol.for('react.memo')) {
        wrapped = React.memo(wrap(original.type, level), original.compare);
      } else if (original.$$typeof === Symbol.for('react.forward_ref')) {
        wrapped = React.forwardRef((props, ref) => transform(props, original.render(props, ref), level));
      }
      cache.set(original, wrapped);
      return wrapped;
    }
    return wrap(component);
  }
  function connect() {
    if (!active || hooked) return;
    try {
      const sheetHost = host();
      if (typeof sheetHost?.openLazy !== 'function') return;
      const unpatch = V.patcher.before('openLazy', sheetHost, args => {
        const [lazy, key, context] = args;
        if (!active || !['MessageEmojiActionSheet', 'MessageReactions', 'MessageLongPressActionSheet'].includes(key) || !lazy?.then) return;
        if (key === 'MessageLongPressActionSheet' && context?.message && !resolveEmoji(context) && !messageEmojis(context).length) return;
        const session = generation;
        args[0] = Promise.resolve(lazy).then(module => {
          if (!active || session !== generation || !module?.default) return module;
          try { return { ...module, default: wrapSheet(module.default, context, key, session) }; }
          catch { return module; }
        });
      });
      if (typeof unpatch === 'function') { unpatches.push(unpatch); hooked = true; }
    } catch {}
  }
  function onLoad() {
    if (active) return;
    active = true; generation++;
    connect();
    let tries = 0;
    const retry = () => {
      retryTimer = undefined;
      if (!active || hooked) return;
      connect();
      if (!hooked && ++tries < 30) retryTimer = env.setTimeout(retry, 2000);
    };
    if (!hooked) retryTimer = env.setTimeout(retry, 2000);
    try { resume = RN.AppState?.addEventListener?.('change', state => { if (state === 'active') connect(); }); } catch {}
  }
  function onUnload() {
    active = false; generation++; hooked = false; pickerOpening = undefined;
    env.clearTimeout(retryTimer);
    try { resume?.remove?.(); } catch {}
    resume = undefined;
    for (const unpatch of unpatches.splice(0).reverse()) { try { unpatch(); } catch {} }
    try { host()?.hideActionSheet?.(KEY); } catch {}
    const manager = byProps('openAlert', 'dismissAlert');
    for (const key of dialogs) { try { manager?.dismissAlert?.(key); } catch {} }
    dialogs.clear();
  }
  function settings() { return guarded(h(Picker, { settings: true })); }
  return { onLoad, onUnload, settings };
}

return createPlugin(vendetta);
})()
}, "Stealmoji");
})()
); }, {"id": "dev.fluttershy2008.stealmoji", "legacyManifest": {"name": "Stealmoji", "description": "Add static or animated emoji with a scrolling server picker, server icons, search, and save/copy tools.", "version": "2.1.3", "authors": [{"name": "Fiery", "id": "890228870559698955"}, {"name": "pylix", "id": "492949202121261067"}, {"name": "aliernfrog", "id": "459370047652102154"}, {"name": "fluttershy_simper", "id": "753962426407452713"}], "main": "index.js", "vendetta": {"icon": "ic_emoji_24px"}, "hash": "9ab88cc5d1c999e05c003211adce2706d8f01c4c91edef06847ab9dcfd35dff4"}, "repository": "https://fluttershy2008-mlp.github.io/lol/valenced/index.json", "host": "valenced"}) };
})()
