(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Valenced API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const hostId = 'valenced';
    const product = 'Valenced';
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the ' + product + ' plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const pathFinders = safe(() => U.discord.utils.modules.finders);
        const source = safe(() => pathFinders.lookupModuleWithImportedPath('../discord_common/js/packages/http-utils/HTTPUtils.tsx')[0])
            ?? rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update ' + product + ' to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        if (props.length && props.every(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL', 'HTTP'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        const found = rawFind(...props);
        if (found) return found;
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.valenced.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    const importedPaths = safe(() => U.discord.utils.modules.finders);
    if (importedPaths?.getModuleWithImportedPath) {
        metro.findByImportedPath = path => safe(() => importedPaths.lookupModuleWithImportedPath(path)[0]);
        metro.getModuleWithImportedPath = (path, callback) => own(importedPaths.getModuleWithImportedPath(path,
            (module, id) => { if (active) callback(module, id); }));
    }
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod(hostId + '.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from ' + product + '.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.[hostId + '.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        // The external plugin receives a scoped API, not a global "valenced".
        // Expose the runtime lookup only for More Alts and only while loaded.
        host: { id: 'valenced',
            getQrRuntimeClient: metadata.id === 'dev.fluttershy2008.more-alts'
                ? () => active ? U : undefined : undefined },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage, version: metadata.version },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createValencedPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


// SPDX-License-Identifier: MIT
'use strict';

// Add a native Valenced overview row while retaining the plugin-manager settings
// entry. Included only in the four packages configured for these shortcuts.
function withValencedSettingsShortcut(options, config) {
    let current;
    function dispose(session) {
        if (!session?.active) return;
        session.active = false;
        if (current === session) current = undefined;
        for (const notify of [...session.listeners]) {
            try { notify(); } catch (error) { session.warn(error); }
        }
        for (const remove of session.disposers.splice(0).reverse()) {
            try { remove(); } catch (error) { session.warn(error); }
        }
        session.refresh?.();
    }
    return {
        ...options,
        async start(api) {
            if (current?.active) return;
            const session = { active: true, registered: false, listeners: new Set(), disposers: [],
                warn: error => api.logger?.warn?.('Could not add ' + config.title + ' to Valenced settings.', error?.message ?? String(error)),
                refresh: undefined };
            current = session;
            const live = () => session.active && current === session;
            api.cleanup(() => dispose(session));
            try { await options.start?.call(this, api); }
            catch (error) { dispose(session); throw error; }
            if (!live()) return;
            const U = api.unscoped, { React, ReactNative: RN } = U.react;
            const settings = U.discord.modules?.settings;
            if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem || !settings.addSettingsItemToSection) {
                session.warn('Native settings registration is unavailable; use the plugin settings button.');
                return;
            }
            session.refresh = () => { try { settings.refreshSettings?.(); } catch (error) { session.warn(error); } };
            const subscribe = listener => { session.listeners.add(listener); return () => session.listeners.delete(listener); };
            function SettingsPage({ navigation } = {}) {
                const enabled = React.useSyncExternalStore(subscribe, live, live);
                React.useLayoutEffect(() => { navigation?.setOptions?.({ title: config.title }); }, [navigation]);
                return enabled ? React.createElement(options.SettingsComponent, { api })
                    : React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen ' + config.title + ' from Valenced settings.');
            }
            function Icon(props) {
                let id;
                try { id = U.assets.getAssetIdByName(config.icon) ?? U.assets.getAssetIdByName('PuzzlePieceIcon'); } catch {}
                if (id == null) return null;
                return U.components?.TableRowAssetIcon
                    ? React.createElement(U.components.TableRowAssetIcon, { ...props, id })
                    : React.createElement(RN.Image, { source: id, style: { width: 24, height: 24 } });
            }
            const key = config.id + '.valenced-settings';
            const register = () => {
                if (!live() || session.registered) return;
                const added = [];
                try {
                    added.push(settings.registerSettingsItem(key, {
                        type: 'route', parent: null, IconComponent: Icon,
                        useTitle: () => config.title, usePredicate: live,
                        screen: { route: key, getComponent: () => SettingsPage },
                    }));
                    // Publish the renderer before making its row visible.
                    if (live()) added.push(settings.addSettingsItemToSection('VALENCED', key));
                    if (!live()) {
                        for (const remove of added.reverse()) remove?.();
                        return;
                    }
                    session.disposers.push(...added);
                    session.registered = true;
                    session.refresh();
                } catch (error) {
                    for (const remove of added.reverse()) { try { remove?.(); } catch {} }
                    session.warn(error);
                }
            };
            // The core settings callback installs the VALENCED section. Register
            // after those callbacks finish, including on the first settings open.
            try {
                const unsubscribe = settings.onSettingsModulesLoaded(() => { Promise.resolve().then(register); });
                if (typeof unsubscribe === 'function') {
                    if (live()) session.disposers.push(unsubscribe);
                    else unsubscribe();
                }
            } catch (error) { session.warn(error); }
        },
        stop(...args) {
            dispose(current);
            return options.stop?.apply(this, args);
        },
    };
}


return { default: withValencedSettingsShortcut(createValencedPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}

return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
'use strict';
const MAIN_PROTECTED_IDS = Object.freeze([
  '823397989954879529',
  '1443574040592777219',
  '1437681030118117469',
  '1515184549078892735',
  '408704573105242115',
  '1411131801455562833',
  '1369338076178026596',
  '370605707965235200',
  '1269103620113039360',
  '1372652863565598861',
  '1469657701662461976',
  '1289988589052104846',
  '1362790366062968983',
  '1410342112079122494',
  '1376842062007111750',
  '1395928282506989690',
  '315664691877642250',
  '87583189161226240',
  '1245213637547659264',
  '1318645442283573298',
  '1134697592723349556',
  '1028183830034661376',
]);

const mainProtected = new Set(MAIN_PROTECTED_IDS);
const isMainProtected = id => mainProtected.has(id);
const withMainProtection = ids => [...new Set([...MAIN_PROTECTED_IDS, ...ids])];


const validID = value => typeof value === 'string' && /^[1-9]\d{16,19}$/.test(value);

function parseIDs(text) {
  if (typeof text !== 'string') throw new Error('Protected IDs must be text.');
  const tokens = text.trim() ? text.trim().split(/[\s,;]+/) : [];
  const invalid = tokens.filter(id => !validID(id));
  if (invalid.length) throw new Error(`Invalid server ID: ${invalid[0]}. Paste full server IDs, separated by spaces, commas or new lines.`);
  return [...new Set(tokens)];
}

function guildRows(store) {
  if (typeof store?.getGuilds !== 'function') throw new Error('Your server list is not ready. Tap Refresh.');
  const raw = store.getGuilds();
  if (!raw || typeof raw !== 'object') throw new Error('Your server list is still loading.');
  const entries = raw instanceof Map ? [...raw.entries()] : Object.entries(raw);
  const rows = entries.map(([key, guild]) => {
    const id = guild?.id ?? key;
    if (!validID(id) || !guild || typeof guild !== 'object') throw new Error('Discord returned an incomplete server list. Tap Refresh.');
    return { id, name: String(guild.name || id), owner: guild.ownerId ?? guild.owner_id,
      unavailable: guild.unavailable === true };
  });
  return [...new Map(rows.map(row => [row.id, row])).values()]
    .sort((a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id));
}

function keepReason(row, account, protectedIDs) {
  if (isMainProtected(row.id)) return 'Main protected';
  if (protectedIDs.has(row.id)) return 'Protected';
  if (row.owner === account) return 'You own this server';
  if (row.unavailable) return 'Server unavailable';
  if (!validID(row.owner)) return 'Ownership unavailable';
  return null;
}

function makePlan(rows, account, text) {
  if (!validID(account)) throw new Error('Your Discord account is still loading.');
  const entered = parseIDs(text), ids = withMainProtection(entered), protectedIDs = new Set(ids);
  const joined = new Set(rows.map(row => row.id));
  const missing = entered.filter(id => !isMainProtected(id) && !joined.has(id));
  // A mistyped but well-formed ID must never silently leave the intended server.
  if (missing.length) throw new Error(`Protected ID ${missing[0]} is not in your server list. Check the ID or remove it before continuing.`);
  const kept = [], targets = [];
  for (const row of rows) {
    const reason = keepReason(row, account, protectedIDs);
    if (reason) kept.push({ ...row, reason }); else targets.push({ ...row });
  }
  return { account, ids, targets, kept };
}

function samePlan(a, b) {
  const signature = plan => JSON.stringify([plan.account, [...plan.ids].sort(),
    plan.targets.map(row => row.id).sort(), plan.kept.map(row => [row.id, row.reason]).sort()]);
  return signature(a) === signature(b);
}

// Requests are serial. Any uncertain result stops the queue; no automatic retries.
async function runQueue({ plan, alive, getRows, getIDs, leave, wait, update }) {
  const result = { left: [], skipped: [], failed: [], stopped: null };
  const publish = () => update({ ...result, left: [...result.left], skipped: [...result.skipped], failed: [...result.failed] });
  for (const original of plan.targets) {
    if (!alive()) { result.stopped = 'Stopped. No more leave requests will be sent.'; break; }
    let row;
    try {
      row = getRows().find(item => item.id === original.id);
      // Retain all IDs protected at confirmation even if saved settings later change.
      const ids = new Set([...plan.ids, ...parseIDs(getIDs())]);
      if (!row || keepReason(row, plan.account, ids)) {
        result.skipped.push(original); publish(); continue;
      }
    } catch (error) { result.stopped = error.message; break; }
    // Recheck immediately before dispatch, after consulting live stores/settings.
    if (!alive()) { result.stopped = 'Stopped. No more leave requests will be sent.'; break; }
    try {
      const response = await leave(row.id);
      const status = Number(response?.status ?? response?.statusCode);
      if (status !== 204) throw new Error(`Leave was not confirmed (HTTP ${Number.isFinite(status) ? status : 'unknown'}). Refresh your server list before trying again.`);
      result.left.push(original);
    } catch (error) {
      result.failed.push({ ...original, error: error?.message ?? 'Leave failed.' });
      result.stopped = 'Stopped after an error. Refresh before trying again.';
      publish(); break;
    }
    publish();
    if (!alive()) { result.stopped = 'Stopped. No more leave requests will be sent.'; break; }
    await wait();
  }
  publish();
  return result;
}

const SHORTCUT_KEY = 'FLUTTERSHY_SERVER_LEAVER';
const SETTINGS_CONFIG = 'SETTING_RENDERER_CONFIG';
const SHORTCUT_LAYER = Symbol.for('server-leaver.settings-layer.v1');

// Settings screens can retain an old list of row keys after a plugin is disabled.
// A hidden renderer keeps those keys valid until Discord recreates the screen.
function hiddenShortcut() {
  return { type: 'pressable', parent: null, title: () => 'Server Leaver',
    useTitle: () => 'Server Leaver', usePredicate: () => false, onPress: () => {}, withArrow: true };
}

function publishRenderer(constants, layer) {
  if (constants[SETTINGS_CONFIG]?.[SHORTCUT_KEY] === layer.record) return true;
  const descriptor = Object.getOwnPropertyDescriptor(constants, SETTINGS_CONFIG);
  if (!descriptor || descriptor.configurable === false) return false;

  let fallback = descriptor.value, hasAssignment = false;
  const readBase = () => descriptor.get && !hasAssignment ? descriptor.get.call(constants) : fallback;
  Object.defineProperty(constants, SETTINGS_CONFIG, {
    configurable: true, enumerable: descriptor.enumerable,
    get: () => ({ ...readBase(), [SHORTCUT_KEY]: layer.record }),
    set(value) {
      if (descriptor.set) descriptor.set.call(constants, value);
      else { fallback = value; hasAssignment = true; }
    },
  });
  return constants[SETTINGS_CONFIG]?.[SHORTCUT_KEY] === layer.record;
}

function attachSettingsShortcut({ api, constants, Settings, open, useTrailing, getAsset, renderIcon,
  patcher, tree, log = () => {} }) {
  const sections = api?.registeredSections;
  const rows = sections && Object.values(sections).find(items => Array.isArray(items)
    && items.some(row => row?.key === 'BUNNY_PLUGINS'));
  if (!rows || !constants) {
    log('Server Leaver shortcut is unavailable; the plugin settings page is still accessible.');
    return () => {};
  }

  let enabled = true, removeGuard, layer, row;
  let icon;
  for (const name of ['ic_leave', 'WrenchIcon']) {
    try { icon = getAsset?.(name); if (icon != null) break; } catch {}
  }
  const record = { type: 'pressable', parent: null, title: () => 'Server Leaver',
    useTitle: () => 'Server Leaver', usePredicate: () => enabled,
    icon, useTrailing, IconComponent: icon != null && renderIcon ? () => renderIcon(icon) : undefined,
    onPress: () => { if (enabled) open(); }, withArrow: true };

  try {
    layer = constants[SHORTCUT_LAYER];
    if (!layer) {
      layer = { record };
      Object.defineProperty(constants, SHORTCUT_LAYER, { value: layer, configurable: true });
    } else layer.record = record;
    // Define the native renderer before exposing its key to the settings list.
    if (!publishRenderer(constants, layer)) throw new Error('Native settings renderer cannot be extended.');
    if (typeof patcher?.before === 'function' && typeof tree?.getAncestors === 'function') {
      removeGuard = patcher.before('getAncestors', tree, args => {
        if (enabled && args[0] === SHORTCUT_KEY) {
          try { publishRenderer(constants, layer); } catch (error) { log(error); }
        }
      });
    }
    row = { key: SHORTCUT_KEY, title: record.title, icon, usePredicate: record.usePredicate,
      useTrailing, rawTabsConfig: record, onPress: record.onPress, render: async () => ({ default: Settings }) };
    const previous = rows.findIndex(item => item?.key === SHORTCUT_KEY);
    if (previous >= 0) rows.splice(previous, 1);
    const blocked = rows.findIndex(item => item?.key === 'FLUTTERSHY_FRIENDS_LIST');
    const anchor = blocked >= 0 ? blocked : rows.findIndex(item => item?.key === 'BUNNY_PLUGINS');
    rows.splice(anchor + 1, 0, row);
  } catch (error) {
    enabled = false;
    if (layer?.record === record) layer.record = hiddenShortcut();
    try { removeGuard?.(); } catch {}
    log(error);
    return () => {};
  }

  let disposed = false;
  return () => {
    if (disposed) return;
    disposed = true; enabled = false;
    if (layer.record === record) layer.record = hiddenShortcut();
    for (const items of new Set([rows, ...Object.values(sections)])) {
      if (!Array.isArray(items)) continue;
      const index = items.indexOf(row);
      if (index >= 0) { try { items.splice(index, 1); } catch {} }
    }
    try { removeGuard?.(); } catch (error) { log(error); }
  };
}



function createPlugin(V, host = globalThis) {
  const { React, ReactNative: RN } = V.metro.common;
  const h = React.createElement, storage = V.plugin.storage;
  const safe = fn => { try { return fn(); } catch { return undefined; } };
  const byProps = (...keys) => safe(() => V.metro.findByProps(...keys));
  const byStore = name => safe(() => V.metro.findByStoreName?.(name));
  const log = error => safe(() => V.logger?.error?.('Server Leaver', error));
  const listeners = new Set();
  const removeStoreListeners = [];
  let active = false, epoch = 0, job = null, report = null, disposeShortcut, appSubscription, removeAccountListener;
  let guildStore, userStore, themeStore;
  function resolve() {
    guildStore = byStore('GuildStore') ?? byProps('getGuilds', 'getGuild');
    userStore = byStore('UserStore') ?? byProps('getCurrentUser', 'getUser');
    themeStore = byStore('ThemeStore');
  }
  function account() { resolve(); return safe(() => userStore?.getCurrentUser?.()?.id); }
  function idsFor(id) {
    if (!validID(id)) return '';
    const value = storage.accounts?.[id];
    if (value == null) return MAIN_PROTECTED_IDS.join('\n');
    if (!Array.isArray(value) || value.some(item => !validID(item))) throw new Error('Protected IDs could not be loaded. Save them again before continuing.');
    return withMainProtection(value).join('\n');
  }
  function save(id, text) {
    if (!active || account() !== id) throw new Error('Your account changed. Reopen this page.');
    if (job) throw new Error('Stop the current leave operation before changing protected IDs.');
    const ids = withMainProtection(parseIDs(text));
    storage.accounts = { ...(storage.accounts ?? {}), [id]: ids };
    emit(); return ids.join('\n');
  }
  function emit() { for (const listener of listeners) safe(listener); }
  function freshPlan(id) {
    if (!active || !validID(id) || account() !== id) throw new Error('Your account changed or the plugin was disabled. Reopen this page.');
    return makePlan(guildRows(guildStore), id, idsFor(id));
  }
  function stop() { if (job) { job.cancelled = true; emit(); } }
  function http() {
    const wrapper = byProps('HTTP');
    const api = wrapper?.HTTP ?? V.metro.common.RestAPI ?? V.metro.common.restAPI ?? byProps('get', 'post', 'del');
    if (typeof api?.del !== 'function') throw new Error('Discord’s leave request API is unavailable on this version.');
    return api;
  }
  async function execute(plan, confirmedEpoch) {
    if (job) throw new Error('A leave operation is already running.');
    if (confirmedEpoch !== epoch || !samePlan(plan, freshPlan(plan.account))) throw new Error('Your server list or protected IDs changed. Preview again before leaving.');
    const api = http();
    const token = { account: plan.account, epoch, cancelled: false };
    job = token; report = null; emit();
    const alive = () => active && job === token && !token.cancelled && epoch === token.epoch
      && account() === token.account && (RN.AppState?.currentState == null || RN.AppState.currentState === 'active');
    try {
      await runQueue({ plan, alive, getRows: () => { resolve(); return guildRows(guildStore); },
        getIDs: () => idsFor(token.account),
        leave: async id => {
          // Native HTTP manages authentication. Never read or store account tokens.
          const request = api.del({ url: `/users/@me/guilds/${id}`, body: { lurking: false } });
          let timeout;
          try {
            return await Promise.race([request, new Promise((_, reject) => {
              timeout = setTimeout(() => reject(new Error('Leave request timed out. It may still complete; refresh before trying again.')), 45000);
            })]);
          } finally { clearTimeout(timeout); }
        },
        wait: () => new Promise(done => setTimeout(done, 1500)),
        update: value => { if (active && job === token && account() === token.account) { report = { ...value, account: token.account }; emit(); } },
      });
    } finally { if (job === token) { job = null; emit(); } }
  }
  function showError(error) { log(error); RN.Alert.alert('Server Leaver', error?.message ?? String(error)); }
  function confirm(plan) {
    if (!plan.targets.length) return RN.Alert.alert('Nothing to leave', 'All listed servers will be kept.');
    if (job) return;
    const confirmedEpoch = epoch;
    RN.Alert.alert('Leave these servers?',
      `Leave ${plan.targets.length} servers and keep ${plan.kept.length}?\n\n${plan.ids.length ? `${plan.ids.length} server IDs are protected.` : 'You have no protected IDs.'}\n\nThis cannot be undone. You may need new invites to rejoin. Tap a server’s Protect button before continuing if you want to keep it.`,
      [{ text: 'Cancel', style: 'cancel' }, { text: `Leave ${plan.targets.length} servers`, style: 'destructive',
        onPress: () => { void execute(plan, confirmedEpoch).catch(showError); } }], { cancelable: true });
  }

  function Settings() {
    const [, rerender] = React.useState(0);
    const refresh = React.useCallback(() => rerender(n => n + 1), []);
    const id = account();
    const saved = safe(() => idsFor(id)) ?? '';
    const [draft, setDraft] = React.useState(saved);
    const [boundAccount, setBoundAccount] = React.useState(id);
    const [query, setQuery] = React.useState('');
    const [editing, setEditing] = React.useState(false);
    React.useEffect(() => { setBoundAccount(id); setDraft(safe(() => idsFor(id)) ?? ''); setQuery(''); setEditing(false); }, [id]);
    React.useEffect(() => {
      listeners.add(refresh);
      return () => { listeners.delete(refresh); };
    }, [refresh]);
    let plan, error;
    try { plan = freshPlan(id); } catch (e) { error = e.message; }
    const busy = !!job, dirty = draft !== saved || boundAccount !== id;
    const scheme = typeof RN.useColorScheme === 'function' ? RN.useColorScheme() : 'dark';
    const dark = (safe(() => themeStore?.theme) ?? scheme) !== 'light';
    const c = dark ? { bg: '#111214', card: '#202226', text: '#f2f3f5', muted: '#b5bac1', border: '#383a40', accent: '#a7afff', green: '#91deb7', danger: '#ff949b' }
      : { bg: '#f2f3f5', card: '#fff', text: '#1e1f22', muted: '#5c6068', border: '#d4d7dc', accent: '#4752c4', green: '#146b43', danger: '#b52c39' };
    const Pressable = RN.Pressable ?? RN.TouchableOpacity;
    const text = (value, style = {}, props = {}) => h(RN.Text, { style: { color: c.text, fontSize: 15, lineHeight: 22, ...style }, ...props }, value);
    const button = (label, action, disabled = false, danger = false) => h(Pressable, {
      accessibilityRole: 'button', accessibilityLabel: label, accessibilityState: { disabled }, disabled,
      onPress: action, style: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 14, paddingVertical: 11,
        borderRadius: 9, borderWidth: 1, borderColor: danger ? c.danger : c.border, opacity: disabled ? 0.4 : 1, marginTop: 10 },
    }, text(label, { color: danger ? c.danger : c.accent, fontWeight: '700' }));
    function saveDraft() {
      try { safe(() => RN.Keyboard?.dismiss?.()); setDraft(save(id, draft)); setEditing(false); } catch (e) { showError(e); }
    }
    function closeEditor() {
      if (account() !== id) return;
      safe(() => RN.Keyboard?.dismiss?.()); setDraft(safe(() => idsFor(id)) ?? ''); setBoundAccount(id); setEditing(false);
    }
    function toggle(serverID) {
      try {
        if (busy || dirty) throw new Error('Save your ID changes first.');
        if (isMainProtected(serverID)) return;
        const ids = new Set(parseIDs(saved));
        if (ids.has(serverID)) ids.delete(serverID); else ids.add(serverID);
        // Do not let a focused offscreen editor pull the list back to the header.
        safe(() => RN.Keyboard?.dismiss?.());
        setDraft(save(id, [...ids].join('\n')));
      } catch (e) { showError(e); }
    }
    const visibleReport = report?.account === id ? report : null;
    const rows = plan ? [...plan.kept, ...plan.targets.map(row => ({ ...row, reason: null }))]
      // Changing protection updates this row in place, not its scroll position.
      .sort((a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id))
      .filter(row => `${row.name}\n${row.id}`.toLowerCase().includes(query.trim().toLowerCase())) : [];
    const inputStyle = { color: c.text, backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 10, padding: 12, marginTop: 10 };
    const editor = h(RN.View, null,
      text('Protected server IDs', { fontSize: 22, lineHeight: 30, fontWeight: '800' }),
      text(`${MAIN_PROTECTED_IDS.length} main server IDs are always protected. Saving restores them if removed from this field.`, { color: c.muted, marginTop: 8 }),
      text('Spaces, commas and new lines work.', { color: c.muted }),
      h(RN.TextInput, { accessibilityLabel: 'Protected server IDs', value: draft, onChangeText: setDraft, editable: !busy,
        multiline: true, autoCorrect: false, autoCapitalize: 'none', placeholder: 'Paste the server IDs you want to keep',
        scrollEnabled: true, placeholderTextColor: c.muted,
        style: { ...inputStyle, height: 160, textAlignVertical: 'top' } }),
      button('Save protected IDs', saveDraft, busy || !validID(id) || boundAccount !== id));
    const header = h(RN.View, { style: { paddingBottom: 14 } },
      text('Server Leaver', { fontSize: 26, lineHeight: 34, fontWeight: '800' }),
      text('Keep the servers you choose. Leave the rest after confirming.', { color: c.muted, marginTop: 5 }),
      text('Protected server IDs', { fontWeight: '700', marginTop: 18 }),
      text('Your 22 main servers always stay. Tap Protect beside any other server you want to keep.', { color: c.muted }),
      RN.Modal ? button('Edit protected IDs', () => { setDraft(saved); setBoundAccount(id); setEditing(true); }, busy)
        : editor,
      dirty ? text('Save your changes before leaving any servers.', { color: c.danger, marginTop: 8 }) : null,
      error ? text(error, { color: c.danger, marginTop: 12 }) : null,
      plan ? h(RN.View, { style: { padding: 16, backgroundColor: c.card, borderRadius: 12, marginTop: 18 } },
        text(`Keep ${plan.kept.length} · Leave ${plan.targets.length}`, { fontSize: 20, fontWeight: '800', lineHeight: 28 }),
        text('Owned, unavailable and incomplete servers are also kept. Only the servers listed below are included.', { color: c.muted, marginTop: 5 }),
        button(busy ? 'Leaving servers…' : `Leave ${plan.targets.length} unprotected servers`, () => confirm(plan),
          busy || dirty || !plan.targets.length, true)) : null,
      busy ? button(job.cancelled ? 'Stopping after current request…' : 'Stop leaving', stop, job.cancelled, true) : null,
      busy ? text('Keep Discord open. Stop prevents the next request; a request already sent may finish.', { color: c.muted, marginTop: 8 }) : null,
      visibleReport ? h(RN.View, { style: { marginTop: 16 } },
        text(`Left ${visibleReport.left.length} · Skipped ${visibleReport.skipped.length} · Failed ${visibleReport.failed.length}`, { fontWeight: '700' }),
        visibleReport.stopped ? text(visibleReport.stopped, { color: c.danger }) : (!busy ? text('Finished.', { color: c.green }) : null),
        ...visibleReport.failed.map(row => text(`${row.name}: ${row.error}`, { color: c.danger }, { key: row.id }))) : null,
      button('Refresh server list', refresh, busy),
      h(RN.TextInput, { accessibilityLabel: 'Search servers', value: query, onChangeText: setQuery, autoCorrect: false,
        autoCapitalize: 'none', placeholder: 'Search server name or ID', placeholderTextColor: c.muted, style: inputStyle }),
      text('Preview — green servers stay, red servers will be left.', { color: c.muted, marginTop: 12 }));
    const list = h(RN.FlatList, { style: { flex: 1, backgroundColor: c.bg }, contentContainerStyle: { padding: 16, paddingBottom: 60 },
      data: rows, keyExtractor: row => row.id, ListHeaderComponent: header, keyboardShouldPersistTaps: 'handled',
      keyboardDismissMode: 'on-drag', removeClippedSubviews: false,
      initialNumToRender: 12, ListEmptyComponent: text(error ? 'Fix the issue above to see your server preview.' : 'No matching servers.', { color: c.muted }),
      renderItem: ({ item: row }) => h(RN.View, { style: { backgroundColor: c.card, padding: 14, borderRadius: 12, marginBottom: 10 } },
        text(row.name, { fontWeight: '700' }), text(row.id, { color: c.muted, fontSize: 12 }, { selectable: true }),
        text(row.reason ? `KEEP · ${row.reason}` : 'LEAVE', { color: row.reason ? c.green : c.danger, fontWeight: '700', marginTop: 5 }),
        button(isMainProtected(row.id) ? 'Main protected' : plan.ids.includes(row.id) ? 'Remove protection' : 'Protect',
          () => toggle(row.id), isMainProtected(row.id) || busy || dirty)),
    });
    if (!RN.Modal) return list;
    return h(RN.View, { style: { flex: 1, backgroundColor: c.bg } }, list,
      editing ? h(RN.Modal, { visible: true, transparent: true, animationType: 'fade', onRequestClose: closeEditor },
        h(RN.KeyboardAvoidingView ?? RN.View, { style: { flex: 1 }, behavior: RN.Platform?.OS === 'ios' ? 'padding' : 'height' },
          h(RN.View, { style: { flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'center', padding: 20 } },
            h(RN.ScrollView, { keyboardShouldPersistTaps: 'handled', style: { flexGrow: 0, maxHeight: '90%', backgroundColor: c.bg, borderRadius: 16 },
              contentContainerStyle: { padding: 20 } }, editor, button('Cancel editing', closeEditor))))) : null);
  }
  function open() {
    if (!active) return;
    try {
      const nav = byProps('getRootNavigationRef')?.getRootNavigationRef?.();
      if (typeof nav?.navigate !== 'function') throw new Error('Open Server Leaver’s settings button on the Plugins page.');
      nav.navigate('BUNNY_CUSTOM_PAGE', { title: 'Server Leaver', render: Settings });
    } catch (e) { showError(e); }
  }
  return {
    onLoad() {
      if (active) return;
      active = true; epoch++; resolve();
      appSubscription = RN.AppState?.addEventListener?.('change', state => { if (state !== 'active') stop(); });
      if (typeof userStore?.addChangeListener === 'function' && typeof userStore?.removeChangeListener === 'function') {
        const store = userStore;
        const changed = () => { if (job && account() !== job.account) stop(); emit(); };
        store.addChangeListener(changed);
        removeAccountListener = () => store.removeChangeListener(changed);
      }
      // Refresh on real changes instead of rebuilding the list during every scroll.
      for (const store of [guildStore, themeStore]) {
        if (typeof store?.addChangeListener !== 'function' || typeof store?.removeChangeListener !== 'function') continue;
        store.addChangeListener(emit);
        removeStoreListeners.push(() => store.removeChangeListener(emit));
      }
      try { disposeShortcut = attachSettingsShortcut({ api: host.bunny?.ui?.settings ?? host.window?.bunny?.ui?.settings,
        constants: byProps('SETTING_RENDERER_CONFIG'), Settings, open, getAsset: name => V.ui?.assets?.getAssetIDByName?.(name),
        patcher: V.patcher, tree: byProps('getAncestors', 'isBlocked'), log }); } catch (e) { log(e); }
      emit();
    },
    onUnload() { stop(); active = false; epoch++; safe(() => disposeShortcut?.()); safe(() => appSubscription?.remove());
      for (const remove of removeStoreListeners.splice(0)) safe(remove);
      safe(() => removeAccountListener?.()); disposeShortcut = appSubscription = removeAccountListener = undefined; emit(); listeners.clear(); },
    settings: Settings,
    controller: { freshPlan, save, execute, stop, getEpoch: () => epoch, isRunning: () => !!job },
  };
}

return createPlugin(vendetta);
})()
}, "Server Leaver");
})()
); }, {"id": "dev.fluttershy2008.server-leaver", "legacyManifest": {"name": "Server Leaver", "description": "Keep your 22 main servers and extra protected IDs. Preview and confirm before leaving other servers. Keeps owned servers; includes progress and Stop.", "version": "1.0.5", "authors": [{"name": "fluttershy_simper"}], "main": "index.js", "vendetta": {"icon": "ic_leave"}, "hash": "7e51497ce0d1b61cfafb27d7c4b3b350d047392ec81f81985b434695aa21757b"}, "repository": "https://fluttershy2008-mlp.github.io/lol/valenced/index.json", "host": "valenced", "version": "1.0.0-beta6"}), {"id": "dev.fluttershy2008.server-leaver", "title": "Server Leaver", "icon": "PuzzlePieceIcon"}) };
})()
