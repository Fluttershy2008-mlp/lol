(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Valenced API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const hostId = 'valenced';
    const product = 'Valenced';
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the ' + product + ' plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const source = rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update ' + product + ' to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        const found = rawFind(...props);
        if (found) return found;
        if (props.some(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.valenced.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod(hostId + '.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from ' + product + '.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.[hostId + '.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createValencedPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createValencedPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}
return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
/*! ReadAllNotificationsButton for Revenge 1.2.1
 * Vencord original by kemo, Vendicated and contributors.
 * Mobile adaptation Copyright (c) 2026 Fluttershy2008-mlp.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Source: https://github.com/Fluttershy2008-mlp/lol/tree/main/read-all-notifications
 */
'use strict';
/*
 * Adapted from Vencord ReadAllNotificationsButton by kemo.
 * Copyright (c) 2022 Vendicated and contributors.
 * Mobile adaptation Copyright (c) 2026 Fluttershy2008-mlp.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

const snowflake = value => typeof value === 'string' && /^[1-9]\d*$/.test(value);
const threadTypes = new Set([10, 11, 12]);
const forumTypes = new Set([15, 16]);
const messageTypes = new Set([0, 2, 5, 10, 11, 12, 13, 15, 16]);
const attempt = getter => { try { return getter(); } catch { return undefined; } };

function values(value) {
  if (value instanceof Map) return Array.from(value.values());
  return value && typeof value === 'object' ? Object.values(value) : [];
}

// Snowflakes exceed Number's precision on real accounts. Compare decimal strings.
function latestId(...ids) {
  return ids.filter(snowflake).reduce((latest, id) => !latest || id.length > latest.length
    || id.length === latest.length && id > latest ? id : latest, undefined);
}

// A snapshot: never invent a message ID or advance beyond a known message/post.
function collectUnread(stores) {
  const { GuildStore, GuildChannelStore, ChannelStore, ReadStateStore,
    ActiveJoinedThreadsStore, ActiveThreadsStore } = stores;
  if (typeof GuildStore?.getGuilds !== 'function' || typeof ReadStateStore?.hasUnread !== 'function'
    || typeof ReadStateStore?.lastMessageId !== 'function') {
    throw new Error('Discord read states are not ready. Reopen a chat and try again.');
  }
  const guilds = GuildStore.getGuilds();
  if (!guilds || typeof guilds !== 'object') throw new Error('Discord servers are still loading.');
  const candidates = new Map(), forumPosts = new Map(), warnings = new Set(), skipped = new Set();
  const available = new Set();
  let availableGuilds = 0;

  function add(raw, guildId) {
    let channel = raw?.channel ?? raw;
    if (typeof channel === 'string') {
      const id = channel;
      channel = attempt(() => ChannelStore?.getChannel?.(id));
      if (!channel) { skipped.add(id); return; }
    }
    if (!channel || typeof channel !== 'object' || !snowflake(channel.id)) return;
    const id = channel.id;
    // Keep guild/private indexes separate, even if an index contains bad entries.
    const owner = channel.guild_id ?? channel.guildId;
    const type = channel.type == null ? null : Number(channel.type);
    if (guildId == null) {
      if (owner != null || type !== 1 && type !== 3) return;
    } else {
      if (owner != null && owner !== guildId) return;
      if (type != null && !messageTypes.has(type)) return;
    }
    const previous = candidates.get(id);
    candidates.set(id, { channel: { id, type: type ?? previous?.channel.type,
      parent_id: channel.parent_id ?? channel.parentId ?? previous?.channel.parent_id }, guildId,
      lastId: latestId(previous?.lastId, channel.lastMessageId, channel.last_message_id) });
    skipped.delete(id);
    if (threadTypes.has(type)) {
      const parentId = channel.parent_id ?? channel.parentId;
      if (snowflake(parentId)) {
        // A forum parent's last_message_id is a *thread ID*, not a reply ID.
        const key = `${guildId}:${parentId}`;
        forumPosts.set(key, latestId(forumPosts.get(key), id));
      }
    }
  }

  function walk(value, guildId, seen = new Set(), depth = 0) {
    if (snowflake(value)) { add(value, guildId); return; }
    if (!value || typeof value !== 'object' || seen.has(value) || depth > 6) return;
    seen.add(value);
    if (value.channel || snowflake(value.id)) { add(value, guildId); return; }
    for (const child of values(value)) walk(child, guildId, seen, depth + 1);
  }

  function readIndex(store, getter, guildId) {
    try {
      if (typeof store?.[getter] !== 'function') return false;
      const index = store[getter](guildId);
      if (!index || typeof index !== 'object') return false;
      walk(index, guildId);
      return true;
    } catch { return false; }
  }

  for (const [key, guild] of guilds instanceof Map ? guilds.entries() : Object.entries(guilds)) {
    const guildId = guild?.id ?? key;
    if (!snowflake(guildId)) continue;
    if (guild?.unavailable || guild?.isMember === false) {
      warnings.add('Some servers are unavailable and were skipped.');
      continue;
    }
    available.add(guildId);
    let listed = false;
    try {
      const index = GuildChannelStore?.getChannels?.(guildId);
      if (index && (index.SELECTABLE != null || index.VOCAL != null)) {
        for (const group of [index.SELECTABLE, index.VOCAL]) walk(group, guildId);
        listed = true;
      }
    } catch {}
    // Merge the full cached index even when SELECTABLE exists: forums and
    // collapsed/muted channels may be absent from the visible channel list.
    if (readIndex(ChannelStore, 'getMutableGuildChannelsForGuild', guildId)) listed = true;
    if (listed) availableGuilds++;
    else warnings.add('Some server channel lists could not be loaded.');

    const joined = readIndex(ActiveJoinedThreadsStore, 'getActiveJoinedThreadsForGuild', guildId);
    const unjoined = readIndex(ActiveJoinedThreadsStore, 'getActiveUnjoinedThreadsForGuild', guildId);
    const active = readIndex(ActiveThreadsStore, 'getThreadsForGuild', guildId);
    const cached = readIndex(ChannelStore, 'getAllThreadsForGuild', guildId);
    if (!joined && !unjoined && !active && !cached) {
      warnings.add('Thread tracking is unavailable on this Discord version; some posts may be skipped.');
    } else if (!unjoined && !active && !cached) {
      warnings.add('Only joined-thread tracking is available; some unfollowed forum posts may be skipped.');
    }
  }

  // Include cached archived/hidden threads with a read state, even when absent
  // from active-thread indexes. Resolve actual channels; never trust state IDs
  // as channel records or include departed/unavailable guilds.
  if (typeof ReadStateStore.getAllReadStates === 'function') {
    const states = attempt(() => ReadStateStore.getAllReadStates(true));
    if (states && typeof states === 'object') {
      for (const state of values(states)) {
        if (state?.type != null && Number(state.type) !== 0) continue;
        const id = state?.channelId;
        if (!snowflake(id)) continue;
        const channel = attempt(() => ChannelStore?.getChannel?.(id));
        if (!channel) continue;
        const guildId = channel.guild_id ?? channel.guildId ?? null;
        if (guildId == null || available.has(guildId)) add(channel, guildId);
      }
    }
  }

  // Resolve forum parents reached only through a thread index.
  for (const { channel, guildId } of Array.from(candidates.values())) {
    if (!threadTypes.has(Number(channel.type))) continue;
    const parentId = channel.parent_id ?? channel.parentId;
    if (!snowflake(parentId) || candidates.has(parentId)) continue;
    const parent = attempt(() => ChannelStore?.getChannel?.(parentId));
    if (parent && forumTypes.has(Number(parent.type))) add(parent, guildId);
  }

  let privateListed = false;
  for (const getter of ['getMutablePrivateChannels', 'getSortedPrivateChannels', 'getPrivateChannels']) {
    if (readIndex(ChannelStore, getter, null)) privateListed = true;
  }
  if (!privateListed) warnings.add('DM and group DM lists could not be loaded; they were skipped.');
  if (!availableGuilds && !privateListed && available.size) {
    throw new Error('Discord server channels are not ready. Reopen a server and try again.');
  }

  const channels = [];
  for (const [id, { channel, guildId, lastId }] of candidates) {
    const type = Number(channel.type), forum = forumTypes.has(type), thread = threadTypes.has(type);
    const parentId = channel.parent_id ?? channel.parentId;
    const messageId = latestId(attempt(() => ReadStateStore.lastMessageId(id)), lastId,
      forum ? forumPosts.get(`${guildId}:${id}`) : undefined);
    const unread = attempt(() => ReadStateStore.hasUnread(id));
    const mentions = attempt(() => ReadStateStore.getMentionCount?.(id)) > 0;
    const postUnread = thread && (attempt(() => ReadStateStore.isForumPostUnread?.(id)) === true
      || snowflake(parentId) && attempt(() => ReadStateStore.isNewForumThread?.(id, parentId, guildId)) === true);
    // Forum "new posts" can be highlighted even when hasUnread(parent) is false.
    // Ack the last known post, also covering posts outside the rendered page.
    const ackId = forum ? attempt(() => ReadStateStore.ackMessageId?.(id)) : undefined;
    const newPosts = forum && snowflake(messageId) && (!snowflake(ackId)
      || messageId !== ackId && latestId(messageId, ackId) === messageId);
    const newPostCount = forum && attempt(() => ActiveJoinedThreadsStore?.getNewThreadCount?.(guildId, id)) > 0;
    if (!unread && !mentions && !postUnread && !newPosts && !newPostCount) {
      if (unread === undefined) skipped.add(id);
      continue;
    }
    if (!snowflake(messageId)) { skipped.add(id); continue; }
    // Do not move an existing read marker backwards if channel metadata lags.
    channels.push({ channelId: id, messageId: latestId(messageId, ackId), readStateType: 0 });
  }
  if (skipped.size) warnings.add(`${skipped.size} channel${skipped.size === 1 ? '' : 's'} could not be checked and were skipped.`);
  return { channels, warnings: Array.from(warnings) };
}

function bulkReadEvent(channels) {
  // This is the same native action and payload as the supplied Vencord plugin.
  return { type: 'BULK_ACK', context: 'APP', channels };
}

/* SPDX-License-Identifier: GPL-3.0-or-later */

function createUI({ React, RN, getState, subscribe, updateOptions, requestReadAll, refresh, getTheme }) {
  const h = React.createElement;
  const Pressable = RN.Pressable ?? RN.TouchableOpacity;
  function useState() {
    const [, redraw] = React.useState(0);
    React.useEffect(() => subscribe(() => redraw(value => value + 1)), []);
    return getState();
  }

  function ReadAllOverlay() {
    const state = useState();
    const [keyboard, setKeyboard] = React.useState(false);
    React.useEffect(() => {
      const show = RN.Keyboard?.addListener?.('keyboardDidShow', () => setKeyboard(true));
      const hide = RN.Keyboard?.addListener?.('keyboardDidHide', () => setKeyboard(false));
      return () => { show?.remove?.(); hide?.remove?.(); };
    }, []);
    if (!state.active || !state.options.showButton || keyboard) return null;
    return h(RN.View, {
      pointerEvents: 'box-none',
      style: { position: 'absolute', [state.options.side]: 12, bottom: 145, zIndex: 9999 },
    }, h(Pressable, {
      accessibilityRole: 'button', accessibilityLabel: 'Mark all server and DM notifications as read',
      accessibilityState: { disabled: state.busy, busy: state.busy },
      onPress: requestReadAll, disabled: state.busy,
      style: { minHeight: 44, minWidth: 92, paddingHorizontal: 14, paddingVertical: 11, borderRadius: 22,
        backgroundColor: '#4752c4', opacity: state.busy ? 0.6 : 1, elevation: 6,
        shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 4, shadowOffset: { width: 0, height: 2 } },
    }, h(RN.Text, { style: { color: '#fff', fontSize: 14, lineHeight: 22, fontWeight: '700', textAlign: 'center' } },
      state.busy ? 'Reading…' : '✓ Read All')));
  }

  function Settings() {
    const state = useState();
    const scheme = typeof RN.useColorScheme === 'function' ? RN.useColorScheme() : 'dark';
    const dark = (getTheme() ?? scheme) !== 'light';
    const colors = dark
      ? { bg: '#18191c', card: '#27292e', text: '#f3f4f6', muted: '#b6bcc7', border: '#4e535c' }
      : { bg: '#f2f3f5', card: '#fff', text: '#202227', muted: '#5b626f', border: '#c3c7cf' };
    const text = (value, style = {}) => h(RN.Text, { style: { color: colors.text, fontSize: 15, lineHeight: 22, ...style } }, value);
    const button = (label, onPress, primary = false) => h(Pressable, {
      accessibilityRole: 'button', onPress, disabled: state.busy || !state.active,
      accessibilityState: { disabled: state.busy || !state.active },
      style: { padding: 14, marginTop: 12, borderRadius: 10, backgroundColor: primary ? '#4752c4' : colors.card,
        borderColor: colors.border, borderWidth: primary ? 0 : 1, opacity: state.busy ? 0.6 : 1 },
    }, text(label, { color: primary ? '#fff' : colors.text, textAlign: 'center', fontWeight: '700' }));
    const toggle = (key, title, detail) => h(RN.View, { key,
      style: { flexDirection: 'row', alignItems: 'center', marginTop: 12, padding: 14, backgroundColor: colors.card, borderRadius: 10 },
    }, h(RN.View, { style: { flex: 1, marginRight: 12 } }, text(title, { fontWeight: '600' }), text(detail, { color: colors.muted, fontSize: 13 })),
    h(RN.Switch, { value: state.options[key], accessibilityLabel: title, onValueChange: value => updateOptions({ [key]: value }) }));
    return h(RN.ScrollView, { style: { flex: 1, backgroundColor: colors.bg }, contentContainerStyle: { padding: 16, paddingBottom: 60 } },
      text('Read All Notifications', { fontSize: 24, lineHeight: 30, fontWeight: '700' }),
      text('Mark unread server channels, forums, media channels, posts, threads, DMs and group DMs as read in one tap.', { color: colors.muted, marginTop: 8 }),
      text('Includes unfollowed forum posts and cached archived threads. Posts Discord has not loaded cannot be checked individually.',
        { color: colors.muted, marginTop: 8, fontSize: 13 }),
      text('This does not delete messages, mention history or Android notifications.',
        { color: colors.muted, marginTop: 8, fontSize: 13 }),
      button(state.busy ? 'Reading…' : '✓ Read all notifications', requestReadAll, true),
      button('Check unread channels', refresh),
      text(state.message, { marginTop: 14 }),
      ...state.warnings.map((warning, index) => h(RN.Text, { key: index, style: { color: colors.muted, marginTop: 8, fontSize: 13 } }, warning)),
      toggle('showButton', 'Show floating button', 'Display Read All in the chat view. It hides while typing.'),
      toggle('confirm', 'Confirm before reading', 'Ask before marking your current unread servers and DMs as read.'),
      button(`Button position: ${state.options.side === 'left' ? 'Left' : 'Right'} — tap to change`,
        () => updateOptions({ side: state.options.side === 'left' ? 'right' : 'left' })),
      text(state.overlay ? 'Floating button is ready. Reopen a chat if it is not visible yet.'
        : 'The floating button is unavailable in this layout. Use the button above or /readall.', { color: colors.muted, marginTop: 18, fontSize: 13 }),
      text('Based on Vencord ReadAllNotificationsButton by kemo, Vendicated and contributors. GPL-3.0-or-later.',
        { color: colors.muted, marginTop: 22, fontSize: 12 }),
    );
  }
  return { ReadAllOverlay, Settings };
}

/* SPDX-License-Identifier: GPL-3.0-or-later */

function createPlugin(V) {
  const { React, ReactNative: RN } = V.metro.common;
  const storage = V.plugin.storage;
  const listeners = new Set();
  const cleanup = [];
  let active = false, busy = false, generation = 0, overlay = false, pending = null;
  let message = 'Ready. Tap Read All to mark your unread channels, forums, posts, threads, DMs and group DMs as read.';
  let warnings = [];
  const log = error => { try { V.logger?.warn?.('[ReadAllNotificationsButton]', error?.message ?? String(error)); } catch {} };
  const safe = getter => { try { return getter(); } catch { return undefined; } };
  const byProps = (...keys) => safe(() => V.metro.findByProps(...keys));
  const byStore = name => safe(() => V.metro.findByStoreName(name));
  const options = () => ({ showButton: storage.showButton !== false, confirm: storage.confirm === true,
    side: storage.side === 'right' ? 'right' : 'left' });
  const changed = () => { for (const listener of listeners) { try { listener(); } catch {} } };
  const subscribe = listener => { listeners.add(listener); return () => listeners.delete(listener); };
  const getState = () => ({ active, busy, overlay, message, warnings: [...warnings], options: options() });
  function notify(text, error = false) {
    message = text;
    changed();
    try {
      if (typeof V.ui?.toasts?.showToast === 'function') {
        const icon = safe(() => V.ui.assets.getAssetIDByName(error ? 'CircleXIcon-primary' : 'Check'));
        V.ui.toasts.showToast(text, icon);
      } else RN.Alert.alert('Read All Notifications', text);
    } catch (err) { log(err); }
  }

  function snapshot() {
    const UserStore = byStore('UserStore');
    const accountId = safe(() => UserStore.getCurrentUser()?.id);
    if (!accountId) throw new Error('Sign in to Discord and wait for your chats to load.');
    const connection = byStore('ConnectionStore');
    if (safe(() => connection.isConnected()) === false) throw new Error('Discord is offline. Reconnect and try again.');
    const ReadStateStore = byStore('ReadStateStore') ?? byProps('hasUnread', 'lastMessageId');
    const result = collectUnread({
      GuildStore: byStore('GuildStore'), GuildChannelStore: byStore('GuildChannelStore'),
      ChannelStore: byStore('ChannelStore'), ReadStateStore,
      ActiveJoinedThreadsStore: byStore('ActiveJoinedThreadsStore'),
      ActiveThreadsStore: byStore('ActiveThreadsStore'),
    });
    return { ...result, accountId, UserStore, ReadStateStore };
  }

  async function readSnapshot(data, run) {
    if (!active || generation !== run || busy) return;
    if (safe(() => data.UserStore.getCurrentUser()?.id) !== data.accountId) {
      notify('Your account changed. Tap Read All again.', true);
      return;
    }
    if (safe(() => byStore('ConnectionStore').isConnected()) === false) {
      notify('Discord is offline. Reconnect and try again.', true);
      return;
    }
    busy = true;
    changed();
    try {
      const dispatcher = safe(() => V.metro.common.FluxDispatcher)
        ?? byProps('dispatch', 'subscribe', 'unsubscribe');
      if (typeof dispatcher?.dispatch !== 'function') throw new Error('Discord notification actions are unavailable on this version.');
      // Discord owns the acknowledgement queue and network synchronization, just
      // as in Vencord. No separate REST call, token access or double ack.
      await dispatcher.dispatch(bulkReadEvent(data.channels));
      if (!active || run !== generation) return;
      notify(`Marked ${data.channels.length} channel${data.channels.length === 1 ? '' : 's'} as read.${warnings.length ? ' Some items were skipped; see plugin settings.' : ''}`);
    } catch (error) {
      log(error);
      if (active && run === generation) notify(`Could not mark notifications as read: ${error?.message ?? 'Unknown error'}`, true);
    } finally {
      if (run === generation) { busy = false; changed(); }
    }
  }

  function requestReadAll() {
    if (!active || busy || pending) return;
    try {
      const data = snapshot();
      warnings = data.warnings;
      if (!data.channels.length) {
        notify(warnings.length ? 'No unread channels could be marked. Check the notes in plugin settings.' : 'All server and DM notifications are already read.');
        return;
      }
      const run = generation;
      if (options().confirm) {
        const token = {};
        pending = token;
        const release = () => { if (pending === token) pending = null; };
        RN.Alert.alert('Read all notifications?', `Mark ${data.channels.length} channels as read? This includes server channels, forums and media channels, loaded posts and threads (including unfollowed posts), DMs and group DMs.`, [
          { text: 'Cancel', style: 'cancel', onPress: release },
          { text: 'Read All', onPress: () => {
            if (pending !== token) return;
            release();
            void readSnapshot(data, run);
          } },
        ], { cancelable: true, onDismiss: release });
      } else return readSnapshot(data, run);
    } catch (error) {
      pending = null;
      log(error);
      notify(error?.message ?? 'Unable to check unread channels.', true);
    }
  }

  function refresh() {
    if (!active || busy) return;
    try {
      const data = snapshot();
      warnings = data.warnings;
      message = `${data.channels.length} unread channel${data.channels.length === 1 ? '' : 's'} ready to mark as read, including DMs and group DMs.`;
      changed();
    } catch (error) { notify(error?.message ?? 'Unable to check unread channels.', true); }
  }

  const { Settings, ReadAllOverlay } = createUI({ React, RN, getState, subscribe, requestReadAll, refresh,
    getTheme: () => safe(() => byStore('ThemeStore').theme),
    updateOptions: value => {
      if (typeof value.showButton === 'boolean') storage.showButton = value.showButton;
      if (typeof value.confirm === 'boolean') storage.confirm = value.confirm;
      if (value.side === 'left' || value.side === 'right') storage.side = value.side;
      changed();
    },
  });

  function mountOverlay() {
    try {
      const ChatView = V.metro.findByTypeName?.('ChatView');
      // Guard all proxy property reads: missing lazy modules can throw here.
      if (typeof ChatView?.type !== 'function' || typeof V.patcher?.after !== 'function') return;
      const unpatch = V.patcher.after('type', ChatView, (_, rendered) => {
        if (!active) return rendered;
        try {
          return React.createElement(React.Fragment, null, rendered,
            React.createElement(ReadAllOverlay, { key: 'read-all-notifications-button' }));
        } catch (error) { log(error); return rendered; }
      });
      if (typeof unpatch === 'function') { cleanup.push(unpatch); overlay = true; }
    } catch (error) { log(error); }
  }

  function onLoad() {
    if (active) return;
    active = true;
    generation++;
    mountOverlay();
    try {
      const unregister = V.commands?.registerCommand?.({
        name: 'readall', displayName: 'readall',
        description: 'Mark all server and DM notifications as read', displayDescription: 'Mark all server and DM notifications as read',
        options: [], applicationId: '-1', inputType: 1, type: 1,
        execute: async () => { await requestReadAll(); return null; },
      });
      if (typeof unregister === 'function') cleanup.push(unregister);
    } catch (error) { log(error); }
    changed();
  }

  function onUnload() {
    active = false;
    generation++;
    busy = false;
    pending = null;
    overlay = false;
    changed();
    for (const dispose of cleanup.splice(0).reverse()) { try { dispose(); } catch (error) { log(error); } }
    listeners.clear();
  }
  return { onLoad, onUnload, settings: Settings };
}

return createPlugin(vendetta);
})()
}, "ReadAllNotificationsButton");
})()
); }, {"id": "dev.fluttershy2008.read-all-notifications", "legacyManifest": {"name": "ReadAllNotificationsButton", "description": "Mark unread channels, forums, media channels, loaded posts and threads, DMs and group DMs as read with one button.", "version": "1.2.2", "authors": [{"name": "Fluttershy2008-mlp", "id": "753962426407452713"}, {"name": "kemo (original Vencord plugin)"}, {"name": "Vendicated and Vencord contributors"}], "main": "index.js", "vendetta": {"icon": "Check"}, "hash": "5015589dd16eab12ee0477859014a9c9d43c22632ea06723b9a5fd1071d94df4"}, "repository": "https://fluttershy2008-mlp.github.io/lol/valenced/index.json", "host": "valenced"}) };
})()
