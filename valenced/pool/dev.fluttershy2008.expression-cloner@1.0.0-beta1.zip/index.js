(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Valenced API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const hostId = 'valenced';
    const product = 'Valenced';
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the ' + product + ' plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const source = rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update ' + product + ' to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        const found = rawFind(...props);
        if (found) return found;
        if (props.some(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.valenced.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod(hostId + '.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from ' + product + '.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.[hostId + '.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createValencedPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createValencedPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}
return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
    "use strict";

    // ExpressionCloner for Revenge / Vendetta-compatible mobile clients.
    // Ported from Vencord's ExpressionCloner behavior and adapted to the
    // mobile action-sheet patterns used by Stealmoji.

    const optional = callback => { try { return callback(); } catch { return undefined; } };
    const find = (...args) => optional(() => vendetta.metro.find(...args));
    const findByProps = (...args) => optional(() => vendetta.metro.findByProps(...args));
    const findByStoreName = (...args) => optional(() => vendetta.metro.findByStoreName(...args));
    const { React, ReactNative, constants, FluxDispatcher } = vendetta.metro.common;
    const { before, after } = vendetta.patcher;
    const { getAssetIDByName } = vendetta.ui.assets;
    const { showToast } = vendetta.ui.toasts;
    const { findInReactTree } = vendetta.utils;
    const { Forms = {}, General = {}, ErrorBoundary } = vendetta.ui.components ?? {};

    const { FormRow, FormIcon, FormDivider } = Forms;
    const { TouchableOpacity } = General;

    const LazyActionSheet = findByProps("openLazy", "hideActionSheet") ?? findByProps("hideActionSheet");
    const ActionSheet = findByProps("ActionSheet")?.ActionSheet ?? find(m => m?.render?.name === "ActionSheet");
    const ActionSheetTitleHeader = findByProps("ActionSheetTitleHeader")?.ActionSheetTitleHeader
        ?? findByProps("BottomSheetTitleHeader")?.BottomSheetTitleHeader;
    const ActionSheetCloseButton = findByProps("ActionSheetCloseButton")?.ActionSheetCloseButton;
    const BottomSheetFlatList = findByProps("BottomSheetScrollView")?.BottomSheetFlatList
        ?? ReactNative.FlatList;
    const ActionSheetRow = findByProps("ActionSheetRow")?.ActionSheetRow;
    const Button = findByProps("TableRow", "Button")?.Button;

    // Discord 346+ removed the legacy FluxContainer(Alert) component that
    // vendetta.ui.alerts.showInputAlert still depends on. Use the current
    // AlertModal stack directly so opening the rename prompt cannot crash.
    const AlertManager = findByProps("openAlert", "dismissAlert");
    const AlertComponents = findByProps("AlertModal", "AlertActions");
    const AlertModal = AlertComponents?.AlertModal;
    const AlertActions = AlertComponents?.AlertActions;
    const AlertActionButton = AlertComponents?.AlertActionButton;

    const GuildStore = findByStoreName("GuildStore");
    const PermissionStore = findByStoreName("PermissionStore");
    const EmojiStore = findByStoreName("EmojiStore");
    const StickerStore = findByStoreName("StickersStore") ?? findByStoreName("StickerStore");
    const UserStore = findByStoreName("UserStore");

    const EmojiActions = findByProps("uploadEmoji");
    const StickerActions = findByProps("fetchSticker", "createGuildSticker")
        ?? findByProps("createGuildSticker", "updateGuildSticker");
    const EmojiSlotModule = findByProps("getMaxEmojiSlots");
    const Surrogates = findByProps("convertSurrogateToName");
    const GuildIconModule = findByProps("GuildIconSizes");
    const GuildIcon = GuildIconModule?.default;
    const GuildIconSizes = GuildIconModule?.GuildIconSizes;

    const iconAdd = getAssetIDByName("ic_add_24px") ?? getAssetIDByName("CirclePlusIcon-primary");
    const iconEmoji = getAssetIDByName("ic_emoji_24px") ?? getAssetIDByName("EmojiIcon");
    const iconSticker = getAssetIDByName("ic_sticker_24px") ?? getAssetIDByName("StickerIcon");
    const iconSuccess = getAssetIDByName("Check") ?? getAssetIDByName("CircleCheckIcon-primary");
    const iconError = getAssetIDByName("Small") ?? getAssetIDByName("CircleXIcon-primary");

    const MAX_EMOJI_BYTES = 256 * 1024;
    const MAX_STICKER_BYTES = 512 * 1024;
    const STICKER_LIMITS = { 0: 5, 1: 15, 2: 30, 3: 60 };
    const unpatches = [];
    let active = false, generation = 0;
    function resolveSheet(promise, callback) {
        const epoch = generation;
        return Promise.resolve(promise).then(module => {
            if (active && epoch === generation) return callback(module);
        }).catch(error => logError("Could not extend this action sheet", error));
    }

    function logError(...args) {
        try { vendetta.logger?.error?.("[ExpressionCloner]", ...args); }
        catch { console.error("[ExpressionCloner]", ...args); }
    }

    function normalizeName(name, type) {
        let out = String(name ?? (type === "Emoji" ? "emoji" : "sticker"));
        if (type === "Emoji") {
            out = out.replace(/^:+|:+$/g, "").split("~")[0].replace(/[^A-Za-z0-9_]/g, "_");
            if (out.length < 2) out = `emoji_${out}`;
            return out.slice(0, 32);
        }
        out = out.trim().replace(/[\r\n\t]/g, " ");
        if (out.length < 2) out = `sticker_${out}`;
        return out.slice(0, 30);
    }

    function validateName(name, type) {
        const value = String(name ?? "").trim();
        if (type === "Emoji") return /^[A-Za-z0-9_]{2,32}$/.test(value);
        return value.length >= 2 && value.length <= 30;
    }

    function dataUrlFromBlob(blob) {
        return new Promise((resolve, reject) => {
            try {
                const reader = new FileReader();
                reader.onerror = () => reject(reader.error ?? new Error("Failed to read image"));
                reader.onloadend = () => resolve(String(reader.result));
                reader.readAsDataURL(blob);
            } catch (e) {
                reject(e);
            }
        });
    }

    function emojiUrl(emoji, size) {
        const ext = emoji.animated ? "gif" : "webp";
        return `https://cdn.discordapp.com/emojis/${emoji.id}.${ext}?size=${size}&quality=lossless`;
    }

    function stickerExt(sticker) {
        const format = Number(sticker.format_type ?? sticker.formatType ?? sticker.format ?? 1);
        if (format === 4) return "gif";
        if (format === 3) return "json";
        return "png";
    }

    function stickerMime(sticker) {
        return stickerExt(sticker) === "gif" ? "image/gif" : "image/png";
    }

    function stickerUrl(sticker, size) {
        const ext = stickerExt(sticker);
        return `https://media.discordapp.net/stickers/${sticker.id}.${ext}?size=${size}&lossless=true`;
    }

    async function fetchCapped(type, item) {
        const max = type === "Sticker" ? MAX_STICKER_BYTES : MAX_EMOJI_BYTES;
        let lastError;

        for (let size = 4096; size >= 16; size = Math.floor(size / 2)) {
            const url = type === "Sticker" ? stickerUrl(item, size) : emojiUrl(item, size);
            try {
                const response = await fetch(url);
                if (!response.ok) {
                    lastError = new Error(`HTTP ${response.status} while fetching image`);
                    continue;
                }
                const blob = await response.blob();
                if (blob.size <= max) return blob;
            } catch (e) {
                lastError = e;
            }
        }
        throw lastError ?? new Error(`${type} is larger than Discord's upload limit`);
    }

    function canCreateExpressions(guild) {
        const currentId = UserStore?.getCurrentUser?.()?.id;
        if (guild?.ownerId === currentId || guild?.owner_id === currentId) return true;
        try {
            return Boolean(PermissionStore?.can?.(constants.Permissions.CREATE_GUILD_EXPRESSIONS, guild));
        } catch {
            return false;
        }
    }

    function emojiSlotsAvailable(guild, item) {
        try {
            const max = guild?.getMaxEmojiSlots?.() ?? EmojiSlotModule?.getMaxEmojiSlots?.(guild);
            if (!max) return true;
            const guildEntry = EmojiStore?.getGuilds?.()?.[guild.id];
            const emojis = guildEntry?.emojis ?? EmojiStore?.getGuildEmoji?.(guild.id) ?? [];
            const list = Array.isArray(emojis) ? emojis : Object.values(emojis ?? {});
            const used = list.filter(e => Boolean(e?.animated) === Boolean(item.animated) && !e?.managed).length;
            return used < max;
        } catch {
            return true;
        }
    }

    function stickerSlotsAvailable(guild) {
        try {
            let max = STICKER_LIMITS[guild?.premiumTier ?? guild?.premium_tier ?? 0] ?? 5;
            const features = guild?.features;
            const hasMore = Array.isArray(features)
                ? features.includes("MORE_STICKERS")
                : Boolean(features?.has?.("MORE_STICKERS"));
            if (hasMore && Number(guild?.premiumTier ?? guild?.premium_tier) === 3) max = 120;
            const stickers = StickerStore?.getStickersByGuildId?.(guild.id);
            return !stickers || stickers.length < max;
        } catch {
            return true;
        }
    }

    function getGuilds(type, item) {
        const guilds = Object.values(GuildStore?.getGuilds?.() ?? {});
        return guilds
            .filter(g => canCreateExpressions(g))
            .filter(g => type === "Emoji" ? emojiSlotsAvailable(g, item) : stickerSlotsAvailable(g))
            .sort((a, b) => String(a?.name ?? "").localeCompare(String(b?.name ?? "")));
    }

    function errorMessage(error) {
        const candidates = [
            error?.body?.message,
            error?.message,
            error?.text,
        ];
        for (const value of candidates) {
            if (!value) continue;
            if (typeof value === "string") {
                try { return JSON.parse(value)?.message ?? value; }
                catch { return value; }
            }
        }
        return "Unknown error";
    }

    async function cloneEmoji(guildId, emoji, customName) {
        if (!EmojiActions?.uploadEmoji) throw new Error("Discord's emoji upload module was not found");
        const blob = await fetchCapped("Emoji", emoji);
        const image = await dataUrlFromBlob(blob);
        return EmojiActions.uploadEmoji({
            guildId,
            image,
            name: customName,
            roles: undefined,
        });
    }

    async function cloneSticker(guildId, sticker, customName) {
        if (Number(sticker.format_type ?? sticker.formatType ?? sticker.format) === 3)
            throw new Error("Lottie stickers are not supported by ExpressionCloner");
        if (!StickerActions?.createGuildSticker)
            throw new Error("Discord's sticker upload module was not found");

        let full = sticker;
        try {
            if (StickerActions.fetchSticker) full = await StickerActions.fetchSticker(sticker.id) ?? sticker;
        } catch { /* message sticker data is enough as a fallback */ }

        const blob = await fetchCapped("Sticker", full);
        const dataUrl = await dataUrlFromBlob(blob);
        const tags = String(full.tags ?? full.emoji_name ?? full.emojiName ?? "sticker").trim() || "sticker";
        const description = String(full.description ?? "").slice(0, 100);
        const mimeType = stickerMime(full);

        // Discord mobile's native action creator normally uploads a local URI.
        // A data URI works on many React Native builds. If it does not, retry the
        // action creator through its web/FormData path, which uses the same auth.
        try {
            return await StickerActions.createGuildSticker({
                guildId,
                name: customName,
                tags,
                description,
                uri: dataUrl,
                mimeType,
                platform: "mobile",
                originalMd5: null,
            });
        } catch (mobileError) {
            try {
                const form = new FormData();
                form.append("name", customName);
                form.append("tags", tags);
                form.append("description", description);
                form.append("file", blob, `${customName}.${stickerExt(full)}`);
                return await StickerActions.createGuildSticker({
                    guildId,
                    body: form,
                    platform: "web",
                });
            } catch (webError) {
                webError.cause ??= mobileError;
                throw webError;
            }
        }
    }

    async function doClone(guild, type, item, customName) {
        try {
            if (type === "Emoji") await cloneEmoji(guild.id, item, customName);
            else await cloneSticker(guild.id, item, customName);
            showToast(`Cloned ${customName} to ${guild.name}`, iconSuccess);
        } catch (e) {
            logError("Clone failed", e);
            showToast(`Clone failed: ${errorMessage(e)}`, iconError);
        }
    }

    function RenamePrompt({ guild, type, item, alertKey }) {
        const initialValue = normalizeName(item.name ?? item.alt, type);
        const [value, setValue] = React.useState(initialValue);
        const [error, setError] = React.useState("");
        const dark = ReactNative.Appearance?.getColorScheme?.() !== "light";

        const confirm = () => {
            const name = String(value ?? "").trim();
            if (!validateName(name, type)) {
                setError(type === "Emoji"
                    ? "Use 2–32 letters, numbers, or underscores."
                    : "Use a name between 2 and 30 characters.");
                return;
            }

            try { AlertManager?.dismissAlert?.(alertKey); } catch {}
            void doClone(guild, type, item, name);
        };

        const input = React.createElement(ReactNative.View, {
            style: { width: "100%", gap: 8 }
        },
            React.createElement(ReactNative.TextInput, {
                value,
                autoFocus: true,
                selectTextOnFocus: true,
                placeholder: type === "Emoji" ? "my_emoji" : "My sticker",
                placeholderTextColor: dark ? "#949ba4" : "#5c5e66",
                returnKeyType: "done",
                onChangeText: text => {
                    setValue(text);
                    if (error) setError("");
                },
                onSubmitEditing: confirm,
                style: {
                    minHeight: 44,
                    borderWidth: 1,
                    borderColor: error ? "#da373c" : (dark ? "#4e5058" : "#c4c9ce"),
                    borderRadius: 8,
                    paddingHorizontal: 12,
                    paddingVertical: 10,
                    color: dark ? "#f2f3f5" : "#1e1f22",
                    backgroundColor: dark ? "#1e1f22" : "#f2f3f5"
                }
            }),
            error ? React.createElement(ReactNative.Text, {
                style: { color: "#da373c", fontSize: 12 }
            }, error) : null
        );

        const primary = React.createElement(AlertActionButton, {
            text: `Clone to ${guild.name}`,
            variant: "primary",
            onPress: confirm
        });
        const cancel = React.createElement(AlertActionButton, {
            text: "Cancel",
            variant: "secondary",
            onPress: () => {
                try { AlertManager?.dismissAlert?.(alertKey); } catch {}
            }
        });

        return React.createElement(AlertModal, {
            title: `${type} name`,
            content: input,
            actions: AlertActions
                ? React.createElement(AlertActions, null, primary, cancel)
                : React.createElement(ReactNative.View, { style: { gap: 8 } }, primary, cancel)
        });
    }

    function askNameAndClone(guild, type, item) {
        const initialValue = normalizeName(item.name ?? item.alt, type);

        if (!AlertManager?.openAlert || !AlertModal || !AlertActionButton) {
            showToast(`Rename prompt unavailable; cloning as ${initialValue}`, iconError);
            void doClone(guild, type, item, initialValue);
            return;
        }

        const alertKey = `expression-cloner-${type.toLowerCase()}-${guild.id}-${item.id ?? "item"}`;
        AlertManager.openAlert(
            alertKey,
            React.createElement(RenamePrompt, { guild, type, item, alertKey })
        );
    }

    function GuildRow({ guild, type, item }) {
        const slotsAvailable = type === "Emoji" ? emojiSlotsAvailable(guild, item) : stickerSlotsAvailable(guild);
        const leading = GuildIcon
            ? React.createElement(GuildIcon, {
                guild,
                size: GuildIconSizes?.MEDIUM,
                animate: false,
            })
            : React.createElement(FormIcon, { source: type === "Emoji" ? iconEmoji : iconSticker });

        return React.createElement(FormRow, {
            leading,
            disabled: !slotsAvailable,
            label: guild.name,
            subLabel: slotsAvailable ? undefined : `No ${type.toLowerCase()} slots available`,
            trailing: React.createElement(FormIcon, { style: { opacity: 1 }, source: iconAdd }),
            onPress: () => {
                LazyActionSheet?.hideActionSheet?.();
                askNameAndClone(guild, type, item);
            },
        });
    }

    function ServerPicker({ type, item }) {
        const guilds = getGuilds(type, item);
        const image = type === "Emoji" ? emojiUrl(item, 128) : stickerUrl(item, 128);

        const header = ActionSheetTitleHeader
            ? React.createElement(ActionSheetTitleHeader, {
                title: `Clone ${normalizeName(item.name ?? item.alt, type)}`,
                leading: React.createElement(FormIcon, {
                    style: { marginRight: 12, opacity: 1 },
                    source: { uri: image },
                    disableColor: true,
                }),
                trailing: ActionSheetCloseButton
                    ? React.createElement(ActionSheetCloseButton, { onPress: () => LazyActionSheet?.hideActionSheet?.() })
                    : undefined,
            })
            : null;

        const list = React.createElement(BottomSheetFlatList, {
            style: { flex: 1 },
            contentContainerStyle: { paddingBottom: 24 },
            data: guilds,
            renderItem: ({ item: guild }) => React.createElement(GuildRow, { guild, type, item }),
            ItemSeparatorComponent: FormDivider,
            keyExtractor: guild => guild.id,
            ListEmptyComponent: React.createElement(FormRow, {
                label: "No eligible servers",
                subLabel: "You need permission to create expressions and a free slot.",
            }),
        });

        return React.createElement(React.Fragment, null, header, list);
    }

    function openServerPicker(type, item) {
        if (!LazyActionSheet?.openLazy || !ActionSheet) {
            showToast("ExpressionCloner could not open the server picker on this Discord build", iconError);
            return;
        }
        const body = ErrorBoundary
            ? React.createElement(ErrorBoundary, null, React.createElement(ServerPicker, { type, item }))
            : React.createElement(ServerPicker, { type, item });
        const element = React.createElement(ActionSheet, { scrollable: true }, body);
        LazyActionSheet.openLazy(Promise.resolve({ default: () => element }), "ExpressionClonerServerPicker");
    }

    function emojiFromNode(emojiNode) {
        if (!emojiNode?.id) return null;
        const src = String(emojiNode.src ?? "");
        return {
            id: String(emojiNode.id),
            name: normalizeName(emojiNode.alt ?? emojiNode.name ?? "emoji", "Emoji"),
            animated: Boolean(emojiNode.animated) || /\.gif(?:\?|$)/i.test(src) || /[?&]animated=true/i.test(src),
            src,
        };
    }

    function cloneButton(emojiNode) {
        const emoji = emojiFromNode(emojiNode);
        if (!emoji || !Button) return null;
        return React.createElement(Button, {
            color: Button.Colors?.BRAND,
            text: "Clone Emoji",
            size: Button.Sizes?.SMALL,
            onPress: () => {
                LazyActionSheet?.hideActionSheet?.();
                openServerPicker("Emoji", emoji);
            },
            style: { marginTop: ReactNative.Platform.select({ android: 12, default: 16 }) },
        });
    }

    function patchMessageEmojiActionSheet() {
        const legacy = findByProps("GuildDetails");
        const patches = [];

        const patchSheet = (method, sheetModule, once = false) => {
            if (!sheetModule?.[method]) return () => {};
            const unpatch = after(method, sheetModule, ([{ emojiNode } = {}], res) => {
                if (!emojiNode?.id) return;
                const view = res?.props?.children?.props?.children;
                if (!view?.type) return;

                const unpatchView = after("type", view, (_, component) => {
                    const isButton = c => c?.type?.name === "Button" || c?.type === Button;
                    const container = findInReactTree(component, c => c?.find?.(isButton));
                    const node = cloneButton(emojiNode);
                    if (!node) return;
                    if (container) {
                        const i = container.findLastIndex?.(isButton) ?? container.length - 1;
                        container.splice(Math.max(0, i + 1), 0, node);
                    } else {
                        component?.props?.children?.push?.(node);
                    }
                }, true);
                patches.push(unpatchView);
            }, once);
            return unpatch;
        };

        if (legacy?.default) {
            patches.push(patchSheet("default", legacy));
        } else if (LazyActionSheet?.openLazy) {
            const unpatchLazy = before("openLazy", LazyActionSheet, ([lazySheet, name]) => {
                if (name !== "MessageEmojiActionSheet") return;
                resolveSheet(lazySheet, module => patches.push(patchSheet("default", module, true)));
            });
            patches.push(unpatchLazy);
        }

        return () => patches.splice(0).reverse().forEach(p => { try { p?.(); } catch {} });
    }

    function openEmojiActionSheet(emoji) {
        if (!emoji?.id) return;
        try {
            const Handlers = findByProps("MessagesHandlers")?.MessagesHandlers;
            if (!Handlers) return openServerPicker("Emoji", {
                id: emoji.id,
                name: normalizeName(emoji.name, "Emoji"),
                animated: Boolean(emoji.animated),
            });
            const instance = new Handlers(() => {});
            instance.isModalOrActionsheetObstructing = () => LazyActionSheet?.hideActionSheet?.();
            instance.handleTapEmoji({
                nativeEvent: {
                    node: {
                        id: emoji.id,
                        alt: emoji.name,
                        src: emojiUrl({ id: emoji.id, animated: Boolean(emoji.animated) }, 128),
                    },
                },
            });
        } catch (e) {
            logError("Failed to open emoji action sheet", e);
            openServerPicker("Emoji", {
                id: emoji.id,
                name: normalizeName(emoji.name, "Emoji"),
                animated: Boolean(emoji.animated),
            });
        }
    }

    function patchReactionLongPress() {
        if (!LazyActionSheet?.openLazy || !TouchableOpacity) return () => {};
        const patches = [];
        const unpatchLazy = before("openLazy", LazyActionSheet, ([lazySheet, name]) => {
            if (name !== "MessageReactions") return;
            resolveSheet(lazySheet, module => {
                const unpatchSheet = after("default", module, (_, sheet) => {
                    const child = sheet?.props?.children;
                    if (!child?.type) return;
                    const unpatchView = after("type", child, (_, view) => {
                        if (!view?.props?.header) return;
                        const unpatchHeader = after("type", view.props.header, (_, header) => {
                            const row = findInReactTree(header, c => c?.props?.tabs?.length);
                            if (!row) return;
                            const { tabs, onSelect } = row.props;
                            row.props.tabs = tabs.map((tab, i) => {
                                const reaction = tab?.props?.reaction?.emoji;
                                if (!reaction?.id) return tab;
                                return React.createElement(TouchableOpacity, {
                                    onPress: () => onSelect(tab.props.index ?? i),
                                    onLongPress: () => openEmojiActionSheet(reaction),
                                }, tab);
                            });
                        }, true);
                        patches.push(unpatchHeader);
                    }, true);
                    patches.push(unpatchView);
                }, true);
                patches.push(unpatchSheet);
            });
        });
        patches.push(unpatchLazy);
        return () => patches.splice(0).reverse().forEach(p => { try { p?.(); } catch {} });
    }


    let hookedStickerDetailModules = new WeakSet();

    function resolveStickerFromProps(props) {
        let sticker = props?.sticker ?? props?.renderableSticker ?? props?.item;
        if (!sticker?.id && sticker?.stickerId) {
            sticker = {
                ...sticker,
                id: sticker.stickerId,
                name: sticker.stickerName ?? sticker.name,
                format_type: sticker.stickerType ?? sticker.format_type,
            };
        }

        const id = sticker?.id ?? props?.stickerId ?? props?.renderableSticker?.id;
        if (id && StickerStore?.getStickerById) {
            try {
                const full = StickerStore.getStickerById(String(id));
                if (full?.id) sticker = { ...sticker, ...full };
            } catch {}
        }

        return sticker?.id ? sticker : null;
    }

    function StickerCloneButton({ sticker }) {
        if (!Button || !sticker?.id) return null;
        const format = Number(sticker.format_type ?? sticker.formatType ?? sticker.format);
        const unsupported = format === 3;

        return React.createElement(Button, {
            color: Button.Colors?.BRAND,
            text: unsupported ? "Clone Sticker (Lottie unsupported)" : "Clone Sticker",
            size: Button.Sizes?.SMALL,
            disabled: unsupported,
            onPress: () => {
                LazyActionSheet?.hideActionSheet?.();
                openServerPicker("Sticker", {
                    ...sticker,
                    name: normalizeName(sticker.name ?? "sticker", "Sticker"),
                });
            },
            style: { marginTop: ReactNative.Platform.select({ android: 12, default: 16 }) },
        });
    }

    function injectStickerDetailButton(props, result) {
        try {
            const sticker = resolveStickerFromProps(props);
            if (!sticker?.id) return;

            const key = `expression-cloner-sticker-${sticker.id}`;
            const view = result?.props?.children;
            const content = view?.props?.children;

            if (content) {
                const children = React.Children.toArray(content).slice();
                if (children.some(child => child?.key === key)) return;
                children.push(React.createElement(StickerCloneButton, { key, sticker }));
                view.props.children = children;
                return;
            }

            const isButton = child => child?.type?.name === "Button" || child?.type === Button;
            const container = findInReactTree(result, node => Array.isArray(node) && node.some?.(isButton));
            if (!container) return;
            if (container.some(child => child?.key === key)) return;

            const lastIndex = container.findLastIndex?.(isButton) ?? container.length - 1;
            container.splice(lastIndex + 1, 0,
                React.createElement(StickerCloneButton, { key, sticker })
            );
        } catch (e) {
            logError("Sticker detail injection failed", e);
        }
    }

    function hookStickerDetailModule(module) {
        if (!module || hookedStickerDetailModules.has(module)) return false;
        const sheetDefault = module.default;

        if (sheetDefault && typeof sheetDefault === "object" && typeof sheetDefault.type === "function") {
            hookedStickerDetailModules.add(module);
            const unpatch = after("type", sheetDefault, (args, result) => {
                injectStickerDetailButton(args?.[0], result);
            });
            unpatches.push(unpatch);
            return true;
        }

        if (typeof sheetDefault === "function") {
            hookedStickerDetailModules.add(module);
            const unpatch = after("default", module, (args, result) => {
                try {
                    if (result?.type && typeof result.type === "function") {
                        const innerUnpatch = after("type", result, (innerArgs, innerResult) => {
                            injectStickerDetailButton(innerArgs?.[0] ?? args?.[0], innerResult);
                        }, true);
                        unpatches.push(innerUnpatch);
                    } else {
                        injectStickerDetailButton(args?.[0], result);
                    }
                } catch (e) {
                    logError("Sticker detail sheet patch failed", e);
                }
            });
            unpatches.push(unpatch);
            return true;
        }

        return false;
    }

    function findStickerDetailModuleByPath() {
        try {
            const registry = globalThis.modules ?? globalThis.window?.modules;
            const requireFn = globalThis.__r ?? globalThis.window?.__r;
            if (!registry || !requireFn) return null;

            const entries = registry instanceof Map
                ? [...registry.entries()]
                : Object.entries(registry);

            for (const [id, factory] of entries) {
                const path = factory?.__filePath ?? factory?.definition?.__filePath;
                if (typeof path !== "string") continue;
                if (!path.endsWith("StickerDetailActionSheet.tsx") && !path.endsWith("StickerDetailActionSheet.ts")) continue;

                try {
                    const module = requireFn(Number(id));
                    const target = module?.default?.type ?? module?.default;
                    if (typeof target === "function") return module;
                } catch {}
            }
        } catch (e) {
            logError("Failed to locate sticker detail module", e);
        }
        return null;
    }

    function patchStickerDetailActionSheet() {
        const localUnpatches = [];
        let retryTimer = null;

        const tryDirect = () => {
            const module = findStickerDetailModuleByPath();
            if (!module) return false;
            return hookStickerDetailModule(module);
        };

        if (LazyActionSheet?.openLazy) {
            const unpatchLazy = before("openLazy", LazyActionSheet, ([lazySheet, name]) => {
                const key = String(name ?? "");
                if (!/sticker_detail_action_sheet|StickerDetailActionSheet/i.test(key)) return;

                resolveSheet(lazySheet, module => hookStickerDetailModule(module))
                    .catch(e => logError("Failed to patch sticker detail sheet", e));
            });
            localUnpatches.push(unpatchLazy);
        }

        if (!tryDirect()) {
            let attempts = 0;
            retryTimer = setInterval(() => {
                attempts++;
                if (tryDirect() || attempts >= 20) {
                    clearInterval(retryTimer);
                    retryTimer = null;
                }
            }, 1000);
        }

        return () => {
            if (retryTimer) clearInterval(retryTimer);
            localUnpatches.splice(0).reverse().forEach(fn => {
                try { fn?.(); } catch {}
            });
        };
    }

    function patchMessageStickerActionSheet() {
        if (!LazyActionSheet?.openLazy || !ActionSheetRow) return () => {};
        const patches = [];
        const unpatchLazy = before("openLazy", LazyActionSheet, ([lazySheet, name, args]) => {
            if (name !== "MessageLongPressActionSheet") return;
            const message = args?.message;
            const items = message?.stickerItems ?? message?.stickers ?? [];
            const stickers = Array.isArray(items)
                ? items.filter(s => s?.id && Number(s.format_type ?? s.formatType ?? s.format) !== 3)
                : [];
            if (!stickers.length) return;

            resolveSheet(lazySheet, module => {
                const unpatchSheet = after("default", module, (_, component) => {
                    let buttons = findInReactTree(component, c => c?.some?.(child =>
                        child?.type?.name === "ButtonRow" || child?.type?.name === "ActionSheetRow" || child?.type === ActionSheetRow
                    ));
                    if (!buttons?.push) return;

                    for (const sticker of stickers) {
                        const label = stickers.length === 1 ? "Clone Sticker" : `Clone Sticker: ${sticker.name ?? sticker.id}`;
                        buttons.push(React.createElement(ActionSheetRow, {
                            label,
                            icon: ActionSheetRow.Icon
                                ? React.createElement(ActionSheetRow.Icon, { source: iconSticker })
                                : undefined,
                            iconSource: !ActionSheetRow.Icon ? iconSticker : undefined,
                            onPress: () => {
                                LazyActionSheet?.hideActionSheet?.();
                                openServerPicker("Sticker", {
                                    ...sticker,
                                    name: normalizeName(sticker.name ?? "sticker", "Sticker"),
                                });
                            },
                        }));
                    }
                }, true);
                patches.push(unpatchSheet);
            });
        });
        patches.push(unpatchLazy);
        return () => patches.splice(0).reverse().forEach(p => { try { p?.(); } catch {} });
    }

    function onLoad() {
        if (active) return;
        if (!LazyActionSheet || !GuildStore || !PermissionStore)
            throw new Error("ExpressionCloner: required Discord modules were not found on this build");

        active = true;
        generation++;
        unpatches.push(patchMessageEmojiActionSheet());
        unpatches.push(patchReactionLongPress());
        unpatches.push(patchStickerDetailActionSheet());
        unpatches.push(patchMessageStickerActionSheet());
        showToast("ExpressionCloner enabled", iconEmoji);
    }

    function onUnload() {
        active = false;
        generation++;
        hookedStickerDetailModules = new WeakSet();
        for (const unpatch of unpatches.splice(0).reverse()) {
            try { unpatch?.(); } catch (e) { logError("Failed to unpatch", e); }
        }
    }

    return { onLoad, onUnload };
})()
}, "ExpressionCloner");
})()
); }, {"id": "dev.fluttershy2008.expression-cloner", "legacyManifest": {"name": "ExpressionCloner", "description": "Clone custom emojis and supported stickers from their action sheets to servers you manage.", "version": "1.1.2", "authors": [{"name": "Fluttershy2008-mlp"}], "main": "index.js", "vendetta": {"icon": "ic_emoji_24px"}, "hash": "12968350212194f893b78e815fd86efb6ee9668961dac4c8776662ff12293039"}, "repository": "https://fluttershy2008-mlp.github.io/lol/valenced/index.json", "host": "valenced"}) };
})()
