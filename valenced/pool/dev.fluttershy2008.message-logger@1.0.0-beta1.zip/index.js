(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Valenced API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const hostId = 'valenced';
    const product = 'Valenced';
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the ' + product + ' plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const source = rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update ' + product + ' to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        const found = rawFind(...props);
        if (found) return found;
        if (props.some(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.valenced.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod(hostId + '.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from ' + product + '.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.[hostId + '.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createValencedPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createValencedPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}
return withRevengeCompatibility(vendetta, function(vendetta) {
return /*! Message Logger for Revenge. GPL-3.0-or-later. Includes BSD-3-Clause code by redstonekasi; see NOTICE. Source: https://github.com/Fluttershy2008-mlp/lol/tree/main/vendetta-plugins/plugins/message-logger */(function(ue,Q,n,Ce,Xe,C,et,tt){"use strict";function nt(e){var a=Object.create(null);return e&&Object.keys(e).forEach(function(t){if(t!=="default"){var r=Object.getOwnPropertyDescriptor(e,t);Object.defineProperty(a,t,r.get?r:{enumerable:!0,get:function(){return e[t]}})}}),a.default=e,Object.freeze(a)}var Ee=nt(et);const Ae={logDeletes:!0,logEdits:!0,logDeletedAttachments:!0,keepDeletedInChat:!0,ignoreBots:!0,ignoreSelf:!1,ignoreUsers:"",ignoreChannels:"",ignoreGuilds:"",nopk:!1},W={messages:200,perChannel:50,edits:10,content:4e3,attachments:10,characters:2e6},M=(e,a=200)=>typeof e=="string"?e.slice(0,a):"",ke=e=>{var a,t;try{const r=new Date((t=(a=e==null?void 0:e.toDate)==null?void 0:a.call(e))!=null?t:e);return e!=null&&Number.isFinite(r.getTime())?r.toISOString():null}catch(r){return null}},ge=e=>new Set(M(e,1e4).split(/[\s,;]+/).filter(Boolean)),he=(e,a)=>e+":"+a;function Le(e){return Array.isArray(e)?e.slice(0,W.attachments).filter(a=>a&&typeof a=="object").map(a=>{var t,r,s;return{id:M(a.id),filename:M((t=a.filename)!=null?t:a.name,512)||"Attachment",url:M((s=(r=a.url)!=null?r:a.proxy_url)!=null?s:a.proxyURL,2048)}}):[]}const Me=e=>JSON.stringify(e.map(a=>[a.id,a.filename]));function at(e){var a;const t=new Map,r=new Map;let s=0;const c=(a=e.now)!=null?a:Date.now,g=()=>({...Ae,...e.options()}),u=()=>{var l;return(l=e.changed)==null?void 0:l.call(e)};function v(l){var d,f;let y;try{y=(d=e.channel)==null?void 0:d.call(e,l.channel_id)}catch(L){}return{guildId:M((f=l.guild_id)!=null?f:y==null?void 0:y.guild_id),channelName:M(y==null?void 0:y.name)||"DM / channel "+M(l.channel_id),parentId:M(y==null?void 0:y.parent_id)}}function I(l,d=!1){var f,y,L,_,m;const S=g();if(!l||typeof l.id!="string"||typeof l.channel_id!="string")return"Unsupported message data";if(((f=l.author)==null?void 0:f.id)==="1"||l.state==="SEND_FAILED"||Number(l.flags)&64)return"System, failed or ephemeral message";if(l.content!=null&&typeof l.content!="string")return"Unsupported message content";if(d?!S.logEdits:!S.logDeletes)return"Logging is disabled";if(S.ignoreBots&&(y=l.author)!=null&&y.bot)return"Bot ignored \u2014 switch off Ignore bots to include it";let N;try{N=(L=e.selfId)==null?void 0:L.call(e)}catch(xe){}if(S.ignoreSelf&&N&&((_=l.author)==null?void 0:_.id)===N)return"Your own message is ignored";const se=v(l);return ge(S.ignoreUsers).has((m=l.author)==null?void 0:m.id)?"User is in the ignore list":ge(S.ignoreChannels).has(l.channel_id)||ge(S.ignoreChannels).has(se.parentId)?"Channel or category is in the ignore list":ge(S.ignoreGuilds).has(se.guildId)?"Server is in the ignore list":null}const i=(l,d=!1)=>I(l,d)!==null;function p(l){var d,f;return{content:M(l.content,W.content),attachments:g().logDeletedAttachments?Le(l.attachments):[],time:ke((f=(d=l.edited_timestamp)!=null?d:l.editedTimestamp)!=null?f:l.timestamp)}}function h(l){var d,f,y,L,_,m,S,N;return{id:l.id,channelId:l.channel_id,...v(l),authorId:M((d=l.author)==null?void 0:d.id),authorName:M((m=(L=(f=l.author)==null?void 0:f.globalName)!=null?L:(y=l.author)==null?void 0:y.global_name)!=null?m:(_=l.author)==null?void 0:_.username)||"Unknown user",bot:!!((S=l.author)!=null&&S.bot),current:p(l),edits:[],deletedAt:null,changedAt:c(),earlierEditsMissing:!!((N=l.edited_timestamp)!=null?N:l.editedTimestamp),droppedEdits:0}}function b(l){var d;s-=(d=r.get(l))!=null?d:0,r.delete(l),t.delete(l)}function E(l){const d=he(l.channelId,l.id);b(d),t.set(d,l);const f=JSON.stringify(l).length;s+=f,r.set(d,f);const y=[...t].filter(([,L])=>L.channelId===l.channelId);for(;y.length>W.perChannel;)b(y.shift()[0]);for(;t.size>W.messages||s>W.characters;)b(t.keys().next().value);return u(),l}function w(l,d){var f,y;if(i(l,!0)||!d||l.id!==d.id||l.channel_id!==d.channel_id||Number(d.flags)&64)return;const L=he(l.channel_id,l.id),_=t.get(L),m=p(l);_!=null&&_.deletedAt&&m.content==="[deleted] "+_.current.content&&(m.content=_.current.content);const S={content:typeof d.content=="string"?M(d.content,W.content):m.content,attachments:Array.isArray(d.attachments)&&g().logDeletedAttachments?Le(d.attachments):m.attachments,time:(y=ke((f=d.edited_timestamp)!=null?f:d.editedTimestamp))!=null?y:new Date(c()).toISOString()};if(m.content===S.content&&Me(m.attachments)===Me(S.attachments))return;const N=_!=null?_:h(l);return N.edits.push(m),N.edits.length>W.edits&&(N.edits.shift(),N.droppedEdits++),N.current=S,N.changedAt=c(),E(N)}function U(l){var d;if(i(l))return;const f=he(l.channel_id,l.id),y=(d=t.get(f))!=null?d:h(l);return y.deletedAt?y:(y.current=p(l),y.deletedAt=new Date(c()).toISOString(),y.changedAt=c(),E(y))}function o(l,d){for(const[f,y]of t)(!l||y.channelId===l)&&(!d||y.id===d)&&b(f);u()}return{ignore:i,ignoreReason:I,recordEdit:w,recordDelete:U,clear:o,get:(l,d)=>t.get(he(l,d)),list:()=>[...t.values()].reverse(),size:()=>t.size}}const Z=new Set;let j,fe,ve,Ie;const F={seen:0,kept:0,labelFailures:0,last:"Waiting for a deletion",hooks:""};function P(e){Object.assign(F,e),Se()}function lt(){P({seen:0,kept:0,labelFailures:0,last:"Waiting for a deletion",hooks:""})}function Se(){!Z.size||j!==void 0||(j=setTimeout(()=>{j=void 0;for(const e of Z)try{e()}catch(a){}},32))}const B=at({options:()=>C.storage,channel:e=>{var a;return(a=fe==null?void 0:fe.getChannel)==null?void 0:a.call(fe,e)},selfId:()=>{var e,a;return(a=(e=ve==null?void 0:ve.getCurrentUser)==null?void 0:e.call(ve))==null?void 0:a.id},changed:Se});function Pe(e,a,t){fe=e,ve=a,Ie=t}function rt(){for(const[e,a]of Object.entries(Ae))C.storage[e]==null&&(C.storage[e]=a)}function Oe(e){return Z.add(e),()=>{Z.delete(e),!Z.size&&j!==void 0&&(clearTimeout(j),j=void 0)}}function ye(e,a){Ie==null||Ie(e,a),B.clear(e,a)}function Be(){B.clear(),j!==void 0&&clearTimeout(j),j=void 0,Se()}function Ue(){var e,a;const t=((a=(e=n.ReactNative).useColorScheme)==null?void 0:a.call(e))!=="light";return{bg:t?"#17191c":"#ffffff",card:t?"#272a30":"#f0f1f5",fg:t?"#f2f3f5":"#202225",muted:t?"#b5bac1":"#535865",red:t?"#ffa0a0":"#a3162c",accent:t?"#c5c9ff":"#343cab"}}const Te=e=>e?new Date(e).toLocaleString():"Time unavailable";function z({label:e,onPress:a,color:t,background:r}){return n.React.createElement(n.ReactNative.Pressable,{accessibilityRole:"button",accessibilityLabel:e,onPress:a,style:{padding:12,borderRadius:8,marginVertical:4,backgroundColor:r}},n.React.createElement(n.ReactNative.Text,{style:{color:t,fontSize:15,fontWeight:"600"}},e))}function pe(e,a){n.ReactNative.Alert.alert("Clear message history?",e,[{text:"Cancel",style:"cancel"},{text:"Clear",style:"destructive",onPress:a}])}function it(e){if(/^https?:\/\//i.test(e))try{Promise.resolve(n.ReactNative.Linking.openURL(e)).catch(()=>n.ReactNative.Alert.alert("Message Logger","This attachment link could not be opened. It may have expired."))}catch(a){n.ReactNative.Alert.alert("Message Logger","This attachment link could not be opened.")}}function ze({version:e,title:a,palette:t}){return n.React.createElement(n.ReactNative.View,{style:{padding:14,marginBottom:12,borderRadius:10,backgroundColor:t.card}},n.React.createElement(n.ReactNative.Text,{style:{color:t.accent,fontWeight:"700",marginBottom:5}},a),n.React.createElement(n.ReactNative.Text,{style:{color:t.muted,fontSize:12,marginBottom:10}},Te(e.time)),n.React.createElement(n.ReactNative.Text,{selectable:!0,style:{color:t.fg,fontSize:16}},e.content||"[No text]"),e.attachments.map((r,s)=>n.React.createElement(n.ReactNative.View,{key:r.id+":"+s,style:{marginTop:8}},n.React.createElement(n.ReactNative.Text,{selectable:!0,style:{color:t.muted}},"Attachment: ",r.filename),/^https?:\/\//i.test(r.url)&&n.React.createElement(z,{label:"Open "+r.filename,color:t.accent,onPress:()=>it(r.url)}))))}function Ge({initialChannel:e,onBack:a}){const t=Ue(),[r,s]=n.React.useState(""),[c,g]=n.React.useState(!!e),[u,v]=n.React.useState("all"),[I,i]=n.React.useState(null),[,p]=n.React.useState(0);n.React.useEffect(()=>Oe(()=>p(o=>o+1)),[]);const h=I&&B.get(I.channelId,I.id),b=r.trim().toLowerCase(),E=B.list().filter(o=>c&&e&&o.channelId!==e||u==="deleted"&&!o.deletedAt||u==="edited"&&!o.edits.length?!1:b?[o.authorName,o.authorId,o.channelName,o.channelId,o.id,...[...o.edits,o.current].map(l=>l.content+" "+l.attachments.map(d=>d.filename).join(" "))].join(" ").toLowerCase().includes(b):!0),w=o=>(o.deletedAt?"DELETED":"EDITED")+(o.edits.length?" \xB7 "+o.edits.length+" saved edits":""),U=o=>n.React.createElement(n.ReactNative.Text,{style:{color:t.fg,fontSize:21,fontWeight:"700",marginVertical:12}},o);return h?n.React.createElement(n.ReactNative.ScrollView,{style:{flex:1,backgroundColor:t.bg},contentContainerStyle:{padding:18}},n.React.createElement(z,{label:"Back to history",color:t.accent,onPress:()=>i(null)}),U(h.authorName),n.React.createElement(n.ReactNative.Text,{selectable:!0,style:{color:t.muted,marginBottom:8}},h.channelName+`
User: `+h.authorId+`
Message: `+h.id),h.deletedAt&&n.React.createElement(n.ReactNative.Text,{style:{color:t.red,marginBottom:12}},"Deleted ",Te(h.deletedAt)),(h.earlierEditsMissing||h.droppedEdits>0)&&n.React.createElement(n.ReactNative.Text,{style:{color:t.muted,marginBottom:12}},"Earlier versions are unavailable or exceeded the history limit."),h.edits.map((o,l)=>n.React.createElement(ze,{key:l,version:o,title:l===0?"Earlier version":"Edit "+l,palette:t})),n.React.createElement(ze,{version:h.current,title:h.deletedAt?"Last version before deletion":"Latest recorded version",palette:t}),n.React.createElement(z,{label:"Clear this message",color:t.red,background:t.card,onPress:()=>pe("Remove this message's saved history from this device.",()=>{ye(h.channelId,h.id),i(null)})}),n.React.createElement(z,{label:"Clear this channel",color:t.red,onPress:()=>pe("Remove all saved history for this channel.",()=>{ye(h.channelId),i(null)})})):n.React.createElement(n.ReactNative.View,{style:{flex:1,backgroundColor:t.bg,padding:16}},a&&n.React.createElement(z,{label:"Back to settings",color:t.accent,onPress:a}),U("Message history \xB7 "+E.length),n.React.createElement(n.ReactNative.Text,{style:{color:t.muted,marginBottom:12}},"Local, temporary history. Tap a message to see its versions. Attachment links may expire."),n.React.createElement(n.ReactNative.TextInput,{accessibilityLabel:"Search message history",value:r,onChangeText:s,placeholder:"Search text, author, channel or ID",placeholderTextColor:t.muted,style:{color:t.fg,backgroundColor:t.card,borderRadius:8,padding:12,marginBottom:8}}),n.React.createElement(n.ReactNative.View,{style:{flexDirection:"row",flexWrap:"wrap"}},[["all","All"],["deleted","Deleted"],["edited","Edited"]].map(([o,l])=>n.React.createElement(z,{key:o,label:(u===o?"\u2713 ":"")+l,color:t.accent,background:t.card,onPress:()=>v(o)}))),e&&n.React.createElement(z,{label:c?"This channel \xB7 Show all channels":"All channels \xB7 Show this channel",color:t.accent,onPress:()=>g(!c)}),n.React.createElement(n.ReactNative.FlatList,{data:E,keyExtractor:o=>o.channelId+":"+o.id,initialNumToRender:10,maxToRenderPerBatch:10,windowSize:5,keyboardShouldPersistTaps:"handled",ListEmptyComponent:n.React.createElement(n.ReactNative.Text,{style:{color:t.muted,paddingVertical:24}},"No matching history yet. Only messages cached while this plugin is running can be recorded."),renderItem:({item:o})=>n.React.createElement(n.ReactNative.Pressable,{accessibilityRole:"button",accessibilityLabel:o.authorName+", "+w(o),onPress:()=>i({id:o.id,channelId:o.channelId}),style:{backgroundColor:t.card,borderRadius:10,padding:14,marginVertical:5}},n.React.createElement(n.ReactNative.Text,{style:{color:o.deletedAt?t.red:t.accent,fontSize:12,fontWeight:"700"}},w(o)),n.React.createElement(n.ReactNative.Text,{numberOfLines:1,style:{color:t.fg,fontWeight:"600",marginTop:6}},o.authorName+" \xB7 "+o.channelName),n.React.createElement(n.ReactNative.Text,{numberOfLines:3,style:{color:t.fg,marginTop:6}},o.current.content||"[Attachment / no text]"),n.React.createElement(n.ReactNative.Text,{style:{color:t.muted,fontSize:11,marginTop:6}},Te(new Date(o.changedAt).toISOString())))}),n.React.createElement(z,{label:c&&e?"Clear this channel's history":"Clear all history",color:t.red,onPress:()=>pe("This also removes retained deleted messages from your chat view. It does not delete any messages on Discord.",()=>ye(c?e:void 0))}))}function st(e){var a,t;try{const r=(t=(a=Q.findByProps("getRootNavigationRef"))==null?void 0:a.getRootNavigationRef)==null?void 0:t.call(a);if(typeof(r==null?void 0:r.navigate)!="function")throw new Error("Navigation unavailable");r.navigate("BUNNY_CUSTOM_PAGE",{title:"Message Logger",render:()=>n.React.createElement(Ge,{initialChannel:e})})}catch(r){n.ReactNative.Alert.alert("Message Logger","Open Revenge Settings \u2192 Plugins \u2192 Message Logger \u2192 settings \u2192 Open message history.")}}function ot(){var e,a;try{const t=(a=(e=Q.findByProps("getRootNavigationRef"))==null?void 0:e.getRootNavigationRef)==null?void 0:a.call(e);if(typeof(t==null?void 0:t.navigate)!="function")throw new Error("Navigation unavailable");t.navigate("BUNNY_CUSTOM_PAGE",{title:"Message Logger",render:()=>n.React.createElement(Ne,null)})}catch(t){n.ReactNative.Alert.alert("Message Logger","Open Revenge Settings \u2192 Plugins \u2192 Message Logger \u2192 settings.")}}function Ne(){tt.useProxy(C.storage);const e=Ue(),[a,t]=n.React.useState(!1),[,r]=n.React.useState(0);if(n.React.useEffect(()=>Oe(()=>r(c=>c+1)),[]),a)return n.React.createElement(Ge,{onBack:()=>t(!1)});const s=[["logDeletes","Log deleted messages"],["logEdits","Log edits"],["logDeletedAttachments","Save attachment details"],["keepDeletedInChat","Keep deleted messages in chat"],["ignoreBots","Ignore bots"],["ignoreSelf","Ignore my messages"],["nopk","Ignore PluralKit originals"]];return n.React.createElement(n.ReactNative.ScrollView,{style:{flex:1,backgroundColor:e.bg},contentContainerStyle:{padding:20},keyboardShouldPersistTaps:"handled"},n.React.createElement(n.ReactNative.Text,{style:{color:e.fg,fontSize:23,fontWeight:"700",marginBottom:12}},"Message Logger 2.0.3"),n.React.createElement(n.ReactNative.Text,{style:{color:e.muted,marginBottom:12}},"Deleted messages and edit history for Revenge, adapted from Vencord. Use /messagelogger in any chat to open its history privately."),n.React.createElement(z,{label:"Open message history",color:e.accent,background:e.card,onPress:()=>t(!0)}),n.React.createElement(n.ReactNative.Text,{selectable:!0,style:{color:e.muted,marginVertical:10}},"Deletions seen: "+F.seen+" \xB7 Kept in chat: "+F.kept+`
Last deletion: `+F.last),F.labelFailures>0&&n.React.createElement(n.ReactNative.Text,{style:{color:e.muted,marginBottom:10}},"Your Discord build rejected the deleted label. Messages are kept with their original text for this session."),n.React.createElement(n.ReactNative.Text,{style:{color:e.muted,marginVertical:14}},"History clears when you restart, disable the plugin or log out. Limits: 200 messages total, 50 per channel, 10 older versions per message, plus a total memory cap. Text is limited to 4,000 characters per version."),s.map(([c,g])=>n.React.createElement(n.ReactNative.View,{key:c,style:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",paddingVertical:10}},n.React.createElement(n.ReactNative.Text,{style:{color:e.fg,fontSize:16,flex:1,paddingRight:12}},g),n.React.createElement(n.ReactNative.Switch,{accessibilityLabel:g,value:!!C.storage[c],onValueChange:u=>{C.storage[c]=u}}))),n.React.createElement(n.ReactNative.Text,{style:{color:e.muted,marginVertical:10}},"PluralKit is optional and only checks IDs for messages retained in chat. It sends no message text or Discord credentials. Attachment records store names and links, not media files."),n.React.createElement(n.ReactNative.Text,{style:{color:e.fg,fontSize:18,fontWeight:"600",marginTop:16}},"Ignore lists"),n.React.createElement(n.ReactNative.Text,{style:{color:e.muted,marginVertical:10}},"Separate IDs with commas or spaces. Channel IDs also support categories. Settings apply to future events; clear history to remove existing records."),[["ignoreUsers","User IDs"],["ignoreChannels","Channel / category IDs"],["ignoreGuilds","Server IDs"]].map(([c,g])=>{var u;return n.React.createElement(n.ReactNative.View,{key:c,style:{marginVertical:8}},n.React.createElement(n.ReactNative.Text,{style:{color:e.fg,marginBottom:5}},g),n.React.createElement(n.ReactNative.TextInput,{accessibilityLabel:g,multiline:!0,autoCorrect:!1,autoCapitalize:"none",maxLength:1e4,value:String((u=C.storage[c])!=null?u:""),onChangeText:v=>{C.storage[c]=v},placeholder:g,placeholderTextColor:e.muted,style:{color:e.fg,backgroundColor:e.card,padding:12,borderRadius:8,minHeight:48}}))}),n.React.createElement(z,{label:"Clear all history",color:e.red,onPress:()=>pe("Remove all locally saved history and retained deleted chat messages.",()=>ye())}))}const $="MESSAGE_LOGGER_FLUTTERSHY_SETTINGS",X="SETTING_RENDERER_CONFIG",je=Symbol.for("message-logger.settings.renderer.v1"),me=Object.freeze({type:"pressable",parent:null,title:()=>"Message Logger",useTitle:()=>"Message Logger",usePredicate:()=>!1,onPress:()=>{},withArrow:!0});function ct(e,a){if(!e)return;let t;try{t=e[je],t||(t={row:me,getter:void 0},Object.defineProperty(e,je,{value:t,configurable:!0}))}catch(s){return}function r(){var s,c,g;try{const u=Object.getOwnPropertyDescriptor(e,X);if(((s=e[X])==null?void 0:s[$])===t.row)return!0;if((u==null?void 0:u.configurable)===!1)return!1;let v=!1,I=(c=u==null?void 0:u.value)!=null?c:e[X];const i=()=>({...u!=null&&u.get&&!v?u.get.call(e):I,[$]:t.row});return Object.defineProperty(e,X,{configurable:!0,enumerable:(g=u==null?void 0:u.enumerable)!=null?g:!0,get:i,set(p){u!=null&&u.set?u.set.call(e,p):(v=!0,I=p)}}),t.getter=i,e[X][$]===t.row}catch(u){return!1}}if(t.row=a,!r()){t.row=me;return}return{ensure:r,release(){t.row===a&&(t.row=me)}}}function dt({settingsAPI:e,Settings:a,constants:t,treeManager:r,patcher:s,openSettings:c,renderIcon:g,getAssetID:u,log:v=()=>{}}){const I=e==null?void 0:e.registeredSections;if(!I||typeof I!="object")return v("Settings shortcut is unavailable on this Revenge version. Use the plugin settings button."),()=>{};const i=Object.values(I).find(o=>Array.isArray(o)&&o.some(l=>(l==null?void 0:l.key)==="BUNNY_PLUGINS"));if(!i||i.some(o=>(o==null?void 0:o.key)===$))return()=>{};let p;for(const o of["HistoryIcon","ChatIcon","WrenchIcon","ic_audit_log_24px"])try{const l=u==null?void 0:u(o);if(l!=null){p=l;break}}catch(l){}let h=!0;const b={type:"pressable",parent:null,title:()=>"Message Logger",useTitle:()=>"Message Logger",icon:p,IconComponent:p!=null&&g?()=>g(p):void 0,usePredicate:()=>h,onPress:()=>{h&&(c==null||c())},withArrow:!0},E=ct(t,b);if(!E)return h=!1,v("Could not register a native settings row safely. Use the plugin settings button."),()=>{};let w;try{typeof(r==null?void 0:r.getAncestors)=="function"&&typeof(s==null?void 0:s.before)=="function"&&(w=s.before("getAncestors",r,o=>{o[0]===$&&E.ensure()}))}catch(o){}const U={key:$,title:()=>"Message Logger",icon:p,usePredicate:b.usePredicate,rawTabsConfig:b,render:async()=>({default:a})};try{const o=i.findIndex(f=>(f==null?void 0:f.key)==="RELATIONSHIP_NOTIFIER_FLUTTERSHY_SETTINGS"),l=i.findIndex(f=>(f==null?void 0:f.key)==="CUSTOMRPC_FLUTTERSHY_SETTINGS"),d=o>=0?o:l>=0?l:i.findIndex(f=>(f==null?void 0:f.key)==="BUNNY_PLUGINS");i.splice(d+1,0,U)}catch(o){return h=!1,w==null||w(),E.release(),v("Could not add the settings shortcut. Use the plugin settings button."),()=>{}}return()=>{h=!1;for(const o of new Set([i,...Object.values(I)])){if(!Array.isArray(o))continue;const l=o.indexOf(U);if(l!==-1)try{o.splice(l,1)}catch(d){}}w==null||w(),w=void 0,E.release()}}const Fe="[deleted] ",ut=200,gt=50,ht=400,ft=10,Ve=10,ee=new Set,A=new Map,x=new Map,V=new Map,te=new Map,ne=new Set,ae=[];let O,Y,D=!1,Re=!0,le=new WeakMap,k=0,K,H;const G=({channelId:e,id:a})=>e+":"+a,J=e=>A.get(G(e))===e,He=e=>e.startsWith(Fe)?e:Fe+e;function we({channelId:e,id:a}){for(const t of[()=>{var r;return(r=O==null?void 0:O.getMessage)==null?void 0:r.call(O,e,a)},()=>{var r,s,c;return(c=(s=(r=O==null?void 0:O.getMessages)==null?void 0:r.call(O,e))==null?void 0:s.get)==null?void 0:c.call(s,a)},()=>{var r,s,c;return(c=(s=(r=Y==null?void 0:Y.get)==null?void 0:r.call(Y,e))==null?void 0:s.get)==null?void 0:c.call(s,a)}])try{const r=t();if(r)return r}catch(r){}}function _e(e,a){var t,r,s,c,g;if(e)return{id:(t=e.id)!=null?t:a.id,channel_id:(s=(r=e.channel_id)!=null?r:e.channelId)!=null?s:a.channelId,guild_id:(c=e.guild_id)!=null?c:e.guildId,author:e.author,state:e.state,flags:e.flags,content:e.content,attachments:e.attachments,timestamp:e.timestamp,edited_timestamp:(g=e.edited_timestamp)!=null?g:e.editedTimestamp}}function We(e,a=()=>{},t=()=>{}){const r=()=>{try{a()}catch(c){}},s=()=>{try{t()}catch(c){}};try{const c=n.FluxDispatcher.dispatch(e);c&&typeof c.then=="function"?Promise.resolve(c).then(s,()=>{r(),s()}):s()}catch(c){r(),s()}}function Ye(e,a=()=>{}){const t={},r=k;ee.add(t),We(e,a,()=>{ee.delete(t),D&&r===k&&q()})}function re(e){const a=G(e);A.delete(a),x.delete(a),V.delete(a)}function ie(e){re(e),x.set(G(e),{entry:e,remove:!0}),q()}function $e(){if(!D||!C.storage.nopk){V.clear();return}if(typeof AbortController!="function"){V.clear();return}for(;ne.size<2&&V.size;){const e=V.values().next().value;if(V.delete(G(e)),!J(e))continue;const a=k,t=new AbortController,r={controller:t,timer:setTimeout(()=>{try{t.abort()}catch(s){}},1e4)};ne.add(r),Promise.resolve().then(()=>{if(!(!D||a!==k||!C.storage.nopk||!J(e)))return fetch("https://api.pluralkit.me/v2/messages/"+encodeURIComponent(e.id),{signal:t.signal})}).then(s=>s!=null&&s.ok?s.json():void 0).then(s=>{var c;!D||a!==k||!C.storage.nopk||!J(e)||(s==null?void 0:s.original)===e.id&&!((c=s.member)!=null&&c.keep_proxy)&&(B.clear(e.channelId,e.id),ie(e))}).catch(()=>{}).finally(()=>{clearTimeout(r.timer),ne.delete(r),a===k&&$e()}).catch(()=>{})}}function vt(e){return{type:"MESSAGE_DELETE",id:e.id,channelId:e.channelId,__vml_cleanup:!0}}function q(){if(!D||K!==void 0||!x.size||ee.size>=Ve)return;const e=k;K=setTimeout(()=>{var a,t,r;if(K=void 0,!(!D||e!==k)){try{if((t=(a=n.FluxDispatcher).isDispatching)!=null&&t.call(a)){q();return}for(let s=0;s<ft&&x.size&&ee.size<Ve;s++){const[c,g]=x.entries().next().value;if(x.delete(c),g.remove){Ye(vt(g.entry));continue}if(J(g.entry))try{const u=we(g.entry);if(!u){re(g.entry);continue}const v=(r=u.content)!=null?r:"";if(typeof v!="string")throw new Error("Unsupported message content");Re&&Ye({type:"MESSAGE_UPDATE",__vml_synthetic:!0,message:{id:g.entry.id,channel_id:g.entry.channelId,content:He(v)}},()=>{!D||e!==k||!J(g.entry)||(Re=!1,P({labelFailures:F.labelFailures+1,last:"Message kept in chat; deleted label is unavailable on this Discord build"}))}),C.storage.nopk&&J(g.entry)&&V.set(c,g.entry)}catch(u){P({last:"Message kept in chat without a deleted label"})}}$e()}catch(s){}q()}},16)}function yt(e){P({seen:F.seen+1});const a=_e(we(e),e);if(!a)return P({last:"Message was not in Discord's local cache"}),!1;if(a.channel_id!==e.channelId||a.id!==e.id)return!1;const t=B.ignoreReason(a);if(t)return P({last:t}),!1;if(A.has(G(e)))return!0;if(B.recordDelete(a),!C.storage.keepDeletedInChat)return P({last:"Saved to history only \u2014 Keep deleted messages in chat is off"}),!1;if(x.size>=ht-1||x.has(G(e)))return P({last:"Saved to history only \u2014 chat retention queue is full"}),!1;A.set(G(e),e),P({kept:F.kept+1,last:"Deleted message kept in chat"}),x.set(G(e),{entry:e,remove:!1});let r=0,s;for(const c of A.values())c.channelId===e.channelId&&(s!=null||(s=c),r++);return r>gt&&s&&ie(s),A.size>ut&&ie(A.values().next().value),q(),!0}function Ke(){k++,le=new WeakMap,ee.clear(),K!==void 0&&clearTimeout(K),H!==void 0&&clearTimeout(H),K=H=void 0,A.clear(),x.clear(),V.clear(),te.clear();for(const e of ne){clearTimeout(e.timer);try{e.controller.abort()}catch(a){}}ne.clear()}function pt(){var e,a,t,r,s,c,g;if(D)return;if(rt(),lt(),Re=!0,O=Q.findByProps("getMessage","getMessages"),Y=Q.findByProps("_channelMessages"),typeof((e=n.FluxDispatcher)==null?void 0:e.dispatch)!="function"||typeof(O==null?void 0:O.getMessage)!="function"&&typeof(O==null?void 0:O.getMessages)!="function"&&typeof(Y==null?void 0:Y.get)!="function")throw new Error("Message Logger: unsupported message store. Include your Discord and Revenge versions when reporting this error.");D=!0;const u=(...v)=>{try{return Q.findByProps(...v)}catch(I){return}};Pe(u("getChannel","getDMFromUserId"),u("getCurrentUser"),(v,I)=>{for(const i of[...A.values()])(!v||i.channelId===v)&&(!I||i.id===I)&&ie(i)}),k++,H!==void 0&&clearTimeout(H),H=void 0;for(const[v,I]of te)x.set(v,{entry:I,remove:!0});te.clear();try{const v=i=>{var p,h,b,E,w,U,o,l,d,f,y,L,_,m,S,N,se,xe,qe,Qe,Ze;if(!D||!i)return i;if(i.type==="LOGOUT"||i.type==="LOGOUT_START"||i.type==="LOGIN_SUCCESS")return Be(),Ke(),i;if(i.type==="CHANNEL_DELETE"){const R=(b=(h=(p=i.channel)==null?void 0:p.id)!=null?h:i.channelId)!=null?b:i.channel_id;for(const T of[...A.values()])T.channelId===R&&re(T);for(const[T,de]of x)de.entry.channelId===R&&x.delete(T);return typeof R=="string"&&B.clear(R),i}if(i.type==="GUILD_DELETE"&&!i.unavailable&&!((E=i.guild)!=null&&E.unavailable)){const R=(l=(o=(U=(w=i.guild)==null?void 0:w.id)!=null?U:i.guildId)!=null?o:i.guild_id)!=null?l:i.id;if(typeof R=="string"){for(const T of B.list())if(T.guildId===R){B.clear(T.channelId,T.id);const de=A.get(G({channelId:T.channelId,id:T.id}));de&&ie(de)}}}if(i.type==="MESSAGE_UPDATE"){const R=i.message,T={id:(f=(d=R==null?void 0:R.id)!=null?d:i.id)!=null?f:i.messageId,channelId:(_=(L=(y=R==null?void 0:R.channel_id)!=null?y:R==null?void 0:R.channelId)!=null?L:i.channelId)!=null?_:i.channel_id};if(!i.__vml_synthetic&&R&&typeof T.id=="string"&&typeof T.channelId=="string")try{B.recordEdit(_e(we(T),T),_e(R,T))}catch(de){}return Re&&R&&typeof R.content=="string"&&A.has(G(T))?{...i,message:{...R,content:He(R.content)}}:i}const De=i.type==="MESSAGE_DELETE_BULK";if(!De&&i.type!=="MESSAGE_DELETE")return i;const be=(xe=(N=(m=i.channelId)!=null?m:i.channel_id)!=null?N:(S=i.message)==null?void 0:S.channel_id)!=null?xe:(se=i.message)==null?void 0:se.channelId,oe=De?i.ids:[(Ze=(qe=i.id)!=null?qe:i.messageId)!=null?Ze:(Qe=i.message)==null?void 0:Qe.id];if(typeof be!="string"||!Array.isArray(oe)||!oe.length)return i;if(i.__vml_cleanup){for(const R of oe)re({id:R,channelId:be});return i}const ce=[];for(const R of oe)try{(typeof R!="string"||!yt({channelId:be,id:R}))&&(typeof R=="string"&&re({channelId:be,id:R}),ce.push(R))}catch(T){P({last:"This deletion could not be retained"}),ce.push(R)}return ce.length?!De||ce.length===oe.length?i:{...i,ids:ce}:null},I=[];for(const i of["dispatch","dirtyDispatch","maybeDispatch"])if(typeof n.FluxDispatcher[i]=="function")try{ae.push(Ce.instead(i,n.FluxDispatcher,function(p,h){const b=p[0];if(!D||!b||typeof b!="object")return h.apply(this,p);let E;if(le.has(b))E=le.get(b);else{try{E=v(b)}catch(w){E=b;try{P({last:"Skipped incompatible event data; Discord handled it normally"})}catch(U){}}le.set(b,E),E&&E!==b&&le.set(E,E)}return E===null?i==="dispatch"?Promise.resolve():void 0:h.apply(this,E===b?p:[E,...p.slice(1)])})),I.push(i)}catch(p){if(i==="dispatch")throw p}P({hooks:I.join(", ")});try{typeof(Ee==null?void 0:Ee.registerCommand)=="function"&&ae.push(Ee.registerCommand({name:"messagelogger",description:"Open your local deleted messages and edit history",options:[],execute:(i,p)=>{var h;st((h=p==null?void 0:p.channel)==null?void 0:h.id)}}))}catch(i){}try{const i=globalThis;ae.push(dt({settingsAPI:(g=(t=(a=i.bunny)==null?void 0:a.ui)==null?void 0:t.settings)!=null?g:(c=(s=(r=i.window)==null?void 0:r.bunny)==null?void 0:s.ui)==null?void 0:c.settings,Settings:Ne,constants:u("SETTING_RENDERER_CONFIG"),treeManager:u("getAncestors","isBlocked"),patcher:{before:Ce.before},openSettings:ot,getAssetID:Xe.getAssetIDByName,renderIcon:p=>{var h;const b=(h=u("TableRowIcon"))==null?void 0:h.TableRowIcon;return b?n.React.createElement(b,{source:p}):n.React.createElement(n.ReactNative.Image,{source:p,style:{width:24,height:24}})}}))}catch(i){}q()}catch(v){throw Je(),v}}function Je(){if(!D&&!ae.length)return;const e=new Map(A);for(const[r,s]of x)e.set(r,s.entry);D=!1,Pe(void 0,void 0),Be(),Ke();for(const[r,s]of e)te.set(r,s);for(const r of ae.splice(0).reverse())try{r()}catch(s){}const a=k,t=()=>{var r,s,c;if(H=void 0,!(D||a!==k))try{if((s=(r=n.FluxDispatcher).isDispatching)!=null&&s.call(r)){H=setTimeout(t,16);return}const g=new Map;for(const u of e.values()){const v=(c=g.get(u.channelId))!=null?c:[];v.push(u.id),g.set(u.channelId,v)}for(const[u,v]of g)We({type:"MESSAGE_DELETE_BULK",channelId:u,ids:v,__vml_cleanup:!0});te.clear()}catch(g){}};t(),O=Y=void 0}return ue.onLoad=pt,ue.onUnload=Je,ue.settings=Ne,ue})({},vendetta.metro,vendetta.metro.common,vendetta.patcher,vendetta.ui.assets,vendetta.plugin,vendetta.commands,vendetta.storage);
}, "Message Logger");
})()
); }, {"id": "dev.fluttershy2008.message-logger", "legacyManifest": {"name": "Message Logger", "description": "Vencord-style deleted messages, edit history, attachment records and ignore filters for Revenge. Open with /messagelogger.", "version": "2.0.5", "authors": [{"name": "Fluttershy2008-mlp", "id": "753962426407452713"}, {"name": "redstonekasi", "id": "265064055490871297"}], "main": "index.js", "vendetta": {"icon": "ic_audit_log_24px"}, "hash": "5f4758322362d1e87f397e32c80355ab172ea748e82b8d60a772c2647b1738f8"}, "repository": "https://fluttershy2008-mlp.github.io/lol/valenced/index.json", "host": "valenced"}) };
})()
