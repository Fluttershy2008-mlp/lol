(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Valenced API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const hostId = 'valenced';
    const product = 'Valenced';
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the ' + product + ' plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const pathFinders = safe(() => U.discord.utils.modules.finders);
        const source = safe(() => pathFinders.lookupModuleWithImportedPath('../discord_common/js/packages/http-utils/HTTPUtils.tsx')[0])
            ?? rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update ' + product + ' to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        if (props.length && props.every(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL', 'HTTP'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        const found = rawFind(...props);
        if (found) return found;
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.valenced.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    const importedPaths = safe(() => U.discord.utils.modules.finders);
    if (importedPaths?.getModuleWithImportedPath) {
        metro.findByImportedPath = path => safe(() => importedPaths.lookupModuleWithImportedPath(path)[0]);
        metro.getModuleWithImportedPath = (path, callback) => own(importedPaths.getModuleWithImportedPath(path,
            (module, id) => { if (active) callback(module, id); }));
    }
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod(hostId + '.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from ' + product + '.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.[hostId + '.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        host: { id: 'valenced' },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage, version: metadata.version },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createValencedPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createValencedPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}
return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
/*!
omggif 1.0.10
omggif is a JavaScript implementation of a GIF 89a encoder and decoder.

https://github.com/deanm/omggif


(c) Dean McNamee <dean@gmail.com>, 2013.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.


gifenc 1.0.3
The MIT License (MIT)
Copyright (c) 2017 Matt DesLauriers

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.



base64-js 1.5.1
The MIT License (MIT)

Copyright (c) 2014 Jameson Little

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/
const module = { exports: {} };
var St=Object.create;var be=Object.defineProperty;var kt=Object.getOwnPropertyDescriptor;var At=Object.getOwnPropertyNames;var It=Object.getPrototypeOf,_t=Object.prototype.hasOwnProperty;var Ue=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports;}catch(n){throw t=0,n;}},Ft=(e,t)=>{for(var n in t)be(e,n,{get:t[n],enumerable:!0});},Ye=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function"){var _loop=function(r){!_t.call(e,r)&&r!==n&&be(e,r,{get:()=>t[r],enumerable:!(o=kt(t,r))||o.enumerable});};for(var r of At(t)){_loop(r);}}return e;};var Pe=(e,t,n)=>(n=e!=null?St(It(e)):{},Ye(t||!e||!e.__esModule?be(n,"default",{value:e,enumerable:!0}):n,e)),Et=e=>Ye(be({},"__esModule",{value:!0}),e);var Ze=Ue(De=>{"use strict";function Ct(e,t,n,i){var r=0,i=i===void 0?{}:i,a=i.loop===void 0?null:i.loop,l=i.palette===void 0?null:i.palette;if(t<=0||n<=0||t>65535||n>65535)throw new Error("Width/Height invalid.");function u(k){var h=k.length;if(h<2||h>256||h&h-1)throw new Error("Invalid code/color length, must be power of 2 and 2 .. 256.");return h;}e[r++]=71,e[r++]=73,e[r++]=70,e[r++]=56,e[r++]=57,e[r++]=97;var f=0,d=0;if(l!==null){for(var c=u(l);c>>=1;)++f;if(c=1<<f,--f,i.background!==void 0){if(d=i.background,d>=c)throw new Error("Background index out of range.");if(d===0)throw new Error("Background index explicitly passed as 0.");}}if(e[r++]=t&255,e[r++]=t>>8&255,e[r++]=n&255,e[r++]=n>>8&255,e[r++]=(l!==null?128:0)|f,e[r++]=d,e[r++]=0,l!==null)for(var g=0,A=l.length;g<A;++g){var m=l[g];e[r++]=m>>16&255,e[r++]=m>>8&255,e[r++]=m&255;}if(a!==null){if(a<0||a>65535)throw new Error("Loop count invalid.");e[r++]=33,e[r++]=255,e[r++]=11,e[r++]=78,e[r++]=69,e[r++]=84,e[r++]=83,e[r++]=67,e[r++]=65,e[r++]=80,e[r++]=69,e[r++]=50,e[r++]=46,e[r++]=48,e[r++]=3,e[r++]=1,e[r++]=a&255,e[r++]=a>>8&255,e[r++]=0;}var y=!1;this.addFrame=function(k,h,T,I,_,E){if(y===!0&&(--r,y=!1),E=E===void 0?{}:E,k<0||h<0||k>65535||h>65535)throw new Error("x/y invalid.");if(T<=0||I<=0||T>65535||I>65535)throw new Error("Width/Height invalid.");if(_.length<T*I)throw new Error("Not enough pixels for the frame size.");var H=!0,C=E.palette;if(C==null&&(H=!1,C=l),C==null)throw new Error("Must supply either a local or global palette.");for(var N=u(C),G=0;N>>=1;)++G;N=1<<G;var Y=E.delay===void 0?0:E.delay,O=E.disposal===void 0?0:E.disposal;if(O<0||O>3)throw new Error("Disposal out of range.");var z=!1,Z=0;if(E.transparent!==void 0&&E.transparent!==null&&(z=!0,Z=E.transparent,Z<0||Z>=N))throw new Error("Transparent color index.");if((O!==0||z||Y!==0)&&(e[r++]=33,e[r++]=249,e[r++]=4,e[r++]=O<<2|(z===!0?1:0),e[r++]=Y&255,e[r++]=Y>>8&255,e[r++]=Z,e[r++]=0),e[r++]=44,e[r++]=k&255,e[r++]=k>>8&255,e[r++]=h&255,e[r++]=h>>8&255,e[r++]=T&255,e[r++]=T>>8&255,e[r++]=I&255,e[r++]=I>>8&255,e[r++]=H===!0?128|G-1:0,H===!0)for(var J=0,$=C.length;J<$;++J){var V=C[J];e[r++]=V>>16&255,e[r++]=V>>8&255,e[r++]=V&255;}return r=Bt(e,r,G<2?2:G,_),r;},this.end=function(){return y===!1&&(e[r++]=59,y=!0),r;},this.getOutputBuffer=function(){return e;},this.setOutputBuffer=function(k){e=k;},this.getOutputBufferPosition=function(){return r;},this.setOutputBufferPosition=function(k){r=k;};}function Bt(e,t,n,o){e[t++]=n;var r=t++,i=1<<n,a=i-1,l=i+1,u=l+1,f=n+1,d=0,c=0;function g(E){for(;d>=E;)e[t++]=c&255,c>>=8,d-=8,t===r+256&&(e[r]=255,r=t++);}function A(E){c|=E<<d,d+=f,g(8);}var m=o[0]&a,y={};A(i);for(var k=1,h=o.length;k<h;++k){var T=o[k]&a,I=m<<8|T,_=y[I];if(_===void 0){for(c|=m<<d,d+=f;d>=8;)e[t++]=c&255,c>>=8,d-=8,t===r+256&&(e[r]=255,r=t++);u===4096?(A(i),u=l+1,f=n+1,y={}):(u>=1<<f&&++f,y[I]=u++),m=T;}else m=_;}return A(m),A(l),g(1),r+1===t?e[r]=0:(e[r]=t-r-1,e[t++]=0),t;}function bt(e){var t=0;if(e[t++]!==71||e[t++]!==73||e[t++]!==70||e[t++]!==56||(e[t++]+1&253)!==56||e[t++]!==97)throw new Error("Invalid GIF 87a/89a header.");var n=e[t++]|e[t++]<<8,o=e[t++]|e[t++]<<8,r=e[t++],i=r>>7,a=r&7,l=1<<a+1,u=e[t++];e[t++];var f=null,d=null;i&&(f=t,d=l,t+=l*3);var c=!0,g=[],A=0,m=null,y=0,k=null;for(this.width=n,this.height=o;c&&t<e.length;)switch(e[t++]){case 33:switch(e[t++]){case 255:if(e[t]!==11||e[t+1]==78&&e[t+2]==69&&e[t+3]==84&&e[t+4]==83&&e[t+5]==67&&e[t+6]==65&&e[t+7]==80&&e[t+8]==69&&e[t+9]==50&&e[t+10]==46&&e[t+11]==48&&e[t+12]==3&&e[t+13]==1&&e[t+16]==0)t+=14,k=e[t++]|e[t++]<<8,t++;else for(t+=12;;){var h=e[t++];if(!(h>=0))throw Error("Invalid block size");if(h===0)break;t+=h;}break;case 249:if(e[t++]!==4||e[t+4]!==0)throw new Error("Invalid graphics extension block.");var T=e[t++];A=e[t++]|e[t++]<<8,m=e[t++],(T&1)===0&&(m=null),y=T>>2&7,t++;break;case 254:for(;;){var h=e[t++];if(!(h>=0))throw Error("Invalid block size");if(h===0)break;t+=h;}break;default:throw new Error("Unknown graphic control label: 0x"+e[t-1].toString(16));}break;case 44:var I=e[t++]|e[t++]<<8,_=e[t++]|e[t++]<<8,E=e[t++]|e[t++]<<8,H=e[t++]|e[t++]<<8,C=e[t++],N=C>>7,G=C>>6&1,Y=C&7,O=1<<Y+1,z=f,Z=d,J=!1;if(N){var J=!0;z=t,Z=O,t+=O*3;}var $=t;for(t++;;){var h=e[t++];if(!(h>=0))throw Error("Invalid block size");if(h===0)break;t+=h;}g.push({x:I,y:_,width:E,height:H,has_local_palette:J,palette_offset:z,palette_size:Z,data_offset:$,data_length:t-$,transparent_index:m,interlaced:!!G,delay:A,disposal:y});break;case 59:c=!1;break;default:throw new Error("Unknown gif block: 0x"+e[t-1].toString(16));}this.numFrames=function(){return g.length;},this.loopCount=function(){return k;},this.frameInfo=function(V){if(V<0||V>=g.length)throw new Error("Frame index out of range.");return g[V];},this.decodeAndBlitFrameBGRA=function(V,D){var R=this.frameInfo(V),we=R.width*R.height,ae=new Uint8Array(we);Xe(e,R.data_offset,ae,we);var he=R.palette_offset,se=R.transparent_index;se===null&&(se=256);var ee=R.width,ne=n-ee,ge=ee,xe=(R.y*n+R.x)*4,_e=((R.y+R.height)*n+R.x)*4,W=xe,pe=ne*4;R.interlaced===!0&&(pe+=n*4*7);for(var me=8,le=0,Fe=ae.length;le<Fe;++le){var ie=ae[le];if(ge===0&&(W+=pe,ge=ee,W>=_e&&(pe=ne*4+n*4*(me-1),W=xe+(ee+ne)*(me<<1),me>>=1)),ie===se)W+=4;else{var s=e[he+ie*3],x=e[he+ie*3+1],p=e[he+ie*3+2];D[W++]=p,D[W++]=x,D[W++]=s,D[W++]=255;}--ge;}},this.decodeAndBlitFrameRGBA=function(V,D){var R=this.frameInfo(V),we=R.width*R.height,ae=new Uint8Array(we);Xe(e,R.data_offset,ae,we);var he=R.palette_offset,se=R.transparent_index;se===null&&(se=256);var ee=R.width,ne=n-ee,ge=ee,xe=(R.y*n+R.x)*4,_e=((R.y+R.height)*n+R.x)*4,W=xe,pe=ne*4;R.interlaced===!0&&(pe+=n*4*7);for(var me=8,le=0,Fe=ae.length;le<Fe;++le){var ie=ae[le];if(ge===0&&(W+=pe,ge=ee,W>=_e&&(pe=ne*4+n*4*(me-1),W=xe+(ee+ne)*(me<<1),me>>=1)),ie===se)W+=4;else{var s=e[he+ie*3],x=e[he+ie*3+1],p=e[he+ie*3+2];D[W++]=s,D[W++]=x,D[W++]=p,D[W++]=255;}--ge;}};}function Xe(e,t,n,o){for(var r=e[t++],i=1<<r,a=i+1,l=a+1,u=r+1,f=(1<<u)-1,d=0,c=0,g=0,A=e[t++],m=new Int32Array(4096),y=null;;){for(;d<16&&A!==0;)c|=e[t++]<<d,d+=8,A===1?A=e[t++]:--A;if(d<u)break;var k=c&f;if(c>>=u,d-=u,k===i){l=a+1,u=r+1,f=(1<<u)-1,y=null;continue;}else if(k===a)break;for(var h=k<l?k:y,T=0,I=h;I>i;)I=m[I]>>8,++T;var _=I,E=g+T+(h!==k?1:0);if(E>o){console.log("Warning, gif stream longer than expected.");return;}n[g++]=_,g+=T;var H=g;for(h!==k&&(n[g++]=_),I=h;T--;)I=m[I],n[--H]=I&255,I>>=8;y!==null&&l<4096&&(m[l++]=y<<8|_,l>=f+1&&u<12&&(++u,f=f<<1|1)),y=k;}return g!==o&&console.log("Warning, gif stream shorter than expected."),n;}try{De.GifWriter=Ct,De.GifReader=bt;}catch{}});var ft=Ue(Ve=>{var tt=Object.defineProperty,Tt=e=>tt(e,"__esModule",{value:!0}),Mt=(e,t)=>{for(var n in t)tt(e,n,{get:t[n],enumerable:!0});};Tt(Ve);Mt(Ve,{GIFEncoder:()=>lt,applyPalette:()=>Ot,default:()=>Zt,nearestColor:()=>jt,nearestColorIndex:()=>at,nearestColorIndexWithDistance:()=>st,prequantize:()=>Nt,quantize:()=>Pt,snapColorsToPalette:()=>Wt});var Gt={signature:"GIF",version:"89a",trailer:59,extensionIntroducer:33,applicationExtensionLabel:255,graphicControlExtensionLabel:249,imageSeparator:44,signatureSize:3,versionSize:3,globalColorTableFlagMask:128,colorResolutionMask:112,sortFlagMask:8,globalColorTableSizeMask:7,applicationIdentifierSize:8,applicationAuthCodeSize:3,disposalMethodMask:28,userInputFlagMask:2,transparentColorFlagMask:1,localColorTableFlagMask:128,interlaceFlagMask:64,idSortFlagMask:32,localColorTableSizeMask:7};function rt(e=256){var t=0,n=new Uint8Array(e);return{get buffer(){return n.buffer;},reset(){t=0;},bytesView(){return n.subarray(0,t);},bytes(){return n.slice(0,t);},writeByte(r){o(t+1),n[t]=r,t++;},writeBytes(r,i=0,a=r.length){o(t+a);for(var l=0;l<a;l++)n[t++]=r[l+i];},writeBytesView(r,i=0,a=r.byteLength){o(t+a),n.set(r.subarray(i,i+a),t),t+=a;}};function o(r){var i=n.length;if(i>=r)return;var a=1024*1024;r=Math.max(r,i*(i<a?2:1.125)>>>0),i!=0&&(r=Math.max(r,256));var l=n;n=new Uint8Array(r),t>0&&n.set(l.subarray(0,t),0);}}var Ne=12,Je=5003,zt=[0,1,3,7,15,31,63,127,255,511,1023,2047,4095,8191,16383,32767,65535];function Rt(e,t,n,o,r=rt(512),i=new Uint8Array(256),a=new Int32Array(Je),l=new Int32Array(Je)){var u=a.length,f=Math.max(2,o);i.fill(0),l.fill(0),a.fill(-1);var d=0,c=0,g=f+1,A=g,m=!1,y=A,k=(1<<y)-1,h=1<<g-1,T=h+1,I=h+2,_=0,E=n[0],H=0;for(var G=u;G<65536;G*=2)++H;H=8-H,r.writeByte(f),N(h);var C=n.length;for(var _G=1;_G<C;_G++)e:{var Y=n[_G],O=(Y<<Ne)+E,z=Y<<H^E;if(a[z]===O){E=l[z];break e;}var Z=z===0?1:u-z;for(;a[z]>=0;)if(z-=Z,z<0&&(z+=u),a[z]===O){E=l[z];break e;}N(E),E=Y,I<1<<Ne?(l[z]=I++,a[z]=O):(a.fill(-1),I=h+2,m=!0,N(h));}return N(E),N(T),r.writeByte(0),r.bytesView();function N(G){for(d&=zt[c],c>0?d|=G<<c:d=G,c+=y;c>=8;)i[_++]=d&255,_>=254&&(r.writeByte(_),r.writeBytesView(i,0,_),_=0),d>>=8,c-=8;if((I>k||m)&&(m?(y=A,k=(1<<y)-1,m=!1):(++y,k=y===Ne?1<<y:(1<<y)-1)),G==T){for(;c>0;)i[_++]=d&255,_>=254&&(r.writeByte(_),r.writeBytesView(i,0,_),_=0),d>>=8,c-=8;_>0&&(r.writeByte(_),r.writeBytesView(i,0,_),_=0);}}}var Lt=Rt;function nt(e,t,n){return e<<8&63488|t<<2&992|n>>3;}function it(e,t,n,o){return e>>4|t&240|(n&240)<<4|(o&240)<<8;}function ot(e,t,n){return e>>4<<8|t&240|n>>4;}function Te(e,t,n){return e<t?t:e>n?n:e;}function Ce(e){return e*e;}function Qe(e,t,n){var o=0,r=1e100;var i=e[t],a=i.cnt,l=i.ac,u=i.rc,f=i.gc,d=i.bc;for(var c=i.fw;c!=0;c=e[c].fw){var A=e[c],m=A.cnt,y=a*m/(a+m);if(!(y>=r)){var g=0;n&&(g+=y*Ce(A.ac-l),g>=r)||(g+=y*Ce(A.rc-u),!(g>=r)&&(g+=y*Ce(A.gc-f),!(g>=r)&&(g+=y*Ce(A.bc-d),!(g>=r)&&(r=g,o=c))));}}i.err=r,i.nn=o;}function Oe(){return{ac:0,rc:0,gc:0,bc:0,cnt:0,nn:0,fw:0,bk:0,tm:0,mtm:0,err:0};}function Ut(e,t){var n=t==="rgb444"?4096:65536,o=new Array(n),r=e.length;if(t==="rgba4444")for(var i=0;i<r;++i){var a=e[i],l=a>>24&255,u=a>>16&255,f=a>>8&255,d=a&255,c=it(d,f,u,l),g=c in o?o[c]:o[c]=Oe();g.rc+=d,g.gc+=f,g.bc+=u,g.ac+=l,g.cnt++;}else if(t==="rgb444")for(var _i=0;_i<r;++_i){var _a=e[_i],_l=_a>>16&255,_u=_a>>8&255,_f=_a&255,_d=ot(_f,_u,_l),_c=_d in o?o[_d]:o[_d]=Oe();_c.rc+=_f,_c.gc+=_u,_c.bc+=_l,_c.cnt++;}else for(var _i2=0;_i2<r;++_i2){var _a2=e[_i2],_l2=_a2>>16&255,_u2=_a2>>8&255,_f2=_a2&255,_d2=nt(_f2,_u2,_l2),_c2=_d2 in o?o[_d2]:o[_d2]=Oe();_c2.rc+=_f2,_c2.gc+=_u2,_c2.bc+=_l2,_c2.cnt++;}return o;}function Pt(e,t,n={}){var{format:o="rgb565",clearAlpha:r=!0,clearAlphaColor:i=0,clearAlphaThreshold:a=0,oneBitAlpha:l=!1}=n;if(!e||!e.buffer)throw new Error("quantize() expected RGBA Uint8Array data");if(!(e instanceof Uint8Array)&&!(e instanceof Uint8ClampedArray))throw new Error("quantize() expected RGBA Uint8Array data");var u=new Uint32Array(e.buffer),f=n.useSqrt!==!1,d=o==="rgba4444",c=Ut(u,o),g=c.length,A=g-1,m=new Uint32Array(g+1);for(var y=0,h=0;h<g;++h){var $=c[h];if($!=null){var k=1/$.cnt;d&&($.ac*=k),$.rc*=k,$.gc*=k,$.bc*=k,c[y++]=$;}}Ce(t)/y<.022&&(f=!1);for(var h=0;h<y-1;++h)c[h].fw=h+1,c[h+1].bk=h,f&&(c[h].cnt=Math.sqrt(c[h].cnt));f&&(c[h].cnt=Math.sqrt(c[h].cnt));var T,I,_;for(h=0;h<y;++h){Qe(c,h,!1);var E=c[h].err;for(I=++m[0];I>1&&(_=I>>1,!(c[T=m[_]].err<=E));I=_)m[I]=T;m[I]=h;}var H=y-t;for(h=0;h<H;){for(var C;;){var N=m[1];if(C=c[N],C.tm>=C.mtm&&c[C.nn].mtm<=C.tm)break;C.mtm==A?N=m[1]=m[m[0]--]:(Qe(c,N,!1),C.tm=h);var E=c[N].err;for(I=1;(_=I+I)<=m[0]&&(_<m[0]&&c[m[_]].err>c[m[_+1]].err&&_++,!(E<=c[T=m[_]].err));I=_)m[I]=T;m[I]=N;}var G=c[C.nn],Y=C.cnt,O=G.cnt,k=1/(Y+O);d&&(C.ac=k*(Y*C.ac+O*G.ac)),C.rc=k*(Y*C.rc+O*G.rc),C.gc=k*(Y*C.gc+O*G.gc),C.bc=k*(Y*C.bc+O*G.bc),C.cnt+=G.cnt,C.mtm=++h,c[G.bk].fw=G.fw,c[G.fw].bk=G.bk,G.mtm=A;}var z=[];var Z=0;for(h=0;;++Z){var J=Te(Math.round(c[h].rc),0,255),_$=Te(Math.round(c[h].gc),0,255),V=Te(Math.round(c[h].bc),0,255),D=255;d&&(D=Te(Math.round(c[h].ac),0,255),l&&(D=D<=(typeof l=="number"?l:127)?0:255),r&&D<=a&&(J=_$=V=i,D=0));var R=d?[J,_$,V,D]:[J,_$,V];if(Dt(z,R)||z.push(R),(h=c[h].fw)==0)break;}return z;}function Dt(e,t){for(var n=0;n<e.length;n++){var o=e[n],r=o[0]===t[0]&&o[1]===t[1]&&o[2]===t[2],i=o.length>=4&&t.length>=4?o[3]===t[3]:!0;if(r&&i)return!0;}return!1;}function Ge(e,t){var n=0,o;for(o=0;o<e.length;o++){var r=e[o]-t[o];n+=r*r;}return n;}function Me(e,t){return t>1?Math.round(e/t)*t:e;}function Nt(e,{roundRGB:t=5,roundAlpha:n=10,oneBitAlpha:o=null}={}){var r=new Uint32Array(e.buffer);for(var i=0;i<r.length;i++){var a=r[i],l=a>>24&255,u=a>>16&255,f=a>>8&255,d=a&255;l=Me(l,n),o&&(l=l<=(typeof o=="number"?o:127)?0:255),d=Me(d,t),f=Me(f,t),u=Me(u,t),r[i]=l<<24|u<<16|f<<8|d<<0;}}function Ot(e,t,n="rgb565"){if(!e||!e.buffer)throw new Error("quantize() expected RGBA Uint8Array data");if(!(e instanceof Uint8Array)&&!(e instanceof Uint8ClampedArray))throw new Error("quantize() expected RGBA Uint8Array data");if(t.length>256)throw new Error("applyPalette() only works with 256 colors or less");var o=new Uint32Array(e.buffer),r=o.length,i=n==="rgb444"?4096:65536,a=new Uint8Array(r),l=new Array(i),u=n==="rgba4444";if(n==="rgba4444")for(var f=0;f<r;f++){var d=o[f],c=d>>24&255,g=d>>16&255,A=d>>8&255,m=d&255,y=it(m,A,g,c),k=y in l?l[y]:l[y]=Ht(m,A,g,c,t);a[f]=k;}else{var _f3=n==="rgb444"?ot:nt;for(var _d3=0;_d3<r;_d3++){var _c3=o[_d3],_g=_c3>>16&255,_A=_c3>>8&255,_m=_c3&255,_y=_f3(_m,_A,_g),_k=_y in l?l[_y]:l[_y]=Vt(_m,_A,_g,t);a[_d3]=_k;}}return a;}function Ht(e,t,n,o,r){var i=0,a=1e100;for(var l=0;l<r.length;l++){var u=r[l],f=u[3],d=Ae(f-o);if(d>a)continue;var c=u[0];if(d+=Ae(c-e),d>a)continue;var g=u[1];if(d+=Ae(g-t),d>a)continue;var A=u[2];d+=Ae(A-n),!(d>a)&&(a=d,i=l);}return i;}function Vt(e,t,n,o){var r=0,i=1e100;for(var a=0;a<o.length;a++){var l=o[a],u=l[0],f=Ae(u-e);if(f>i)continue;var d=l[1];if(f+=Ae(d-t),f>i)continue;var c=l[2];f+=Ae(c-n),!(f>i)&&(i=f,r=a);}return r;}function Wt(e,t,n=5){if(!e.length||!t.length)return;var o=e.map(a=>a.slice(0,3)),r=n*n,i=e[0].length;for(var a=0;a<t.length;a++){var l=t[a];l.length<i?l=[l[0],l[1],l[2],255]:l.length>i?l=l.slice(0,3):l=l.slice();var u=st(o,l.slice(0,3),Ge),f=u[0],d=u[1];d>0&&d<=r&&(e[f]=l);}}function Ae(e){return e*e;}function at(e,t,n=Ge){var o=1/0,r=-1;for(var i=0;i<e.length;i++){var a=e[i],l=n(t,a);l<o&&(o=l,r=i);}return r;}function st(e,t,n=Ge){var o=1/0,r=-1;for(var i=0;i<e.length;i++){var a=e[i],l=n(t,a);l<o&&(o=l,r=i);}return[r,o];}function jt(e,t,n=Ge){return e[at(e,t,n)];}function lt(e={}){var{initialCapacity:t=4096,auto:n=!0}=e,o=rt(t),r=5003,i=new Uint8Array(256),a=new Int32Array(r),l=new Int32Array(r),u=!1;return{reset(){o.reset(),u=!1;},finish(){o.writeByte(Gt.trailer);},bytes(){return o.bytes();},bytesView(){return o.bytesView();},get buffer(){return o.buffer;},get stream(){return o;},writeHeader:f,writeFrame(d,c,g,A={}){var{transparent:m=!1,transparentIndex:y=0,delay:k=0,palette:h=null,repeat:T=0,colorDepth:I=8,dispose:_=-1}=A,E=!1;if(n?u||(E=!0,f(),u=!0):E=!!A.first,c=Math.max(0,Math.floor(c)),g=Math.max(0,Math.floor(g)),E){if(!h)throw new Error("First frame must include a { palette } option");$t(o,c,g,h,I),et(o,h),T>=0&&Kt(o,T);}var H=Math.round(k/10);qt(o,_,H,m,y);var C=!!h&&!E;Yt(o,c,g,C?h:null),C&&et(o,h),Xt(o,d,c,g,I,i,a,l);}};function f(){ct(o,"GIF89a");}}function qt(e,t,n,o,r){e.writeByte(33),e.writeByte(249),e.writeByte(4),r<0&&(r=0,o=!1);var i,a;o?(i=1,a=2):(i=0,a=0),t>=0&&(a=t&7),a<<=2,e.writeByte(0|a|0|i),ve(e,n),e.writeByte(r||0),e.writeByte(0);}function $t(e,t,n,o,r=8){var l=He(o.length)-1,u=128|r-1<<4|0|l,f=0,d=0;ve(e,t),ve(e,n),e.writeBytes([u,f,d]);}function Kt(e,t){e.writeByte(33),e.writeByte(255),e.writeByte(11),ct(e,"NETSCAPE2.0"),e.writeByte(3),e.writeByte(1),ve(e,t),e.writeByte(0);}function et(e,t){var n=1<<He(t.length);for(var o=0;o<n;o++){var r=[0,0,0];o<t.length&&(r=t[o]),e.writeByte(r[0]),e.writeByte(r[1]),e.writeByte(r[2]);}}function Yt(e,t,n,o){if(e.writeByte(44),ve(e,0),ve(e,0),ve(e,t),ve(e,n),o){var a=He(o.length)-1;e.writeByte(128|a);}else e.writeByte(0);}function Xt(e,t,n,o,r=8,i,a,l){Lt(n,o,t,r,e,i,a,l);}function ve(e,t){e.writeByte(t&255),e.writeByte(t>>8&255);}function ct(e,t){for(var n=0;n<t.length;n++)e.writeByte(t.charCodeAt(n));}function He(e){return Math.max(Math.ceil(Math.log2(e)),1);}var Zt=lt;});var ht=Ue(ze=>{"use strict";ze.byteLength=Qt;ze.toByteArray=tr;ze.fromByteArray=ir;var ue=[],re=[],Jt=typeof Uint8Array<"u"?Uint8Array:Array,We="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";for(Ie=0,dt=We.length;Ie<dt;++Ie)ue[Ie]=We[Ie],re[We.charCodeAt(Ie)]=Ie;var Ie,dt;re[45]=62;re[95]=63;function ut(e){var t=e.length;if(t%4>0)throw new Error("Invalid string. Length must be a multiple of 4");var n=e.indexOf("=");n===-1&&(n=t);var o=n===t?0:4-n%4;return[n,o];}function Qt(e){var t=ut(e),n=t[0],o=t[1];return(n+o)*3/4-o;}function er(e,t,n){return(t+n)*3/4-n;}function tr(e){var t,n=ut(e),o=n[0],r=n[1],i=new Jt(er(e,o,r)),a=0,l=r>0?o-4:o,u;for(u=0;u<l;u+=4)t=re[e.charCodeAt(u)]<<18|re[e.charCodeAt(u+1)]<<12|re[e.charCodeAt(u+2)]<<6|re[e.charCodeAt(u+3)],i[a++]=t>>16&255,i[a++]=t>>8&255,i[a++]=t&255;return r===2&&(t=re[e.charCodeAt(u)]<<2|re[e.charCodeAt(u+1)]>>4,i[a++]=t&255),r===1&&(t=re[e.charCodeAt(u)]<<10|re[e.charCodeAt(u+1)]<<4|re[e.charCodeAt(u+2)]>>2,i[a++]=t>>8&255,i[a++]=t&255),i;}function rr(e){return ue[e>>18&63]+ue[e>>12&63]+ue[e>>6&63]+ue[e&63];}function nr(e,t,n){for(var o,r=[],i=t;i<n;i+=3)o=(e[i]<<16&16711680)+(e[i+1]<<8&65280)+(e[i+2]&255),r.push(rr(o));return r.join("");}function ir(e){for(var t,n=e.length,o=n%3,r=[],i=16383,a=0,l=n-o;a<l;a+=i)r.push(nr(e,a,a+i>l?l:a+i));return o===1?(t=e[n-1],r.push(ue[t>>2]+ue[t<<4&63]+"==")):o===2&&(t=(e[n-2]<<8)+e[n-1],r.push(ue[t>>10]+ue[t>>4&63]+ue[t<<2&63]+"=")),r.join("");}});var hr={};Ft(hr,{default:()=>ur});module.exports=Et(hr);var mt=Pe(Ze(),1),wt=Pe(ft(),1),Be=Pe(ht(),1),{GIFEncoder:or,quantize:ar,applyPalette:sr}=wt.default,yt=e=>/^R0lGOD[dl]h/.test(e),oe=320,je=512*1024,vt=()=>new Promise(e=>setTimeout(e,0));function lr(e){var t=()=>new Error("This GIF download is incomplete. Reopen the GIF or share the original file and try again.");if(e.length<13)throw t();if(!/^GIF8[79]a$/.test(String.fromCharCode(...e.subarray(0,6))))throw new Error("This file could not be read as an animated GIF.");var n=13,o=0,r=!1;function i(f){if(n+f>e.length)throw t();var d=n;return n+=f,d;}function a(f){f&128&&i(3*(1<<(f&7)+1));}function l(){for(;;){var f=e[i(1)];if(f===0)return;i(f);}}for(a(e[10]);n<e.length;){var f=e[i(1)];if(f===59){if(!o||r)throw t();return n===e.length?e:e.subarray(0,n);}if(f===33){var d=e[i(1)];l(),d===249&&(r=!0);}else if(f===44){var _d4=i(9);if(a(e[_d4+8]),i(1),l(),r=!1,++o>250)throw new Error("Use a GIF with 250 frames or fewer.");}else throw new Error("This GIF contains an invalid data block. Share the original GIF file and try again.");}if(!o||r)throw t();var u=new Uint8Array(e.length+1);return u.set(e),u[e.length]=59,u;}function cr(e){var t=lr(e),n;try{n=new mt.GifReader(t);}catch{throw new Error("This file could not be read as an animated GIF.");}var{width:o,height:r}=n,i=n.numFrames();if(!o||!r||o*r>4*1024*1024)throw new Error("This GIF is too large to resize on mobile. Use a GIF below 4 megapixels.");if(!i||i>250)throw new Error("Use a GIF with 250 frames or fewer.");var a=[],l=0;for(var u=0;u<i;u++){var f=n.frameInfo(u);if(!f.width||!f.height||f.x+f.width>o||f.y+f.height>r||f.data_offset+f.data_length>t.length||f.palette_offset==null||f.palette_offset+f.palette_size*3>t.length||t[f.data_offset]<2||t[f.data_offset]>8)throw new Error("This GIF contains an invalid frame.");var d=f.delay<2?100:f.delay*10;l+=d,a.push({...f,delayMs:d});}if(l>5e3)throw new Error("Discord stickers can be at most 5 seconds long. Use a shorter GIF; it has not been trimmed or uploaded.");return{bytes:t,reader:n,width:o,height:r,frames:a,duration:l};}function gt(e,t){if(t.transparent_index!=null||!(e[10]&128))return[0,0,0,0];var n=13+e[11]*3;return[e[n]??0,e[n+1]??0,e[n+2]??0,255];}function pt(e,t,n,o){for(var r=n.y;r<n.y+n.height;r++){var i=(r*t+n.x)*4;for(var a=0;a<n.width;a++,i+=4)e.set(o,i);}}function fr(e,t,n){var o=Math.min(oe/t,oe/n),r=Math.max(1,Math.round(t*o)),i=Math.max(1,Math.round(n*o)),a=Math.floor((oe-r)/2),l=Math.floor((oe-i)/2),u=new Uint8Array(oe*oe*4);for(var f=0;f<i;f++){var d=Math.min(n-1,Math.floor((f+.5)*n/i));for(var c=0;c<r;c++){var g=Math.min(t-1,Math.floor((c+.5)*t/r)),A=(d*t+g)*4,m=((f+l)*oe+c+a)*4;u[m]=e[A],u[m+1]=e[A+1],u[m+2]=e[A+2],u[m+3]=e[A+3];}}return u;}async function dr(e,t,n,o){var{reader:r,width:i,height:a,frames:l}=t,u=new Uint8Array(i*a*4);pt(u,i,{x:0,y:0,width:i,height:a},gt(e,l[0]));var f=or(),d,c;for(var g=0;g<l.length;g++){o(),d?.disposal===2?pt(u,i,d,gt(e,d)):d?.disposal===3&&c&&u.set(c);var A=l[g];c=A.disposal===3?u.slice():null,r.decodeAndBlitFrameRGBA(g,u);var m=fr(u,i,a),y=ar(m,n-1,{format:"rgba4444",oneBitAlpha:!0}),k=[[0,0,0,0],...y.filter(T=>T[3]!==0)];k.length===1&&k.push([0,0,0,255]);var h=sr(m,k,"rgba4444");if(f.writeFrame(h,oe,oe,{palette:k,delay:A.delayMs,repeat:r.loopCount()??-1,transparent:!0,transparentIndex:0,dispose:2}),f.bytesView().length>je)return null;d=A,await vt();}return f.finish(),f.bytesView().length<=je?f.bytes():null;}async function xt(e,t=()=>{}){t(),e=e.replace(/\s/g,"");var n=(0,Be.toByteArray)(e),o=cr(n),{bytes:r}=o;if(o.width===oe&&o.height===oe&&r.length<=je)return{base64:r===n?e:(0,Be.fromByteArray)(r),mimeType:"image/gif",extension:"gif"};if(o.width*o.height*o.frames.length>80*1024*1024)throw new Error("This GIF is too complex to resize on mobile. Use a smaller GIF.");for(var i of[256,128,64]){await vt(),t();var a=await dr(r,o,i,t);if(a)return{base64:(0,Be.fromByteArray)(a),mimeType:"image/gif",extension:"gif"};}throw new Error("This animated GIF is still over 512 KiB after resizing. Use a shorter or simpler GIF.");}var ur=(()=>{"use strict";var e=typeof vendetta<"u"?vendetta:globalThis.vendetta;if(!e?.metro||!e?.patcher)throw new Error("SaveAsSticker needs Revenge's Vendetta plugin support.");var{React:t,ReactNative:n,constants:o}=e.metro.common,r=t.createElement,i="SaveAsStickerPicker",a="save-as-sticker-action",l=512*1024,u=25*1024*1024,f=[5,15,30,60],d=[],c=!1,g=0,A=!1,m=(...s)=>{try{return e.metro.findByProps(...s);}catch{return;}},y=s=>{try{return e.metro.findByStoreName(s);}catch{return;}},k=(...s)=>{for(var x of s)try{var p=e.ui.assets.getAssetIDByName(x);if(p!=null)return p;}catch{}},h=(...s)=>e.logger?.error?.("[SaveAsSticker]",...s),T=s=>{try{e.ui.toasts.showToast(s,k("StickerIcon","ic_sticker_24px"));}catch{console.log("[SaveAsSticker]",s);}},I=m("openLazy","hideActionSheet"),_=m("ActionSheetRow")?.ActionSheetRow,E=e.ui.components?.Forms??{},H=m("ActionSheetTitleHeader")?.ActionSheetTitleHeader??m("BottomSheetTitleHeader")?.BottomSheetTitleHeader,C=m("ActionSheetCloseButton")?.ActionSheetCloseButton,N=m("GuildIconSizes"),G=N?.default,Y=N?.GuildIconSizes,O=m("BottomSheetFlatList")?.BottomSheetFlatList??m("BottomSheetScrollView")?.BottomSheetFlatList??n.FlatList,z=m("ActionSheet")?.ActionSheet;if(!z)try{z=e.metro.find(s=>s?.render?.name==="ActionSheet");}catch{}function Z(s){var x=String(s||"sticker").replace(/\.[a-z0-9]{1,6}$/i,"").replace(/[\u0000-\u001f]/g,"").trim().slice(0,30);return x.length>=2?x:"sticker";}function J(s,x=!1){if(!s)return null;var p=String(s.content_type??s.contentType??s.mimeType??""),w=s.mediaType??s.type,S=[s.url,s.sourceURI,s.mediaUrl,s.uri,s.proxy_url,s.proxyURL,s.image?.url,s.thumbnail?.url,s.video?.url].find(U=>typeof U=="string"&&/\.gif(?:[?#]|$)/i.test(U)),M=p==="image/gif"||!!S;if(!M&&(/^(video|audio)\//i.test(p)||/^(video|audio|file)$/i.test(String(w))))return null;var B=S??s.mediaUrl??s.sourceURI??s.url??s.uri??s.proxy_url??s.proxyURL;if(S&&(B=B.replace(/([?&])format=(?:webp|png|jpe?g|mp4)(?=&|$)/gi,"$1").replace(/([?&])animated=false(?=&|$)/gi,"$1").replace(/\?&/,"?").replace(/&&+/g,"&").replace(/[?&]$/,"")),typeof B!="string"||!/^https:\/\//i.test(B))return null;var L=s.filename??s.name??B.split(/[?#]/)[0].split("/").pop()??"sticker";return!x&&w!=="image"&&!p.startsWith("image/")&&!/\.(png|apng|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i.test(L)&&!/\.(png|apng|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i.test(B)?null:{url:B,filename:L,contentType:M?"image/gif":p,id:s.id??s.attachmentId};}function $(...s){var x=s.flatMap(w=>{if(!w||typeof w!="object")return[];var v=w.analyticsLocation;return v&&typeof v=="object"?[w,v]:[w];});for(var w of x)if(w.selectedMedia){var v=w.selectedMedia,S=J({...v.source,...v},v.mediaType==="image");return S?[S]:[];}for(var _w of x){var _v=_w.source;if(_w.syncer?.sources){var _S=_w.syncer.index?.value??_w.syncer.index??0;_v=_w.syncer.sources[_S];}if(Array.isArray(_v)&&(_v=_v[0]),_v){var _S2=J(_v);return _S2?[_S2]:[];}}var p=[];for(var _w2 of x){for(var _v2 of _w2.message?.attachments??[]){var _S3=J(_v2);_S3&&p.push(_S3);}for(var _v3 of _w2.message?.embeds??[])for(var _S4 of[_v3.image,...(_v3.images??[]),_v3.type==="image"?_v3:null,_v3.type==="gifv"&&/\.gif(?:[?#]|$)/i.test(_v3.video?.url??"")?{..._v3.video,contentType:"image/gif"}:null,_v3.type==="gifv"&&/\.gif(?:[?#]|$)/i.test(_v3.thumbnail?.url??"")?_v3.thumbnail:null]){var M=J(_S4,!0);M&&p.push(M);}}return p.filter((w,v)=>p.findIndex(S=>S.url===w.url)===v);}function V(s){if(!s?.id||s.unavailable)return!1;var x=y("UserStore")?.getCurrentUser?.()?.id;if(x&&(s.ownerId===x||s.owner_id===x))return!0;var p=o?.Permissions?.CREATE_GUILD_EXPRESSIONS??1n<<43n;try{return!!y("PermissionStore")?.can?.(p,s);}catch{return!1;}}function D(s){var x=Number(s.premiumTier??s.premium_tier??0),p=s.features,w=Array.isArray(p)?p.includes("MORE_STICKERS"):p?.has?.("MORE_STICKERS"),v=Number(s.premiumFeatures?.additionalStickerSlots??s.premium_features?.additional_sticker_slots??0),S=w&&x===3?120:f[x]??f[0],M=Number(s.maxStickers??s.max_stickers??0),B=Math.max(S+(Number.isFinite(v)?Math.max(0,v):0),M||0),U=(y("GuildStickersStore")??y("StickersStore")??y("StickerStore"))?.getStickersByGuildId?.(s.id)??s.stickers;return U&&!Array.isArray(U)&&(U=Object.values(U)),{max:B,used:Array.isArray(U)?U.length:null};}function R(){return Object.values(y("GuildStore")?.getGuilds?.()??{}).filter(V).sort((s,x)=>String(s.name).localeCompare(String(x.name)));}function we(s){var x=Number(s?.body?.code??s?.code);if(x===50013)return"You need Create Expressions permission in this server.";if(x===30039)return"This server has no free sticker slots. Choose another server.";for(var p of[s?.body?.message,s?.message,s?.text])if(!(typeof p!="string"||!p))try{return JSON.parse(p)?.message??p;}catch{return p;}return"Discord could not upload the sticker. Please try again.";}function ae(){var s=m("writeFile","readFile","removeFile");if(s)return s;for(var x of["NativeFileModule","RTNFileManager","DCDFileManager"])try{var p=n.NativeModules?.[x]??globalThis.nativeModuleProxy?.[x];if(p?.writeFile)return p;}catch{}}function he(s){return new Promise((x,p)=>{var w=new FileReader();w.onerror=()=>p(w.error??new Error("Could not read the image.")),w.onload=()=>x(String(w.result).split(",")[1]),w.readAsDataURL(s);});}function se(s){return Math.floor(s.length*3/4)-(s.endsWith("==")?2:s.endsWith("=")?1:0);}function ee(s){var x="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",p=[],w=0,v=0;for(var B of s.slice(0,44)){var L=x.indexOf(B);if(L<0)break;v=v<<6|L,w+=6,w>=8&&(w-=8,p.push(v>>>w&255));}var S=[137,80,78,71,13,10,26,10];if(p.length<24||S.some((B,L)=>p[L]!==B)||String.fromCharCode(...p.slice(12,16))!=="IHDR")return null;var M=B=>p[B]*16777216+p[B+1]*65536+p[B+2]*256+p[B+3];return{width:M(16),height:M(20)};}function ne(s){if(typeof s!="string"||!s)throw new Error("Discord did not return a local image path.");return /^(file|content):\/\//.test(s)?s:"file://"+s;}async function ge(s,x){var p=ae();if(!p?.writeFile||!p?.removeFile)throw new Error("Discord's image file module is unavailable on this build.");var w=[],v=m("launchCropper","cleanSingle")??m("launchCropper"),S;async function M(){if(S&&v?.cleanSingle)try{await v.cleanSingle(S);}catch{}for(var L of w)try{await p.removeFile("cache",L);}catch{}}var B=()=>{if(!c||g!==x)throw Object.assign(new Error("Cancelled"),{code:"E_PICKER_CANCELLED"});};try{var L=s.url,U=m("maybeRefreshAttachmentUrl");if(/^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\//i.test(L))try{L=(await U?.maybeRefreshAttachmentUrl?.(L))||L;}catch{}var j=await(e.utils?.safeFetch??fetch)(L,{},2e4);if(!j.ok)throw new Error("Image download failed (HTTP "+j.status+"). Reopen the image and try again.");if(Number(j.headers?.get?.("content-length"))>u)throw new Error("Choose an image smaller than 25 MB.");var ce=await j.blob();if(ce.size>u)throw new Error("Choose an image smaller than 25 MB.");var P=await he(ce);if(B(),!P)throw new Error("The image is empty.");var b="save-as-sticker-"+Date.now()+"-"+Math.random().toString(36).slice(2);if(yt(P)){T("Preparing animated GIF\u2026");var fe=await xt(P,B);B();var Se=b+"-sticker.gif";w.push(Se);var ke=ne(await p.writeFile("cache",Se,fe.base64,"base64"));return B(),{uri:ke,mimeType:fe.mimeType,cleanup:M};}if(s.contentType==="image/gif"||ce.type==="image/gif")throw new Error("This link returned a video or still preview. Share the original .gif file and try again.");var X=ee(P);if(!X||X.width!==320||X.height!==320||se(P)>l){if(!v?.launchCropper)throw new Error("Image cropping is unavailable. Choose a 320\xD7320 PNG under 512 KiB.");var _fe=ce.type||s.contentType||"image/png",_Se=/jpeg/i.test(_fe)?"jpg":/webp/i.test(_fe)?"webp":/gif/i.test(_fe)?"gif":/avif/i.test(_fe)?"avif":"png",_ke=b+"."+_Se;w.push(_ke);var Ee=ne(await p.writeFile("cache",_ke,P,"base64"));B();var F=await v.launchCropper({uri:Ee,width:320,height:320,mimeType:"image/png",includeBase64:!0,freeStyleCropEnabled:!1});if(S=F?.path??F?.uri,B(),P=F?.data??F?.base64,!P&&S&&p.readFile&&(P=await p.readFile(S.replace(/^file:\/\//,""),"base64")),typeof P!="string"||!P)throw new Error("The cropper did not return an image.");P=P.replace(/^data:[^,]*,/,"").replace(/\s/g,"");}var Q=ee(P);if(!Q||Q.width!==320||Q.height!==320)throw new Error("The cropper did not produce a 320\xD7320 PNG. The sticker was not uploaded.");if(se(P)>l)throw new Error("The cropped sticker is over 512 KiB. Try a simpler image.");var te=b+"-sticker.png";w.push(te);var ye=ne(await p.writeFile("cache",te,P,"base64"));return B(),{uri:ye,mimeType:"image/png",cleanup:M};}catch(L){throw await M(),L;}}async function xe(s,x,p){if(A||!c)return;A=!0;var w=g,v;try{if(p.length<2||p.length>30)throw new Error("Use a sticker name between 2 and 30 characters.");var S=m("createGuildSticker");if(!S?.createGuildSticker)throw new Error("Discord's sticker upload module is unavailable on this build.");if(I.hideActionSheet(i),n.Keyboard?.dismiss?.(),await new Promise(U=>setTimeout(U,300)),!c||g!==w||(T("Preparing your sticker\u2026"),v=await ge(x,w),!c||g!==w))return;var M=y("GuildStore")?.getGuild?.(s.id)??s;if(!V(M))throw new Error("You no longer have Create Expressions permission in this server.");var B=D(M);if(B.used!=null&&B.used>=B.max)throw new Error("This server has no free sticker slots. Choose another server.");T("Adding sticker to "+s.name+"\u2026");var L=await S.createGuildSticker({guildId:s.id,name:p,tags:"slight_smile",description:"",uri:v.uri,mimeType:v.mimeType,platform:"mobile",originalMd5:null});if(!L?.id&&!L?.body?.id)throw new Error("Discord did not confirm the upload. Check the server's stickers before trying again.");c&&g===w&&T("Sticker added to "+s.name);}catch(S){if(S?.code==="E_PICKER_CANCELLED"||/cancel/i.test(String(S?.message??"")))return;if(h("Upload failed",S),c&&g===w){var _M=we(S);n.Alert?.alert?n.Alert.alert("Sticker could not be added",_M):T(_M);}}finally{await v?.cleanup?.(),A=!1;}}function _e({images:s}){var[x,p]=t.useState(s.length===1?s[0]:null),[w,v]=t.useState(null),[S,M]=t.useState(Z(s[0]?.filename)),[,B]=t.useState(0),L=n.Appearance?.getColorScheme?.()!=="light",U={text:L?"#f2f3f5":"#1e1f22",muted:L?"#b5bac1":"#4e5058",input:L?"#1e1f22":"#e3e5e8"};t.useEffect(()=>{var F=[y("GuildStore"),y("PermissionStore"),y("GuildStickersStore"),y("StickersStore")].filter(Boolean),K=()=>B(q=>q+1);return F.forEach(q=>q.addChangeListener?.(K)),()=>F.forEach(q=>q.removeChangeListener?.(K));},[]);var j=(F,K={})=>r(n.Text,{style:{color:U.text,fontSize:16,...K}},F),ce=(F,K,q=!1)=>r(n.Pressable,{accessibilityRole:"button",accessibilityLabel:F,disabled:q,onPress:K,style:{padding:14,borderRadius:8,backgroundColor:q?"#555967":"#5865f2",marginTop:12}},j(F,{color:"#ffffff",fontWeight:"600",textAlign:"center"})),P={color:U.text,backgroundColor:U.input,borderRadius:8,padding:12,fontSize:16,marginTop:10},b=()=>I.hideActionSheet(i),X=x?r(n.Image,{source:{uri:x.url},resizeMode:"contain",accessibilityLabel:"Sticker preview",style:{width:26,height:26,marginRight:12}}):null,Q=w?"Sticker name":x?"Saving "+Z(x.filename):"Choose image",te=C?r(C,{onPress:b,accessibilityLabel:"Close"}):r(n.Pressable,{onPress:b,accessibilityRole:"button",accessibilityLabel:"Close",hitSlop:10,style:{width:40,height:40,alignItems:"center",justifyContent:"center"}},j("\xD7",{fontSize:32,lineHeight:36})),ye=H?r(H,{title:Q,leading:X,trailing:te}):r(n.View,{style:{flexDirection:"row",alignItems:"center",paddingHorizontal:28,minHeight:72}},X,r(n.Text,{numberOfLines:1,style:{flex:1,color:U.text,fontSize:20,fontWeight:"600",textAlign:"center",paddingHorizontal:8}},Q),te),fe=Math.min(640,(n.Dimensions?.get?.("window")?.height??800)*.62);function Se(F){if(G)return r(G,{guild:F,size:Y?.MEDIUM,animate:!1});if(F.icon)return r(n.Image,{source:{uri:"https://cdn.discordapp.com/icons/"+F.id+"/"+F.icon+".png?size=96"},style:{width:44,height:44,borderRadius:14},resizeMode:"cover"});var K=String(F.name).trim().split(/\s+/).map(q=>q[0]).join("").slice(0,3);return r(n.View,{style:{width:44,height:44,borderRadius:14,backgroundColor:"#5865f2",alignItems:"center",justifyContent:"center"}},j(K,{color:"#ffffff",fontWeight:"600"}));}function ke(F){var K=D(F),q=K.used!=null&&K.used>=K.max,de=q?"No slots available":K.used==null?"Check slots on upload":void 0,qe=()=>{var Re=y("GuildStore")?.getGuild?.(F.id)??F,Le=D(Re);!V(Re)||Le.used!=null&&Le.used>=Le.max||v(Re);},$e=k("ic_add_24px","PlusSmallIcon","PlusIcon"),Ke=E.FormIcon&&$e!=null?r(E.FormIcon,{source:$e,style:{opacity:1}}):j("+",{color:U.muted,fontSize:30,fontWeight:"300"});return E.FormRow?r(E.FormRow,{key:F.id,leading:Se(F),label:F.name,subLabel:de,trailing:Ke,disabled:q,onPress:qe,accessibilityLabel:F.name,accessibilityRole:"button",accessibilityState:{disabled:q}}):r(n.Pressable,{key:F.id,accessibilityRole:"button",accessibilityLabel:F.name,accessibilityState:{disabled:q},disabled:q,onPress:qe,style:{minHeight:80,paddingHorizontal:32,flexDirection:"row",alignItems:"center",opacity:q?.4:1}},Se(F),r(n.View,{style:{flex:1,marginLeft:18,marginRight:16}},j(F.name,{fontWeight:"600",fontSize:18}),de?j(de,{color:U.muted,fontSize:13,marginTop:3}):null),Ke);}if(x&&!w){var F=R(),K=r(n.View,{style:{padding:24}},j("No servers available. You need Create Expressions permission to add a sticker.",{color:U.muted,fontSize:14})),q=O?r(O,{style:{flex:1},contentContainerStyle:{paddingBottom:32},data:F,renderItem:({item:de})=>ke(de),keyExtractor:de=>de.id,extraData:F.map(de=>de.id+":"+D(de).used).join(","),ListEmptyComponent:K}):r(n.ScrollView,{style:{flex:1},contentContainerStyle:{paddingBottom:32}},F.length?F.map(ke):K);return r(z,{scrollable:!0},r(n.View,{style:{height:fe}},ye,q));}var Ee;if(!x)Ee=s.map((F,K)=>r(n.Pressable,{key:F.url,accessibilityRole:"button",accessibilityLabel:"Use image "+(K+1),onPress:()=>{p(F),M(Z(F.filename));},style:{flexDirection:"row",alignItems:"center",gap:12,paddingVertical:10}},r(n.Image,{source:{uri:F.url},style:{width:64,height:64},resizeMode:"contain"}),j(F.filename,{flex:1})));else{var _F=S.trim().length>=2&&S.trim().length<=30&&!/[\u0000-\u001f]/.test(S);Ee=r(n.View,null,r(n.Image,{source:{uri:x.url},style:{height:128,width:"100%",marginBottom:12},resizeMode:"contain"}),j("Server: "+w.name,{fontWeight:"600"}),j("Sticker name",{marginTop:12}),r(n.TextInput,{value:S,onChangeText:M,maxLength:30,placeholder:"Sticker name",placeholderTextColor:U.muted,style:P,selectTextOnFocus:!0}),j(x.contentType==="image/gif"?"GIFs keep their animation and resize automatically. Maximum 5 seconds and 512 KiB.":"Crop to 320\xD7320 if needed. GIFs keep their animation.",{color:U.muted,fontSize:13,marginTop:12}),ce("Add sticker",()=>{xe(w,x,S.trim());},!_F),ce("Choose another server",()=>v(null)));}return r(z,{scrollable:!0},ye,r(n.ScrollView,{keyboardShouldPersistTaps:"handled",style:{maxHeight:fe},contentContainerStyle:{padding:20,paddingBottom:40}},Ee));}function W(s,x){if(!c)return;if(A){T("A sticker upload is already in progress.");return;}if(!z){T("The server picker is unavailable on this Discord build.");return;}I.hideActionSheet(x);var p=e.ui.components?.ErrorBoundary,w=()=>{var v=r(_e,{images:s});return p?r(p,null,v):v;};I.openLazy(Promise.resolve({default:w}),i,{});}function pe(s,x){var p=k("StickerIcon","ic_sticker_24px");return r(_,{key:a,label:"Save as Sticker",icon:_.Icon&&p!=null?r(_.Icon,{source:p}):void 0,iconSource:_.Icon?void 0:p,onPress:()=>W(s,x)});}function me(s,x,p){var w=null,v=-1,S=!1,M=b=>String(b?.props?.label??b?.props?.message??""),B=b=>b?.props&&typeof b.props.onPress=="function"&&(b.type===_||b.props.label!=null||b.props.message!=null);function L(b,X=0){if(!(!b||X>40))if(Array.isArray(b)){var Q=b.filter(B);if(Q.length){var te=Q.some(ye=>/save image/i.test(M(ye)))?1e3:Q.some(ye=>/copy image link/i.test(M(ye)))?900:10;te+Q.length>v&&(w=b,v=te+Q.length);}b.forEach(te=>L(te,X+1));}else b.props&&((b.key===a||M(b)==="Save as Sticker")&&(S=!0),L(b.props.children,X+1));}if(L(s),S||!w)return s;var U=pe(x,p),j=w.findIndex(b=>/save image/i.test(M(b))),ce=j>=0?j+1:w.length;function P(b){if(b===w)return[...w.slice(0,ce),U,...w.slice(ce)];if(Array.isArray(b)){var X=b.map(P);return X.some((Q,te)=>Q!==b[te])?X:b;}if(b?.props?.children!=null){var _X=P(b.props.children);return _X!==b.props.children?t.cloneElement(b,{children:_X}):b;}return b;}return P(s);}function le(s,x,p,w){var v=(S,M)=>{if(!c||g!==w)return M;try{var B=$(S,x);return B.length?me(M,B,p):M;}catch(B){return h("Could not add image menu action",B),M;}};return typeof s=="function"&&!s.prototype?.isReactComponent?function(...M){return v(M[0],s.apply(this,M));}:s?.$$typeof===Symbol.for("react.memo")?t.memo(le(s.type,x,p,w),s.compare):s?.$$typeof===Symbol.for("react.forward_ref")?t.forwardRef((S,M)=>v(S,s.render(S,M))):s;}function Fe(){if(!I?.openLazy||!_||!z||!y("GuildStore"))throw new Error("SaveAsSticker: required menu modules were not found on this Discord build.");c||(c=!0,g++,d.push(e.patcher.before("openLazy",I,s=>{var[x,p,w]=s;if(p!=="MessageLongPressActionSheet"&&p!=="MediaShareActionSheet"||!x?.then)return;var v=g;s[0]=Promise.resolve(x).then(S=>!c||v!==g||!S?.default?S:{...S,default:le(S.default,w,p,v)});})),T("SaveAsSticker 1.3.2 enabled"));}function ie(){c=!1,g++;for(var s of d.splice(0).reverse())try{s();}catch{}try{I?.hideActionSheet?.(i);}catch{}}return{onLoad:Fe,onUnload:ie};})();
return module.exports.default;
})()
}, "SaveAsSticker");
})()
); }, {"id": "dev.fluttershy2008.save-as-sticker", "legacyManifest": {"name": "SaveAsSticker", "description": "Save images and animated GIFs as server stickers. Pick a server, name your sticker, and automatically resize GIFs while keeping them animated.", "version": "1.3.4", "authors": [{"name": "Fluttershy2008-mlp"}], "main": "index.js", "vendetta": {"icon": "ic_sticker_24px"}, "hash": "954342bc9a9282b565ec9ad1da75b453032b7e29224d511e122ad78278398d78"}, "repository": "https://fluttershy2008-mlp.github.io/lol/valenced/index.json", "host": "valenced", "version": "1.0.0-beta2"}) };
})()
