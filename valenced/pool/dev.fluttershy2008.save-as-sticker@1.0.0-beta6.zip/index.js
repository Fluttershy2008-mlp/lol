(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Valenced API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const hostId = 'valenced';
    const product = 'Valenced';
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the ' + product + ' plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const pathFinders = safe(() => U.discord.utils.modules.finders);
        const source = safe(() => pathFinders.lookupModuleWithImportedPath('../discord_common/js/packages/http-utils/HTTPUtils.tsx')[0])
            ?? rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
// SPDX-License-Identifier: MIT
// Replaces openLegacyPage in the Valenced expression picker package. Settings routes
// belong to SettingsNavigator; they are not routes of the root Chat navigator.
// Uses the enclosing adapter's scoped timers, route and disposal ownership.
function openLegacyPage(navigation, params) {
    if (!active) return;
    if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
    const settings = U.discord.modules?.settings;
    if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
        throw new Error('Update Valenced to open this plugin page.');
    let cancelled = false, timer, unsubscribe, readySubscription, loadingSubscription;
    const live = () => active && !cancelled && params.__expressionOpen?.() !== false;
    const cancel = own(() => {
        cancelled = true;
        clearTimeoutScoped(timer);
        unsubscribe?.(); readySubscription?.(); loadingSubscription?.();
    });
    const navigate = () => {
        if (!live()) return;
        timer = setTimeoutScoped(() => {
            if (!live()) return;
            loadingSubscription?.(); loadingSubscription = undefined;
            navigation.navigate('settings', { screen: legacyRoute, params });
        }, 0);
    };
    const registered = () => {
        if (!live()) return;
        if (!routeRegistered) {
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
        }
        navigate();
    };
    const start = () => {
        if (!live()) return;
        // Open the real Settings navigator first when its lazy modules have not
        // loaded. Waiting for their registration without doing this deadlocks.
        if (settings.isSettingsModulesLoaded?.() === false) {
            // Back during a cold Settings load cancels this opening. A module
            // becoming available later must not navigate the user away again.
            if (navigation.getRootState && navigation.addListener) {
                let entered = false;
                const changed = () => {
                    let state = navigation.getRootState(), loading = false;
                    for (let depth = 0; depth < 12 && state?.routes?.length; depth++) {
                        const route = state.routes[state.index ?? state.routes.length - 1];
                        if (route?.params?.__expressionLoading === params.__expressionPage) loading = true;
                        state = route?.state;
                    }
                    if (loading) entered = true;
                    else if (entered && live()) { params.__expressionCancel?.(); cancel(); }
                };
                const remove = navigation.addListener('state', changed);
                loadingSubscription = typeof remove === 'function' ? remove : () => navigation.removeListener?.('state', changed);
            }
            navigation.navigate('settings', { __expressionLoading: params.__expressionPage });
        }
        unsubscribe = settings.onSettingsModulesLoaded(registered);
    };
    if (navigation.isReady?.() === false && navigation.addListener) {
        const ready = () => { readySubscription?.(); start(); };
        const remove = navigation.addListener('ready', ready);
        readySubscription = typeof remove === 'function' ? remove : () => navigation.removeListener?.('ready', ready);
    } else start();
    return cancel;
}

    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        if (props.length && props.every(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL', 'HTTP'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        const found = rawFind(...props);
        if (found) return found;
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.valenced.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    const importedPaths = safe(() => U.discord.utils.modules.finders);
    if (importedPaths?.getModuleWithImportedPath) {
        metro.findByImportedPath = path => safe(() => importedPaths.lookupModuleWithImportedPath(path)[0]);
        metro.getModuleWithImportedPath = (path, callback) => own(importedPaths.getModuleWithImportedPath(path,
            (module, id) => { if (active) callback(module, id); }));
    }
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod(hostId + '.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from ' + product + '.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.[hostId + '.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        host: { id: 'valenced' },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage, version: metadata.version },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createValencedPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createValencedPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}

return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
/*!
omggif 1.0.10
omggif is a JavaScript implementation of a GIF 89a encoder and decoder.

https://github.com/deanm/omggif


(c) Dean McNamee <dean@gmail.com>, 2013.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.


gifenc 1.0.3
The MIT License (MIT)
Copyright (c) 2017 Matt DesLauriers

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.



base64-js 1.5.1
The MIT License (MIT)

Copyright (c) 2014 Jameson Little

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


fast-png 8.0.0
MIT License

Copyright (c) 2015 Michaël Zasso

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


iobuffer 6.0.1
The MIT License (MIT)

Copyright (c) 2015 Michaël Zasso

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


jpeg-js 0.4.4
Copyright (c) 2014, Eugene Ware
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Eugene Ware nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY EUGENE WARE ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL EUGENE WARE BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


fflate 0.8.3
MIT License

Copyright (c) 2026 Arjun Barrett

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/
const module = { exports: {} };
var Qn=Object.create;var At=Object.defineProperty;var Jn=Object.getOwnPropertyDescriptor;var ei=Object.getOwnPropertyNames;var ti=Object.getPrototypeOf,ri=Object.prototype.hasOwnProperty;var ni=(e,t,r)=>t in e?At(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;var ut=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports;}catch(r){throw t=0,r;}},ii=(e,t)=>{for(var r in t)At(e,r,{get:t[r],enumerable:!0});},Ir=(e,t,r,n)=>{if(t&&typeof t=="object"||typeof t=="function"){var _loop=function(i){!ri.call(e,i)&&i!==r&&At(e,i,{get:()=>t[i],enumerable:!(n=Jn(t,i))||n.enumerable});};for(var i of ei(t)){_loop(i);}}return e;};var bt=(e,t,r)=>(r=e!=null?Qn(ti(e)):{},Ir(t||!e||!e.__esModule?At(r,"default",{value:e,enumerable:!0}):r,e)),oi=e=>Ir(At({},"__esModule",{value:!0}),e);var ye=(e,t,r)=>ni(e,typeof t!="symbol"?t+"":t,r);var Mr=ut(Jt=>{"use strict";function si(e,t,r,o){var i=0,o=o===void 0?{}:o,s=o.loop===void 0?null:o.loop,a=o.palette===void 0?null:o.palette;if(t<=0||r<=0||t>65535||r>65535)throw new Error("Width/Height invalid.");function c(E){var x=E.length;if(x<2||x>256||x&x-1)throw new Error("Invalid code/color length, must be power of 2 and 2 .. 256.");return x;}e[i++]=71,e[i++]=73,e[i++]=70,e[i++]=56,e[i++]=57,e[i++]=97;var f=0,l=0;if(a!==null){for(var h=c(a);h>>=1;)++f;if(h=1<<f,--f,o.background!==void 0){if(l=o.background,l>=h)throw new Error("Background index out of range.");if(l===0)throw new Error("Background index explicitly passed as 0.");}}if(e[i++]=t&255,e[i++]=t>>8&255,e[i++]=r&255,e[i++]=r>>8&255,e[i++]=(a!==null?128:0)|f,e[i++]=l,e[i++]=0,a!==null)for(var g=0,b=a.length;g<b;++g){var S=a[g];e[i++]=S>>16&255,e[i++]=S>>8&255,e[i++]=S&255;}if(s!==null){if(s<0||s>65535)throw new Error("Loop count invalid.");e[i++]=33,e[i++]=255,e[i++]=11,e[i++]=78,e[i++]=69,e[i++]=84,e[i++]=83,e[i++]=67,e[i++]=65,e[i++]=80,e[i++]=69,e[i++]=50,e[i++]=46,e[i++]=48,e[i++]=3,e[i++]=1,e[i++]=s&255,e[i++]=s>>8&255,e[i++]=0;}var v=!1;this.addFrame=function(E,x,A,u,y,d){if(v===!0&&(--i,v=!1),d=d===void 0?{}:d,E<0||x<0||E>65535||x>65535)throw new Error("x/y invalid.");if(A<=0||u<=0||A>65535||u>65535)throw new Error("Width/Height invalid.");if(y.length<A*u)throw new Error("Not enough pixels for the frame size.");var I=!0,m=d.palette;if(m==null&&(I=!1,m=a),m==null)throw new Error("Must supply either a local or global palette.");for(var B=c(m),w=0;B>>=1;)++w;B=1<<w;var P=d.delay===void 0?0:d.delay,N=d.disposal===void 0?0:d.disposal;if(N<0||N>3)throw new Error("Disposal out of range.");var L=!1,$=0;if(d.transparent!==void 0&&d.transparent!==null&&(L=!0,$=d.transparent,$<0||$>=B))throw new Error("Transparent color index.");if((N!==0||L||P!==0)&&(e[i++]=33,e[i++]=249,e[i++]=4,e[i++]=N<<2|(L===!0?1:0),e[i++]=P&255,e[i++]=P>>8&255,e[i++]=$,e[i++]=0),e[i++]=44,e[i++]=E&255,e[i++]=E>>8&255,e[i++]=x&255,e[i++]=x>>8&255,e[i++]=A&255,e[i++]=A>>8&255,e[i++]=u&255,e[i++]=u>>8&255,e[i++]=I===!0?128|w-1:0,I===!0)for(var oe=0,W=m.length;oe<W;++oe){var X=m[oe];e[i++]=X>>16&255,e[i++]=X>>8&255,e[i++]=X&255;}return i=ai(e,i,w<2?2:w,y),i;},this.end=function(){return v===!1&&(e[i++]=59,v=!0),i;},this.getOutputBuffer=function(){return e;},this.setOutputBuffer=function(E){e=E;},this.getOutputBufferPosition=function(){return i;},this.setOutputBufferPosition=function(E){i=E;};}function ai(e,t,r,n){e[t++]=r;var i=t++,o=1<<r,s=o-1,a=o+1,c=a+1,f=r+1,l=0,h=0;function g(d){for(;l>=d;)e[t++]=h&255,h>>=8,l-=8,t===i+256&&(e[i]=255,i=t++);}function b(d){h|=d<<l,l+=f,g(8);}var S=n[0]&s,v={};b(o);for(var E=1,x=n.length;E<x;++E){var A=n[E]&s,u=S<<8|A,y=v[u];if(y===void 0){for(h|=S<<l,l+=f;l>=8;)e[t++]=h&255,h>>=8,l-=8,t===i+256&&(e[i]=255,i=t++);c===4096?(b(o),c=a+1,f=r+1,v={}):(c>=1<<f&&++f,v[u]=c++),S=A;}else S=y;}return b(S),b(a),g(1),i+1===t?e[i]=0:(e[i]=t-i-1,e[t++]=0),t;}function li(e){var t=0;if(e[t++]!==71||e[t++]!==73||e[t++]!==70||e[t++]!==56||(e[t++]+1&253)!==56||e[t++]!==97)throw new Error("Invalid GIF 87a/89a header.");var r=e[t++]|e[t++]<<8,n=e[t++]|e[t++]<<8,i=e[t++],o=i>>7,s=i&7,a=1<<s+1,c=e[t++];e[t++];var f=null,l=null;o&&(f=t,l=a,t+=a*3);var h=!0,g=[],b=0,S=null,v=0,E=null;for(this.width=r,this.height=n;h&&t<e.length;)switch(e[t++]){case 33:switch(e[t++]){case 255:if(e[t]!==11||e[t+1]==78&&e[t+2]==69&&e[t+3]==84&&e[t+4]==83&&e[t+5]==67&&e[t+6]==65&&e[t+7]==80&&e[t+8]==69&&e[t+9]==50&&e[t+10]==46&&e[t+11]==48&&e[t+12]==3&&e[t+13]==1&&e[t+16]==0)t+=14,E=e[t++]|e[t++]<<8,t++;else for(t+=12;;){var x=e[t++];if(!(x>=0))throw Error("Invalid block size");if(x===0)break;t+=x;}break;case 249:if(e[t++]!==4||e[t+4]!==0)throw new Error("Invalid graphics extension block.");var A=e[t++];b=e[t++]|e[t++]<<8,S=e[t++],(A&1)===0&&(S=null),v=A>>2&7,t++;break;case 254:for(;;){var x=e[t++];if(!(x>=0))throw Error("Invalid block size");if(x===0)break;t+=x;}break;default:throw new Error("Unknown graphic control label: 0x"+e[t-1].toString(16));}break;case 44:var u=e[t++]|e[t++]<<8,y=e[t++]|e[t++]<<8,d=e[t++]|e[t++]<<8,I=e[t++]|e[t++]<<8,m=e[t++],B=m>>7,w=m>>6&1,P=m&7,N=1<<P+1,L=f,$=l,oe=!1;if(B){var oe=!0;L=t,$=N,t+=N*3;}var W=t;for(t++;;){var x=e[t++];if(!(x>=0))throw Error("Invalid block size");if(x===0)break;t+=x;}g.push({x:u,y,width:d,height:I,has_local_palette:oe,palette_offset:L,palette_size:$,data_offset:W,data_length:t-W,transparent_index:S,interlaced:!!w,delay:b,disposal:v});break;case 59:h=!1;break;default:throw new Error("Unknown gif block: 0x"+e[t-1].toString(16));}this.numFrames=function(){return g.length;},this.loopCount=function(){return E;},this.frameInfo=function(X){if(X<0||X>=g.length)throw new Error("Frame index out of range.");return g[X];},this.decodeAndBlitFrameBGRA=function(X,V){var K=this.frameInfo(X),j=K.width*K.height,xe=new Uint8Array(j);Br(e,K.data_offset,xe,j);var ne=K.palette_offset,re=K.transparent_index;re===null&&(re=256);var Z=K.width,_=r-Z,z=Z,ce=(K.y*r+K.x)*4,ve=((K.y+K.height)*r+K.x)*4,Q=ce,le=_*4;K.interlaced===!0&&(le+=r*4*7);for(var ae=8,G=0,O=xe.length;G<O;++G){var ue=xe[G];if(z===0&&(Q+=le,z=Z,Q>=ve&&(le=_*4+r*4*(ae-1),Q=ce+(Z+_)*(ae<<1),ae>>=1)),ue===re)Q+=4;else{var se=e[ne+ue*3],de=e[ne+ue*3+1],Fe=e[ne+ue*3+2];V[Q++]=Fe,V[Q++]=de,V[Q++]=se,V[Q++]=255;}--z;}},this.decodeAndBlitFrameRGBA=function(X,V){var K=this.frameInfo(X),j=K.width*K.height,xe=new Uint8Array(j);Br(e,K.data_offset,xe,j);var ne=K.palette_offset,re=K.transparent_index;re===null&&(re=256);var Z=K.width,_=r-Z,z=Z,ce=(K.y*r+K.x)*4,ve=((K.y+K.height)*r+K.x)*4,Q=ce,le=_*4;K.interlaced===!0&&(le+=r*4*7);for(var ae=8,G=0,O=xe.length;G<O;++G){var ue=xe[G];if(z===0&&(Q+=le,z=Z,Q>=ve&&(le=_*4+r*4*(ae-1),Q=ce+(Z+_)*(ae<<1),ae>>=1)),ue===re)Q+=4;else{var se=e[ne+ue*3],de=e[ne+ue*3+1],Fe=e[ne+ue*3+2];V[Q++]=se,V[Q++]=de,V[Q++]=Fe,V[Q++]=255;}--z;}};}function Br(e,t,r,n){for(var i=e[t++],o=1<<i,s=o+1,a=s+1,c=i+1,f=(1<<c)-1,l=0,h=0,g=0,b=e[t++],S=new Int32Array(4096),v=null;;){for(;l<16&&b!==0;)h|=e[t++]<<l,l+=8,b===1?b=e[t++]:--b;if(l<c)break;var E=h&f;if(h>>=c,l-=c,E===o){a=s+1,c=i+1,f=(1<<c)-1,v=null;continue;}else if(E===s)break;for(var x=E<a?E:v,A=0,u=x;u>o;)u=S[u]>>8,++A;var y=u,d=g+A+(x!==E?1:0);if(d>n){console.log("Warning, gif stream longer than expected.");return;}r[g++]=y,g+=A;var I=g;for(x!==E&&(r[g++]=y),u=x;A--;)u=S[u],r[--I]=u&255,u>>=8;v!==null&&a<4096&&(S[a++]=v<<8|y,a>=f+1&&c<12&&(++c,f=f<<1|1)),v=E;}return g!==n&&console.log("Warning, gif stream shorter than expected."),r;}try{Jt.GifWriter=si,Jt.GifReader=li;}catch{}});var Kr=ut(nr=>{var Nr=Object.defineProperty,ci=e=>Nr(e,"__esModule",{value:!0}),fi=(e,t)=>{for(var r in t)Nr(e,r,{get:t[r],enumerable:!0});};ci(nr);fi(nr,{GIFEncoder:()=>$r,applyPalette:()=>mi,default:()=>Fi,nearestColor:()=>Ei,nearestColorIndex:()=>Hr,nearestColorIndexWithDistance:()=>Wr,prequantize:()=>yi,quantize:()=>gi,snapColorsToPalette:()=>bi});var hi={signature:"GIF",version:"89a",trailer:59,extensionIntroducer:33,applicationExtensionLabel:255,graphicControlExtensionLabel:249,imageSeparator:44,signatureSize:3,versionSize:3,globalColorTableFlagMask:128,colorResolutionMask:112,sortFlagMask:8,globalColorTableSizeMask:7,applicationIdentifierSize:8,applicationAuthCodeSize:3,disposalMethodMask:28,userInputFlagMask:2,transparentColorFlagMask:1,localColorTableFlagMask:128,interlaceFlagMask:64,idSortFlagMask:32,localColorTableSizeMask:7};function Or(e=256){var t=0,r=new Uint8Array(e);return{get buffer(){return r.buffer;},reset(){t=0;},bytesView(){return r.subarray(0,t);},bytes(){return r.slice(0,t);},writeByte(i){n(t+1),r[t]=i,t++;},writeBytes(i,o=0,s=i.length){n(t+s);for(var a=0;a<s;a++)r[t++]=i[a+o];},writeBytesView(i,o=0,s=i.byteLength){n(t+s),r.set(i.subarray(o,o+s),t),t+=s;}};function n(i){var o=r.length;if(o>=i)return;var s=1024*1024;i=Math.max(i,o*(o<s?2:1.125)>>>0),o!=0&&(i=Math.max(i,256));var a=r;r=new Uint8Array(i),t>0&&r.set(a.subarray(0,t),0);}}var er=12,Rr=5003,ui=[0,1,3,7,15,31,63,127,255,511,1023,2047,4095,8191,16383,32767,65535];function di(e,t,r,n,i=Or(512),o=new Uint8Array(256),s=new Int32Array(Rr),a=new Int32Array(Rr)){var c=s.length,f=Math.max(2,n);o.fill(0),a.fill(0),s.fill(-1);var l=0,h=0,g=f+1,b=g,S=!1,v=b,E=(1<<v)-1,x=1<<g-1,A=x+1,u=x+2,y=0,d=r[0],I=0;for(var w=c;w<65536;w*=2)++I;I=8-I,i.writeByte(f),B(x);var m=r.length;for(var _w=1;_w<m;_w++)e:{var P=r[_w],N=(P<<er)+d,L=P<<I^d;if(s[L]===N){d=a[L];break e;}var $=L===0?1:c-L;for(;s[L]>=0;)if(L-=$,L<0&&(L+=c),s[L]===N){d=a[L];break e;}B(d),d=P,u<1<<er?(a[L]=u++,s[L]=N):(s.fill(-1),u=x+2,S=!0,B(x));}return B(d),B(A),i.writeByte(0),i.bytesView();function B(w){for(l&=ui[h],h>0?l|=w<<h:l=w,h+=v;h>=8;)o[y++]=l&255,y>=254&&(i.writeByte(y),i.writeBytesView(o,0,y),y=0),l>>=8,h-=8;if((u>E||S)&&(S?(v=b,E=(1<<v)-1,S=!1):(++v,E=v===er?1<<v:(1<<v)-1)),w==A){for(;h>0;)o[y++]=l&255,y>=254&&(i.writeByte(y),i.writeBytesView(o,0,y),y=0),l>>=8,h-=8;y>0&&(i.writeByte(y),i.writeBytesView(o,0,y),y=0);}}}var pi=di;function Lr(e,t,r){return e<<8&63488|t<<2&992|r>>3;}function zr(e,t,r,n){return e>>4|t&240|(r&240)<<4|(n&240)<<8;}function Gr(e,t,r){return e>>4<<8|t&240|r>>4;}function Nt(e,t,r){return e<t?t:e>r?r:e;}function Et(e){return e*e;}function Dr(e,t,r){var n=0,i=1e100;var o=e[t],s=o.cnt,a=o.ac,c=o.rc,f=o.gc,l=o.bc;for(var h=o.fw;h!=0;h=e[h].fw){var b=e[h],S=b.cnt,v=s*S/(s+S);if(!(v>=i)){var g=0;r&&(g+=v*Et(b.ac-a),g>=i)||(g+=v*Et(b.rc-c),!(g>=i)&&(g+=v*Et(b.gc-f),!(g>=i)&&(g+=v*Et(b.bc-l),!(g>=i)&&(i=g,n=h))));}}o.err=i,o.nn=n;}function tr(){return{ac:0,rc:0,gc:0,bc:0,cnt:0,nn:0,fw:0,bk:0,tm:0,mtm:0,err:0};}function vi(e,t){var r=t==="rgb444"?4096:65536,n=new Array(r),i=e.length;if(t==="rgba4444")for(var o=0;o<i;++o){var s=e[o],a=s>>24&255,c=s>>16&255,f=s>>8&255,l=s&255,h=zr(l,f,c,a),g=h in n?n[h]:n[h]=tr();g.rc+=l,g.gc+=f,g.bc+=c,g.ac+=a,g.cnt++;}else if(t==="rgb444")for(var _o2=0;_o2<i;++_o2){var _s=e[_o2],_a=_s>>16&255,_c=_s>>8&255,_f=_s&255,_l=Gr(_f,_c,_a),_h=_l in n?n[_l]:n[_l]=tr();_h.rc+=_f,_h.gc+=_c,_h.bc+=_a,_h.cnt++;}else for(var _o3=0;_o3<i;++_o3){var _s2=e[_o3],_a2=_s2>>16&255,_c2=_s2>>8&255,_f2=_s2&255,_l2=Lr(_f2,_c2,_a2),_h2=_l2 in n?n[_l2]:n[_l2]=tr();_h2.rc+=_f2,_h2.gc+=_c2,_h2.bc+=_a2,_h2.cnt++;}return n;}function gi(e,t,r={}){var{format:n="rgb565",clearAlpha:i=!0,clearAlphaColor:o=0,clearAlphaThreshold:s=0,oneBitAlpha:a=!1}=r;if(!e||!e.buffer)throw new Error("quantize() expected RGBA Uint8Array data");if(!(e instanceof Uint8Array)&&!(e instanceof Uint8ClampedArray))throw new Error("quantize() expected RGBA Uint8Array data");var c=new Uint32Array(e.buffer),f=r.useSqrt!==!1,l=n==="rgba4444",h=vi(c,n),g=h.length,b=g-1,S=new Uint32Array(g+1);for(var v=0,x=0;x<g;++x){var W=h[x];if(W!=null){var E=1/W.cnt;l&&(W.ac*=E),W.rc*=E,W.gc*=E,W.bc*=E,h[v++]=W;}}Et(t)/v<.022&&(f=!1);for(var x=0;x<v-1;++x)h[x].fw=x+1,h[x+1].bk=x,f&&(h[x].cnt=Math.sqrt(h[x].cnt));f&&(h[x].cnt=Math.sqrt(h[x].cnt));var A,u,y;for(x=0;x<v;++x){Dr(h,x,!1);var d=h[x].err;for(u=++S[0];u>1&&(y=u>>1,!(h[A=S[y]].err<=d));u=y)S[u]=A;S[u]=x;}var I=v-t;for(x=0;x<I;){for(var m;;){var B=S[1];if(m=h[B],m.tm>=m.mtm&&h[m.nn].mtm<=m.tm)break;m.mtm==b?B=S[1]=S[S[0]--]:(Dr(h,B,!1),m.tm=x);var d=h[B].err;for(u=1;(y=u+u)<=S[0]&&(y<S[0]&&h[S[y]].err>h[S[y+1]].err&&y++,!(d<=h[A=S[y]].err));u=y)S[u]=A;S[u]=B;}var w=h[m.nn],P=m.cnt,N=w.cnt,E=1/(P+N);l&&(m.ac=E*(P*m.ac+N*w.ac)),m.rc=E*(P*m.rc+N*w.rc),m.gc=E*(P*m.gc+N*w.gc),m.bc=E*(P*m.bc+N*w.bc),m.cnt+=w.cnt,m.mtm=++x,h[w.bk].fw=w.fw,h[w.fw].bk=w.bk,w.mtm=b;}var L=[];var $=0;for(x=0;;++$){var oe=Nt(Math.round(h[x].rc),0,255),_W=Nt(Math.round(h[x].gc),0,255),X=Nt(Math.round(h[x].bc),0,255),V=255;l&&(V=Nt(Math.round(h[x].ac),0,255),a&&(V=V<=(typeof a=="number"?a:127)?0:255),i&&V<=s&&(oe=_W=X=o,V=0));var K=l?[oe,_W,X,V]:[oe,_W,X];if(xi(L,K)||L.push(K),(x=h[x].fw)==0)break;}return L;}function xi(e,t){for(var r=0;r<e.length;r++){var n=e[r],i=n[0]===t[0]&&n[1]===t[1]&&n[2]===t[2],o=n.length>=4&&t.length>=4?n[3]===t[3]:!0;if(i&&o)return!0;}return!1;}function Lt(e,t){var r=0,n;for(n=0;n<e.length;n++){var i=e[n]-t[n];r+=i*i;}return r;}function Ot(e,t){return t>1?Math.round(e/t)*t:e;}function yi(e,{roundRGB:t=5,roundAlpha:r=10,oneBitAlpha:n=null}={}){var i=new Uint32Array(e.buffer);for(var o=0;o<i.length;o++){var s=i[o],a=s>>24&255,c=s>>16&255,f=s>>8&255,l=s&255;a=Ot(a,r),n&&(a=a<=(typeof n=="number"?n:127)?0:255),l=Ot(l,t),f=Ot(f,t),c=Ot(c,t),i[o]=a<<24|c<<16|f<<8|l<<0;}}function mi(e,t,r="rgb565"){if(!e||!e.buffer)throw new Error("quantize() expected RGBA Uint8Array data");if(!(e instanceof Uint8Array)&&!(e instanceof Uint8ClampedArray))throw new Error("quantize() expected RGBA Uint8Array data");if(t.length>256)throw new Error("applyPalette() only works with 256 colors or less");var n=new Uint32Array(e.buffer),i=n.length,o=r==="rgb444"?4096:65536,s=new Uint8Array(i),a=new Array(o),c=r==="rgba4444";if(r==="rgba4444")for(var f=0;f<i;f++){var l=n[f],h=l>>24&255,g=l>>16&255,b=l>>8&255,S=l&255,v=zr(S,b,g,h),E=v in a?a[v]:a[v]=wi(S,b,g,h,t);s[f]=E;}else{var _f3=r==="rgb444"?Gr:Lr;for(var _l3=0;_l3<i;_l3++){var _h3=n[_l3],_g=_h3>>16&255,_b=_h3>>8&255,_S=_h3&255,_v=_f3(_S,_b,_g),_E=_v in a?a[_v]:a[_v]=Ai(_S,_b,_g,t);s[_l3]=_E;}}return s;}function wi(e,t,r,n,i){var o=0,s=1e100;for(var a=0;a<i.length;a++){var c=i[a],f=c[3],l=it(f-n);if(l>s)continue;var h=c[0];if(l+=it(h-e),l>s)continue;var g=c[1];if(l+=it(g-t),l>s)continue;var b=c[2];l+=it(b-r),!(l>s)&&(s=l,o=a);}return o;}function Ai(e,t,r,n){var i=0,o=1e100;for(var s=0;s<n.length;s++){var a=n[s],c=a[0],f=it(c-e);if(f>o)continue;var l=a[1];if(f+=it(l-t),f>o)continue;var h=a[2];f+=it(h-r),!(f>o)&&(o=f,i=s);}return i;}function bi(e,t,r=5){if(!e.length||!t.length)return;var n=e.map(s=>s.slice(0,3)),i=r*r,o=e[0].length;for(var s=0;s<t.length;s++){var a=t[s];a.length<o?a=[a[0],a[1],a[2],255]:a.length>o?a=a.slice(0,3):a=a.slice();var c=Wr(n,a.slice(0,3),Lt),f=c[0],l=c[1];l>0&&l<=i&&(e[f]=a);}}function it(e){return e*e;}function Hr(e,t,r=Lt){var n=1/0,i=-1;for(var o=0;o<e.length;o++){var s=e[o],a=r(t,s);a<n&&(n=a,i=o);}return i;}function Wr(e,t,r=Lt){var n=1/0,i=-1;for(var o=0;o<e.length;o++){var s=e[o],a=r(t,s);a<n&&(n=a,i=o);}return[i,n];}function Ei(e,t,r=Lt){return e[Hr(e,t,r)];}function $r(e={}){var{initialCapacity:t=4096,auto:r=!0}=e,n=Or(t),i=5003,o=new Uint8Array(256),s=new Int32Array(i),a=new Int32Array(i),c=!1;return{reset(){n.reset(),c=!1;},finish(){n.writeByte(hi.trailer);},bytes(){return n.bytes();},bytesView(){return n.bytesView();},get buffer(){return n.buffer;},get stream(){return n;},writeHeader:f,writeFrame(l,h,g,b={}){var{transparent:S=!1,transparentIndex:v=0,delay:E=0,palette:x=null,repeat:A=0,colorDepth:u=8,dispose:y=-1}=b,d=!1;if(r?c||(d=!0,f(),c=!0):d=!!b.first,h=Math.max(0,Math.floor(h)),g=Math.max(0,Math.floor(g)),d){if(!x)throw new Error("First frame must include a { palette } option");Si(n,h,g,x,u),Pr(n,x),A>=0&&Ci(n,A);}var I=Math.round(E/10);_i(n,y,I,S,v);var m=!!x&&!d;Ti(n,h,g,m?x:null),m&&Pr(n,x),ki(n,l,h,g,u,o,s,a);}};function f(){Yr(n,"GIF89a");}}function _i(e,t,r,n,i){e.writeByte(33),e.writeByte(249),e.writeByte(4),i<0&&(i=0,n=!1);var o,s;n?(o=1,s=2):(o=0,s=0),t>=0&&(s=t&7),s<<=2,e.writeByte(0|s|0|o),Je(e,r),e.writeByte(i||0),e.writeByte(0);}function Si(e,t,r,n,i=8){var a=rr(n.length)-1,c=128|i-1<<4|0|a,f=0,l=0;Je(e,t),Je(e,r),e.writeBytes([c,f,l]);}function Ci(e,t){e.writeByte(33),e.writeByte(255),e.writeByte(11),Yr(e,"NETSCAPE2.0"),e.writeByte(3),e.writeByte(1),Je(e,t),e.writeByte(0);}function Pr(e,t){var r=1<<rr(t.length);for(var n=0;n<r;n++){var i=[0,0,0];n<t.length&&(i=t[n]),e.writeByte(i[0]),e.writeByte(i[1]),e.writeByte(i[2]);}}function Ti(e,t,r,n){if(e.writeByte(44),Je(e,0),Je(e,0),Je(e,t),Je(e,r),n){var s=rr(n.length)-1;e.writeByte(128|s);}else e.writeByte(0);}function ki(e,t,r,n,i=8,o,s,a){pi(r,n,t,i,e,o,s,a);}function Je(e,t){e.writeByte(t&255),e.writeByte(t>>8&255);}function Yr(e,t){for(var r=0;r<t.length;r++)e.writeByte(t.charCodeAt(r));}function rr(e){return Math.max(Math.ceil(Math.log2(e)),1);}var Fi=$r;});var or=ut(zt=>{"use strict";zt.byteLength=Ii;zt.toByteArray=Mi;zt.fromByteArray=Pi;var We=[],Oe=[],Ui=typeof Uint8Array<"u"?Uint8Array:Array,ir="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";for(ot=0,Xr=ir.length;ot<Xr;++ot)We[ot]=ir[ot],Oe[ir.charCodeAt(ot)]=ot;var ot,Xr;Oe[45]=62;Oe[95]=63;function qr(e){var t=e.length;if(t%4>0)throw new Error("Invalid string. Length must be a multiple of 4");var r=e.indexOf("=");r===-1&&(r=t);var n=r===t?0:4-r%4;return[r,n];}function Ii(e){var t=qr(e),r=t[0],n=t[1];return(r+n)*3/4-n;}function Bi(e,t,r){return(t+r)*3/4-r;}function Mi(e){var t,r=qr(e),n=r[0],i=r[1],o=new Ui(Bi(e,n,i)),s=0,a=i>0?n-4:n,c;for(c=0;c<a;c+=4)t=Oe[e.charCodeAt(c)]<<18|Oe[e.charCodeAt(c+1)]<<12|Oe[e.charCodeAt(c+2)]<<6|Oe[e.charCodeAt(c+3)],o[s++]=t>>16&255,o[s++]=t>>8&255,o[s++]=t&255;return i===2&&(t=Oe[e.charCodeAt(c)]<<2|Oe[e.charCodeAt(c+1)]>>4,o[s++]=t&255),i===1&&(t=Oe[e.charCodeAt(c)]<<10|Oe[e.charCodeAt(c+1)]<<4|Oe[e.charCodeAt(c+2)]>>2,o[s++]=t>>8&255,o[s++]=t&255),o;}function Ri(e){return We[e>>18&63]+We[e>>12&63]+We[e>>6&63]+We[e&63];}function Di(e,t,r){for(var n,i=[],o=t;o<r;o+=3)n=(e[o]<<16&16711680)+(e[o+1]<<8&65280)+(e[o+2]&255),i.push(Ri(n));return i.join("");}function Pi(e){for(var t,r=e.length,n=r%3,i=[],o=16383,s=0,a=r-n;s<a;s+=o)i.push(Di(e,s,s+o>a?a:s+o));return n===1?(t=e[r-1],i.push(We[t>>2]+We[t<<4&63]+"==")):n===2&&(t=(e[r-2]<<8)+e[r-1],i.push(We[t>>10]+We[t>>4&63]+We[t<<2&63]+"=")),i.join("");}});var $n=ut((Os,jt)=>{var Wn=Wn||function(e){return Buffer.from(e).toString("base64");};function So(e){var t=this,r=Math.round,n=Math.floor,i=new Array(64),o=new Array(64),s=new Array(64),a=new Array(64),c,f,l,h,g=new Array(65535),b=new Array(65535),S=new Array(64),v=new Array(64),E=[],x=0,A=7,u=new Array(64),y=new Array(64),d=new Array(64),I=new Array(256),m=new Array(2048),B,w=[0,1,5,6,14,15,27,28,2,4,7,13,16,26,29,42,3,8,12,17,25,30,41,43,9,11,18,24,31,40,44,53,10,19,23,32,39,45,52,54,20,22,33,38,46,51,55,60,21,34,37,47,50,56,59,61,35,36,48,49,57,58,62,63],P=[0,0,1,5,1,1,1,1,1,1,0,0,0,0,0,0,0],N=[0,1,2,3,4,5,6,7,8,9,10,11],L=[0,0,2,1,3,3,2,4,3,5,5,4,4,0,0,1,125],$=[1,2,3,0,4,17,5,18,33,49,65,6,19,81,97,7,34,113,20,50,129,145,161,8,35,66,177,193,21,82,209,240,36,51,98,114,130,9,10,22,23,24,25,26,37,38,39,40,41,42,52,53,54,55,56,57,58,67,68,69,70,71,72,73,74,83,84,85,86,87,88,89,90,99,100,101,102,103,104,105,106,115,116,117,118,119,120,121,122,131,132,133,134,135,136,137,138,146,147,148,149,150,151,152,153,154,162,163,164,165,166,167,168,169,170,178,179,180,181,182,183,184,185,186,194,195,196,197,198,199,200,201,202,210,211,212,213,214,215,216,217,218,225,226,227,228,229,230,231,232,233,234,241,242,243,244,245,246,247,248,249,250],oe=[0,0,3,1,1,1,1,1,1,1,1,1,0,0,0,0,0],W=[0,1,2,3,4,5,6,7,8,9,10,11],X=[0,0,2,1,2,4,4,3,4,7,5,4,4,0,1,2,119],V=[0,1,2,3,17,4,5,33,49,6,18,65,81,7,97,113,19,34,50,129,8,20,66,145,161,177,193,9,35,51,82,240,21,98,114,209,10,22,36,52,225,37,241,23,24,25,26,38,39,40,41,42,53,54,55,56,57,58,67,68,69,70,71,72,73,74,83,84,85,86,87,88,89,90,99,100,101,102,103,104,105,106,115,116,117,118,119,120,121,122,130,131,132,133,134,135,136,137,138,146,147,148,149,150,151,152,153,154,162,163,164,165,166,167,168,169,170,178,179,180,181,182,183,184,185,186,194,195,196,197,198,199,200,201,202,210,211,212,213,214,215,216,217,218,226,227,228,229,230,231,232,233,234,242,243,244,245,246,247,248,249,250];function K(T){for(var p=[16,11,10,16,24,40,51,61,12,12,14,19,26,58,60,55,14,13,16,24,40,57,69,56,14,17,22,29,51,87,80,62,18,22,37,56,68,109,103,77,24,35,55,64,81,104,113,92,49,64,78,87,103,121,120,101,72,92,95,98,112,100,103,99],R=0;R<64;R++){var F=n((p[R]*T+50)/100);F<1?F=1:F>255&&(F=255),i[w[R]]=F;}for(var U=[17,18,24,47,99,99,99,99,18,21,26,66,99,99,99,99,24,26,56,99,99,99,99,99,47,66,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],C=0;C<64;C++){var D=n((U[C]*T+50)/100);D<1?D=1:D>255&&(D=255),o[w[C]]=D;}for(var Y=[1,1.387039845,1.306562965,1.175875602,1,.785694958,.5411961,.275899379],q=0,ie=0;ie<8;ie++)for(var k=0;k<8;k++)s[q]=1/(i[w[q]]*Y[ie]*Y[k]*8),a[q]=1/(o[w[q]]*Y[ie]*Y[k]*8),q++;}function j(T,p){for(var R=0,F=0,U=new Array(),C=1;C<=16;C++){for(var D=1;D<=T[C];D++)U[p[F]]=[],U[p[F]][0]=R,U[p[F]][1]=C,F++,R++;R*=2;}return U;}function xe(){c=j(P,N),f=j(oe,W),l=j(L,$),h=j(X,V);}function ne(){for(var T=1,p=2,R=1;R<=15;R++){for(var F=T;F<p;F++)b[32767+F]=R,g[32767+F]=[],g[32767+F][1]=R,g[32767+F][0]=F;for(var U=-(p-1);U<=-T;U++)b[32767+U]=R,g[32767+U]=[],g[32767+U][1]=R,g[32767+U][0]=p-1+U;T<<=1,p<<=1;}}function re(){for(var T=0;T<256;T++)m[T]=19595*T,m[T+256>>0]=38470*T,m[T+512>>0]=7471*T+32768,m[T+768>>0]=-11059*T,m[T+1024>>0]=-21709*T,m[T+1280>>0]=32768*T+8421375,m[T+1536>>0]=-27439*T,m[T+1792>>0]=-5329*T;}function Z(T){for(var p=T[0],R=T[1]-1;R>=0;)p&1<<R&&(x|=1<<A),R--,A--,A<0&&(x==255?(_(255),_(0)):_(x),A=7,x=0);}function _(T){E.push(T);}function z(T){_(T>>8&255),_(T&255);}function ce(T,p){var R,F,U,C,D,Y,q,ie,k=0,H,J=8,ge=64;for(H=0;H<J;++H){R=T[k],F=T[k+1],U=T[k+2],C=T[k+3],D=T[k+4],Y=T[k+5],q=T[k+6],ie=T[k+7];var M=R+ie,ee=R-ie,fe=F+q,te=F-q,pe=U+Y,Ee=U-Y,me=C+D,Ae=C-D,Ue=M+me,Pe=M-me,Ne=fe+pe,Ie=fe-pe;T[k]=Ue+Ne,T[k+4]=Ue-Ne;var ke=(Ie+Pe)*.707106781;T[k+2]=Pe+ke,T[k+6]=Pe-ke,Ue=Ae+Ee,Ne=Ee+te,Ie=te+ee;var _e=(Ue-Ie)*.382683433,rt=.5411961*Ue+_e,je=1.306562965*Ie+_e,Ge=Ne*.707106781,nt=ee+Ge,Ze=ee-Ge;T[k+5]=Ze+rt,T[k+3]=Ze-rt,T[k+1]=nt+je,T[k+7]=nt-je,k+=8;}for(k=0,H=0;H<J;++H){R=T[k],F=T[k+8],U=T[k+16],C=T[k+24],D=T[k+32],Y=T[k+40],q=T[k+48],ie=T[k+56];var vt=R+ie,lt=R-ie,gt=F+q,xt=F-q,yt=U+Y,mt=U-Y,ct=C+D,Dt=C-D,he=vt+ct,Se=vt-ct,be=gt+yt,He=gt-yt;T[k]=he+be,T[k+32]=he-be;var Qe=(He+Se)*.707106781;T[k+16]=Se+Qe,T[k+48]=Se-Qe,he=Dt+mt,be=mt+xt,He=xt+lt;var Be=(he-He)*.382683433,wt=.5411961*he+Be,ft=1.306562965*He+Be,ht=be*.707106781,Fr=lt+ht,Ur=lt-ht;T[k+40]=Ur+wt,T[k+24]=Ur-wt,T[k+8]=Fr+ft,T[k+56]=Fr-ft,k++;}var Pt;for(H=0;H<ge;++H)Pt=T[H]*p[H],S[H]=Pt>0?Pt+.5|0:Pt-.5|0;return S;}function ve(){z(65504),z(16),_(74),_(70),_(73),_(70),_(0),_(1),_(1),_(0),z(1),z(1),_(0),_(0);}function Q(T){if(T){z(65505),T[0]===69&&T[1]===120&&T[2]===105&&T[3]===102?z(T.length+2):(z(T.length+5+2),_(69),_(120),_(105),_(102),_(0));for(var p=0;p<T.length;p++)_(T[p]);}}function le(T,p){z(65472),z(17),_(8),z(p),z(T),_(3),_(1),_(17),_(0),_(2),_(17),_(1),_(3),_(17),_(1);}function ae(){z(65499),z(132),_(0);for(var T=0;T<64;T++)_(i[T]);_(1);for(var p=0;p<64;p++)_(o[p]);}function G(){z(65476),z(418),_(0);for(var T=0;T<16;T++)_(P[T+1]);for(var p=0;p<=11;p++)_(N[p]);_(16);for(var R=0;R<16;R++)_(L[R+1]);for(var F=0;F<=161;F++)_($[F]);_(1);for(var U=0;U<16;U++)_(oe[U+1]);for(var C=0;C<=11;C++)_(W[C]);_(17);for(var D=0;D<16;D++)_(X[D+1]);for(var Y=0;Y<=161;Y++)_(V[Y]);}function O(T){typeof T>"u"||T.constructor!==Array||T.forEach(p=>{if(typeof p=="string"){z(65534);var R=p.length;z(R+2);var F;for(F=0;F<R;F++)_(p.charCodeAt(F));}});}function ue(){z(65498),z(12),_(3),_(1),_(0),_(2),_(17),_(3),_(17),_(0),_(63),_(0);}function se(T,p,R,F,U){for(var C=U[0],D=U[240],Y,q=16,ie=63,k=64,H=ce(T,p),J=0;J<k;++J)v[w[J]]=H[J];var ge=v[0]-R;R=v[0],ge==0?Z(F[0]):(Y=32767+ge,Z(F[b[Y]]),Z(g[Y]));for(var M=63;M>0&&v[M]==0;M--);if(M==0)return Z(C),R;for(var ee=1,fe;ee<=M;){for(var te=ee;v[ee]==0&&ee<=M;++ee);var pe=ee-te;if(pe>=q){fe=pe>>4;for(var Ee=1;Ee<=fe;++Ee)Z(D);pe=pe&15;}Y=32767+v[ee],Z(U[(pe<<4)+b[Y]]),Z(g[Y]),ee++;}return M!=ie&&Z(C),R;}function de(){for(var T=String.fromCharCode,p=0;p<256;p++)I[p]=T(p);}this.encode=function(T,p){var R=new Date().getTime();p&&Fe(p),E=new Array(),x=0,A=7,z(65496),ve(),O(T.comments),Q(T.exifBuffer),ae(),le(T.width,T.height),G(),ue();var F=0,U=0,C=0;x=0,A=7,this.encode.displayName="_encode_";for(var D=T.data,Y=T.width,q=T.height,ie=Y*4,k=Y*3,H,J=0,ge,M,ee,fe,te,pe,Ee,me;J<q;){for(H=0;H<ie;){for(fe=ie*J+H,te=fe,pe=-1,Ee=0,me=0;me<64;me++)Ee=me>>3,pe=(me&7)*4,te=fe+Ee*ie+pe,J+Ee>=q&&(te-=ie*(J+1+Ee-q)),H+pe>=ie&&(te-=H+pe-ie+4),ge=D[te++],M=D[te++],ee=D[te++],u[me]=(m[ge]+m[M+256>>0]+m[ee+512>>0]>>16)-128,y[me]=(m[ge+768>>0]+m[M+1024>>0]+m[ee+1280>>0]>>16)-128,d[me]=(m[ge+1280>>0]+m[M+1536>>0]+m[ee+1792>>0]>>16)-128;F=se(u,s,F,c,l),U=se(y,a,U,f,h),C=se(d,a,C,f,h),H+=32;}J+=8;}if(A>=0){var Ae=[];Ae[1]=A+1,Ae[0]=(1<<A+1)-1,Z(Ae);}if(z(65497),typeof jt>"u")return new Uint8Array(E);return Buffer.from(E);var Ue,Pe;};function Fe(T){if(T<=0&&(T=1),T>100&&(T=100),B!=T){var p=0;T<50?p=Math.floor(5e3/T):p=Math.floor(200-T*2),K(p),B=T;}}function Re(){var T=new Date().getTime();e||(e=50),de(),xe(),ne(),re(),Fe(e);var p=new Date().getTime()-T;}Re();}typeof jt<"u"?jt.exports=Hn:typeof window<"u"&&(window["jpeg-js"]=window["jpeg-js"]||{},window["jpeg-js"].encode=Hn);function Hn(e,t){typeof t>"u"&&(t=50);var r=new So(t),n=r.encode(e,t);return{data:n,width:e.width,height:e.height};}});var Kn=ut((Ls,Cr)=>{var Sr=function(){"use strict";var t=new Int32Array([0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63]),r=4017,n=799,i=3406,o=2276,s=1567,a=3784,c=5793,f=2896;function l(){}function h(A,u){for(var y=0,d=[],I,m,B=16;B>0&&!A[B-1];)B--;d.push({children:[],index:0});var w=d[0],P;for(I=0;I<B;I++){for(m=0;m<A[I];m++){for(w=d.pop(),w.children[w.index]=u[y];w.index>0;){if(d.length===0)throw new Error("Could not recreate Huffman Table");w=d.pop();}for(w.index++,d.push(w);d.length<=I;)d.push(P={children:[],index:0}),w.children[w.index]=P.children,w=P;y++;}I+1<B&&(d.push(P={children:[],index:0}),w.children[w.index]=P.children,w=P);}return d[0].children;}function g(A,u,y,d,I,m,B,w,P,N){var L=y.precision,$=y.samplesPerLine,oe=y.scanLines,W=y.mcusPerLine,X=y.progressive,V=y.maxH,K=y.maxV,j=u,xe=0,ne=0;function re(){if(ne>0)return ne--,xe>>ne&1;if(xe=A[u++],xe==255){var k=A[u++];if(k)throw new Error("unexpected marker: "+(xe<<8|k).toString(16));}return ne=7,xe>>>7;}function Z(k){for(var H=k,J;(J=re())!==null;){if(H=H[J],typeof H=="number")return H;if(typeof H!="object")throw new Error("invalid huffman sequence");}return null;}function _(k){for(var H=0;k>0;){var J=re();if(J===null)return;H=H<<1|J,k--;}return H;}function z(k){var H=_(k);return H>=1<<k-1?H:H+(-1<<k)+1;}function ce(k,H){var J=Z(k.huffmanTableDC),ge=J===0?0:z(J);H[0]=k.pred+=ge;for(var M=1;M<64;){var ee=Z(k.huffmanTableAC),fe=ee&15,te=ee>>4;if(fe===0){if(te<15)break;M+=16;continue;}M+=te;var pe=t[M];H[pe]=z(fe),M++;}}function ve(k,H){var J=Z(k.huffmanTableDC),ge=J===0?0:z(J)<<P;H[0]=k.pred+=ge;}function Q(k,H){H[0]|=re()<<P;}var le=0;function ae(k,H){if(le>0){le--;return;}for(var J=m,ge=B;J<=ge;){var M=Z(k.huffmanTableAC),ee=M&15,fe=M>>4;if(ee===0){if(fe<15){le=_(fe)+(1<<fe)-1;break;}J+=16;continue;}J+=fe;var te=t[J];H[te]=z(ee)*(1<<P),J++;}}var G=0,O;function ue(k,H){for(var J=m,ge=B,M=0;J<=ge;){var ee=t[J],fe=H[ee]<0?-1:1;switch(G){case 0:var te=Z(k.huffmanTableAC),pe=te&15,M=te>>4;if(pe===0)M<15?(le=_(M)+(1<<M),G=4):(M=16,G=1);else{if(pe!==1)throw new Error("invalid ACn encoding");O=z(pe),G=M?2:3;}continue;case 1:case 2:H[ee]?H[ee]+=(re()<<P)*fe:(M--,M===0&&(G=G==2?3:0));break;case 3:H[ee]?H[ee]+=(re()<<P)*fe:(H[ee]=O<<P,G=0);break;case 4:H[ee]&&(H[ee]+=(re()<<P)*fe);break;}J++;}G===4&&(le--,le===0&&(G=0));}function se(k,H,J,ge,M){var ee=J/W|0,fe=J%W,te=ee*k.v+ge,pe=fe*k.h+M;k.blocks[te]===void 0&&N.tolerantDecoding||H(k,k.blocks[te][pe]);}function de(k,H,J){var ge=J/k.blocksPerLine|0,M=J%k.blocksPerLine;k.blocks[ge]===void 0&&N.tolerantDecoding||H(k,k.blocks[ge][M]);}var Fe=d.length,Re,T,p,R,F,U;X?m===0?U=w===0?ve:Q:U=w===0?ae:ue:U=ce;var C=0,D,Y;Fe==1?Y=d[0].blocksPerLine*d[0].blocksPerColumn:Y=W*y.mcusPerColumn,I||(I=Y);for(var q,ie;C<Y;){for(T=0;T<Fe;T++)d[T].pred=0;if(le=0,Fe==1)for(Re=d[0],F=0;F<I;F++)de(Re,U,C),C++;else for(F=0;F<I;F++){for(T=0;T<Fe;T++)for(Re=d[T],q=Re.h,ie=Re.v,p=0;p<ie;p++)for(R=0;R<q;R++)se(Re,U,C,p,R);if(C++,C===Y)break;}if(C===Y)do{if(A[u]===255&&A[u+1]!==0)break;u+=1;}while(u<A.length-2);if(ne=0,D=A[u]<<8|A[u+1],D<65280)throw new Error("marker was not found");if(D>=65488&&D<=65495)u+=2;else break;}return u-j;}function b(A,u){var y=[],d=u.blocksPerLine,I=u.blocksPerColumn,m=d<<3,B=new Int32Array(64),w=new Uint8Array(64);function P(j,xe,ne){var re=u.quantizationTable,Z,_,z,ce,ve,Q,le,ae,G,O=ne,ue;for(ue=0;ue<64;ue++)O[ue]=j[ue]*re[ue];for(ue=0;ue<8;++ue){var se=8*ue;if(O[1+se]==0&&O[2+se]==0&&O[3+se]==0&&O[4+se]==0&&O[5+se]==0&&O[6+se]==0&&O[7+se]==0){G=c*O[0+se]+512>>10,O[0+se]=G,O[1+se]=G,O[2+se]=G,O[3+se]=G,O[4+se]=G,O[5+se]=G,O[6+se]=G,O[7+se]=G;continue;}Z=c*O[0+se]+128>>8,_=c*O[4+se]+128>>8,z=O[2+se],ce=O[6+se],ve=f*(O[1+se]-O[7+se])+128>>8,ae=f*(O[1+se]+O[7+se])+128>>8,Q=O[3+se]<<4,le=O[5+se]<<4,G=Z-_+1>>1,Z=Z+_+1>>1,_=G,G=z*a+ce*s+128>>8,z=z*s-ce*a+128>>8,ce=G,G=ve-le+1>>1,ve=ve+le+1>>1,le=G,G=ae+Q+1>>1,Q=ae-Q+1>>1,ae=G,G=Z-ce+1>>1,Z=Z+ce+1>>1,ce=G,G=_-z+1>>1,_=_+z+1>>1,z=G,G=ve*o+ae*i+2048>>12,ve=ve*i-ae*o+2048>>12,ae=G,G=Q*n+le*r+2048>>12,Q=Q*r-le*n+2048>>12,le=G,O[0+se]=Z+ae,O[7+se]=Z-ae,O[1+se]=_+le,O[6+se]=_-le,O[2+se]=z+Q,O[5+se]=z-Q,O[3+se]=ce+ve,O[4+se]=ce-ve;}for(ue=0;ue<8;++ue){var de=ue;if(O[8+de]==0&&O[16+de]==0&&O[24+de]==0&&O[32+de]==0&&O[40+de]==0&&O[48+de]==0&&O[56+de]==0){G=c*ne[ue+0]+8192>>14,O[0+de]=G,O[8+de]=G,O[16+de]=G,O[24+de]=G,O[32+de]=G,O[40+de]=G,O[48+de]=G,O[56+de]=G;continue;}Z=c*O[0+de]+2048>>12,_=c*O[32+de]+2048>>12,z=O[16+de],ce=O[48+de],ve=f*(O[8+de]-O[56+de])+2048>>12,ae=f*(O[8+de]+O[56+de])+2048>>12,Q=O[24+de],le=O[40+de],G=Z-_+1>>1,Z=Z+_+1>>1,_=G,G=z*a+ce*s+2048>>12,z=z*s-ce*a+2048>>12,ce=G,G=ve-le+1>>1,ve=ve+le+1>>1,le=G,G=ae+Q+1>>1,Q=ae-Q+1>>1,ae=G,G=Z-ce+1>>1,Z=Z+ce+1>>1,ce=G,G=_-z+1>>1,_=_+z+1>>1,z=G,G=ve*o+ae*i+2048>>12,ve=ve*i-ae*o+2048>>12,ae=G,G=Q*n+le*r+2048>>12,Q=Q*r-le*n+2048>>12,le=G,O[0+de]=Z+ae,O[56+de]=Z-ae,O[8+de]=_+le,O[48+de]=_-le,O[16+de]=z+Q,O[40+de]=z-Q,O[24+de]=ce+ve,O[32+de]=ce-ve;}for(ue=0;ue<64;++ue){var Fe=128+(O[ue]+8>>4);xe[ue]=Fe<0?0:Fe>255?255:Fe;}}x(m*I*8);for(var N,L,$=0;$<I;$++){var oe=$<<3;for(N=0;N<8;N++)y.push(new Uint8Array(m));for(var W=0;W<d;W++){P(u.blocks[$][W],w,B);var X=0,V=W<<3;for(L=0;L<8;L++){var K=y[oe+L];for(N=0;N<8;N++)K[V+N]=w[X++];}}}return y;}function S(A){return A<0?0:A>255?255:A;}l.prototype={load:function(u){var y=new XMLHttpRequest();y.open("GET",u,!0),y.responseType="arraybuffer",y.onload=function(){var d=new Uint8Array(y.response||y.mozResponseArrayBuffer);this.parse(d),this.onload&&this.onload();}.bind(this),y.send(null);},parse:function(u){var y=this.opts.maxResolutionInMP*1e3*1e3,d=0,I=u.length;function m(){var te=u[d]<<8|u[d+1];return d+=2,te;}function B(){var te=m(),pe=u.subarray(d,d+te-2);return d+=pe.length,pe;}function w(te){var pe=1,Ee=1,me,Ae;for(Ae in te.components)te.components.hasOwnProperty(Ae)&&(me=te.components[Ae],pe<me.h&&(pe=me.h),Ee<me.v&&(Ee=me.v));var Ue=Math.ceil(te.samplesPerLine/8/pe),Pe=Math.ceil(te.scanLines/8/Ee);for(Ae in te.components)if(te.components.hasOwnProperty(Ae)){me=te.components[Ae];var Ne=Math.ceil(Math.ceil(te.samplesPerLine/8)*me.h/pe),Ie=Math.ceil(Math.ceil(te.scanLines/8)*me.v/Ee),ke=Ue*me.h,_e=Pe*me.v,rt=_e*ke,je=[];x(rt*256);for(var Ge=0;Ge<_e;Ge++){for(var nt=[],Ze=0;Ze<ke;Ze++)nt.push(new Int32Array(64));je.push(nt);}me.blocksPerLine=Ne,me.blocksPerColumn=Ie,me.blocks=je;}te.maxH=pe,te.maxV=Ee,te.mcusPerLine=Ue,te.mcusPerColumn=Pe;}var P=null,N=null,L=null,$,oe,W=[],X=[],V=[],K=[],j=m(),xe=-1;if(this.comments=[],j!=65496)throw new Error("SOI not found");for(j=m();j!=65497;){var ne,re,Z;switch(j){case 65280:break;case 65504:case 65505:case 65506:case 65507:case 65508:case 65509:case 65510:case 65511:case 65512:case 65513:case 65514:case 65515:case 65516:case 65517:case 65518:case 65519:case 65534:var _=B();if(j===65534){var z=String.fromCharCode.apply(null,_);this.comments.push(z);}j===65504&&_[0]===74&&_[1]===70&&_[2]===73&&_[3]===70&&_[4]===0&&(P={version:{major:_[5],minor:_[6]},densityUnits:_[7],xDensity:_[8]<<8|_[9],yDensity:_[10]<<8|_[11],thumbWidth:_[12],thumbHeight:_[13],thumbData:_.subarray(14,14+3*_[12]*_[13])}),j===65505&&_[0]===69&&_[1]===120&&_[2]===105&&_[3]===102&&_[4]===0&&(this.exifBuffer=_.subarray(5,_.length)),j===65518&&_[0]===65&&_[1]===100&&_[2]===111&&_[3]===98&&_[4]===101&&_[5]===0&&(N={version:_[6],flags0:_[7]<<8|_[8],flags1:_[9]<<8|_[10],transformCode:_[11]});break;case 65499:for(var ce=m(),ve=ce+d-2;d<ve;){var Q=u[d++];x(256);var le=new Int32Array(64);if(Q>>4===0)for(re=0;re<64;re++){var ae=t[re];le[ae]=u[d++];}else if(Q>>4===1)for(re=0;re<64;re++){var ae=t[re];le[ae]=m();}else throw new Error("DQT: invalid table spec");W[Q&15]=le;}break;case 65472:case 65473:case 65474:m(),$={},$.extended=j===65473,$.progressive=j===65474,$.precision=u[d++],$.scanLines=m(),$.samplesPerLine=m(),$.components={},$.componentsOrder=[];var G=$.scanLines*$.samplesPerLine;if(G>y){var O=Math.ceil((G-y)/1e6);throw new Error(`maxResolutionInMP limit exceeded by ${O}MP`);}var ue=u[d++],se,de=0,Fe=0;for(ne=0;ne<ue;ne++){se=u[d];var Re=u[d+1]>>4,T=u[d+1]&15,p=u[d+2];if(Re<=0||T<=0)throw new Error("Invalid sampling factor, expected values above 0");$.componentsOrder.push(se),$.components[se]={h:Re,v:T,quantizationIdx:p},d+=3;}w($),X.push($);break;case 65476:var R=m();for(ne=2;ne<R;){var F=u[d++],U=new Uint8Array(16),C=0;for(re=0;re<16;re++,d++)C+=U[re]=u[d];x(16+C);var D=new Uint8Array(C);for(re=0;re<C;re++,d++)D[re]=u[d];ne+=17+C,(F>>4===0?K:V)[F&15]=h(U,D);}break;case 65501:m(),oe=m();break;case 65500:m(),m();break;case 65498:var Y=m(),q=u[d++],ie=[],k;for(ne=0;ne<q;ne++){k=$.components[u[d++]];var H=u[d++];k.huffmanTableDC=K[H>>4],k.huffmanTableAC=V[H&15],ie.push(k);}var J=u[d++],ge=u[d++],M=u[d++],ee=g(u,d,$,ie,oe,J,ge,M>>4,M&15,this.opts);d+=ee;break;case 65535:u[d]!==255&&d--;break;default:if(u[d-3]==255&&u[d-2]>=192&&u[d-2]<=254){d-=3;break;}else if(j===224||j==225){if(xe!==-1)throw new Error(`first unknown JPEG marker at offset ${xe.toString(16)}, second unknown JPEG marker ${j.toString(16)} at offset ${(d-1).toString(16)}`);xe=d-1;var te=m();if(u[d+te-2]===255){d+=te-2;break;}}throw new Error("unknown JPEG marker "+j.toString(16));}j=m();}if(X.length!=1)throw new Error("only single frame JPEGs supported");for(var ne=0;ne<X.length;ne++){var fe=X[ne].components;for(var re in fe)fe[re].quantizationTable=W[fe[re].quantizationIdx],delete fe[re].quantizationIdx;}this.width=$.samplesPerLine,this.height=$.scanLines,this.jfif=P,this.adobe=N,this.components=[];for(var ne=0;ne<$.componentsOrder.length;ne++){var k=$.components[$.componentsOrder[ne]];this.components.push({lines:b($,k),scaleX:k.h/$.maxH,scaleY:k.v/$.maxV});}},getData:function(u,y){var d=this.width/u,I=this.height/y,m,B,w,P,N,L,$,oe,W,X,V=0,K,j,xe,ne,re,Z,_,z,ce,ve,Q,le=u*y*this.components.length;x(le);var ae=new Uint8Array(le);switch(this.components.length){case 1:for(m=this.components[0],X=0;X<y;X++)for(N=m.lines[0|X*m.scaleY*I],W=0;W<u;W++)K=N[0|W*m.scaleX*d],ae[V++]=K;break;case 2:for(m=this.components[0],B=this.components[1],X=0;X<y;X++)for(N=m.lines[0|X*m.scaleY*I],L=B.lines[0|X*B.scaleY*I],W=0;W<u;W++)K=N[0|W*m.scaleX*d],ae[V++]=K,K=L[0|W*B.scaleX*d],ae[V++]=K;break;case 3:for(Q=!0,this.adobe&&this.adobe.transformCode?Q=!0:typeof this.opts.colorTransform<"u"&&(Q=!!this.opts.colorTransform),m=this.components[0],B=this.components[1],w=this.components[2],X=0;X<y;X++)for(N=m.lines[0|X*m.scaleY*I],L=B.lines[0|X*B.scaleY*I],$=w.lines[0|X*w.scaleY*I],W=0;W<u;W++)Q?(K=N[0|W*m.scaleX*d],j=L[0|W*B.scaleX*d],xe=$[0|W*w.scaleX*d],z=S(K+1.402*(xe-128)),ce=S(K-.3441363*(j-128)-.71413636*(xe-128)),ve=S(K+1.772*(j-128))):(z=N[0|W*m.scaleX*d],ce=L[0|W*B.scaleX*d],ve=$[0|W*w.scaleX*d]),ae[V++]=z,ae[V++]=ce,ae[V++]=ve;break;case 4:if(!this.adobe)throw new Error("Unsupported color mode (4 components)");for(Q=!1,this.adobe&&this.adobe.transformCode?Q=!0:typeof this.opts.colorTransform<"u"&&(Q=!!this.opts.colorTransform),m=this.components[0],B=this.components[1],w=this.components[2],P=this.components[3],X=0;X<y;X++)for(N=m.lines[0|X*m.scaleY*I],L=B.lines[0|X*B.scaleY*I],$=w.lines[0|X*w.scaleY*I],oe=P.lines[0|X*P.scaleY*I],W=0;W<u;W++)Q?(K=N[0|W*m.scaleX*d],j=L[0|W*B.scaleX*d],xe=$[0|W*w.scaleX*d],ne=oe[0|W*P.scaleX*d],re=255-S(K+1.402*(xe-128)),Z=255-S(K-.3441363*(j-128)-.71413636*(xe-128)),_=255-S(K+1.772*(j-128))):(re=N[0|W*m.scaleX*d],Z=L[0|W*B.scaleX*d],_=$[0|W*w.scaleX*d],ne=oe[0|W*P.scaleX*d]),ae[V++]=255-re,ae[V++]=255-Z,ae[V++]=255-_,ae[V++]=255-ne;break;default:throw new Error("Unsupported color mode");}return ae;},copyToImageData:function(u,y){var d=u.width,I=u.height,m=u.data,B=this.getData(d,I),w=0,P=0,N,L,$,oe,W,X,V,K,j;switch(this.components.length){case 1:for(L=0;L<I;L++)for(N=0;N<d;N++)$=B[w++],m[P++]=$,m[P++]=$,m[P++]=$,y&&(m[P++]=255);break;case 3:for(L=0;L<I;L++)for(N=0;N<d;N++)V=B[w++],K=B[w++],j=B[w++],m[P++]=V,m[P++]=K,m[P++]=j,y&&(m[P++]=255);break;case 4:for(L=0;L<I;L++)for(N=0;N<d;N++)W=B[w++],X=B[w++],$=B[w++],oe=B[w++],V=255-S(W*(1-oe/255)+oe),K=255-S(X*(1-oe/255)+oe),j=255-S($*(1-oe/255)+oe),m[P++]=V,m[P++]=K,m[P++]=j,y&&(m[P++]=255);break;default:throw new Error("Unsupported color mode");}}};var v=0,E=0;function x(A=0){var u=v+A;if(u>E){var y=Math.ceil((u-E)/1024/1024);throw new Error(`maxMemoryUsageInMB limit exceeded by at least ${y}MB`);}v=u;}return l.resetMaxMemoryUsage=function(A){v=0,E=A;},l.getBytesAllocated=function(){return v;},l.requestMemoryAllocation=x,l;}();typeof Cr<"u"?Cr.exports=Yn:typeof window<"u"&&(window["jpeg-js"]=window["jpeg-js"]||{},window["jpeg-js"].decode=Yn);function Yn(e,t={}){var r={colorTransform:void 0,useTArray:!1,formatAsRGBA:!0,tolerantDecoding:!0,maxResolutionInMP:100,maxMemoryUsageInMB:512},n={...r,...t},i=new Uint8Array(e),o=new Sr();o.opts=n,Sr.resetMaxMemoryUsage(n.maxMemoryUsageInMB*1024*1024),o.parse(i);var s=n.formatAsRGBA?4:3,a=o.width*o.height*s;try{Sr.requestMemoryAllocation(a);var c={width:o.width,height:o.height,exifBuffer:o.exifBuffer,data:n.useTArray?new Uint8Array(a):Buffer.alloc(a)};o.comments.length>0&&(c.comments=o.comments);}catch(f){throw f instanceof RangeError?new Error("Could not allocate enough memory for the image. Required: "+a):f instanceof ReferenceError&&f.message==="Buffer is not defined"?new Error("Buffer is not globally defined in this environment. Consider setting useTArray to true"):f;}return o.copyToImageData(c,n.formatAsRGBA),c;}});var qn=ut((zs,Xn)=>{var Co=$n(),To=Kn();Xn.exports={encode:Co,decode:To};});var Bo={};ii(Bo,{default:()=>Io});module.exports=oi(Bo);var Zr=bt(Mr(),1),Qr=bt(Kr(),1),_t=bt(or(),1),{GIFEncoder:Ni,quantize:Oi,applyPalette:Li}=Qr.default,Jr=e=>/^R0lGOD[dl]h/.test(e),Le=320,sr=512*1024,en=()=>new Promise(e=>setTimeout(e,0));function zi(e){var t=()=>new Error("This GIF download is incomplete. Reopen the GIF or share the original file and try again.");if(e.length<13)throw t();if(!/^GIF8[79]a$/.test(String.fromCharCode(...e.subarray(0,6))))throw new Error("This file could not be read as an animated GIF.");var r=13,n=0,i=!1;function o(f){if(r+f>e.length)throw t();var l=r;return r+=f,l;}function s(f){f&128&&o(3*(1<<(f&7)+1));}function a(){for(;;){var f=e[o(1)];if(f===0)return;o(f);}}for(s(e[10]);r<e.length;){var f=e[o(1)];if(f===59){if(!n||i)throw t();return r===e.length?e:e.subarray(0,r);}if(f===33){var l=e[o(1)];a(),l===249&&(i=!0);}else if(f===44){var _l4=o(9);if(s(e[_l4+8]),o(1),a(),i=!1,++n>250)throw new Error("Use a GIF with 250 frames or fewer.");}else throw new Error("This GIF contains an invalid data block. Share the original GIF file and try again.");}if(!n||i)throw t();var c=new Uint8Array(e.length+1);return c.set(e),c[e.length]=59,c;}function Gi(e){var t=zi(e),r;try{r=new Zr.GifReader(t);}catch{throw new Error("This file could not be read as an animated GIF.");}var{width:n,height:i}=r,o=r.numFrames();if(!n||!i||n*i>4*1024*1024)throw new Error("This GIF is too large to resize on mobile. Use a GIF below 4 megapixels.");if(!o||o>250)throw new Error("Use a GIF with 250 frames or fewer.");var s=[],a=0;for(var c=0;c<o;c++){var f=r.frameInfo(c);if(!f.width||!f.height||f.x+f.width>n||f.y+f.height>i||f.data_offset+f.data_length>t.length||f.palette_offset==null||f.palette_offset+f.palette_size*3>t.length||t[f.data_offset]<2||t[f.data_offset]>8)throw new Error("This GIF contains an invalid frame.");var l=f.delay<2?100:f.delay*10;a+=l,s.push({...f,delayMs:l});}if(a>5e3)throw new Error("Discord stickers can be at most 5 seconds long. Use a shorter GIF; it has not been trimmed or uploaded.");return{bytes:t,reader:r,width:n,height:i,frames:s,duration:a};}function Vr(e,t){if(t.transparent_index!=null||!(e[10]&128))return[0,0,0,0];var r=13+e[11]*3;return[e[r]??0,e[r+1]??0,e[r+2]??0,255];}function jr(e,t,r,n){for(var i=r.y;i<r.y+r.height;i++){var o=(i*t+r.x)*4;for(var s=0;s<r.width;s++,o+=4)e.set(n,o);}}function Hi(e,t,r){var n=Math.min(Le/t,Le/r),i=Math.max(1,Math.round(t*n)),o=Math.max(1,Math.round(r*n)),s=Math.floor((Le-i)/2),a=Math.floor((Le-o)/2),c=new Uint8Array(Le*Le*4);for(var f=0;f<o;f++){var l=Math.min(r-1,Math.floor((f+.5)*r/o));for(var h=0;h<i;h++){var g=Math.min(t-1,Math.floor((h+.5)*t/i)),b=(l*t+g)*4,S=((f+a)*Le+h+s)*4;c[S]=e[b],c[S+1]=e[b+1],c[S+2]=e[b+2],c[S+3]=e[b+3];}}return c;}async function Wi(e,t,r,n){var{reader:i,width:o,height:s,frames:a}=t,c=new Uint8Array(o*s*4);jr(c,o,{x:0,y:0,width:o,height:s},Vr(e,a[0]));var f=Ni(),l,h;for(var g=0;g<a.length;g++){n(),l?.disposal===2?jr(c,o,l,Vr(e,l)):l?.disposal===3&&h&&c.set(h);var b=a[g];h=b.disposal===3?c.slice():null,i.decodeAndBlitFrameRGBA(g,c);var S=Hi(c,o,s),v=Oi(S,r-1,{format:"rgba4444",oneBitAlpha:!0}),E=[[0,0,0,0],...v.filter(A=>A[3]!==0)];E.length===1&&E.push([0,0,0,255]);var x=Li(S,E,"rgba4444");if(f.writeFrame(x,Le,Le,{palette:E,delay:b.delayMs,repeat:i.loopCount()??-1,transparent:!0,transparentIndex:0,dispose:2}),f.bytesView().length>sr)return null;l=b,await en();}return f.finish(),f.bytesView().length<=sr?f.bytes():null;}async function tn(e,t=()=>{}){t(),e=e.replace(/\s/g,"");var r=(0,_t.toByteArray)(e),n=Gi(r),{bytes:i}=n;if(n.width===Le&&n.height===Le&&i.length<=sr)return{base64:i===r?e:(0,_t.fromByteArray)(i),mimeType:"image/gif",extension:"gif"};if(n.width*n.height*n.frames.length>80*1024*1024)throw new Error("This GIF is too complex to resize on mobile. Use a smaller GIF.");for(var o of[256,128,64]){await en(),t();var s=await Wi(i,n,o,t);if(s)return{base64:(0,_t.fromByteArray)(s),mimeType:"image/gif",extension:"gif"};}throw new Error("This animated GIF is still over 512 KiB after resizing. Use a shorter or simpler GIF.");}async function St(e){var t=new Set();async function r(n,i){if(n==null||i>5)return;if(typeof n=="string")try{return r(JSON.parse(n),i+1);}catch{return;}if(typeof n!="object"||t.has(n))return;if(t.add(n),typeof n.then=="function")try{return r(await n,i+1);}catch{return;}if(Array.isArray(n)||typeof n.id=="string"&&n.id)return n;for(var a of["body","data","result","response","emoji","sticker","emojis","stickers","parsedBody"]){var c=await r(n[a],i+1);if(c)return c;}if(typeof n.json=="function")try{var _a3=await r(await n.json(),i+1);if(_a3)return _a3;}catch{}else{var _a4=await r(n.json,i+1);if(_a4)return _a4;}var o;try{o=typeof n.text=="function"?await n.text():n.text;}catch{}var s=await r(o,i+1);return s||(typeof n.message=="string"?n:void 0);}return r(e,0);}function rn(e,t=globalThis){var r=a=>{try{return a();}catch{}},n=(...a)=>r(()=>e.metro.findByProps(...a));function i(){var a=[()=>typeof valenced<"u"?valenced.discord?.native?.FileModule:void 0,()=>typeof revenge<"u"?revenge.discord?.native?.FileModule:void 0,()=>n("writeFile","removeFile"),...["NativeFileModule","RTNFileManager","DCDFileManager"].map(c=>()=>e.metro.common.ReactNative.NativeModules?.[c]??t.nativeModuleProxy?.[c])];for(var c of a){var f=r(c);if(typeof f?.writeFile=="function"&&typeof f?.removeFile=="function")return f;}}function o(){for(var a of[()=>e.metro.common.RestAPI,()=>e.metro.common.restAPI,()=>n("HTTP")?.HTTP,()=>n("get","post","del")]){var c=r(a);if(typeof c?.post=="function")return c;}}function s(a){if(a!=="sticker"&&a!=="emoji")throw new Error("Unknown expression type.");var c=a==="sticker"?"createGuildSticker":"uploadEmoji",f=n(c),l=typeof f?.[c]=="function",h=l?void 0:o();if(!l&&!h)throw new Error("Discord\u2019s signed-in upload API is unavailable. Restart Discord and try again.");return async(g,b=()=>{})=>{b();var S=`/guilds/${g.guildId}/${a==="sticker"?"stickers":"emojis"}`,v,E,x=async()=>{if(typeof h?.get!="function")return;b();var y=await h.get({url:S,failImmediatelyWhenRateLimited:!0});if(b(),y?.ok===!1||Number(y?.status??y?.statusCode)>=400)return;var d=await St(y);return b(),Array.isArray(d)?d:void 0;};if(l)v=await f[c](g);else{var y;if(a==="sticker"){if(typeof t.FormData!="function")throw new Error("Discord\u2019s multipart upload support is unavailable.");if(y=new t.FormData(),typeof y.getParts!="function")throw new Error("Discord\u2019s native multipart upload support is unavailable.");if(!/^(file|content):\/\//.test(g.uri))throw new Error("The sticker file is not ready to upload.");y.append("name",g.name),y.append("tags",g.tags),y.append("description",g.description??""),y.append("file",{uri:g.uri,name:g.mimeType==="image/gif"?"sticker.gif":"sticker.png",type:g.mimeType});}else y={name:g.name,image:g.image,roles:g.roles??[]};try{var d=await x();d&&(E=new Set(d.map(I=>I.id)));}catch{b();}b(),v=await h.post({url:S,body:y,oldFormErrors:!0,failImmediatelyWhenRateLimited:!0});}var A=await St(v),u=v?.status??v?.statusCode??v?.response?.status;if(v?.ok===!1||Number(u)>=400)throw{status:u,body:A??v?.body};if(b(),!A?.id&&!l&&E){var _y;try{_y=await x();}catch{b();}var _d=r(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.()?.id),I=_y?.filter(m=>typeof m.id=="string"&&m.id&&!E.has(m.id)&&m.name===g.name&&(!m.user?.id||m.user.id===_d))??[];I.length===1&&(A=I[0]);}if((!l||a==="sticker")&&!A?.id)throw new Error(`Discord did not confirm the upload. Check the server\u2019s ${a==="sticker"?"stickers":"emoji"} before trying again.`);return b(),!l&&a==="sticker"&&r(()=>e.metro.common.FluxDispatcher?.dispatch?.({type:"GUILD_STICKERS_CREATE_SUCCESS",guildId:g.guildId,sticker:{...A,user:A.user??r(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.())}})),A;};}return{resolve:s,files:i};}function nn(e,t=globalThis){var r=rn(e,t),n=c=>{try{return c();}catch{}},i=(...c)=>n(()=>e.metro.findByProps(...c)),o=()=>Object.assign(new Error("Cancelled"),{code:"E_PICKER_CANCELLED"});function s(c,f,l){return new Promise((h,g)=>{var b,S=!1,v=x=>{S||(S=!0,t.clearTimeout(b),l?.removeEventListener?.("abort",E),x?g(x):h());},E=()=>v(o());if(l?.aborted){E();return;}l?.addEventListener?.("abort",E),b=t.setTimeout(()=>{try{f(),v();}catch(x){v(x);}},c);});}function a(c){if(c!=="sticker"||e.host?.id!=="valenced")return r.resolve(c);var f=n(()=>e.metro.common.RestAPI)??n(()=>e.metro.common.restAPI)??i("HTTP")?.HTTP??i("get","post","del");if(typeof f?.post!="function")throw new Error("Discord\u2019s signed-in sticker upload API is unavailable. Restart Discord and try again.");return async(l,h=()=>{},g)=>{if(h(),g?.aborted)throw o();if(typeof t.FormData!="function")throw new Error("Discord\u2019s multipart upload support is unavailable.");var b=new t.FormData();if(typeof b.getParts!="function")throw new Error("Discord\u2019s native multipart upload support is unavailable.");if(!/^(file|content):\/\//.test(l.uri))throw new Error("The sticker file is not ready to upload.");b.append("name",l.name),b.append("tags",l.tags),b.append("description",l.description??""),b.append("file",{uri:l.uri,name:l.mimeType==="image/gif"?"sticker.gif":"sticker.png",type:l.mimeType});var S=`/guilds/${l.guildId}/stickers`,v=n(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.()?.id),E=()=>{if(h(),g?.aborted||v&&n(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.()?.id)!==v)throw o();},x=w=>Number(w?.status??w?.statusCode??w?.response?.status);async function A(){if(typeof f.get!="function")return;E();var w=await f.get({url:S,failImmediatelyWhenRateLimited:!0});if(E(),w?.ok===!1||x(w)>=400)return;var P=await St(w);return E(),Array.isArray(P)?P:void 0;}var u;try{u=await A();}catch{E();}var y=u?new Set(u.map(w=>w.id)):void 0;E();var d=await f.post({url:S,body:b,oldFormErrors:!0,failImmediatelyWhenRateLimited:!0});E();var I=await St(d);E();var m=x(d);if(d?.ok===!1||m>=400||typeof I?.code=="number"&&typeof I?.message=="string")throw{status:m,body:I??d?.body};var B=w=>w&&!Array.isArray(w)&&typeof w.id=="string"&&w.id&&(w.name==null||w.name===l.name)&&(w.guild_id==null||w.guild_id===l.guildId)&&(!v||!w.user?.id||w.user.id===v)&&(w.format_type==null||(l.mimeType==="image/gif"?w.format_type===4:[1,2].includes(w.format_type)));if(!B(I)&&(I=void 0,y)){var w=[350,750,1500];for(var P=0;P<=w.length;P++){var N=void 0;try{N=await A();}catch{E();}if(!N)break;var L=N.filter($=>!y.has($.id)&&$.name===l.name&&B($));if(L.length===1){I=L[0];break;}if(L.length>1||P===w.length||!Number.isNaN(m)&&m!==201&&m!==202)break;await s(w[P],E,g);}}if(E(),!I?.id)throw Object.assign(new Error("Discord did not confirm the upload. The server\u2019s sticker list was checked; no upload was repeated."),{code:"STICKER_UPLOAD_UNCONFIRMED"});return n(()=>e.metro.common.FluxDispatcher?.dispatch?.({type:"GUILD_STICKERS_CREATE_SUCCESS",guildId:l.guildId,sticker:{...I,name:I.name??l.name,guild_id:I.guild_id??l.guildId,user:I.user??n(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.())}})),I;};}return{files:r.files,resolve:a};}function on(e,t){var{React:r,ReactNative:n}=e.metro.common,i=r.createElement,o=new Set(),s=0,a=l=>{try{return l();}catch{}},c=(...l)=>a(()=>e.metro.findByProps(...l));function f(l,h,g){var b=c("openAlert","dismissAlert");if(!n.Modal||typeof b?.openAlert!="function"||!r.useState||!r.useEffect)return!1;for(var A of[...o])A.close();var S=`${t}.panel.${Date.now().toString(36)}.${Math.random().toString(36).slice(2)}.${++s}`,v={visible:!0,listeners:new Set()},E=()=>{if(!v.visible)return;v.visible=!1;for(var y of v.listeners)y();o.delete(v),a(()=>g?.()),a(()=>b.dismissAlert(S));var A=c("useAlertStore")??a(()=>e.metro.findByImportedPath?.("design/components/AlertModal/native/useAlertStore.native.tsx")),u=A?.useAlertStore??A?.default;typeof u?.setState=="function"&&a(()=>u.setState(y=>{if(!Array.isArray(y.alerts))return y;var d=y.alerts.filter(I=>I.key!==S&&I.node!==v.node);return d.length===y.alerts.length?y:{alerts:d};}));};v.close=E;function x(){var[,A]=r.useState(0);r.useEffect(()=>{var I=()=>A(m=>m+1);return v.listeners.add(I),()=>{v.listeners.delete(I),E();};},[]);var u=n.useWindowDimensions?.()??n.Dimensions?.get?.("window")??{height:800};if(!v.visible)return null;var d=(a(()=>e.metro.findByStoreName("ThemeStore")?.theme)??n.Appearance?.getColorScheme?.())==="light"?"#ffffff":"#242429";return i(n.Modal,{visible:!0,transparent:!0,animationType:"slide",presentationStyle:"overFullScreen",onRequestClose:E,onDismiss:E,statusBarTranslucent:!1,navigationBarTranslucent:!1},i(n.KeyboardAvoidingView??n.View,{style:{flex:1},behavior:n.Platform?.OS==="ios"?"padding":"height"},i(n.View,{style:{flex:1,justifyContent:"flex-end",backgroundColor:"rgba(0,0,0,0.65)"}},i(n.Pressable??n.TouchableOpacity,{onPress:E,accessibilityRole:"button",accessibilityLabel:`Close ${h}`,style:{position:"absolute",top:0,left:0,right:0,bottom:0}}),i(n.View,{testID:t+"-panel",accessibilityViewIsModal:!0,onAccessibilityEscape:E,style:{height:Math.min(720,u.height*.86),maxHeight:"92%",backgroundColor:d,borderTopLeftRadius:20,borderTopRightRadius:20,overflow:"hidden",paddingTop:8,paddingBottom:16}},l(E)))));}v.node=i(x),o.add(v);try{var _A=b.openAlert(S,v.node,E,{dismissable:!0});return _A?.catch&&_A.catch(E),!0;}catch{return E(),!1;}}return{open:f,closeAll(){for(var l of[...o])l.close();}};}function sn(e,{title:t,id:r,testID:n},i=globalThis){var{React:o,ReactNative:s}=e.metro.common,a=o.createElement,c=new Set(),f=0,l=b=>{try{return b();}catch{}};function h(b){var S=l(()=>b.getCurrentRoute?.());if(S)return S;var v=l(()=>b.getRootState?.()??b.getState?.()),E;for(var x=0;x<12&&v?.routes?.length;x++)E=v.routes[v.index??v.routes.length-1],v=E?.state;return E;}function g(b,S){var v=l(()=>e.metro.findByProps("getRootNavigationRef")?.getRootNavigationRef?.());if(!v?.navigate||!v.goBack||!v.getCurrentRoute&&!v.getRootState&&!v.getState)return!1;for(var w of[...c])w.close();var E=`${r}.${Date.now().toString(36)}.${++f}.${Math.random().toString(36).slice(2)}`,x=l(()=>e.metro.common.NavigationNative?.useIsFocused),A={open:!0,listeners:new Set(),presented:!1,mounted:!1},u=()=>h(v)?.params?.__expressionPage===E,y=()=>A.open&&(!A.presented||u()),d=(w=!0)=>{if(!A.open)return;var P=u();A.open=!1,i.clearTimeout(A.timer),i.clearTimeout(A.mountTimer),l(()=>A.cancelNavigation?.()),l(()=>A.unsubscribe?.()),c.delete(A),l(()=>S?.());for(var N of A.listeners)N();w&&P&&l(()=>v.canGoBack?.())!==!1&&l(()=>v.goBack());};A.close=d,c.add(A);function I(){var[,w]=o.useState(0),P=typeof x=="function"?x():void 0;o.useEffect(()=>{var L=()=>w($=>$+1);return A.listeners.add(L),A.mounted=!0,i.clearTimeout(A.mountTimer),u()&&(A.presented=!0),!A.open&&u()&&l(()=>v.goBack()),()=>{A.listeners.delete(L),d(!1);};},[]),o.useEffect(()=>{!A.open&&u()&&l(()=>v.goBack());},[P]);var N=l(()=>e.metro.findByStoreName("ThemeStore")?.theme)!=="light";return a(s.View,{testID:n,style:{flex:1,backgroundColor:N?"#242429":"#fff"}},A.open?b(()=>d(),y):a(s.Text,{style:{padding:24,fontSize:16,color:N?"#f2f3f5":"#202127"}},t+" is closed. Use Back to return to Discord."));}var m=()=>{A.open&&(u()?A.presented=!0:A.presented&&d(!1));},B=l(()=>v.addListener?.("state",m));return A.unsubscribe=typeof B=="function"?B:()=>B?.remove?.(),A.timer=i.setTimeout(()=>{if(A.timer=void 0,!!A.open){A.mountTimer=i.setTimeout(()=>{!A.open||A.mounted||(d(!1),l(()=>e.ui.toasts.showToast(t+" could not open. Reopen the image menu and try again.")));},8e3);try{var _w2=v.navigate("BUNNY_CUSTOM_PAGE",{title:t,__expressionPage:E,__expressionOpen:()=>A.open,__expressionCancel:()=>d(!1),render:I});typeof _w2=="function"&&(A.cancelNavigation=_w2);}catch{d(!1),l(()=>e.ui.toasts.showToast(t+" could not open. Reopen the image menu and try again."));}}},350),!0;}return{open:g,closeAll(){for(var b of[...c])b.close();}};}var Ce=Uint8Array,De=Uint16Array,gr=Int32Array,Gt=new Ce([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),Ht=new Ce([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),hr=new Ce([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),hn=function(e,t){for(var r=new De(31),n=0;n<31;++n)r[n]=t+=1<<e[n-1];for(var i=new gr(r[30]),n=1;n<30;++n)for(var o=r[n];o<r[n+1];++o)i[o]=o-r[n]<<5|n;return{b:r,r:i};},un=hn(Gt,2),dn=un.b,ur=un.r;dn[28]=258,ur[258]=28;var pn=hn(Ht,0),$i=pn.b,an=pn.r,dr=new De(32768);for(we=0;we<32768;++we)Ke=(we&43690)>>1|(we&21845)<<1,Ke=(Ke&52428)>>2|(Ke&13107)<<2,Ke=(Ke&61680)>>4|(Ke&3855)<<4,dr[we]=((Ke&65280)>>8|(Ke&255)<<8)>>1;var Ke,we,$e=function(e,t,r){for(var n=e.length,i=0,o=new De(t);i<n;++i)e[i]&&++o[e[i]-1];var s=new De(t);for(i=1;i<t;++i)s[i]=s[i-1]+o[i-1]<<1;var a;if(r){a=new De(1<<t);var c=15-t;for(i=0;i<n;++i)if(e[i])for(var f=i<<4|e[i],l=t-e[i],h=s[e[i]-1]++<<l,g=h|(1<<l)-1;h<=g;++h)a[dr[h]>>c]=f;}else for(a=new De(n),i=0;i<n;++i)e[i]&&(a[i]=dr[s[e[i]-1]++]>>15-e[i]);return a;},et=new Ce(288);for(we=0;we<144;++we)et[we]=8;var we;for(we=144;we<256;++we)et[we]=9;var we;for(we=256;we<280;++we)et[we]=7;var we;for(we=280;we<288;++we)et[we]=8;var we,kt=new Ce(32);for(we=0;we<32;++we)kt[we]=5;var we,Yi=$e(et,9,0),Ki=$e(et,9,1),Xi=$e(kt,5,0),qi=$e(kt,5,1),ar=function(e){for(var t=e[0],r=1;r<e.length;++r)e[r]>t&&(t=e[r]);return t;},ze=function(e,t,r){var n=t/8|0;return(e[n]|e[n+1]<<8)>>(t&7)&r;},lr=function(e,t){var r=t/8|0;return(e[r]|e[r+1]<<8|e[r+2]<<16)>>(t&7);},xr=function(e){return(e+7)/8|0;},st=function(e,t,r){return(t==null||t<0)&&(t=0),(r==null||r>e.length)&&(r=e.length),new Ce(e.subarray(t,r));};var Vi=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],Me=function(e,t,r){var n=new Error(t||Vi[e]);if(n.code=e,Error.captureStackTrace&&Error.captureStackTrace(n,Me),!r)throw n;return n;},vn=function(e,t,r,n){var i=e.length,o=n?n.length:0;if(!i||t.f&&!t.l)return r||new Ce(0);var s=!r,a=s||t.i!=2,c=t.i;s&&(r=new Ce(i*3));var f=function(G){var O=r.length;if(G>O){var ue=new Ce(Math.max(O*2,G));ue.set(r),r=ue;}},l=t.f||0,h=t.p||0,g=t.b||0,b=t.l,S=t.d,v=t.m,E=t.n,x=i*8;do{if(!b){l=ze(e,h,1);var A=ze(e,h+1,3);if(h+=3,A){if(A==1)b=Ki,S=qi,v=9,E=5;else if(A==2){var I=ze(e,h,31)+257,m=ze(e,h+10,15)+4,B=I+ze(e,h+5,31)+1;h+=14;for(var w=new Ce(B),P=new Ce(19),N=0;N<m;++N)P[hr[N]]=ze(e,h+N*3,7);h+=m*3;for(var L=ar(P),$=(1<<L)-1,oe=$e(P,L,1),N=0;N<B;){var W=oe[ze(e,h,$)];h+=W&15;var u=W>>4;if(u<16)w[N++]=u;else{var X=0,V=0;for(u==16?(V=3+ze(e,h,3),h+=2,X=w[N-1]):u==17?(V=3+ze(e,h,7),h+=3):u==18&&(V=11+ze(e,h,127),h+=7);V--;)w[N++]=X;}}var K=w.subarray(0,I),j=w.subarray(I);v=ar(K),E=ar(j),b=$e(K,v,1),S=$e(j,E,1);}else Me(1);}else{var u=xr(h)+4,y=e[u-4]|e[u-3]<<8,d=u+y;if(d>i){c&&Me(0);break;}a&&f(g+y),r.set(e.subarray(u,d),g),t.b=g+=y,t.p=h=d*8,t.f=l;continue;}if(h>x){c&&Me(0);break;}}a&&f(g+131072);for(var xe=(1<<v)-1,ne=(1<<E)-1,re=h;;re=h){var X=b[lr(e,h)&xe],Z=X>>4;if(h+=X&15,h>x){c&&Me(0);break;}if(X||Me(2),Z<256)r[g++]=Z;else if(Z==256){re=h,b=null;break;}else{var _=Z-254;if(Z>264){var N=Z-257,z=Gt[N];_=ze(e,h,(1<<z)-1)+dn[N],h+=z;}var ce=S[lr(e,h)&ne],ve=ce>>4;ce||Me(3),h+=ce&15;var j=$i[ve];if(ve>3){var z=Ht[ve];j+=lr(e,h)&(1<<z)-1,h+=z;}if(h>x){c&&Me(0);break;}a&&f(g+131072);var Q=g+_;if(g<j){var le=o-j,ae=Math.min(j,Q);for(le+g<0&&Me(3);g<ae;++g)r[g]=n[le+g];}for(;g<Q;++g)r[g]=r[g-j];}}t.l=b,t.p=re,t.b=g,t.f=l,b&&(l=1,t.m=v,t.d=S,t.n=E);}while(!l);return g!=r.length&&s?st(r,0,g):r.subarray(0,g);},Xe=function(e,t,r){r<<=t&7;var n=t/8|0;e[n]|=r,e[n+1]|=r>>8;},Ct=function(e,t,r){r<<=t&7;var n=t/8|0;e[n]|=r,e[n+1]|=r>>8,e[n+2]|=r>>16;},cr=function(e,t){for(var r=[],n=0;n<e.length;++n)e[n]&&r.push({s:n,f:e[n]});var i=r.length,o=r.slice();if(!i)return{t:xn,l:0};if(i==1){var s=new Ce(r[0].s+1);return s[r[0].s]=1,{t:s,l:1};}r.sort(function(d,I){return d.f-I.f;}),r.push({s:-1,f:25001});var a=r[0],c=r[1],f=0,l=1,h=2;for(r[0]={s:-1,f:a.f+c.f,l:a,r:c};l!=i-1;)a=r[r[f].f<r[h].f?f++:h++],c=r[f!=l&&r[f].f<r[h].f?f++:h++],r[l++]={s:-1,f:a.f+c.f,l:a,r:c};for(var g=o[0].s,n=1;n<i;++n)o[n].s>g&&(g=o[n].s);var b=new De(g+1),S=pr(r[l-1],b,0);if(S>t){var n=0,v=0,E=S-t,x=1<<E;for(o.sort(function(I,m){return b[m.s]-b[I.s]||I.f-m.f;});n<i;++n){var A=o[n].s;if(b[A]>t)v+=x-(1<<S-b[A]),b[A]=t;else break;}for(v>>=E;v>0;){var u=o[n].s;b[u]<t?v-=1<<t-b[u]++-1:++n;}for(;n>=0&&v;--n){var y=o[n].s;b[y]==t&&(--b[y],++v);}S=t;}return{t:new Ce(b),l:S};},pr=function(e,t,r){return e.s==-1?Math.max(pr(e.l,t,r+1),pr(e.r,t,r+1)):t[e.s]=r;},ln=function(e){for(var t=e.length;t&&!e[--t];);for(var r=new De(++t),n=0,i=e[0],o=1,s=function(c){r[n++]=c;},a=1;a<=t;++a)if(e[a]==i&&a!=t)++o;else{if(!i&&o>2){for(;o>138;o-=138)s(32754);o>2&&(s(o>10?o-11<<5|28690:o-3<<5|12305),o=0);}else if(o>3){for(s(i),--o;o>6;o-=6)s(8304);o>2&&(s(o-3<<5|8208),o=0);}for(;o--;)s(i);o=1,i=e[a];}return{c:r.subarray(0,n),n:t};},Tt=function(e,t){for(var r=0,n=0;n<t.length;++n)r+=e[n]*t[n];return r;},gn=function(e,t,r){var n=r.length,i=xr(t+2);e[i]=n&255,e[i+1]=n>>8,e[i+2]=e[i]^255,e[i+3]=e[i+1]^255;for(var o=0;o<n;++o)e[i+o+4]=r[o];return(i+4+n)*8;},cn=function(e,t,r,n,i,o,s,a,c,f,l){Xe(t,l++,r),++i[256];for(var h=cr(i,15),g=h.t,b=h.l,S=cr(o,15),v=S.t,E=S.l,x=ln(g),A=x.c,u=x.n,y=ln(v),d=y.c,I=y.n,m=new De(19),B=0;B<A.length;++B)++m[A[B]&31];for(var B=0;B<d.length;++B)++m[d[B]&31];for(var w=cr(m,7),P=w.t,N=w.l,L=19;L>4&&!P[hr[L-1]];--L);var $=f+5<<3,oe=Tt(i,et)+Tt(o,kt)+s,W=Tt(i,g)+Tt(o,v)+s+14+3*L+Tt(m,P)+2*m[16]+3*m[17]+7*m[18];if(c>=0&&$<=oe&&$<=W)return gn(t,l,e.subarray(c,c+f));var X,V,K,j;if(Xe(t,l,1+(W<oe)),l+=2,W<oe){X=$e(g,b,0),V=g,K=$e(v,E,0),j=v;var xe=$e(P,N,0);Xe(t,l,u-257),Xe(t,l+5,I-1),Xe(t,l+10,L-4),l+=14;for(var B=0;B<L;++B)Xe(t,l+3*B,P[hr[B]]);l+=3*L;for(var ne=[A,d],re=0;re<2;++re)for(var Z=ne[re],B=0;B<Z.length;++B){var _=Z[B]&31;Xe(t,l,xe[_]),l+=P[_],_>15&&(Xe(t,l,Z[B]>>5&127),l+=Z[B]>>12);}}else X=Yi,V=et,K=Xi,j=kt;for(var B=0;B<a;++B){var z=n[B];if(z>255){var _=z>>18&31;Ct(t,l,X[_+257]),l+=V[_+257],_>7&&(Xe(t,l,z>>23&31),l+=Gt[_]);var ce=z&31;Ct(t,l,K[ce]),l+=j[ce],ce>3&&(Ct(t,l,z>>5&8191),l+=Ht[ce]);}else Ct(t,l,X[z]),l+=V[z];}return Ct(t,l,X[256]),l+V[256];},ji=new gr([65540,131080,131088,131104,262176,1048704,1048832,2114560,2117632]),xn=new Ce(0),Zi=function(e,t,r,n,i,o){var s=o.z||e.length,a=new Ce(n+s+5*(1+Math.ceil(s/7e3))+i),c=a.subarray(n,a.length-i),f=o.l,l=(o.r||0)&7;if(t){l&&(c[0]=o.r>>3);for(var h=ji[t-1],g=h>>13,b=h&8191,S=(1<<r)-1,v=o.p||new De(32768),E=o.h||new De(S+1),x=Math.ceil(r/3),A=2*x,u=function(se){return(e[se]^e[se+1]<<x^e[se+2]<<A)&S;},y=new gr(25e3),d=new De(288),I=new De(32),m=0,B=0,w=o.i||0,P=0,N=o.w||0,L=0;w+2<s;++w){var $=u(w),oe=w&32767,W=E[$];if(v[oe]=W,E[$]=oe,N<=w){var X=s-w;if((m>7e3||P>24576)&&(X>423||!f)){l=cn(e,c,0,y,d,I,B,P,L,w-L,l),P=m=B=0,L=w;for(var V=0;V<286;++V)d[V]=0;for(var V=0;V<30;++V)I[V]=0;}var K=2,j=0,xe=b,ne=oe-W&32767;if(X>2&&$==u(w-ne))for(var re=Math.min(g,X)-1,Z=Math.min(32767,w),_=Math.min(258,X);ne<=Z&&--xe&&oe!=W;){if(e[w+K]==e[w+K-ne]){for(var z=0;z<_&&e[w+z]==e[w+z-ne];++z);if(z>K){if(K=z,j=ne,z>re)break;for(var ce=Math.min(ne,z-2),ve=0,V=0;V<ce;++V){var Q=w-ne+V&32767,le=v[Q],ae=Q-le&32767;ae>ve&&(ve=ae,W=Q);}}}oe=W,W=v[oe],ne+=oe-W&32767;}if(j){y[P++]=268435456|ur[K]<<18|an[j];var G=ur[K]&31,O=an[j]&31;B+=Gt[G]+Ht[O],++d[257+G],++I[O],N=w+K,++m;}else y[P++]=e[w],++d[e[w]];}}for(w=Math.max(w,N);w<s;++w)y[P++]=e[w],++d[e[w]];l=cn(e,c,f,y,d,I,B,P,L,w-L,l),f||(o.r=l&7|c[l/8|0]<<3,l-=7,o.h=E,o.p=v,o.i=w,o.w=N);}else{for(var w=o.w||0;w<s+f;w+=65535){var ue=w+65535;ue>=s&&(c[l/8|0]=f,ue=s),l=gn(c,l+1,e.subarray(w,ue));}o.i=s;}return st(a,0,n+xr(l)+i);};var yn=function(){var e=1,t=0;return{p:function(r){for(var n=e,i=t,o=r.length|0,s=0;s!=o;){for(var a=Math.min(s+2655,o);s<a;++s)i+=n+=r[s];n=(n&65535)+15*(n>>16),i=(i&65535)+15*(i>>16);}e=n,t=i;},d:function(){return e%=65521,t%=65521,(e&255)<<24|(e&65280)<<8|(t&255)<<8|t>>8;}};},Qi=function(e,t,r,n,i){if(!i&&(i={l:1},t.dictionary)){var o=t.dictionary.subarray(-32768),s=new Ce(o.length+e.length);s.set(o),s.set(e,o.length),e=s,i.w=o.length;}return Zi(e,t.level==null?6:t.level,t.mem==null?i.l?Math.ceil(Math.max(8,Math.min(13,Math.log(e.length)))*1.5):20:12+t.mem,r,n,i);};var mn=function(e,t,r){for(;r;++t)e[t]=r,r>>>=8;};var Ji=function(e,t){var r=t.level,n=r==0?0:r<6?1:r==9?3:2;if(e[0]=120,e[1]=n<<6|(t.dictionary&&32),e[1]|=31-(e[0]<<8|e[1])%31,t.dictionary){var i=yn();i.p(t.dictionary),mn(e,2,i.d());}},wn=function(e,t){return((e[0]&15)!=8||e[0]>>4>7||(e[0]<<8|e[1])%31)&&Me(6,"invalid zlib data"),(e[1]>>5&1)==+!t&&Me(6,"invalid zlib data: "+(e[1]&32?"need":"unexpected")+" dictionary"),(e[1]>>3&4)+2;};var fr=function(){function e(t,r){typeof t=="function"&&(r=t,t={}),this.ondata=r;var n=t&&t.dictionary&&t.dictionary.subarray(-32768);this.s={i:0,b:n?n.length:0},this.o=new Ce(32768),this.p=new Ce(0),n&&this.o.set(n);}return e.prototype.e=function(t){if(this.ondata||Me(5),this.d&&Me(4),!this.p.length)this.p=t;else if(t.length){var r=new Ce(this.p.length+t.length);r.set(this.p),r.set(t,this.p.length),this.p=r;}},e.prototype.c=function(t){this.s.i=+(this.d=t||!1);var r=this.s.b,n=vn(this.p,this.s,this.o);this.ondata(st(n,r,this.s.b),this.d),this.o=st(n,this.s.b-32768),this.s.b=this.o.length,this.p=st(this.p,this.s.p/8|0),this.s.p&=7;},e.prototype.push=function(t,r){this.e(t),this.c(r);},e;}();function An(e,t){t||(t={});var r=yn();r.p(e);var n=Qi(e,t,t.dictionary?6:2,4);return Ji(n,t),mn(n,n.length-4,r.d()),n;}var Ft=function(){function e(t,r){fr.call(this,t,r),this.v=t&&t.dictionary?2:1;}return e.prototype.push=function(t,r){if(fr.prototype.e.call(this,t),this.v){if(this.p.length<6&&!r)return;this.p=this.p.subarray(wn(this.p,this.v-1)),this.v=0;}r&&(this.p.length<4&&Me(6,"invalid zlib data"),this.p=this.p.subarray(0,-4)),fr.prototype.c.call(this,r);},e;}();function bn(e,t){return vn(e.subarray(wn(e,t&&t.dictionary),-4),{i:2},t&&t.out,t&&t.dictionary);}var fn=typeof TextEncoder<"u"&&new TextEncoder(),vr=typeof TextDecoder<"u"&&new TextDecoder(),eo=0;try{vr.decode(xn,{stream:!0}),eo=1;}catch{}var to=function(e){for(var t="",r=0;;){var n=e[r++],i=(n>127)+(n>223)+(n>239);if(r+i>e.length)return{s:t,r:st(e,r-1)};i?i==3?(n=((n&15)<<18|(e[r++]&63)<<12|(e[r++]&63)<<6|e[r++]&63)-65536,t+=String.fromCharCode(55296|n>>10,56320|n&1023)):i&1?t+=String.fromCharCode((n&31)<<6|e[r++]&63):t+=String.fromCharCode((n&15)<<12|(e[r++]&63)<<6|e[r++]&63):t+=String.fromCharCode(n);}};function En(e,t){if(t){for(var r=new Ce(e.length),n=0;n<e.length;++n)r[n]=e.charCodeAt(n);return r;}if(fn)return fn.encode(e);for(var i=e.length,o=new Ce(e.length+(e.length>>1)),s=0,a=function(l){o[s++]=l;},n=0;n<i;++n){if(s+5>o.length){var c=new Ce(s+8+(i-n<<1));c.set(o),o=c;}var f=e.charCodeAt(n);f<128||t?a(f):f<2048?(a(192|f>>6),a(128|f&63)):f>55295&&f<57344?(f=65536+(f&1047552)|e.charCodeAt(++n)&1023,a(240|f>>18),a(128|f>>12&63),a(128|f>>6&63),a(128|f&63)):(a(224|f>>12),a(128|f>>6&63),a(128|f&63));}return st(o,0,s);}function _n(e,t){if(t){for(var r="",n=0;n<e.length;n+=16384)r+=String.fromCharCode.apply(null,e.subarray(n,n+16384));return r;}else{if(vr)return vr.decode(e);var i=to(e),o=i.s,r=i.r;return r.length&&Me(8),o;}}var Wt=class{encode(t=""){return En(String(t));}},dt=class{constructor(t="utf-8"){this.latin1=/^(latin1|iso-8859-1)$/i.test(t);}decode(t=new Uint8Array()){var r=new Uint8Array(t.buffer??t,t.byteOffset??0,t.byteLength);return _n(r,this.latin1);}};function yr(e,t="utf8"){return new dt(t).decode(e);}var ro=new Wt();function Sn(e){return ro.encode(e);}var no=1024*8,io=(()=>{var e=new Uint8Array(4),t=new Uint32Array(e.buffer);return!((t[0]=1)&e[0]);})(),mr={int8:globalThis.Int8Array,uint8:globalThis.Uint8Array,int16:globalThis.Int16Array,uint16:globalThis.Uint16Array,int32:globalThis.Int32Array,uint32:globalThis.Uint32Array,uint64:globalThis.BigUint64Array,int64:globalThis.BigInt64Array,float32:globalThis.Float32Array,float64:globalThis.Float64Array},at=class e{constructor(t=no,r={}){ye(this,"buffer");ye(this,"byteLength");ye(this,"byteOffset");ye(this,"length");ye(this,"offset");ye(this,"lastWrittenByte");ye(this,"littleEndian");ye(this,"_data");ye(this,"_mark");ye(this,"_marks");var n=!1;typeof t=="number"?t=new ArrayBuffer(t):(n=!0,this.lastWrittenByte=t.byteLength);var i=r.offset?r.offset>>>0:0,o=t.byteLength-i,s=i;(ArrayBuffer.isView(t)||t instanceof e)&&(t.byteLength!==t.buffer.byteLength&&(s=t.byteOffset+i),t=t.buffer),n?this.lastWrittenByte=o:this.lastWrittenByte=0,this.buffer=t,this.length=o,this.byteLength=o,this.byteOffset=s,this.offset=0,this.littleEndian=!0,this._data=new DataView(this.buffer,s,o),this._mark=0,this._marks=[];}available(t=1){return this.offset+t<=this.length;}isLittleEndian(){return this.littleEndian;}setLittleEndian(){return this.littleEndian=!0,this;}isBigEndian(){return!this.littleEndian;}setBigEndian(){return this.littleEndian=!1,this;}skip(t=1){return this.offset+=t,this;}back(t=1){return this.offset-=t,this;}seek(t){return this.offset=t,this;}mark(){return this._mark=this.offset,this;}reset(){return this.offset=this._mark,this;}pushMark(){return this._marks.push(this.offset),this;}popMark(){var t=this._marks.pop();if(t===void 0)throw new Error("Mark stack empty");return this.seek(t),this;}rewind(){return this.offset=0,this;}ensureAvailable(t=1){if(!this.available(t)){var n=(this.offset+t)*2,i=new Uint8Array(n);i.set(new Uint8Array(this.buffer)),this.buffer=i.buffer,this.length=n,this.byteLength=n,this._data=new DataView(this.buffer);}return this;}readBoolean(){return this.readUint8()!==0;}readInt8(){return this._data.getInt8(this.offset++);}readUint8(){return this._data.getUint8(this.offset++);}readByte(){return this.readUint8();}readBytes(t=1){return this.readArray(t,"uint8");}readArray(t,r){var n=mr[r].BYTES_PER_ELEMENT*t,i=this.byteOffset+this.offset,o=this.buffer.slice(i,i+n);if(this.littleEndian===io&&r!=="uint8"&&r!=="int8"){var a=new Uint8Array(this.buffer.slice(i,i+n));a.reverse();var c=new mr[r](a.buffer);return this.offset+=n,c.reverse(),c;}var s=new mr[r](o);return this.offset+=n,s;}readInt16(){var t=this._data.getInt16(this.offset,this.littleEndian);return this.offset+=2,t;}readUint16(){var t=this._data.getUint16(this.offset,this.littleEndian);return this.offset+=2,t;}readInt32(){var t=this._data.getInt32(this.offset,this.littleEndian);return this.offset+=4,t;}readUint32(){var t=this._data.getUint32(this.offset,this.littleEndian);return this.offset+=4,t;}readFloat32(){var t=this._data.getFloat32(this.offset,this.littleEndian);return this.offset+=4,t;}readFloat64(){var t=this._data.getFloat64(this.offset,this.littleEndian);return this.offset+=8,t;}readBigInt64(){var t=this._data.getBigInt64(this.offset,this.littleEndian);return this.offset+=8,t;}readBigUint64(){var t=this._data.getBigUint64(this.offset,this.littleEndian);return this.offset+=8,t;}readChar(){return String.fromCharCode(this.readInt8());}readChars(t=1){var r="";for(var n=0;n<t;n++)r+=this.readChar();return r;}readUtf8(t=1){return yr(this.readBytes(t));}decodeText(t=1,r="utf8"){return yr(this.readBytes(t),r);}writeBoolean(t){return this.writeUint8(t?255:0),this;}writeInt8(t){return this.ensureAvailable(1),this._data.setInt8(this.offset++,t),this._updateLastWrittenByte(),this;}writeUint8(t){return this.ensureAvailable(1),this._data.setUint8(this.offset++,t),this._updateLastWrittenByte(),this;}writeByte(t){return this.writeUint8(t);}writeBytes(t){this.ensureAvailable(t.length);for(var r=0;r<t.length;r++)this._data.setUint8(this.offset++,t[r]);return this._updateLastWrittenByte(),this;}writeInt16(t){return this.ensureAvailable(2),this._data.setInt16(this.offset,t,this.littleEndian),this.offset+=2,this._updateLastWrittenByte(),this;}writeUint16(t){return this.ensureAvailable(2),this._data.setUint16(this.offset,t,this.littleEndian),this.offset+=2,this._updateLastWrittenByte(),this;}writeInt32(t){return this.ensureAvailable(4),this._data.setInt32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeUint32(t){return this.ensureAvailable(4),this._data.setUint32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeFloat32(t){return this.ensureAvailable(4),this._data.setFloat32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeFloat64(t){return this.ensureAvailable(8),this._data.setFloat64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeBigInt64(t){return this.ensureAvailable(8),this._data.setBigInt64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeBigUint64(t){return this.ensureAvailable(8),this._data.setBigUint64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeChar(t){return this.writeUint8(t.charCodeAt(0));}writeChars(t){for(var r=0;r<t.length;r++)this.writeUint8(t.charCodeAt(r));return this;}writeUtf8(t){return this.writeBytes(Sn(t));}toArray(){return new Uint8Array(this.buffer,this.byteOffset,this.lastWrittenByte);}getWrittenByteLength(){return this.lastWrittenByte-this.byteOffset;}_updateLastWrittenByte(){this.offset>this.lastWrittenByte&&(this.lastWrittenByte=this.offset);}};var Tn=[];for(var e=0;e<256;e++){var t=e;for(var r=0;r<8;r++)t&1?t=3988292384^t>>>1:t=t>>>1;Tn[e]=t;}var Cn=4294967295;function oo(e,t,r){var n=e;for(var i=0;i<r;i++)n=Tn[(n^t[i])&255]^n>>>8;return n;}function kn(e,t){return(oo(Cn,e,t)^Cn)>>>0;}function wr(e,t,r){var n=e.readUint32(),i=kn(new Uint8Array(e.buffer,e.byteOffset+e.offset-t-4,t),t);if(i!==n)throw new Error(`CRC mismatch for chunk ${r}. Expected ${n}, found ${i}`);}function tt(e,t){e.writeUint32(kn(new Uint8Array(e.buffer,e.byteOffset+e.offset-t,t),t));}function $t(e,t,r){for(var n=0;n<r;n++)t[n]=e[n];}function Yt(e,t,r,n){var i=0;for(;i<n;i++)t[i]=e[i];for(;i<r;i++)t[i]=e[i]+t[i-n]&255;}function Kt(e,t,r,n){var i=0;if(r.length===0)for(;i<n;i++)t[i]=e[i];else for(;i<n;i++)t[i]=e[i]+r[i]&255;}function Xt(e,t,r,n,i){var o=0;if(r.length===0){for(;o<i;o++)t[o]=e[o];for(;o<n;o++)t[o]=e[o]+(t[o-i]>>1)&255;}else{for(;o<i;o++)t[o]=e[o]+(r[o]>>1)&255;for(;o<n;o++)t[o]=e[o]+(t[o-i]+r[o]>>1)&255;}}function qt(e,t,r,n,i){var o=0;if(r.length===0){for(;o<i;o++)t[o]=e[o];for(;o<n;o++)t[o]=e[o]+t[o-i]&255;}else{for(;o<i;o++)t[o]=e[o]+r[o]&255;for(;o<n;o++)t[o]=e[o]+so(t[o-i],r[o],r[o-i])&255;}}function so(e,t,r){var n=e+t-r,i=Math.abs(n-e),o=Math.abs(n-t),s=Math.abs(n-r);return i<=o&&i<=s?e:o<=s?t:r;}function Fn(e,t,r,n,i,o){switch(e){case 0:$t(t,r,i);break;case 1:Yt(t,r,i,o);break;case 2:Kt(t,r,n,i);break;case 3:Xt(t,r,n,i,o);break;case 4:qt(t,r,n,i,o);break;default:throw new Error(`Unsupported filter: ${e}`);}}var ao=new Uint16Array([255]),lo=new Uint8Array(ao.buffer),co=lo[0]===255;function Un(e){var{data:t,width:r,height:n,channels:i,depth:o}=e,s=[{x:0,y:0,xStep:8,yStep:8},{x:4,y:0,xStep:8,yStep:8},{x:0,y:4,xStep:4,yStep:8},{x:2,y:0,xStep:4,yStep:4},{x:0,y:2,xStep:2,yStep:4},{x:1,y:0,xStep:2,yStep:2},{x:0,y:1,xStep:1,yStep:2}],a=Math.ceil(o/8)*i,c=new Uint8Array(n*r*a),f=0;for(var l=0;l<7;l++){var h=s[l],g=Math.ceil((r-h.x)/h.xStep),b=Math.ceil((n-h.y)/h.yStep);if(g<=0||b<=0)continue;var S=g*a,v=new Uint8Array(S);for(var E=0;E<b;E++){var x=t[f++],A=t.subarray(f,f+S);f+=S;var u=new Uint8Array(S);Fn(x,A,u,v,S,a),v.set(u);for(var y=0;y<g;y++){var d=h.x+y*h.xStep,I=h.y+E*h.yStep;if(!(d>=r||I>=n))for(var m=0;m<a;m++)c[(I*r+d)*a+m]=u[y*a+m];}}}if(o===16){var _l5=new Uint16Array(c.buffer);if(co)for(var _h4=0;_h4<_l5.length;_h4++)_l5[_h4]=fo(_l5[_h4]);return _l5;}else return c;}function fo(e){return(e&255)<<8|e>>8&255;}var ho=new Uint16Array([255]),uo=new Uint8Array(ho.buffer),po=uo[0]===255,vo=new Uint8Array(0);function Ar(e){var{data:t,width:r,height:n,channels:i,depth:o}=e,s=Math.ceil(o/8)*i,a=Math.ceil(o/8*i*r),c=new Uint8Array(n*a),f=vo,l=0,h,g;for(var b=0;b<n;b++){switch(h=t.subarray(l+1,l+1+a),g=c.subarray(b*a,(b+1)*a),t[l]){case 0:$t(h,g,a);break;case 1:Yt(h,g,a,s);break;case 2:Kt(h,g,f,a);break;case 3:Xt(h,g,f,a,s);break;case 4:qt(h,g,f,a,s);break;default:throw new Error(`Unsupported filter: ${t[l]}`);}f=g,l+=a+1;}if(o===16){var _b2=new Uint16Array(c.buffer);if(po)for(var S=0;S<_b2.length;S++)_b2[S]=go(_b2[S]);return _b2;}else return c;}function go(e){return(e&255)<<8|e>>8&255;}var Ut=Uint8Array.of(137,80,78,71,13,10,26,10);function In(e){e.writeBytes(Ut);}function br(e){if(!Bn(e.readBytes(Ut.length)))throw new Error("wrong PNG signature");}function Bn(e){if(e.length<Ut.length)return!1;for(var _t2=0;_t2<Ut.length;_t2++)if(e[_t2]!==Ut[_t2])return!1;return!0;}var Er="tEXt",Mn=0,Rn=new dt("latin1");function Dn(e){if(Pn(e),e.length===0||e.length>79)throw new Error("keyword length must be between 1 and 79");}var xo=/^[\u0000-\u00FF]*$/;function Pn(e){if(!xo.test(e))throw new Error("invalid latin1 text");}function Nn(e,t,r){var n=_r(t);e[n]=yo(t,r-n.length-1);}function On(e,t,r){Dn(t),Pn(r);var n=t.length+1+r.length;e.writeUint32(n),e.writeChars(Er),e.writeChars(t),e.writeByte(Mn),e.writeChars(r),tt(e,n+4);}function _r(e){for(e.mark();e.readByte()!==Mn;);var t=e.offset;e.reset();var r=Rn.decode(e.readBytes(t-e.offset-1));return e.skip(1),Dn(r),r;}function yo(e,t){return Rn.decode(e.readBytes(t));}var Te={UNKNOWN:-1,GREYSCALE:0,TRUECOLOUR:2,INDEXED_COLOUR:3,GREYSCALE_ALPHA:4,TRUECOLOUR_ALPHA:6},pt={UNKNOWN:-1,DEFLATE:0},It={UNKNOWN:-1,ADAPTIVE:0},Ye={UNKNOWN:-1,NO_INTERLACE:0,ADAM7:1},Bt={NONE:0,BACKGROUND:1,PREVIOUS:2},Vt={SOURCE:0,OVER:1};var Mt=class extends at{constructor(r,n={}){super(r);ye(this,"_checkCrc");ye(this,"_inflator");ye(this,"_png");ye(this,"_apng");ye(this,"_end");ye(this,"_hasPalette");ye(this,"_palette");ye(this,"_hasTransparency");ye(this,"_transparency");ye(this,"_compressionMethod");ye(this,"_filterMethod");ye(this,"_interlaceMethod");ye(this,"_colorType");ye(this,"_isAnimated");ye(this,"_numberOfFrames");ye(this,"_numberOfPlays");ye(this,"_frames");ye(this,"_writingDataChunks");ye(this,"_chunks");ye(this,"_inflatorResult");var{checkCrc:i=!1}=n;this._checkCrc=i,this._inflator=new Ft((o,s)=>{if(this._chunks.push(o),s){var a=this._chunks.reduce((f,l)=>f+l.length,0);this._inflatorResult=new Uint8Array(a);var c=0;for(var f of this._chunks)this._inflatorResult.set(f,c),c+=f.length;this._chunks=[];}}),this._chunks=[],this._png={width:-1,height:-1,channels:-1,data:new Uint8Array(0),depth:1,text:{}},this._apng={width:-1,height:-1,channels:-1,depth:1,numberOfFrames:1,numberOfPlays:0,text:{},frames:[]},this._end=!1,this._hasPalette=!1,this._palette=[],this._hasTransparency=!1,this._transparency=new Uint16Array(0),this._compressionMethod=pt.UNKNOWN,this._filterMethod=It.UNKNOWN,this._interlaceMethod=Ye.UNKNOWN,this._colorType=Te.UNKNOWN,this._isAnimated=!1,this._numberOfFrames=1,this._numberOfPlays=0,this._frames=[],this._writingDataChunks=!1,this._inflatorResult=new Uint8Array(0),this.setBigEndian();}decode(){for(br(this);!this._end;){var _r2=this.readUint32(),n=this.readChars(4);this.decodeChunk(_r2,n);}return this._inflator.push(new Uint8Array(0),!0),this.decodeImage(),this._png;}decodeApng(){for(br(this);!this._end;){var _r3=this.readUint32(),n=this.readChars(4);this.decodeApngChunk(_r3,n);}return this.decodeApngImage(),this._apng;}decodeChunk(r,n){var i=this.offset;switch(n){case"IHDR":this.decodeIHDR();break;case"PLTE":this.decodePLTE(r);break;case"IDAT":this.decodeIDAT(r);break;case"IEND":this._end=!0;break;case"tRNS":this.decodetRNS(r);break;case"iCCP":this.decodeiCCP(r);break;case Er:Nn(this._png.text,this,r);break;case"pHYs":this.decodepHYs();break;default:this.skip(r);break;}if(this.offset-i!==r)throw new Error(`Length mismatch while decoding chunk ${n}`);this._checkCrc?wr(this,r+4,n):this.skip(4);}decodeApngChunk(r,n){var i=this.offset;switch(n!=="fdAT"&&n!=="IDAT"&&this._writingDataChunks&&this.pushDataToFrame(),n){case"acTL":this.decodeACTL();break;case"fcTL":this.decodeFCTL();break;case"fdAT":this.decodeFDAT(r);break;default:this.decodeChunk(r,n),this.offset=i+r;break;}if(this.offset-i!==r)throw new Error(`Length mismatch while decoding chunk ${n}`);this._checkCrc?wr(this,r+4,n):this.skip(4);}decodeIHDR(){var r=this._png;r.width=this.readUint32(),r.height=this.readUint32(),r.depth=mo(this.readUint8());var n=this.readUint8();this._colorType=n;var i;switch(n){case Te.GREYSCALE:i=1;break;case Te.TRUECOLOUR:i=3;break;case Te.INDEXED_COLOUR:i=1;break;case Te.GREYSCALE_ALPHA:i=2;break;case Te.TRUECOLOUR_ALPHA:i=4;break;case Te.UNKNOWN:default:throw new Error(`Unknown color type: ${n}`);}if(this._png.channels=i,this._compressionMethod=this.readUint8(),this._compressionMethod!==pt.DEFLATE)throw new Error(`Unsupported compression method: ${this._compressionMethod}`);this._filterMethod=this.readUint8(),this._interlaceMethod=this.readUint8();}decodeACTL(){this._numberOfFrames=this.readUint32(),this._numberOfPlays=this.readUint32(),this._isAnimated=!0;}decodeFCTL(){var r={sequenceNumber:this.readUint32(),width:this.readUint32(),height:this.readUint32(),xOffset:this.readUint32(),yOffset:this.readUint32(),delayNumber:this.readUint16(),delayDenominator:this.readUint16(),disposeOp:this.readUint8(),blendOp:this.readUint8(),data:new Uint8Array(0)};this._frames.push(r);}decodePLTE(r){if(r%3!==0)throw new RangeError(`PLTE field length must be a multiple of 3. Got ${r}`);var n=r/3;this._hasPalette=!0;var i=[];this._palette=i;for(var o=0;o<n;o++)i.push([this.readUint8(),this.readUint8(),this.readUint8()]);}decodeIDAT(r){this._writingDataChunks=!0;var n=r,i=this.offset+this.byteOffset;try{this._inflator.push(new Uint8Array(this.buffer,i,n),!1);}catch(o){throw new Error("Error while decompressing the data:",{cause:o});}this.skip(r);}decodeFDAT(r){this._writingDataChunks=!0;var n=r,i=this.offset+this.byteOffset;i+=4,n-=4;try{this._inflator.push(new Uint8Array(this.buffer,i,n),!1);}catch(o){throw new Error("Error while decompressing the data:",{cause:o});}this.skip(r);}decodetRNS(r){switch(this._colorType){case Te.GREYSCALE:case Te.TRUECOLOUR:{if(r%2!==0)throw new RangeError(`tRNS chunk length must be a multiple of 2. Got ${r}`);if(r/2>this._png.width*this._png.height)throw new Error(`tRNS chunk contains more alpha values than there are pixels (${r/2} vs ${this._png.width*this._png.height})`);this._hasTransparency=!0,this._transparency=new Uint16Array(r/2);for(var n=0;n<r/2;n++)this._transparency[n]=this.readUint16();break;}case Te.INDEXED_COLOUR:{if(r>this._palette.length)throw new Error(`tRNS chunk contains more alpha values than there are palette colors (${r} vs ${this._palette.length})`);var _n2=0;for(;_n2<r;_n2++){var i=this.readByte();this._palette[_n2].push(i);}for(;_n2<this._palette.length;_n2++)this._palette[_n2].push(255);break;}case Te.UNKNOWN:case Te.GREYSCALE_ALPHA:case Te.TRUECOLOUR_ALPHA:default:throw new Error(`tRNS chunk is not supported for color type ${this._colorType}`);}}decodeiCCP(r){var n=_r(this),i=this.readUint8();if(i!==pt.DEFLATE)throw new Error(`Unsupported iCCP compression method: ${i}`);var o=this.readBytes(r-n.length-2);this._png.iccEmbeddedProfile={name:n,profile:bn(o)};}decodepHYs(){var r=this.readUint32(),n=this.readUint32(),i=this.readByte();this._png.resolution={x:r,y:n,unit:i};}decodeApngImage(){this._apng.width=this._png.width,this._apng.height=this._png.height,this._apng.channels=this._png.channels,this._apng.depth=this._png.depth,this._apng.numberOfFrames=this._numberOfFrames,this._apng.numberOfPlays=this._numberOfPlays,this._apng.text=this._png.text,this._apng.resolution=this._png.resolution;for(var _r4=0;_r4<this._numberOfFrames;_r4++){var n={sequenceNumber:this._frames[_r4].sequenceNumber,delayNumber:this._frames[_r4].delayNumber,delayDenominator:this._frames[_r4].delayDenominator,data:this._apng.depth===8?new Uint8Array(this._apng.width*this._apng.height*this._apng.channels):new Uint16Array(this._apng.width*this._apng.height*this._apng.channels)},i=this._frames.at(_r4);if(i){if(i.data=Ar({data:i.data,width:i.width,height:i.height,channels:this._apng.channels,depth:this._apng.depth}),this._hasPalette&&(this._apng.palette=this._palette),this._hasTransparency&&(this._apng.transparency=this._transparency),_r4===0||i.xOffset===0&&i.yOffset===0&&i.width===this._png.width&&i.height===this._png.height)n.data=i.data;else{var o=this._apng.frames.at(_r4-1);this.disposeFrame(i,o,n),this.addFrameDataToCanvas(n,i);}this._apng.frames.push(n);}}return this._apng;}disposeFrame(r,n,i){switch(r.disposeOp){case Bt.NONE:break;case Bt.BACKGROUND:for(var o=0;o<this._png.height;o++)for(var s=0;s<this._png.width;s++){var a=(o*r.width+s)*this._png.channels;for(var c=0;c<this._png.channels;c++)i.data[a+c]=0;}break;case Bt.PREVIOUS:i.data.set(n.data);break;default:throw new Error("Unknown disposeOp");}}addFrameDataToCanvas(r,n){var i=1<<this._png.depth,o=(s,a)=>{var c=((s+n.yOffset)*this._png.width+n.xOffset+a)*this._png.channels,f=(s*n.width+a)*this._png.channels;return{index:c,frameIndex:f};};switch(n.blendOp){case Vt.SOURCE:for(var s=0;s<n.height;s++)for(var a=0;a<n.width;a++){var{index:c,frameIndex:f}=o(s,a);for(var l=0;l<this._png.channels;l++)r.data[c+l]=n.data[f+l];}break;case Vt.OVER:for(var _s3=0;_s3<n.height;_s3++)for(var _a5=0;_a5<n.width;_a5++){var{index:_c3,frameIndex:_f4}=o(_s3,_a5);for(var _l6=0;_l6<this._png.channels;_l6++){var h=n.data[_f4+this._png.channels-1]/i,g=_l6%(this._png.channels-1)===0?1:n.data[_f4+_l6],b=Math.floor(h*g+(1-h)*r.data[_c3+_l6]);r.data[_c3+_l6]+=b;}}break;default:throw new Error("Unknown blendOp");}}decodeImage(){var r=this._inflatorResult;if(this._filterMethod!==It.ADAPTIVE)throw new Error(`Filter method ${this._filterMethod} not supported`);if(this._interlaceMethod===Ye.NO_INTERLACE)this._png.data=Ar({data:r,width:this._png.width,height:this._png.height,channels:this._png.channels,depth:this._png.depth});else if(this._interlaceMethod===Ye.ADAM7)this._png.data=Un({data:r,width:this._png.width,height:this._png.height,channels:this._png.channels,depth:this._png.depth});else throw new Error(`Interlace method ${this._interlaceMethod} not supported`);this._hasPalette&&(this._png.palette=this._palette),this._hasTransparency&&(this._png.transparency=this._transparency);}pushDataToFrame(){this._inflator.push(new Uint8Array(0),!0);var r=this._inflatorResult,n=this._frames.at(-1);n?n.data=r:this._frames.push({sequenceNumber:0,width:this._png.width,height:this._png.height,xOffset:0,yOffset:0,delayNumber:0,delayDenominator:0,disposeOp:Bt.NONE,blendOp:Vt.SOURCE,data:r}),this._inflator=new Ft((i,o)=>{if(this._chunks.push(i),o){var s=this._chunks.reduce((c,f)=>c+f.length,0);this._inflatorResult=new Uint8Array(s);var a=0;for(var c of this._chunks)this._inflatorResult.set(c,a),a+=c.length;this._chunks=[];}}),this._chunks=[],this._writingDataChunks=!1;}};function mo(e){if(e!==1&&e!==2&&e!==4&&e!==8&&e!==16)throw new Error(`invalid bit depth: ${e}`);return e;}var wo={level:3},Rt=class extends at{constructor(r,n={}){super();ye(this,"_png");ye(this,"_zlibOptions");ye(this,"_colorType");ye(this,"_interlaceMethod");this._colorType=Te.UNKNOWN,this._zlibOptions={...wo,...n.zlib},this._png=this._checkData(r),this._interlaceMethod=(n.interlace==="Adam7"?Ye.ADAM7:Ye.NO_INTERLACE)??Ye.NO_INTERLACE,this.setBigEndian();}encode(){if(In(this),this.encodeIHDR(),this._png.palette&&(this.encodePLTE(),this._png.palette[0].length===4&&this.encodeTRNS()),this.encodeData(),this._png.text)for(var[_r5,n]of Object.entries(this._png.text))On(this,_r5,n);return this.encodeIEND(),this.toArray();}encodeIHDR(){this.writeUint32(13),this.writeChars("IHDR"),this.writeUint32(this._png.width),this.writeUint32(this._png.height),this.writeByte(this._png.depth),this.writeByte(this._colorType),this.writeByte(pt.DEFLATE),this.writeByte(It.ADAPTIVE),this.writeByte(this._interlaceMethod),tt(this,17);}encodeIEND(){this.writeUint32(0),this.writeChars("IEND"),tt(this,4);}encodePLTE(){var r=this._png.palette?.length*3;this.writeUint32(r),this.writeChars("PLTE");for(var n of this._png.palette)this.writeByte(n[0]),this.writeByte(n[1]),this.writeByte(n[2]);tt(this,4+r);}encodeTRNS(){var r=this._png.palette.filter(n=>n.at(-1)!==255);this.writeUint32(r.length),this.writeChars("tRNS");for(var n of r)this.writeByte(n.at(-1));tt(this,4+r.length);}encodeIDAT(r){this.writeUint32(r.length),this.writeChars("IDAT"),this.writeBytes(r),tt(this,r.length+4);}encodeData(){var{width:r,height:n,channels:i,depth:o,data:s}=this._png,a=o<=8?Math.ceil(r*o/8)*i:Math.ceil(r*o/8*i/2),c=new at().setBigEndian(),f=0;if(this._interlaceMethod===Ye.NO_INTERLACE)for(var g=0;g<n;g++)c.writeByte(0),o===16?f=_o(s,c,a,f):f=bo(s,c,a,f);else this._interlaceMethod===Ye.ADAM7&&(f=Eo(this._png,s,c,f));var l=c.toArray(),h=An(l,this._zlibOptions);this.encodeIDAT(h);}_checkData(r){var{colorType:n,channels:i,depth:o}=Ao(r,r.palette),s={width:Ln(r.width,"width"),height:Ln(r.height,"height"),channels:i,data:r.data,depth:o,text:r.text,palette:r.palette};this._colorType=n;var a=o<8?Math.ceil(s.width*o/8)*s.height*i:s.width*s.height*i;if(s.data.length!==a)throw new RangeError(`wrong data size. Found ${s.data.length}, expected ${a}`);return s;}};function Ln(e,t){if(Number.isInteger(e)&&e>0)return e;throw new TypeError(`${t} must be a positive integer`);}function Ao(e,t){var{channels:r=4,depth:n=8}=e;if(r!==4&&r!==3&&r!==2&&r!==1)throw new RangeError(`unsupported number of channels: ${r}`);var i={channels:r,depth:n,colorType:Te.UNKNOWN};switch(r){case 4:i.colorType=Te.TRUECOLOUR_ALPHA;break;case 3:i.colorType=Te.TRUECOLOUR;break;case 1:t?i.colorType=Te.INDEXED_COLOUR:i.colorType=Te.GREYSCALE;break;case 2:i.colorType=Te.GREYSCALE_ALPHA;break;default:throw new Error("unsupported number of channels");}return i;}function bo(e,t,r,n){for(var i=0;i<r;i++)t.writeByte(e[n++]);return n;}function Eo(e,t,r,n){var i=[{x:0,y:0,xStep:8,yStep:8},{x:4,y:0,xStep:8,yStep:8},{x:0,y:4,xStep:4,yStep:8},{x:2,y:0,xStep:4,yStep:4},{x:0,y:2,xStep:2,yStep:4},{x:1,y:0,xStep:2,yStep:2},{x:0,y:1,xStep:1,yStep:2}],{width:o,height:s,channels:a,depth:c}=e,f;c===16?f=a*c/8/2:f=a*c/8;for(var l=0;l<7;l++){var h=i[l],g=Math.floor((o-h.x+h.xStep-1)/h.xStep),b=Math.floor((s-h.y+h.yStep-1)/h.yStep);if(g<=0||b<=0)continue;var S=g*f;for(var v=0;v<b;v++){var E=h.y+v*h.yStep,x=c<=8?new Uint8Array(S):new Uint16Array(S),A=0;for(var u=0;u<g;u++){var y=h.x+u*h.xStep;if(y<o&&E<s){var d=(E*o+y)*f;for(var I=0;I<f;I++)x[A++]=t[d+I];}}if(r.writeByte(0),c===8)r.writeBytes(x);else if(c===16)for(var _u of x)r.writeByte(_u>>8&255),r.writeByte(_u&255);}}return n;}function _o(e,t,r,n){for(var i=0;i<r;i++)t.writeUint16(e[n++]);return n;}function zn(e,t){return new Mt(e,t).decode();}function Gn(e,t){return new Rt(e,t).encode();}var Vn=bt(qn(),1);var Qt=bt(or(),1),qe=320,ko=16e6,jn=[137,80,78,71,13,10,26,10],Tr=(e,t)=>e[t]*16777216+e[t+1]*65536+e[t+2]*256+e[t+3],Ve=()=>new Error("This image could not be decoded. Reopen the original image and try again.");function Zn(e,t){if(!Number.isInteger(e)||!Number.isInteger(t)||e<1||t<1)throw Ve();if(e>16384||t>16384||e*t>ko)throw new Error("This image is too large to prepare locally. Choose an image under 16 megapixels.");}function Fo(e,t){if(e.length<33||jn.some((x,A)=>e[A]!==x))throw Ve();var r=Tr(e,16),n=Tr(e,20),i=e[24],o=e[25],s=e[28];Zn(r,n);var a={0:1,2:3,3:1,4:2,6:4}[o];if(!a||![1,2,4,8,16].includes(i)||s>1)throw Ve();var c=s?[[0,0,8,8],[4,0,8,8],[0,4,4,8],[2,0,4,4],[0,2,2,4],[1,0,2,2],[0,1,1,2]]:[[0,0,1,1]],f=0;for(var[x,A,u,y]of c){var d=Math.max(0,Math.ceil((r-x)/u)),I=Math.max(0,Math.ceil((n-A)/y));d&&I&&(f+=(Math.ceil(d*a*i/8)+1)*I);}var l=[e.subarray(0,8)],h=[],g=!1;for(var _x=8;_x+12<=e.length;){t();var _A2=Tr(e,_x),_u2=_x+_A2+12;if(_u2>e.length)throw Ve();var _y2=String.fromCharCode(...e.subarray(_x+4,_x+8));if(_x===8&&(_y2!=="IHDR"||_A2!==13))throw Ve();if(_y2==="acTL")throw Object.assign(new Error("Use the original 320\xD7320 APNG or an animated GIF to keep this animation."),{code:"ANIMATED_PNG"});if(["IHDR","PLTE","tRNS","IDAT","IEND"].includes(_y2)&&l.push(e.subarray(_x,_u2)),_y2==="IDAT"&&h.push(e.subarray(_x+8,_x+8+_A2)),_x=_u2,_y2==="IEND"){g=!0;break;}}if(!g||!h.length)throw Ve();var b=0,S=new Ft(x=>{if(b+=x.length,b>f)throw Ve();});for(var _x2 of h)for(var _A3=0;_A3<_x2.length;_A3+=1024)t(),S.push(_x2.subarray(_A3,_A3+1024),!1);if(S.push(new Uint8Array(0),!0),b!==f)throw Ve();var v=new Uint8Array(l.reduce((x,A)=>x+A.length,0)),E=0;for(var _x3 of l)v.set(_x3,E),E+=_x3.length;return v;}function Uo(e){if(!e)return 1;try{var _t3=-1;for(var s=0;s<Math.min(12,e.length-8);s++)if(e[s]===73&&e[s+1]===73||e[s]===77&&e[s+1]===77){_t3=s;break;}if(_t3<0)return 1;var _r6=new DataView(e.buffer,e.byteOffset+_t3,e.byteLength-_t3),n=e[_t3]===73,i=_r6.getUint32(4,n),o=Math.min(_r6.getUint16(i,n),256);for(var _s4=0;_s4<o;_s4++){var a=i+2+_s4*12;if(_r6.getUint16(a,n)===274){var c=_r6.getUint16(a+8,n);return c>=1&&c<=8?c:1;}}}catch{}return 1;}function Zt(e,t,r,n){var{width:i,height:o,data:s,channels:a=4,depth:c=8,palette:f,transparency:l,orientation:h=1}=e,g=t,b=r;h===2&&(g=i-1-t),h===3&&(g=i-1-t,b=o-1-r),h===4&&(b=o-1-r),h===5&&(g=r,b=t),h===6&&(g=r,b=o-1-t),h===7&&(g=i-1-r,b=o-1-t),h===8&&(g=i-1-r,b=t);var S=b*i+g;if(f||c<8){var x=g*c,A=Math.ceil(i*c/8),u=c===8?s[S]:s[b*A+(x>>3)]>>8-c-(x&7)&(1<<c)-1;if(f){var y=f[u];if(!y)throw Ve();n[0]=y[0],n[1]=y[1],n[2]=y[2],n[3]=y[3]??255;}else n[0]=n[1]=n[2]=u*255/((1<<c)-1),n[3]=l?.[0]===u?0:255;return;}var v=S*a,E=c===16?1/257:1;n[0]=s[v]*E,a<=2?(n[1]=n[2]=n[0],n[3]=a===2?s[v+1]*E:l?.[0]===s[v]?0:255):(n[1]=s[v+1]*E,n[2]=s[v+2]*E,n[3]=a===4?s[v+3]*E:l?.length===3&&l[0]===s[v]&&l[1]===s[v+1]&&l[2]===s[v+2]?0:255);}function kr(e,t=()=>{}){t();var r=(0,Qt.toByteArray)(e.replace(/\s/g,"")),n;if(jn.every((v,E)=>r[E]===v))n=zn(Fo(r,t),{checkCrc:!0});else if(r[0]===255&&r[1]===216)n=Vn.default.decode(r,{useTArray:!0,formatAsRGBA:!0,tolerantDecoding:!1,maxResolutionInMP:16,maxMemoryUsageInMB:128}),n={...n,channels:4,depth:8,orientation:Uo(n.exifBuffer)};else throw Object.assign(new Error("This image format needs conversion to PNG."),{code:"STATIC_FORMAT_UNSUPPORTED"});t(),Zn(n.width,n.height);var i=n.orientation>=5,o=i?n.height:n.width,s=i?n.width:n.height,a=Math.min(qe/o,qe/s),c=Math.max(1,Math.round(o*a)),f=Math.max(1,Math.round(s*a)),l=Math.floor((qe-c)/2),h=Math.floor((qe-f)/2),g=new Uint8Array(qe*qe*4),b=Array.from({length:4},()=>new Float64Array(4));for(var v=0;v<f;v++){v%16===0&&t();var E=Math.max(0,Math.min(s-1,(v+.5)*s/f-.5)),x=Math.floor(E),A=Math.min(s-1,x+1),u=E-x;for(var y=0;y<c;y++){var d=Math.max(0,Math.min(o-1,(y+.5)*o/c-.5)),I=Math.floor(d),m=Math.min(o-1,I+1),B=d-I;Zt(n,I,x,b[0]),Zt(n,m,x,b[1]),Zt(n,I,A,b[2]),Zt(n,m,A,b[3]);var w=[(1-B)*(1-u),B*(1-u),(1-B)*u,B*u],P=((v+h)*qe+y+l)*4,N=0;for(var L=0;L<4;L++)N+=b[L][3]*w[L];if(g[P+3]=Math.round(N),N)for(var _L=0;_L<3;_L++){var $=0;for(var oe=0;oe<4;oe++)$+=b[oe][_L]*b[oe][3]*w[oe];g[P+_L]=Math.round($/N);}}}t();var S=Gn({width:qe,height:qe,data:g,channels:4,depth:8});if(S.length>512*1024)throw new Error("The prepared sticker is over 512 KiB.");return t(),{base64:(0,Qt.fromByteArray)(S),mimeType:"image/png"};}var Io=(()=>{"use strict";var e=typeof vendetta<"u"?vendetta:globalThis.vendetta;if(!e?.metro||!e?.patcher)throw new Error("SaveAsSticker needs Revenge's Vendetta plugin support.");var{React:t,ReactNative:r,constants:n}=e.metro.common,i=t.createElement,o=nn(e),s=on(e,"SaveAsStickerPicker"),a=sn(e,{title:"Save as Sticker",id:"save-as-sticker",testID:"SaveAsStickerPage"}),c="SaveAsStickerPicker",f="save-as-sticker-action",l=512*1024,h=25*1024*1024,g=[5,15,30,60],b=[],S=new Set(),v=!1,E=0,x=!1,A,u=(...p)=>{try{return e.metro.findByProps(...p);}catch{return;}},y=p=>{try{return e.metro.findByStoreName(p);}catch{return;}},d=(...p)=>{for(var R of p)try{var F=e.ui.assets.getAssetIDByName(R);if(F!=null)return F;}catch{}},I=(...p)=>e.logger?.error?.("[SaveAsSticker]",...p),m=p=>{try{e.ui.toasts.showToast(p,d("StickerIcon","ic_sticker_24px"));}catch{console.log("[SaveAsSticker]",p);}},B=u("openLazy","hideActionSheet"),w=u("ActionSheetRow")?.ActionSheetRow,P=e.ui.components?.Forms??{},N=u("ActionSheetTitleHeader")?.ActionSheetTitleHeader??u("BottomSheetTitleHeader")?.BottomSheetTitleHeader,L=u("ActionSheetCloseButton")?.ActionSheetCloseButton,$=u("GuildIconSizes"),oe=$?.default,W=$?.GuildIconSizes,X=u("BottomSheetFlatList")?.BottomSheetFlatList??u("BottomSheetScrollView")?.BottomSheetFlatList??r.FlatList,V=u("ActionSheet")?.ActionSheet;if(!V)try{V=e.metro.find(p=>p?.render?.name==="ActionSheet");}catch{}function K(p){var R=String(p||"sticker").replace(/\.[a-z0-9]{1,6}$/i,"").replace(/[\u0000-\u001f]/g,"").trim().slice(0,30);return R.length>=2?R:"sticker";}function j(p,R=!1){if(!p)return null;var F=String(p.content_type??p.contentType??p.mimeType??""),U=p.mediaType??p.type,D=[p.url,p.sourceURI,p.mediaUrl,p.uri,p.proxy_url,p.proxyURL,p.image?.url,p.thumbnail?.url,p.video?.url].find(k=>typeof k=="string"&&/\.gif(?:[?#]|$)/i.test(k)),Y=F==="image/gif"||!!D;if(!Y&&(/^(video|audio)\//i.test(F)||/^(video|audio|file)$/i.test(String(U))))return null;var q=D??p.mediaUrl??p.sourceURI??p.url??p.uri??p.proxy_url??p.proxyURL;if(D&&(q=q.replace(/([?&])format=(?:webp|png|jpe?g|mp4)(?=&|$)/gi,"$1").replace(/([?&])animated=false(?=&|$)/gi,"$1").replace(/\?&/,"?").replace(/&&+/g,"&").replace(/[?&]$/,"")),typeof q!="string"||!/^https:\/\//i.test(q))return null;var ie=p.filename??p.name??q.split(/[?#]/)[0].split("/").pop()??"sticker";return!R&&U!=="image"&&!F.startsWith("image/")&&!/\.(png|apng|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i.test(ie)&&!/\.(png|apng|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i.test(q)?null:{url:q,proxyURL:p.proxy_url??p.proxyURL,filename:ie,contentType:Y?"image/gif":F,id:p.id??p.attachmentId};}function xe(...p){var R=p.flatMap(U=>{if(!U||typeof U!="object")return[];var C=U.analyticsLocation;return C&&typeof C=="object"?[U,C]:[U];});for(var U of R)if(U.selectedMedia){var C=U.selectedMedia,D=j({...C.source,...C},C.mediaType==="image");return D?[D]:[];}for(var _U of R){var _C=_U.source;if(_U.syncer?.sources){var _D=_U.syncer.index?.value??_U.syncer.index??0;_C=_U.syncer.sources[_D];}if(Array.isArray(_C)&&(_C=_C[0]),_C){var _D2=j(_C);return _D2?[_D2]:[];}}var F=[];for(var _U2 of R){for(var _C2 of _U2.message?.attachments??[]){var _D3=j(_C2);_D3&&F.push(_D3);}for(var _C3 of _U2.message?.embeds??[])for(var _D4 of[_C3.image,...(_C3.images??[]),_C3.type==="image"?_C3:null,_C3.type==="gifv"&&/\.gif(?:[?#]|$)/i.test(_C3.video?.url??"")?{..._C3.video,contentType:"image/gif"}:null,_C3.type==="gifv"&&/\.gif(?:[?#]|$)/i.test(_C3.thumbnail?.url??"")?_C3.thumbnail:null]){var Y=j(_D4,!0);Y&&F.push(Y);}}return F.filter((U,C)=>F.findIndex(D=>D.url===U.url)===C);}function ne(p){if(!p?.id||p.unavailable)return!1;var R=y("UserStore")?.getCurrentUser?.()?.id;if(R&&(p.ownerId===R||p.owner_id===R))return!0;var F=n?.Permissions?.CREATE_GUILD_EXPRESSIONS??1n<<43n;try{return!!y("PermissionStore")?.can?.(F,p);}catch{return!1;}}function re(p){var R=Number(p.premiumTier??p.premium_tier??0),F=p.features,U=Array.isArray(F)?F.includes("MORE_STICKERS"):F?.has?.("MORE_STICKERS"),C=Number(p.premiumFeatures?.additionalStickerSlots??p.premium_features?.additional_sticker_slots??0),D=U&&R===3?120:g[R]??g[0],Y=Number(p.maxStickers??p.max_stickers??0),q=Math.max(D+(Number.isFinite(C)?Math.max(0,C):0),Y||0),k=(y("GuildStickersStore")??y("StickersStore")??y("StickerStore"))?.getStickersByGuildId?.(p.id)??p.stickers;return k&&!Array.isArray(k)&&(k=Object.values(k)),{max:q,used:Array.isArray(k)?k.length:null};}function Z(){return Object.values(y("GuildStore")?.getGuilds?.()??{}).filter(ne).sort((p,R)=>String(p.name).localeCompare(String(R.name)));}function _(p){var R=Number(p?.body?.code??p?.code);if(R===50013)return"You need Create Expressions permission in this server.";if(R===30039)return"This server has no free sticker slots. Choose another server.";for(var F of[p?.body?.message,p?.message,p?.text])if(!(typeof F!="string"||!F))try{return JSON.parse(F)?.message??F;}catch{return F;}return"Discord could not upload the sticker. Please try again.";}function z(){return o.files();}function ce(p,R){return new Promise((F,U)=>{var C=new FileReader(),D=!1,Y=(ie,k)=>{D||(D=!0,R?.removeEventListener?.("abort",q),ie(k));},q=()=>{Y(U,Object.assign(new Error("Cancelled"),{code:"E_PICKER_CANCELLED"}));try{C.abort?.();}catch{}};if(C.onerror=()=>Y(U,C.error??new Error("Could not read the image.")),C.onload=()=>Y(F,String(C.result).split(",")[1]),R?.aborted){q();return;}R?.addEventListener?.("abort",q);try{C.readAsDataURL(p);}catch(ie){Y(U,ie);}});}function ve(p){return Math.floor(p.length*3/4)-(p.endsWith("==")?2:p.endsWith("=")?1:0);}function Q(p){var R="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",F=[],U=0,C=0;for(var q of p.slice(0,44)){var ie=R.indexOf(q);if(ie<0)break;C=C<<6|ie,U+=6,U>=8&&(U-=8,F.push(C>>>U&255));}var D=[137,80,78,71,13,10,26,10];if(F.length<24||D.some((q,ie)=>F[ie]!==q)||String.fromCharCode(...F.slice(12,16))!=="IHDR")return null;var Y=q=>F[q]*16777216+F[q+1]*65536+F[q+2]*256+F[q+3];return{width:Y(16),height:Y(20)};}function le(p){if(typeof p!="string"||!p)throw new Error("Discord did not return a local image path.");return /^(file|content):\/\//.test(p)?p:"file://"+p;}async function ae(p,R,F={}){var U=z();if(!U?.writeFile||!U?.removeFile)throw new Error("Discord's image file module is unavailable on this build.");var C=[],D=u("launchCropper","cleanSingle")??u("launchCropper"),Y;async function q(){if(Y&&D?.cleanSingle)try{await D.cleanSingle(Y);}catch{}for(var k of C)try{await U.removeFile("cache",k);}catch{}}async function ie(k,H){try{return kr(k,R).base64;}catch(J){if(J?.code!=="STATIC_FORMAT_UNSUPPORTED")throw J;var ge=p.proxyURL??H;if(!/^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/(?:attachments|ephemeral-attachments|external)\//i.test(ge))throw new Error("Use a PNG or JPEG image, or an animated GIF. This image format could not be converted.");var M=new URL(ge.replace(/^https:\/\/cdn\.discordapp\.com/i,"https://media.discordapp.net"));M.searchParams.set("format","png"),M.searchParams.set("width","320"),M.searchParams.set("height","320"),R();var ee=await(e.utils?.safeFetch??fetch)(M.toString(),{signal:F.controller?.signal},2e4);if(!ee.ok)throw new Error("Discord could not convert this image to PNG. Use the original PNG or JPEG.");var fe=await ee.blob();if(fe.size>h)throw new Error("Choose an image smaller than 25 MB.");var te=await ce(fe,F.controller?.signal);return R(),kr(te,R).base64;}}try{var k=p.url,H=u("maybeRefreshAttachmentUrl");if(/^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\//i.test(k))try{k=(await H?.maybeRefreshAttachmentUrl?.(k))||k;}catch{}R();var J=await(e.utils?.safeFetch??fetch)(k,{signal:F.controller?.signal},2e4);if(!J.ok)throw new Error("Image download failed (HTTP "+J.status+"). Reopen the image and try again.");if(Number(J.headers?.get?.("content-length"))>h)throw new Error("Choose an image smaller than 25 MB.");var ge=await J.blob();if(ge.size>h)throw new Error("Choose an image smaller than 25 MB.");var M=await ce(ge,F.controller?.signal);if(R(),!M)throw new Error("The image is empty.");var ee="save-as-sticker-"+Date.now()+"-"+Math.random().toString(36).slice(2);if(Jr(M)){m("Preparing animated GIF\u2026");var me=await tn(M,R);R();var Ae=ee+"-sticker.gif";C.push(Ae);var Ue=le(await U.writeFile("cache",Ae,me.base64,"base64"));return R(),{uri:Ue,mimeType:me.mimeType,cleanup:q};}if(p.contentType==="image/gif"||ge.type==="image/gif")throw new Error("This link returned a video or still preview. Share the original .gif file and try again.");var fe=Q(M);if(!fe||fe.width!==320||fe.height!==320||ve(M)>l)if(!D?.launchCropper)M=await ie(M,k);else{var _me=M,_Ae=ge.type||p.contentType||"image/png",_Ue=/jpeg/i.test(_Ae)?"jpg":/webp/i.test(_Ae)?"webp":/avif/i.test(_Ae)?"avif":"png",Pe=ee+"."+_Ue;C.push(Pe);var Ne=le(await U.writeFile("cache",Pe,M,"base64"));R();var Ie;try{Ie=await D.launchCropper({uri:Ne,width:320,height:320,mimeType:"image/png",includeBase64:!0,freeStyleCropEnabled:!1});}catch(_e){if(_e?.code==="E_PICKER_CANCELLED"||/cancel/i.test(String(_e?.message??"")))throw _e;R();}Y=Ie?.path??Ie?.uri,R(),M=Ie?.data??Ie?.base64,!M&&Y&&U.readFile&&(M=await U.readFile(Y.replace(/^file:\/\//,""),"base64")),(typeof M!="string"||!M)&&(M=_me),M=M.replace(/^data:[^,]*,/,"").replace(/\s/g,"");var ke=Q(M);(!ke||ke.width!==320||ke.height!==320||ve(M)>l)&&(M=await ie(M,k));}var te=Q(M);if(!te||te.width!==320||te.height!==320)throw new Error("The cropper did not produce a 320\xD7320 PNG. The sticker was not uploaded.");if(ve(M)>l)throw new Error("The cropped sticker is over 512 KiB. Try a simpler image.");var pe=ee+"-sticker.png";C.push(pe);var Ee=le(await U.writeFile("cache",pe,M,"base64"));return R(),{uri:Ee,mimeType:"image/png",cleanup:q};}catch(k){throw await q(),k;}}async function G(p,R,F,U){if(x||!v)return;var C=U?.control??{};x=C,S.add(C);var D=E,Y=y("UserStore")?.getCurrentUser?.()?.id,q=()=>{if(!v||E!==D||C.cancelled||C.expired||U&&!U.isCurrent()||!Y||y("UserStore")?.getCurrentUser?.()?.id!==Y)throw Object.assign(new Error("Cancelled"),{code:"E_PICKER_CANCELLED"});},ie,k;C.cancel=H=>{C.cancelled=!0;try{C.controller?.abort();}catch{}C.writing&&!H||(clearTimeout(k),x===C&&(x=!1));};try{if(F.length<2||F.length>30)throw new Error("Use a sticker name between 2 and 30 characters.");if(!Y)throw new Error("Your Discord account is still loading. Reopen the picker and try again.");q();var H=o.resolve("sticker");U||(B.hideActionSheet(c),r.Keyboard?.dismiss?.(),await new Promise(fe=>setTimeout(fe,300))),q(),m("Preparing your sticker\u2026"),ie=await ae(R,q,C),q();var J=y("GuildStore"),ge=J?.getGuild?.(p.id)??J?.getGuilds?.()?.[p.id];if(!ne(ge))throw new Error("You no longer have Create Expressions permission in this server.");var M=re(ge);if(M.used!=null&&M.used>=M.max)throw new Error("This server has no free sticker slots. Choose another server.");m("Adding sticker to "+p.name+"\u2026"),C.writing=!0,U&&(k=setTimeout(()=>{C.expired=!0,x===C&&(x=!1),U.isCurrent()&&(U.onError("Discord\u2019s upload response timed out. Check the server\u2019s stickers before trying again."),U.onFinished());},45e3));var ee=await H({guildId:p.id,name:F,tags:"slight_smile",description:"",uri:ie.uri,mimeType:ie.mimeType,platform:"mobile",originalMd5:null},q,C.controller?.signal);if(q(),!ee?.id&&!ee?.body?.id)throw new Error("Discord did not confirm the upload. Check the server's stickers before trying again.");U&&U.onSuccess(),v&&E===D&&m("Sticker added to "+p.name);}catch(H){if(C.cancelled||C.expired||H?.code==="E_PICKER_CANCELLED"||/cancel/i.test(String(H?.message??"")))return;if(I("Upload failed",H),v&&E===D){var _J=_(H);U?U.isCurrent()&&U.onError(_J):r.Alert?.alert?r.Alert.alert("Sticker could not be added",_J):m(_J);}}finally{clearTimeout(k),S.delete(C),x===C&&(x=!1),U?.isCurrent()&&U.onFinished(),await ie?.cleanup?.();}}function O({images:p,onClose:R,inPanel:F=!1,page:U=!1,isOpen:C}){var[D,Y]=t.useState(p.length===1?p[0]:null),[q,ie]=t.useState(null),[k,H]=t.useState(K(p[0]?.filename)),[,J]=t.useState(0),[ge,M]=t.useState(""),[ee,fe]=t.useState(!1),[te,pe]=t.useState(""),Ee=t.useRef(!0),me=t.useRef(!1),Ae=t.useRef(),Ue=t.useRef(!1),Pe=t.useRef(E),Ne=()=>Ee.current&&!me.current&&v&&E===Pe.current&&(!C||C()),Ie=(y("ThemeStore")?.theme??r.Appearance?.getColorScheme?.())!=="light",ke={text:Ie?"#f2f3f5":"#1e1f22",muted:Ie?"#b5bac1":"#4e5058",input:Ie?"#1e1f22":"#e3e5e8"};t.useEffect(()=>{Ee.current=!0;var he=[y("GuildStore"),y("PermissionStore"),y("GuildStickersStore"),y("StickersStore")].filter(Boolean),Se=()=>J(be=>be+1);return he.forEach(be=>be.addChangeListener?.(Se)),()=>{Ee.current=!1,Ae.current?.cancel?.(),he.forEach(be=>be.removeChangeListener?.(Se));};},[]);var _e=(he,Se={})=>i(r.Text,{style:{color:ke.text,fontSize:16,...Se}},he),rt=(he,Se,be=!1)=>i(r.Pressable,{accessibilityRole:"button",accessibilityLabel:he,disabled:be,onPress:Se,style:{padding:14,borderRadius:8,backgroundColor:be?"#555967":"#5865f2",marginTop:12}},_e(he,{color:"#ffffff",fontWeight:"600",textAlign:"center"})),je={color:ke.text,backgroundColor:ke.input,borderRadius:8,padding:12,fontSize:16,marginTop:10},Ge=()=>{if(!me.current){me.current=!0,Ae.current?.cancel?.();try{r.Keyboard?.dismiss?.();}catch{}(R??(()=>B.hideActionSheet(c)))();}},nt=()=>{if(!U){Ge(),G(q,D,k.trim());return;}if(!Ne()||Ue.current)return;if(x){pe("A sticker upload is already in progress. You can close this page while it finishes.");return;}try{r.Keyboard?.dismiss?.();}catch{}Ue.current=!0,fe(!0),pe("");var he={controller:typeof AbortController=="function"?new AbortController():void 0};Ae.current=he,G(q,D,k.trim(),{control:he,isCurrent:Ne,onError:pe,onSuccess:Ge,onFinished(){Ae.current===he&&(Ae.current=void 0,Ue.current=!1,fe(!1));}});},Ze=D?i(r.Image,{source:{uri:D.url},resizeMode:"contain",accessibilityLabel:"Sticker preview",style:{width:26,height:26,marginRight:12}}):null,vt=q?"Sticker name":D?"Saving "+K(D.filename):"Choose image",lt=!F&&L?i(L,{onPress:Ge,accessibilityLabel:"Close"}):i(r.Pressable,{onPress:Ge,accessibilityRole:"button",accessibilityLabel:"Close",hitSlop:10,style:{width:40,height:40,alignItems:"center",justifyContent:"center"}},_e("\xD7",{fontSize:32,lineHeight:36})),gt=!F&&N?i(N,{title:vt,leading:Ze,trailing:lt}):i(r.View,{style:{flexDirection:"row",alignItems:"center",paddingHorizontal:28,minHeight:72}},Ze,i(r.Text,{numberOfLines:1,style:{flex:1,color:ke.text,fontSize:20,fontWeight:"600",textAlign:"center",paddingHorizontal:8}},vt),lt),xt=Math.min(640,(r.Dimensions?.get?.("window")?.height??800)*.62);function yt(he){if(oe)return i(oe,{guild:he,size:W?.MEDIUM,animate:!1});if(he.icon)return i(r.Image,{source:{uri:"https://cdn.discordapp.com/icons/"+he.id+"/"+he.icon+".png?size=96"},style:{width:44,height:44,borderRadius:14},resizeMode:"cover"});var Se=String(he.name).trim().split(/\s+/).map(be=>be[0]).join("").slice(0,3);return i(r.View,{style:{width:44,height:44,borderRadius:14,backgroundColor:"#5865f2",alignItems:"center",justifyContent:"center"}},_e(Se,{color:"#ffffff",fontWeight:"600"}));}function mt(he){var Se=re(he),be=Se.used!=null&&Se.used>=Se.max,He=be?"No slots available":Se.used==null?"Check slots on upload":void 0,Qe=()=>{if(U&&(!Ne()||ee))return;var ft=y("GuildStore")?.getGuild?.(he.id)??he,ht=re(ft);!ne(ft)||ht.used!=null&&ht.used>=ht.max||(ie(ft),pe(""));},Be=d("ic_add_24px","PlusSmallIcon","PlusIcon"),wt=P.FormIcon&&Be!=null?i(P.FormIcon,{source:Be,style:{opacity:1}}):_e("+",{color:ke.muted,fontSize:30,fontWeight:"300"});return P.FormRow?i(P.FormRow,{key:he.id,leading:yt(he),label:he.name,subLabel:He,trailing:wt,disabled:be,onPress:Qe,accessibilityLabel:he.name,accessibilityRole:"button",accessibilityState:{disabled:be}}):i(r.Pressable,{key:he.id,accessibilityRole:"button",accessibilityLabel:he.name,accessibilityState:{disabled:be},disabled:be,onPress:Qe,style:{minHeight:80,paddingHorizontal:32,flexDirection:"row",alignItems:"center",opacity:be?.4:1}},yt(he),i(r.View,{style:{flex:1,marginLeft:18,marginRight:16}},_e(he.name,{fontWeight:"600",fontSize:18}),He?_e(He,{color:ke.muted,fontSize:13,marginTop:3}):null),wt);}if(D&&!q){var he=Z().filter(Be=>`${Be.name}
${Be.id}`.toLowerCase().includes(ge.trim().toLowerCase())),Se=i(r.View,{style:{padding:24}},_e(ge.trim()?"No servers match your search.":"No servers available. You need Create Expressions permission to add a sticker.",{color:ke.muted,fontSize:14})),be=F?r.FlatList:X,He=be?i(be,{style:{flex:1},contentContainerStyle:{paddingBottom:32},data:he,keyboardShouldPersistTaps:"handled",keyboardDismissMode:"on-drag",nestedScrollEnabled:!0,removeClippedSubviews:!1,initialNumToRender:12,renderItem:({item:Be})=>mt(Be),keyExtractor:Be=>Be.id,extraData:he.map(Be=>Be.id+":"+re(Be).used).join(","),ListEmptyComponent:Se}):i(r.ScrollView,{style:{flex:1},contentContainerStyle:{paddingBottom:32}},he.length?he.map(mt):Se),Qe=i(r.View,{style:F?{flex:1,minHeight:0}:{height:xt}},gt,i(r.TextInput,{accessibilityLabel:"Search servers",placeholder:"Search server name or ID",placeholderTextColor:ke.muted,value:ge,onChangeText:M,autoCorrect:!1,autoCapitalize:"none",style:{...je,marginHorizontal:20,marginBottom:12}}),He);return F?Qe:i(V,{scrollable:!1},Qe);}var ct;if(!D)ct=p.map((he,Se)=>i(r.Pressable,{key:he.url,accessibilityRole:"button",accessibilityLabel:"Use image "+(Se+1),onPress:()=>{Y(he),H(K(he.filename));},style:{flexDirection:"row",alignItems:"center",gap:12,paddingVertical:10}},i(r.Image,{source:{uri:he.url},style:{width:64,height:64},resizeMode:"contain"}),_e(he.filename,{flex:1})));else{var _he=k.trim().length>=2&&k.trim().length<=30&&!/[\u0000-\u001f]/.test(k);ct=i(r.View,null,i(r.Image,{source:{uri:D.url},style:{height:128,width:"100%",marginBottom:12},resizeMode:"contain"}),_e("Server: "+q.name,{fontWeight:"600"}),_e("Sticker name",{marginTop:12}),i(r.TextInput,{value:k,onChangeText:H,maxLength:30,placeholder:"Sticker name",placeholderTextColor:ke.muted,style:je,selectTextOnFocus:!0,editable:!ee}),_e(D.contentType==="image/gif"?"GIFs keep their animation and resize automatically. Maximum 5 seconds and 512 KiB.":"Images fit inside 320\xD7320 with transparent padding. GIFs keep their animation.",{color:ke.muted,fontSize:13,marginTop:12}),rt("Add sticker",nt,!_he||ee),ee?_e("Preparing and adding your sticker\u2026",{color:ke.muted,marginTop:12}):null,te?_e(te,{color:"#e66b70",marginTop:12}):null,rt("Choose another server",()=>{ie(null),pe("");},ee));}var Dt=i(r.View,{style:F?{flex:1,minHeight:0}:{}},gt,i(r.ScrollView,{keyboardShouldPersistTaps:"handled",keyboardDismissMode:"on-drag",style:F?{flex:1}:{maxHeight:xt},contentContainerStyle:{padding:20,paddingBottom:40}},ct));return F?Dt:i(V,{scrollable:!1},Dt);}function ue(p,R){if(!v||A)return;if(e.host?.id==="valenced"){var C={session:E};A=C;var D=()=>{C.closed=!0,A===C&&(A=void 0);},Y=()=>v&&E===C.session&&!C.closed&&A===C;try{B.hideActionSheet(R);}catch{}var q=e.ui.components?.ErrorBoundary;if(a.open((ie,k)=>{var H=i(O,{images:p,onClose:ie,inPanel:!0,page:!0,isOpen:()=>Y()&&k()});return q?i(q,null,H):H;},D))return;D(),m("Save as Sticker could not open. Restart Discord and reopen the image menu.");return;}if(x){m("A sticker upload is already in progress.");return;}if(s.open(C=>i(O,{images:p,onClose:C,inPanel:!0}),"sticker picker")){B.hideActionSheet(R);return;}if(!V){m("The server picker is unavailable on this Discord build.");return;}B.hideActionSheet(R);var F=e.ui.components?.ErrorBoundary,U=()=>{var C=i(O,{images:p});return F?i(F,null,C):C;};B.openLazy(Promise.resolve({default:U}),c,{});}function se(p,R){var F=d("StickerIcon","ic_sticker_24px");return i(w,{key:f,label:"Save as Sticker",icon:w.Icon&&F!=null?i(w.Icon,{source:F}):void 0,iconSource:w.Icon?void 0:F,onPress:()=>ue(p,R)});}function de(p,R,F){var U=null,C=-1,D=!1,Y=M=>String(M?.props?.label??M?.props?.message??""),q=M=>M?.props&&typeof M.props.onPress=="function"&&(M.type===w||M.props.label!=null||M.props.message!=null);function ie(M,ee=0){if(!(!M||ee>40))if(Array.isArray(M)){var fe=M.filter(q);if(fe.length){var te=fe.some(pe=>/save image/i.test(Y(pe)))?1e3:fe.some(pe=>/copy image link/i.test(Y(pe)))?900:10;te+fe.length>C&&(U=M,C=te+fe.length);}M.forEach(te=>ie(te,ee+1));}else M.props&&((M.key===f||Y(M)==="Save as Sticker")&&(D=!0),ie(M.props.children,ee+1));}if(ie(p),D||!U)return p;var k=se(R,F),H=U.findIndex(M=>/save image/i.test(Y(M))),J=H>=0?H+1:U.length;function ge(M){if(M===U)return[...U.slice(0,J),k,...U.slice(J)];if(Array.isArray(M)){var ee=M.map(ge);return ee.some((fe,te)=>fe!==M[te])?ee:M;}if(M?.props?.children!=null){var _ee=ge(M.props.children);return _ee!==M.props.children?t.cloneElement(M,{children:_ee}):M;}return M;}return ge(p);}function Fe(p,R,F,U){var C=(D,Y)=>{if(!v||E!==U)return Y;try{var q=xe(D,R);return q.length?de(Y,q,F):Y;}catch(q){return I("Could not add image menu action",q),Y;}};return typeof p=="function"&&!p.prototype?.isReactComponent?function(...Y){return C(Y[0],p.apply(this,Y));}:p?.$$typeof===Symbol.for("react.memo")?t.memo(Fe(p.type,R,F,U),p.compare):p?.$$typeof===Symbol.for("react.forward_ref")?t.forwardRef((D,Y)=>C(D,p.render(D,Y))):p;}function Re(){if(!B?.openLazy||!w||!V&&e.host?.id!=="valenced"||!y("GuildStore"))throw new Error("SaveAsSticker: required menu modules were not found on this Discord build.");v||(v=!0,E++,b.push(e.patcher.before("openLazy",B,p=>{var[R,F,U]=p;if(F!=="MessageLongPressActionSheet"&&F!=="MediaShareActionSheet"||!R?.then)return;var C=E;p[0]=Promise.resolve(R).then(D=>!v||C!==E||!D?.default?D:{...D,default:Fe(D.default,U,F,C)});})),m("SaveAsSticker enabled"));}function T(){v=!1,E++,A=void 0,a.closeAll(),s.closeAll();for(var p of S)p.cancel?.(!0);S.clear(),x=!1;for(var _p of b.splice(0).reverse())try{_p();}catch{}try{B?.hideActionSheet?.(c);}catch{}}return{onLoad:Re,onUnload:T};})();
return module.exports.default;
})()
}, "SaveAsSticker");
})()
); }, {"id": "dev.fluttershy2008.save-as-sticker", "legacyManifest": {"name": "SaveAsSticker", "description": "Save images and animated GIFs as server stickers. Pick a server, name your sticker, and automatically resize GIFs while keeping them animated.", "version": "1.3.8", "authors": [{"name": "Fluttershy2008-mlp"}], "main": "index.js", "vendetta": {"icon": "ic_sticker_24px"}, "hash": "9ac85e3a572f058bd4cf5a9f6d9c1bdb08e6d84cc3e69e036cbaf48e41f0ab2b"}, "repository": "https://fluttershy2008-mlp.github.io/lol/valenced/index.json", "host": "valenced", "version": "1.0.0-beta6"}) };
})()
