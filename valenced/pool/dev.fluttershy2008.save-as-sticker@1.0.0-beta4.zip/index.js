(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Valenced API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const hostId = 'valenced';
    const product = 'Valenced';
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the ' + product + ' plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const pathFinders = safe(() => U.discord.utils.modules.finders);
        const source = safe(() => pathFinders.lookupModuleWithImportedPath('../discord_common/js/packages/http-utils/HTTPUtils.tsx')[0])
            ?? rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update ' + product + ' to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        if (props.length && props.every(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL', 'HTTP'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        const found = rawFind(...props);
        if (found) return found;
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.valenced.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    const importedPaths = safe(() => U.discord.utils.modules.finders);
    if (importedPaths?.getModuleWithImportedPath) {
        metro.findByImportedPath = path => safe(() => importedPaths.lookupModuleWithImportedPath(path)[0]);
        metro.getModuleWithImportedPath = (path, callback) => own(importedPaths.getModuleWithImportedPath(path,
            (module, id) => { if (active) callback(module, id); }));
    }
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod(hostId + '.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from ' + product + '.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.[hostId + '.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        host: { id: 'valenced' },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage, version: metadata.version },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createValencedPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createValencedPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}

return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
/*!
omggif 1.0.10
omggif is a JavaScript implementation of a GIF 89a encoder and decoder.

https://github.com/deanm/omggif


(c) Dean McNamee <dean@gmail.com>, 2013.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.


gifenc 1.0.3
The MIT License (MIT)
Copyright (c) 2017 Matt DesLauriers

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.



base64-js 1.5.1
The MIT License (MIT)

Copyright (c) 2014 Jameson Little

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


fast-png 8.0.0
MIT License

Copyright (c) 2015 Michaël Zasso

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


iobuffer 6.0.1
The MIT License (MIT)

Copyright (c) 2015 Michaël Zasso

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


jpeg-js 0.4.4
Copyright (c) 2014, Eugene Ware
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Eugene Ware nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY EUGENE WARE ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL EUGENE WARE BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


fflate 0.8.3
MIT License

Copyright (c) 2026 Arjun Barrett

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/
const module = { exports: {} };
var Kn=Object.create;var st=Object.defineProperty;var Zn=Object.getOwnPropertyDescriptor;var Qn=Object.getOwnPropertyNames;var Jn=Object.getPrototypeOf,ei=Object.prototype.hasOwnProperty;var ti=(e,t,r)=>t in e?st(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;var nt=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports;}catch(r){throw t=0,r;}},ri=(e,t)=>{for(var r in t)st(e,r,{get:t[r],enumerable:!0});},Ur=(e,t,r,n)=>{if(t&&typeof t=="object"||typeof t=="function"){var _loop=function(i){!ei.call(e,i)&&i!==r&&st(e,i,{get:()=>t[i],enumerable:!(n=Zn(t,i))||n.enumerable});};for(var i of Qn(t)){_loop(i);}}return e;};var lt=(e,t,r)=>(r=e!=null?Kn(Jn(e)):{},Ur(t||!e||!e.__esModule?st(r,"default",{value:e,enumerable:!0}):r,e)),ni=e=>Ur(st({},"__esModule",{value:!0}),e);var we=(e,t,r)=>ti(e,typeof t!="symbol"?t+"":t,r);var Ir=nt(Gt=>{"use strict";function ii(e,t,r,o){var i=0,o=o===void 0?{}:o,a=o.loop===void 0?null:o.loop,s=o.palette===void 0?null:o.palette;if(t<=0||r<=0||t>65535||r>65535)throw new Error("Width/Height invalid.");function h(S){var g=S.length;if(g<2||g>256||g&g-1)throw new Error("Invalid code/color length, must be power of 2 and 2 .. 256.");return g;}e[i++]=71,e[i++]=73,e[i++]=70,e[i++]=56,e[i++]=57,e[i++]=97;var f=0,l=0;if(s!==null){for(var c=h(s);c>>=1;)++f;if(c=1<<f,--f,o.background!==void 0){if(l=o.background,l>=c)throw new Error("Background index out of range.");if(l===0)throw new Error("Background index explicitly passed as 0.");}}if(e[i++]=t&255,e[i++]=t>>8&255,e[i++]=r&255,e[i++]=r>>8&255,e[i++]=(s!==null?128:0)|f,e[i++]=l,e[i++]=0,s!==null)for(var p=0,m=s.length;p<m;++p){var _=s[p];e[i++]=_>>16&255,e[i++]=_>>8&255,e[i++]=_&255;}if(a!==null){if(a<0||a>65535)throw new Error("Loop count invalid.");e[i++]=33,e[i++]=255,e[i++]=11,e[i++]=78,e[i++]=69,e[i++]=84,e[i++]=83,e[i++]=67,e[i++]=65,e[i++]=80,e[i++]=69,e[i++]=50,e[i++]=46,e[i++]=48,e[i++]=3,e[i++]=1,e[i++]=a&255,e[i++]=a>>8&255,e[i++]=0;}var A=!1;this.addFrame=function(S,g,k,v,x,d){if(A===!0&&(--i,A=!1),d=d===void 0?{}:d,S<0||g<0||S>65535||g>65535)throw new Error("x/y invalid.");if(k<=0||v<=0||k>65535||v>65535)throw new Error("Width/Height invalid.");if(x.length<k*v)throw new Error("Not enough pixels for the frame size.");var M=!0,y=d.palette;if(y==null&&(M=!1,y=s),y==null)throw new Error("Must supply either a local or global palette.");for(var B=h(y),C=0;B>>=1;)++C;B=1<<C;var N=d.delay===void 0?0:d.delay,O=d.disposal===void 0?0:d.disposal;if(O<0||O>3)throw new Error("Disposal out of range.");var z=!1,Y=0;if(d.transparent!==void 0&&d.transparent!==null&&(z=!0,Y=d.transparent,Y<0||Y>=B))throw new Error("Transparent color index.");if((O!==0||z||N!==0)&&(e[i++]=33,e[i++]=249,e[i++]=4,e[i++]=O<<2|(z===!0?1:0),e[i++]=N&255,e[i++]=N>>8&255,e[i++]=Y,e[i++]=0),e[i++]=44,e[i++]=S&255,e[i++]=S>>8&255,e[i++]=g&255,e[i++]=g>>8&255,e[i++]=k&255,e[i++]=k>>8&255,e[i++]=v&255,e[i++]=v>>8&255,e[i++]=M===!0?128|C-1:0,M===!0)for(var J=0,L=y.length;J<L;++J){var W=y[J];e[i++]=W>>16&255,e[i++]=W>>8&255,e[i++]=W&255;}return i=oi(e,i,C<2?2:C,x),i;},this.end=function(){return A===!1&&(e[i++]=59,A=!0),i;},this.getOutputBuffer=function(){return e;},this.setOutputBuffer=function(S){e=S;},this.getOutputBufferPosition=function(){return i;},this.setOutputBufferPosition=function(S){i=S;};}function oi(e,t,r,n){e[t++]=r;var i=t++,o=1<<r,a=o-1,s=o+1,h=s+1,f=r+1,l=0,c=0;function p(d){for(;l>=d;)e[t++]=c&255,c>>=8,l-=8,t===i+256&&(e[i]=255,i=t++);}function m(d){c|=d<<l,l+=f,p(8);}var _=n[0]&a,A={};m(o);for(var S=1,g=n.length;S<g;++S){var k=n[S]&a,v=_<<8|k,x=A[v];if(x===void 0){for(c|=_<<l,l+=f;l>=8;)e[t++]=c&255,c>>=8,l-=8,t===i+256&&(e[i]=255,i=t++);h===4096?(m(o),h=s+1,f=r+1,A={}):(h>=1<<f&&++f,A[v]=h++),_=k;}else _=x;}return m(_),m(s),p(1),i+1===t?e[i]=0:(e[i]=t-i-1,e[t++]=0),t;}function ai(e){var t=0;if(e[t++]!==71||e[t++]!==73||e[t++]!==70||e[t++]!==56||(e[t++]+1&253)!==56||e[t++]!==97)throw new Error("Invalid GIF 87a/89a header.");var r=e[t++]|e[t++]<<8,n=e[t++]|e[t++]<<8,i=e[t++],o=i>>7,a=i&7,s=1<<a+1,h=e[t++];e[t++];var f=null,l=null;o&&(f=t,l=s,t+=s*3);var c=!0,p=[],m=0,_=null,A=0,S=null;for(this.width=r,this.height=n;c&&t<e.length;)switch(e[t++]){case 33:switch(e[t++]){case 255:if(e[t]!==11||e[t+1]==78&&e[t+2]==69&&e[t+3]==84&&e[t+4]==83&&e[t+5]==67&&e[t+6]==65&&e[t+7]==80&&e[t+8]==69&&e[t+9]==50&&e[t+10]==46&&e[t+11]==48&&e[t+12]==3&&e[t+13]==1&&e[t+16]==0)t+=14,S=e[t++]|e[t++]<<8,t++;else for(t+=12;;){var g=e[t++];if(!(g>=0))throw Error("Invalid block size");if(g===0)break;t+=g;}break;case 249:if(e[t++]!==4||e[t+4]!==0)throw new Error("Invalid graphics extension block.");var k=e[t++];m=e[t++]|e[t++]<<8,_=e[t++],(k&1)===0&&(_=null),A=k>>2&7,t++;break;case 254:for(;;){var g=e[t++];if(!(g>=0))throw Error("Invalid block size");if(g===0)break;t+=g;}break;default:throw new Error("Unknown graphic control label: 0x"+e[t-1].toString(16));}break;case 44:var v=e[t++]|e[t++]<<8,x=e[t++]|e[t++]<<8,d=e[t++]|e[t++]<<8,M=e[t++]|e[t++]<<8,y=e[t++],B=y>>7,C=y>>6&1,N=y&7,O=1<<N+1,z=f,Y=l,J=!1;if(B){var J=!0;z=t,Y=O,t+=O*3;}var L=t;for(t++;;){var g=e[t++];if(!(g>=0))throw Error("Invalid block size");if(g===0)break;t+=g;}p.push({x:v,y:x,width:d,height:M,has_local_palette:J,palette_offset:z,palette_size:Y,data_offset:L,data_length:t-L,transparent_index:_,interlaced:!!C,delay:m,disposal:A});break;case 59:c=!1;break;default:throw new Error("Unknown gif block: 0x"+e[t-1].toString(16));}this.numFrames=function(){return p.length;},this.loopCount=function(){return S;},this.frameInfo=function(W){if(W<0||W>=p.length)throw new Error("Frame index out of range.");return p[W];},this.decodeAndBlitFrameBGRA=function(W,j){var $=this.frameInfo(W),K=$.width*$.height,ye=new Uint8Array(K);Tr(e,$.data_offset,ye,K);var ee=$.palette_offset,te=$.transparent_index;te===null&&(te=256);var Z=$.width,w=r-Z,D=Z,le=($.y*r+$.x)*4,ve=(($.y+$.height)*r+$.x)*4,Q=le,se=w*4;$.interlaced===!0&&(se+=r*4*7);for(var oe=8,G=0,R=ye.length;G<R;++G){var fe=ye[G];if(D===0&&(Q+=se,D=Z,Q>=ve&&(se=w*4+r*4*(oe-1),Q=le+(Z+w)*(oe<<1),oe>>=1)),fe===te)Q+=4;else{var ne=e[ee+fe*3],ue=e[ee+fe*3+1],b=e[ee+fe*3+2];j[Q++]=b,j[Q++]=ue,j[Q++]=ne,j[Q++]=255;}--D;}},this.decodeAndBlitFrameRGBA=function(W,j){var $=this.frameInfo(W),K=$.width*$.height,ye=new Uint8Array(K);Tr(e,$.data_offset,ye,K);var ee=$.palette_offset,te=$.transparent_index;te===null&&(te=256);var Z=$.width,w=r-Z,D=Z,le=($.y*r+$.x)*4,ve=(($.y+$.height)*r+$.x)*4,Q=le,se=w*4;$.interlaced===!0&&(se+=r*4*7);for(var oe=8,G=0,R=ye.length;G<R;++G){var fe=ye[G];if(D===0&&(Q+=se,D=Z,Q>=ve&&(se=w*4+r*4*(oe-1),Q=le+(Z+w)*(oe<<1),oe>>=1)),fe===te)Q+=4;else{var ne=e[ee+fe*3],ue=e[ee+fe*3+1],b=e[ee+fe*3+2];j[Q++]=ne,j[Q++]=ue,j[Q++]=b,j[Q++]=255;}--D;}};}function Tr(e,t,r,n){for(var i=e[t++],o=1<<i,a=o+1,s=a+1,h=i+1,f=(1<<h)-1,l=0,c=0,p=0,m=e[t++],_=new Int32Array(4096),A=null;;){for(;l<16&&m!==0;)c|=e[t++]<<l,l+=8,m===1?m=e[t++]:--m;if(l<h)break;var S=c&f;if(c>>=h,l-=h,S===o){s=a+1,h=i+1,f=(1<<h)-1,A=null;continue;}else if(S===a)break;for(var g=S<s?S:A,k=0,v=g;v>o;)v=_[v]>>8,++k;var x=v,d=p+k+(g!==S?1:0);if(d>n){console.log("Warning, gif stream longer than expected.");return;}r[p++]=x,p+=k;var M=p;for(g!==S&&(r[p++]=x),v=g;k--;)v=_[v],r[--M]=v&255,v>>=8;A!==null&&s<4096&&(_[s++]=A<<8|x,s>=f+1&&h<12&&(++h,f=f<<1|1)),A=S;}return p!==n&&console.log("Warning, gif stream shorter than expected."),r;}try{Gt.GifWriter=ii,Gt.GifReader=ai;}catch{}});var $r=nt(Yt=>{var Dr=Object.defineProperty,si=e=>Dr(e,"__esModule",{value:!0}),li=(e,t)=>{for(var r in t)Dr(e,r,{get:t[r],enumerable:!0});};si(Yt);li(Yt,{GIFEncoder:()=>Hr,applyPalette:()=>xi,default:()=>Fi,nearestColor:()=>Ai,nearestColorIndex:()=>zr,nearestColorIndexWithDistance:()=>Gr,prequantize:()=>gi,quantize:()=>pi,snapColorsToPalette:()=>mi});var fi={signature:"GIF",version:"89a",trailer:59,extensionIntroducer:33,applicationExtensionLabel:255,graphicControlExtensionLabel:249,imageSeparator:44,signatureSize:3,versionSize:3,globalColorTableFlagMask:128,colorResolutionMask:112,sortFlagMask:8,globalColorTableSizeMask:7,applicationIdentifierSize:8,applicationAuthCodeSize:3,disposalMethodMask:28,userInputFlagMask:2,transparentColorFlagMask:1,localColorTableFlagMask:128,interlaceFlagMask:64,idSortFlagMask:32,localColorTableSizeMask:7};function Or(e=256){var t=0,r=new Uint8Array(e);return{get buffer(){return r.buffer;},reset(){t=0;},bytesView(){return r.subarray(0,t);},bytes(){return r.slice(0,t);},writeByte(i){n(t+1),r[t]=i,t++;},writeBytes(i,o=0,a=i.length){n(t+a);for(var s=0;s<a;s++)r[t++]=i[s+o];},writeBytesView(i,o=0,a=i.byteLength){n(t+a),r.set(i.subarray(o,o+a),t),t+=a;}};function n(i){var o=r.length;if(o>=i)return;var a=1024*1024;i=Math.max(i,o*(o<a?2:1.125)>>>0),o!=0&&(i=Math.max(i,256));var s=r;r=new Uint8Array(i),t>0&&r.set(s.subarray(0,t),0);}}var Ht=12,Mr=5003,ci=[0,1,3,7,15,31,63,127,255,511,1023,2047,4095,8191,16383,32767,65535];function hi(e,t,r,n,i=Or(512),o=new Uint8Array(256),a=new Int32Array(Mr),s=new Int32Array(Mr)){var h=a.length,f=Math.max(2,n);o.fill(0),s.fill(0),a.fill(-1);var l=0,c=0,p=f+1,m=p,_=!1,A=m,S=(1<<A)-1,g=1<<p-1,k=g+1,v=g+2,x=0,d=r[0],M=0;for(var C=h;C<65536;C*=2)++M;M=8-M,i.writeByte(f),B(g);var y=r.length;for(var _C=1;_C<y;_C++)e:{var N=r[_C],O=(N<<Ht)+d,z=N<<M^d;if(a[z]===O){d=s[z];break e;}var Y=z===0?1:h-z;for(;a[z]>=0;)if(z-=Y,z<0&&(z+=h),a[z]===O){d=s[z];break e;}B(d),d=N,v<1<<Ht?(s[z]=v++,a[z]=O):(a.fill(-1),v=g+2,_=!0,B(g));}return B(d),B(k),i.writeByte(0),i.bytesView();function B(C){for(l&=ci[c],c>0?l|=C<<c:l=C,c+=A;c>=8;)o[x++]=l&255,x>=254&&(i.writeByte(x),i.writeBytesView(o,0,x),x=0),l>>=8,c-=8;if((v>S||_)&&(_?(A=m,S=(1<<A)-1,_=!1):(++A,S=A===Ht?1<<A:(1<<A)-1)),C==k){for(;c>0;)o[x++]=l&255,x>=254&&(i.writeByte(x),i.writeBytesView(o,0,x),x=0),l>>=8,c-=8;x>0&&(i.writeByte(x),i.writeBytesView(o,0,x),x=0);}}}var ui=hi;function Lr(e,t,r){return e<<8&63488|t<<2&992|r>>3;}function Pr(e,t,r,n){return e>>4|t&240|(r&240)<<4|(n&240)<<8;}function Nr(e,t,r){return e>>4<<8|t&240|r>>4;}function Et(e,t,r){return e<t?t:e>r?r:e;}function ft(e){return e*e;}function Br(e,t,r){var n=0,i=1e100;var o=e[t],a=o.cnt,s=o.ac,h=o.rc,f=o.gc,l=o.bc;for(var c=o.fw;c!=0;c=e[c].fw){var m=e[c],_=m.cnt,A=a*_/(a+_);if(!(A>=i)){var p=0;r&&(p+=A*ft(m.ac-s),p>=i)||(p+=A*ft(m.rc-h),!(p>=i)&&(p+=A*ft(m.gc-f),!(p>=i)&&(p+=A*ft(m.bc-l),!(p>=i)&&(i=p,n=c))));}}o.err=i,o.nn=n;}function Wt(){return{ac:0,rc:0,gc:0,bc:0,cnt:0,nn:0,fw:0,bk:0,tm:0,mtm:0,err:0};}function di(e,t){var r=t==="rgb444"?4096:65536,n=new Array(r),i=e.length;if(t==="rgba4444")for(var o=0;o<i;++o){var a=e[o],s=a>>24&255,h=a>>16&255,f=a>>8&255,l=a&255,c=Pr(l,f,h,s),p=c in n?n[c]:n[c]=Wt();p.rc+=l,p.gc+=f,p.bc+=h,p.ac+=s,p.cnt++;}else if(t==="rgb444")for(var _o2=0;_o2<i;++_o2){var _a=e[_o2],_s=_a>>16&255,_h=_a>>8&255,_f=_a&255,_l=Nr(_f,_h,_s),_c=_l in n?n[_l]:n[_l]=Wt();_c.rc+=_f,_c.gc+=_h,_c.bc+=_s,_c.cnt++;}else for(var _o3=0;_o3<i;++_o3){var _a2=e[_o3],_s2=_a2>>16&255,_h2=_a2>>8&255,_f2=_a2&255,_l2=Lr(_f2,_h2,_s2),_c2=_l2 in n?n[_l2]:n[_l2]=Wt();_c2.rc+=_f2,_c2.gc+=_h2,_c2.bc+=_s2,_c2.cnt++;}return n;}function pi(e,t,r={}){var{format:n="rgb565",clearAlpha:i=!0,clearAlphaColor:o=0,clearAlphaThreshold:a=0,oneBitAlpha:s=!1}=r;if(!e||!e.buffer)throw new Error("quantize() expected RGBA Uint8Array data");if(!(e instanceof Uint8Array)&&!(e instanceof Uint8ClampedArray))throw new Error("quantize() expected RGBA Uint8Array data");var h=new Uint32Array(e.buffer),f=r.useSqrt!==!1,l=n==="rgba4444",c=di(h,n),p=c.length,m=p-1,_=new Uint32Array(p+1);for(var A=0,g=0;g<p;++g){var L=c[g];if(L!=null){var S=1/L.cnt;l&&(L.ac*=S),L.rc*=S,L.gc*=S,L.bc*=S,c[A++]=L;}}ft(t)/A<.022&&(f=!1);for(var g=0;g<A-1;++g)c[g].fw=g+1,c[g+1].bk=g,f&&(c[g].cnt=Math.sqrt(c[g].cnt));f&&(c[g].cnt=Math.sqrt(c[g].cnt));var k,v,x;for(g=0;g<A;++g){Br(c,g,!1);var d=c[g].err;for(v=++_[0];v>1&&(x=v>>1,!(c[k=_[x]].err<=d));v=x)_[v]=k;_[v]=g;}var M=A-t;for(g=0;g<M;){for(var y;;){var B=_[1];if(y=c[B],y.tm>=y.mtm&&c[y.nn].mtm<=y.tm)break;y.mtm==m?B=_[1]=_[_[0]--]:(Br(c,B,!1),y.tm=g);var d=c[B].err;for(v=1;(x=v+v)<=_[0]&&(x<_[0]&&c[_[x]].err>c[_[x+1]].err&&x++,!(d<=c[k=_[x]].err));v=x)_[v]=k;_[v]=B;}var C=c[y.nn],N=y.cnt,O=C.cnt,S=1/(N+O);l&&(y.ac=S*(N*y.ac+O*C.ac)),y.rc=S*(N*y.rc+O*C.rc),y.gc=S*(N*y.gc+O*C.gc),y.bc=S*(N*y.bc+O*C.bc),y.cnt+=C.cnt,y.mtm=++g,c[C.bk].fw=C.fw,c[C.fw].bk=C.bk,C.mtm=m;}var z=[];var Y=0;for(g=0;;++Y){var J=Et(Math.round(c[g].rc),0,255),_L=Et(Math.round(c[g].gc),0,255),W=Et(Math.round(c[g].bc),0,255),j=255;l&&(j=Et(Math.round(c[g].ac),0,255),s&&(j=j<=(typeof s=="number"?s:127)?0:255),i&&j<=a&&(J=_L=W=o,j=0));var $=l?[J,_L,W,j]:[J,_L,W];if(vi(z,$)||z.push($),(g=c[g].fw)==0)break;}return z;}function vi(e,t){for(var r=0;r<e.length;r++){var n=e[r],i=n[0]===t[0]&&n[1]===t[1]&&n[2]===t[2],o=n.length>=4&&t.length>=4?n[3]===t[3]:!0;if(i&&o)return!0;}return!1;}function St(e,t){var r=0,n;for(n=0;n<e.length;n++){var i=e[n]-t[n];r+=i*i;}return r;}function _t(e,t){return t>1?Math.round(e/t)*t:e;}function gi(e,{roundRGB:t=5,roundAlpha:r=10,oneBitAlpha:n=null}={}){var i=new Uint32Array(e.buffer);for(var o=0;o<i.length;o++){var a=i[o],s=a>>24&255,h=a>>16&255,f=a>>8&255,l=a&255;s=_t(s,r),n&&(s=s<=(typeof n=="number"?n:127)?0:255),l=_t(l,t),f=_t(f,t),h=_t(h,t),i[o]=s<<24|h<<16|f<<8|l<<0;}}function xi(e,t,r="rgb565"){if(!e||!e.buffer)throw new Error("quantize() expected RGBA Uint8Array data");if(!(e instanceof Uint8Array)&&!(e instanceof Uint8ClampedArray))throw new Error("quantize() expected RGBA Uint8Array data");if(t.length>256)throw new Error("applyPalette() only works with 256 colors or less");var n=new Uint32Array(e.buffer),i=n.length,o=r==="rgb444"?4096:65536,a=new Uint8Array(i),s=new Array(o),h=r==="rgba4444";if(r==="rgba4444")for(var f=0;f<i;f++){var l=n[f],c=l>>24&255,p=l>>16&255,m=l>>8&255,_=l&255,A=Pr(_,m,p,c),S=A in s?s[A]:s[A]=yi(_,m,p,c,t);a[f]=S;}else{var _f3=r==="rgb444"?Nr:Lr;for(var _l3=0;_l3<i;_l3++){var _c3=n[_l3],_p=_c3>>16&255,_m=_c3>>8&255,_2=_c3&255,_A=_f3(_2,_m,_p),_S=_A in s?s[_A]:s[_A]=wi(_2,_m,_p,t);a[_l3]=_S;}}return a;}function yi(e,t,r,n,i){var o=0,a=1e100;for(var s=0;s<i.length;s++){var h=i[s],f=h[3],l=Qe(f-n);if(l>a)continue;var c=h[0];if(l+=Qe(c-e),l>a)continue;var p=h[1];if(l+=Qe(p-t),l>a)continue;var m=h[2];l+=Qe(m-r),!(l>a)&&(a=l,o=s);}return o;}function wi(e,t,r,n){var i=0,o=1e100;for(var a=0;a<n.length;a++){var s=n[a],h=s[0],f=Qe(h-e);if(f>o)continue;var l=s[1];if(f+=Qe(l-t),f>o)continue;var c=s[2];f+=Qe(c-r),!(f>o)&&(o=f,i=a);}return i;}function mi(e,t,r=5){if(!e.length||!t.length)return;var n=e.map(a=>a.slice(0,3)),i=r*r,o=e[0].length;for(var a=0;a<t.length;a++){var s=t[a];s.length<o?s=[s[0],s[1],s[2],255]:s.length>o?s=s.slice(0,3):s=s.slice();var h=Gr(n,s.slice(0,3),St),f=h[0],l=h[1];l>0&&l<=i&&(e[f]=s);}}function Qe(e){return e*e;}function zr(e,t,r=St){var n=1/0,i=-1;for(var o=0;o<e.length;o++){var a=e[o],s=r(t,a);s<n&&(n=s,i=o);}return i;}function Gr(e,t,r=St){var n=1/0,i=-1;for(var o=0;o<e.length;o++){var a=e[o],s=r(t,a);s<n&&(n=s,i=o);}return[i,n];}function Ai(e,t,r=St){return e[zr(e,t,r)];}function Hr(e={}){var{initialCapacity:t=4096,auto:r=!0}=e,n=Or(t),i=5003,o=new Uint8Array(256),a=new Int32Array(i),s=new Int32Array(i),h=!1;return{reset(){n.reset(),h=!1;},finish(){n.writeByte(fi.trailer);},bytes(){return n.bytes();},bytesView(){return n.bytesView();},get buffer(){return n.buffer;},get stream(){return n;},writeHeader:f,writeFrame(l,c,p,m={}){var{transparent:_=!1,transparentIndex:A=0,delay:S=0,palette:g=null,repeat:k=0,colorDepth:v=8,dispose:x=-1}=m,d=!1;if(r?h||(d=!0,f(),h=!0):d=!!m.first,c=Math.max(0,Math.floor(c)),p=Math.max(0,Math.floor(p)),d){if(!g)throw new Error("First frame must include a { palette } option");Ei(n,c,p,g,v),Rr(n,g),k>=0&&_i(n,k);}var M=Math.round(S/10);bi(n,x,M,_,A);var y=!!g&&!d;Si(n,c,p,y?g:null),y&&Rr(n,g),Ci(n,l,c,p,v,o,a,s);}};function f(){Wr(n,"GIF89a");}}function bi(e,t,r,n,i){e.writeByte(33),e.writeByte(249),e.writeByte(4),i<0&&(i=0,n=!1);var o,a;n?(o=1,a=2):(o=0,a=0),t>=0&&(a=t&7),a<<=2,e.writeByte(0|a|0|o),je(e,r),e.writeByte(i||0),e.writeByte(0);}function Ei(e,t,r,n,i=8){var s=$t(n.length)-1,h=128|i-1<<4|0|s,f=0,l=0;je(e,t),je(e,r),e.writeBytes([h,f,l]);}function _i(e,t){e.writeByte(33),e.writeByte(255),e.writeByte(11),Wr(e,"NETSCAPE2.0"),e.writeByte(3),e.writeByte(1),je(e,t),e.writeByte(0);}function Rr(e,t){var r=1<<$t(t.length);for(var n=0;n<r;n++){var i=[0,0,0];n<t.length&&(i=t[n]),e.writeByte(i[0]),e.writeByte(i[1]),e.writeByte(i[2]);}}function Si(e,t,r,n){if(e.writeByte(44),je(e,0),je(e,0),je(e,t),je(e,r),n){var a=$t(n.length)-1;e.writeByte(128|a);}else e.writeByte(0);}function Ci(e,t,r,n,i=8,o,a,s){ui(r,n,t,i,e,o,a,s);}function je(e,t){e.writeByte(t&255),e.writeByte(t>>8&255);}function Wr(e,t){for(var r=0;r<t.length;r++)e.writeByte(t.charCodeAt(r));}function $t(e){return Math.max(Math.ceil(Math.log2(e)),1);}var Fi=Hr;});var Xt=nt(Ct=>{"use strict";Ct.byteLength=Ui;Ct.toByteArray=Ii;Ct.fromByteArray=Ri;var Ne=[],Re=[],ki=typeof Uint8Array<"u"?Uint8Array:Array,Vt="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";for(Je=0,Yr=Vt.length;Je<Yr;++Je)Ne[Je]=Vt[Je],Re[Vt.charCodeAt(Je)]=Je;var Je,Yr;Re[45]=62;Re[95]=63;function Vr(e){var t=e.length;if(t%4>0)throw new Error("Invalid string. Length must be a multiple of 4");var r=e.indexOf("=");r===-1&&(r=t);var n=r===t?0:4-r%4;return[r,n];}function Ui(e){var t=Vr(e),r=t[0],n=t[1];return(r+n)*3/4-n;}function Ti(e,t,r){return(t+r)*3/4-r;}function Ii(e){var t,r=Vr(e),n=r[0],i=r[1],o=new ki(Ti(e,n,i)),a=0,s=i>0?n-4:n,h;for(h=0;h<s;h+=4)t=Re[e.charCodeAt(h)]<<18|Re[e.charCodeAt(h+1)]<<12|Re[e.charCodeAt(h+2)]<<6|Re[e.charCodeAt(h+3)],o[a++]=t>>16&255,o[a++]=t>>8&255,o[a++]=t&255;return i===2&&(t=Re[e.charCodeAt(h)]<<2|Re[e.charCodeAt(h+1)]>>4,o[a++]=t&255),i===1&&(t=Re[e.charCodeAt(h)]<<10|Re[e.charCodeAt(h+1)]<<4|Re[e.charCodeAt(h+2)]>>2,o[a++]=t>>8&255,o[a++]=t&255),o;}function Mi(e){return Ne[e>>18&63]+Ne[e>>12&63]+Ne[e>>6&63]+Ne[e&63];}function Bi(e,t,r){for(var n,i=[],o=t;o<r;o+=3)n=(e[o]<<16&16711680)+(e[o+1]<<8&65280)+(e[o+2]&255),i.push(Mi(n));return i.join("");}function Ri(e){for(var t,r=e.length,n=r%3,i=[],o=16383,a=0,s=r-n;a<s;a+=o)i.push(Bi(e,a,a+o>s?s:a+o));return n===1?(t=e[r-1],i.push(Ne[t>>2]+Ne[t<<4&63]+"==")):n===2&&(t=(e[r-2]<<8)+e[r-1],i.push(Ne[t>>10]+Ne[t>>4&63]+Ne[t<<2&63]+"=")),i.join("");}});var Gn=nt((Ba,Ot)=>{var zn=zn||function(e){return Buffer.from(e).toString("base64");};function Eo(e){var t=this,r=Math.round,n=Math.floor,i=new Array(64),o=new Array(64),a=new Array(64),s=new Array(64),h,f,l,c,p=new Array(65535),m=new Array(65535),_=new Array(64),A=new Array(64),S=[],g=0,k=7,v=new Array(64),x=new Array(64),d=new Array(64),M=new Array(256),y=new Array(2048),B,C=[0,1,5,6,14,15,27,28,2,4,7,13,16,26,29,42,3,8,12,17,25,30,41,43,9,11,18,24,31,40,44,53,10,19,23,32,39,45,52,54,20,22,33,38,46,51,55,60,21,34,37,47,50,56,59,61,35,36,48,49,57,58,62,63],N=[0,0,1,5,1,1,1,1,1,1,0,0,0,0,0,0,0],O=[0,1,2,3,4,5,6,7,8,9,10,11],z=[0,0,2,1,3,3,2,4,3,5,5,4,4,0,0,1,125],Y=[1,2,3,0,4,17,5,18,33,49,65,6,19,81,97,7,34,113,20,50,129,145,161,8,35,66,177,193,21,82,209,240,36,51,98,114,130,9,10,22,23,24,25,26,37,38,39,40,41,42,52,53,54,55,56,57,58,67,68,69,70,71,72,73,74,83,84,85,86,87,88,89,90,99,100,101,102,103,104,105,106,115,116,117,118,119,120,121,122,131,132,133,134,135,136,137,138,146,147,148,149,150,151,152,153,154,162,163,164,165,166,167,168,169,170,178,179,180,181,182,183,184,185,186,194,195,196,197,198,199,200,201,202,210,211,212,213,214,215,216,217,218,225,226,227,228,229,230,231,232,233,234,241,242,243,244,245,246,247,248,249,250],J=[0,0,3,1,1,1,1,1,1,1,1,1,0,0,0,0,0],L=[0,1,2,3,4,5,6,7,8,9,10,11],W=[0,0,2,1,2,4,4,3,4,7,5,4,4,0,1,2,119],j=[0,1,2,3,17,4,5,33,49,6,18,65,81,7,97,113,19,34,50,129,8,20,66,145,161,177,193,9,35,51,82,240,21,98,114,209,10,22,36,52,225,37,241,23,24,25,26,38,39,40,41,42,53,54,55,56,57,58,67,68,69,70,71,72,73,74,83,84,85,86,87,88,89,90,99,100,101,102,103,104,105,106,115,116,117,118,119,120,121,122,130,131,132,133,134,135,136,137,138,146,147,148,149,150,151,152,153,154,162,163,164,165,166,167,168,169,170,178,179,180,181,182,183,184,185,186,194,195,196,197,198,199,200,201,202,210,211,212,213,214,215,216,217,218,226,227,228,229,230,231,232,233,234,242,243,244,245,246,247,248,249,250];function $(u){for(var F=[16,11,10,16,24,40,51,61,12,12,14,19,26,58,60,55,14,13,16,24,40,57,69,56,14,17,22,29,51,87,80,62,18,22,37,56,68,109,103,77,24,35,55,64,81,104,113,92,49,64,78,87,103,121,120,101,72,92,95,98,112,100,103,99],T=0;T<64;T++){var I=n((F[T]*u+50)/100);I<1?I=1:I>255&&(I=255),i[C[T]]=I;}for(var H=[17,18,24,47,99,99,99,99,18,21,26,66,99,99,99,99,24,26,56,99,99,99,99,99,47,66,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],P=0;P<64;P++){var X=n((H[P]*u+50)/100);X<1?X=1:X>255&&(X=255),o[C[P]]=X;}for(var ie=[1,1.387039845,1.306562965,1.175875602,1,.785694958,.5411961,.275899379],de=0,pe=0;pe<8;pe++)for(var E=0;E<8;E++)a[de]=1/(i[C[de]]*ie[pe]*ie[E]*8),s[de]=1/(o[C[de]]*ie[pe]*ie[E]*8),de++;}function K(u,F){for(var T=0,I=0,H=new Array(),P=1;P<=16;P++){for(var X=1;X<=u[P];X++)H[F[I]]=[],H[F[I]][0]=T,H[F[I]][1]=P,I++,T++;T*=2;}return H;}function ye(){h=K(N,O),f=K(J,L),l=K(z,Y),c=K(W,j);}function ee(){for(var u=1,F=2,T=1;T<=15;T++){for(var I=u;I<F;I++)m[32767+I]=T,p[32767+I]=[],p[32767+I][1]=T,p[32767+I][0]=I;for(var H=-(F-1);H<=-u;H++)m[32767+H]=T,p[32767+H]=[],p[32767+H][1]=T,p[32767+H][0]=F-1+H;u<<=1,F<<=1;}}function te(){for(var u=0;u<256;u++)y[u]=19595*u,y[u+256>>0]=38470*u,y[u+512>>0]=7471*u+32768,y[u+768>>0]=-11059*u,y[u+1024>>0]=-21709*u,y[u+1280>>0]=32768*u+8421375,y[u+1536>>0]=-27439*u,y[u+1792>>0]=-5329*u;}function Z(u){for(var F=u[0],T=u[1]-1;T>=0;)F&1<<T&&(g|=1<<k),T--,k--,k<0&&(g==255?(w(255),w(0)):w(g),k=7,g=0);}function w(u){S.push(u);}function D(u){w(u>>8&255),w(u&255);}function le(u,F){var T,I,H,P,X,ie,de,pe,E=0,U,V=8,ge=64;for(U=0;U<V;++U){T=u[E],I=u[E+1],H=u[E+2],P=u[E+3],X=u[E+4],ie=u[E+5],de=u[E+6],pe=u[E+7];var ae=T+pe,ce=T-pe,me=I+de,re=I-de,xe=H+ie,Se=H-ie,be=P+X,ke=P-X,Te=ae+be,Ie=ae-be,He=me+xe,he=me-xe;u[E]=Te+He,u[E+4]=Te-He;var _e=(he+Ie)*.707106781;u[E+2]=Ie+_e,u[E+6]=Ie-_e,Te=ke+Se,He=Se+re,he=re+ce;var Ee=(Te-he)*.382683433,Pe=.5411961*Te+Ee,De=1.306562965*he+Ee,Ue=He*.707106781,qe=ce+Ue,We=ce-Ue;u[E+5]=We+Pe,u[E+3]=We-Pe,u[E+1]=qe+De,u[E+7]=qe-De,E+=8;}for(E=0,U=0;U<V;++U){T=u[E],I=u[E+8],H=u[E+16],P=u[E+24],X=u[E+32],ie=u[E+40],de=u[E+48],pe=u[E+56];var rt=T+pe,Nt=T-pe,xr=I+de,yr=I-de,wr=H+ie,mr=H-ie,Ar=P+X,jn=P-X,at=rt+Ar,zt=rt-Ar,mt=xr+wr,At=xr-wr;u[E]=at+mt,u[E+32]=at-mt;var br=(At+zt)*.707106781;u[E+16]=zt+br,u[E+48]=zt-br,at=jn+mr,mt=mr+yr,At=yr+Nt;var Er=(at-At)*.382683433,_r=.5411961*at+Er,Sr=1.306562965*At+Er,Cr=mt*.707106781,Fr=Nt+Cr,kr=Nt-Cr;u[E+40]=kr+_r,u[E+24]=kr-_r,u[E+8]=Fr+Sr,u[E+56]=Fr-Sr,E++;}var bt;for(U=0;U<ge;++U)bt=u[U]*F[U],_[U]=bt>0?bt+.5|0:bt-.5|0;return _;}function ve(){D(65504),D(16),w(74),w(70),w(73),w(70),w(0),w(1),w(1),w(0),D(1),D(1),w(0),w(0);}function Q(u){if(u){D(65505),u[0]===69&&u[1]===120&&u[2]===105&&u[3]===102?D(u.length+2):(D(u.length+5+2),w(69),w(120),w(105),w(102),w(0));for(var F=0;F<u.length;F++)w(u[F]);}}function se(u,F){D(65472),D(17),w(8),D(F),D(u),w(3),w(1),w(17),w(0),w(2),w(17),w(1),w(3),w(17),w(1);}function oe(){D(65499),D(132),w(0);for(var u=0;u<64;u++)w(i[u]);w(1);for(var F=0;F<64;F++)w(o[F]);}function G(){D(65476),D(418),w(0);for(var u=0;u<16;u++)w(N[u+1]);for(var F=0;F<=11;F++)w(O[F]);w(16);for(var T=0;T<16;T++)w(z[T+1]);for(var I=0;I<=161;I++)w(Y[I]);w(1);for(var H=0;H<16;H++)w(J[H+1]);for(var P=0;P<=11;P++)w(L[P]);w(17);for(var X=0;X<16;X++)w(W[X+1]);for(var ie=0;ie<=161;ie++)w(j[ie]);}function R(u){typeof u>"u"||u.constructor!==Array||u.forEach(F=>{if(typeof F=="string"){D(65534);var T=F.length;D(T+2);var I;for(I=0;I<T;I++)w(F.charCodeAt(I));}});}function fe(){D(65498),D(12),w(3),w(1),w(0),w(2),w(17),w(3),w(17),w(0),w(63),w(0);}function ne(u,F,T,I,H){for(var P=H[0],X=H[240],ie,de=16,pe=63,E=64,U=le(u,F),V=0;V<E;++V)A[C[V]]=U[V];var ge=A[0]-T;T=A[0],ge==0?Z(I[0]):(ie=32767+ge,Z(I[m[ie]]),Z(p[ie]));for(var ae=63;ae>0&&A[ae]==0;ae--);if(ae==0)return Z(P),T;for(var ce=1,me;ce<=ae;){for(var re=ce;A[ce]==0&&ce<=ae;++ce);var xe=ce-re;if(xe>=de){me=xe>>4;for(var Se=1;Se<=me;++Se)Z(X);xe=xe&15;}ie=32767+A[ce],Z(H[(xe<<4)+m[ie]]),Z(p[ie]),ce++;}return ae!=pe&&Z(P),T;}function ue(){for(var u=String.fromCharCode,F=0;F<256;F++)M[F]=u(F);}this.encode=function(u,F){var T=new Date().getTime();F&&b(F),S=new Array(),g=0,k=7,D(65496),ve(),R(u.comments),Q(u.exifBuffer),oe(),se(u.width,u.height),G(),fe();var I=0,H=0,P=0;g=0,k=7,this.encode.displayName="_encode_";for(var X=u.data,ie=u.width,de=u.height,pe=ie*4,E=ie*3,U,V=0,ge,ae,ce,me,re,xe,Se,be;V<de;){for(U=0;U<pe;){for(me=pe*V+U,re=me,xe=-1,Se=0,be=0;be<64;be++)Se=be>>3,xe=(be&7)*4,re=me+Se*pe+xe,V+Se>=de&&(re-=pe*(V+1+Se-de)),U+xe>=pe&&(re-=U+xe-pe+4),ge=X[re++],ae=X[re++],ce=X[re++],v[be]=(y[ge]+y[ae+256>>0]+y[ce+512>>0]>>16)-128,x[be]=(y[ge+768>>0]+y[ae+1024>>0]+y[ce+1280>>0]>>16)-128,d[be]=(y[ge+1280>>0]+y[ae+1536>>0]+y[ce+1792>>0]>>16)-128;I=ne(v,a,I,h,l),H=ne(x,s,H,f,c),P=ne(d,s,P,f,c),U+=32;}V+=8;}if(k>=0){var ke=[];ke[1]=k+1,ke[0]=(1<<k+1)-1,Z(ke);}if(D(65497),typeof Ot>"u")return new Uint8Array(S);return Buffer.from(S);var Te,Ie;};function b(u){if(u<=0&&(u=1),u>100&&(u=100),B!=u){var F=0;u<50?F=Math.floor(5e3/u):F=Math.floor(200-u*2),$(F),B=u;}}function q(){var u=new Date().getTime();e||(e=50),ue(),ye(),ee(),te(),b(e);var F=new Date().getTime()-u;}q();}typeof Ot<"u"?Ot.exports=Nn:typeof window<"u"&&(window["jpeg-js"]=window["jpeg-js"]||{},window["jpeg-js"].encode=Nn);function Nn(e,t){typeof t>"u"&&(t=50);var r=new Eo(t),n=r.encode(e,t);return{data:n,width:e.width,height:e.height};}});var Wn=nt((Ra,pr)=>{var dr=function(){"use strict";var t=new Int32Array([0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63]),r=4017,n=799,i=3406,o=2276,a=1567,s=3784,h=5793,f=2896;function l(){}function c(k,v){for(var x=0,d=[],M,y,B=16;B>0&&!k[B-1];)B--;d.push({children:[],index:0});var C=d[0],N;for(M=0;M<B;M++){for(y=0;y<k[M];y++){for(C=d.pop(),C.children[C.index]=v[x];C.index>0;){if(d.length===0)throw new Error("Could not recreate Huffman Table");C=d.pop();}for(C.index++,d.push(C);d.length<=M;)d.push(N={children:[],index:0}),C.children[C.index]=N.children,C=N;x++;}M+1<B&&(d.push(N={children:[],index:0}),C.children[C.index]=N.children,C=N);}return d[0].children;}function p(k,v,x,d,M,y,B,C,N,O){var z=x.precision,Y=x.samplesPerLine,J=x.scanLines,L=x.mcusPerLine,W=x.progressive,j=x.maxH,$=x.maxV,K=v,ye=0,ee=0;function te(){if(ee>0)return ee--,ye>>ee&1;if(ye=k[v++],ye==255){var E=k[v++];if(E)throw new Error("unexpected marker: "+(ye<<8|E).toString(16));}return ee=7,ye>>>7;}function Z(E){for(var U=E,V;(V=te())!==null;){if(U=U[V],typeof U=="number")return U;if(typeof U!="object")throw new Error("invalid huffman sequence");}return null;}function w(E){for(var U=0;E>0;){var V=te();if(V===null)return;U=U<<1|V,E--;}return U;}function D(E){var U=w(E);return U>=1<<E-1?U:U+(-1<<E)+1;}function le(E,U){var V=Z(E.huffmanTableDC),ge=V===0?0:D(V);U[0]=E.pred+=ge;for(var ae=1;ae<64;){var ce=Z(E.huffmanTableAC),me=ce&15,re=ce>>4;if(me===0){if(re<15)break;ae+=16;continue;}ae+=re;var xe=t[ae];U[xe]=D(me),ae++;}}function ve(E,U){var V=Z(E.huffmanTableDC),ge=V===0?0:D(V)<<N;U[0]=E.pred+=ge;}function Q(E,U){U[0]|=te()<<N;}var se=0;function oe(E,U){if(se>0){se--;return;}for(var V=y,ge=B;V<=ge;){var ae=Z(E.huffmanTableAC),ce=ae&15,me=ae>>4;if(ce===0){if(me<15){se=w(me)+(1<<me)-1;break;}V+=16;continue;}V+=me;var re=t[V];U[re]=D(ce)*(1<<N),V++;}}var G=0,R;function fe(E,U){for(var V=y,ge=B,ae=0;V<=ge;){var ce=t[V],me=U[ce]<0?-1:1;switch(G){case 0:var re=Z(E.huffmanTableAC),xe=re&15,ae=re>>4;if(xe===0)ae<15?(se=w(ae)+(1<<ae),G=4):(ae=16,G=1);else{if(xe!==1)throw new Error("invalid ACn encoding");R=D(xe),G=ae?2:3;}continue;case 1:case 2:U[ce]?U[ce]+=(te()<<N)*me:(ae--,ae===0&&(G=G==2?3:0));break;case 3:U[ce]?U[ce]+=(te()<<N)*me:(U[ce]=R<<N,G=0);break;case 4:U[ce]&&(U[ce]+=(te()<<N)*me);break;}V++;}G===4&&(se--,se===0&&(G=0));}function ne(E,U,V,ge,ae){var ce=V/L|0,me=V%L,re=ce*E.v+ge,xe=me*E.h+ae;E.blocks[re]===void 0&&O.tolerantDecoding||U(E,E.blocks[re][xe]);}function ue(E,U,V){var ge=V/E.blocksPerLine|0,ae=V%E.blocksPerLine;E.blocks[ge]===void 0&&O.tolerantDecoding||U(E,E.blocks[ge][ae]);}var b=d.length,q,u,F,T,I,H;W?y===0?H=C===0?ve:Q:H=C===0?oe:fe:H=le;var P=0,X,ie;b==1?ie=d[0].blocksPerLine*d[0].blocksPerColumn:ie=L*x.mcusPerColumn,M||(M=ie);for(var de,pe;P<ie;){for(u=0;u<b;u++)d[u].pred=0;if(se=0,b==1)for(q=d[0],I=0;I<M;I++)ue(q,H,P),P++;else for(I=0;I<M;I++){for(u=0;u<b;u++)for(q=d[u],de=q.h,pe=q.v,F=0;F<pe;F++)for(T=0;T<de;T++)ne(q,H,P,F,T);if(P++,P===ie)break;}if(P===ie)do{if(k[v]===255&&k[v+1]!==0)break;v+=1;}while(v<k.length-2);if(ee=0,X=k[v]<<8|k[v+1],X<65280)throw new Error("marker was not found");if(X>=65488&&X<=65495)v+=2;else break;}return v-K;}function m(k,v){var x=[],d=v.blocksPerLine,M=v.blocksPerColumn,y=d<<3,B=new Int32Array(64),C=new Uint8Array(64);function N(K,ye,ee){var te=v.quantizationTable,Z,w,D,le,ve,Q,se,oe,G,R=ee,fe;for(fe=0;fe<64;fe++)R[fe]=K[fe]*te[fe];for(fe=0;fe<8;++fe){var ne=8*fe;if(R[1+ne]==0&&R[2+ne]==0&&R[3+ne]==0&&R[4+ne]==0&&R[5+ne]==0&&R[6+ne]==0&&R[7+ne]==0){G=h*R[0+ne]+512>>10,R[0+ne]=G,R[1+ne]=G,R[2+ne]=G,R[3+ne]=G,R[4+ne]=G,R[5+ne]=G,R[6+ne]=G,R[7+ne]=G;continue;}Z=h*R[0+ne]+128>>8,w=h*R[4+ne]+128>>8,D=R[2+ne],le=R[6+ne],ve=f*(R[1+ne]-R[7+ne])+128>>8,oe=f*(R[1+ne]+R[7+ne])+128>>8,Q=R[3+ne]<<4,se=R[5+ne]<<4,G=Z-w+1>>1,Z=Z+w+1>>1,w=G,G=D*s+le*a+128>>8,D=D*a-le*s+128>>8,le=G,G=ve-se+1>>1,ve=ve+se+1>>1,se=G,G=oe+Q+1>>1,Q=oe-Q+1>>1,oe=G,G=Z-le+1>>1,Z=Z+le+1>>1,le=G,G=w-D+1>>1,w=w+D+1>>1,D=G,G=ve*o+oe*i+2048>>12,ve=ve*i-oe*o+2048>>12,oe=G,G=Q*n+se*r+2048>>12,Q=Q*r-se*n+2048>>12,se=G,R[0+ne]=Z+oe,R[7+ne]=Z-oe,R[1+ne]=w+se,R[6+ne]=w-se,R[2+ne]=D+Q,R[5+ne]=D-Q,R[3+ne]=le+ve,R[4+ne]=le-ve;}for(fe=0;fe<8;++fe){var ue=fe;if(R[8+ue]==0&&R[16+ue]==0&&R[24+ue]==0&&R[32+ue]==0&&R[40+ue]==0&&R[48+ue]==0&&R[56+ue]==0){G=h*ee[fe+0]+8192>>14,R[0+ue]=G,R[8+ue]=G,R[16+ue]=G,R[24+ue]=G,R[32+ue]=G,R[40+ue]=G,R[48+ue]=G,R[56+ue]=G;continue;}Z=h*R[0+ue]+2048>>12,w=h*R[32+ue]+2048>>12,D=R[16+ue],le=R[48+ue],ve=f*(R[8+ue]-R[56+ue])+2048>>12,oe=f*(R[8+ue]+R[56+ue])+2048>>12,Q=R[24+ue],se=R[40+ue],G=Z-w+1>>1,Z=Z+w+1>>1,w=G,G=D*s+le*a+2048>>12,D=D*a-le*s+2048>>12,le=G,G=ve-se+1>>1,ve=ve+se+1>>1,se=G,G=oe+Q+1>>1,Q=oe-Q+1>>1,oe=G,G=Z-le+1>>1,Z=Z+le+1>>1,le=G,G=w-D+1>>1,w=w+D+1>>1,D=G,G=ve*o+oe*i+2048>>12,ve=ve*i-oe*o+2048>>12,oe=G,G=Q*n+se*r+2048>>12,Q=Q*r-se*n+2048>>12,se=G,R[0+ue]=Z+oe,R[56+ue]=Z-oe,R[8+ue]=w+se,R[48+ue]=w-se,R[16+ue]=D+Q,R[40+ue]=D-Q,R[24+ue]=le+ve,R[32+ue]=le-ve;}for(fe=0;fe<64;++fe){var b=128+(R[fe]+8>>4);ye[fe]=b<0?0:b>255?255:b;}}g(y*M*8);for(var O,z,Y=0;Y<M;Y++){var J=Y<<3;for(O=0;O<8;O++)x.push(new Uint8Array(y));for(var L=0;L<d;L++){N(v.blocks[Y][L],C,B);var W=0,j=L<<3;for(z=0;z<8;z++){var $=x[J+z];for(O=0;O<8;O++)$[j+O]=C[W++];}}}return x;}function _(k){return k<0?0:k>255?255:k;}l.prototype={load:function(v){var x=new XMLHttpRequest();x.open("GET",v,!0),x.responseType="arraybuffer",x.onload=function(){var d=new Uint8Array(x.response||x.mozResponseArrayBuffer);this.parse(d),this.onload&&this.onload();}.bind(this),x.send(null);},parse:function(v){var x=this.opts.maxResolutionInMP*1e3*1e3,d=0,M=v.length;function y(){var re=v[d]<<8|v[d+1];return d+=2,re;}function B(){var re=y(),xe=v.subarray(d,d+re-2);return d+=xe.length,xe;}function C(re){var xe=1,Se=1,be,ke;for(ke in re.components)re.components.hasOwnProperty(ke)&&(be=re.components[ke],xe<be.h&&(xe=be.h),Se<be.v&&(Se=be.v));var Te=Math.ceil(re.samplesPerLine/8/xe),Ie=Math.ceil(re.scanLines/8/Se);for(ke in re.components)if(re.components.hasOwnProperty(ke)){be=re.components[ke];var He=Math.ceil(Math.ceil(re.samplesPerLine/8)*be.h/xe),he=Math.ceil(Math.ceil(re.scanLines/8)*be.v/Se),_e=Te*be.h,Ee=Ie*be.v,Pe=Ee*_e,De=[];g(Pe*256);for(var Ue=0;Ue<Ee;Ue++){for(var qe=[],We=0;We<_e;We++)qe.push(new Int32Array(64));De.push(qe);}be.blocksPerLine=He,be.blocksPerColumn=he,be.blocks=De;}re.maxH=xe,re.maxV=Se,re.mcusPerLine=Te,re.mcusPerColumn=Ie;}var N=null,O=null,z=null,Y,J,L=[],W=[],j=[],$=[],K=y(),ye=-1;if(this.comments=[],K!=65496)throw new Error("SOI not found");for(K=y();K!=65497;){var ee,te,Z;switch(K){case 65280:break;case 65504:case 65505:case 65506:case 65507:case 65508:case 65509:case 65510:case 65511:case 65512:case 65513:case 65514:case 65515:case 65516:case 65517:case 65518:case 65519:case 65534:var w=B();if(K===65534){var D=String.fromCharCode.apply(null,w);this.comments.push(D);}K===65504&&w[0]===74&&w[1]===70&&w[2]===73&&w[3]===70&&w[4]===0&&(N={version:{major:w[5],minor:w[6]},densityUnits:w[7],xDensity:w[8]<<8|w[9],yDensity:w[10]<<8|w[11],thumbWidth:w[12],thumbHeight:w[13],thumbData:w.subarray(14,14+3*w[12]*w[13])}),K===65505&&w[0]===69&&w[1]===120&&w[2]===105&&w[3]===102&&w[4]===0&&(this.exifBuffer=w.subarray(5,w.length)),K===65518&&w[0]===65&&w[1]===100&&w[2]===111&&w[3]===98&&w[4]===101&&w[5]===0&&(O={version:w[6],flags0:w[7]<<8|w[8],flags1:w[9]<<8|w[10],transformCode:w[11]});break;case 65499:for(var le=y(),ve=le+d-2;d<ve;){var Q=v[d++];g(256);var se=new Int32Array(64);if(Q>>4===0)for(te=0;te<64;te++){var oe=t[te];se[oe]=v[d++];}else if(Q>>4===1)for(te=0;te<64;te++){var oe=t[te];se[oe]=y();}else throw new Error("DQT: invalid table spec");L[Q&15]=se;}break;case 65472:case 65473:case 65474:y(),Y={},Y.extended=K===65473,Y.progressive=K===65474,Y.precision=v[d++],Y.scanLines=y(),Y.samplesPerLine=y(),Y.components={},Y.componentsOrder=[];var G=Y.scanLines*Y.samplesPerLine;if(G>x){var R=Math.ceil((G-x)/1e6);throw new Error(`maxResolutionInMP limit exceeded by ${R}MP`);}var fe=v[d++],ne,ue=0,b=0;for(ee=0;ee<fe;ee++){ne=v[d];var q=v[d+1]>>4,u=v[d+1]&15,F=v[d+2];if(q<=0||u<=0)throw new Error("Invalid sampling factor, expected values above 0");Y.componentsOrder.push(ne),Y.components[ne]={h:q,v:u,quantizationIdx:F},d+=3;}C(Y),W.push(Y);break;case 65476:var T=y();for(ee=2;ee<T;){var I=v[d++],H=new Uint8Array(16),P=0;for(te=0;te<16;te++,d++)P+=H[te]=v[d];g(16+P);var X=new Uint8Array(P);for(te=0;te<P;te++,d++)X[te]=v[d];ee+=17+P,(I>>4===0?$:j)[I&15]=c(H,X);}break;case 65501:y(),J=y();break;case 65500:y(),y();break;case 65498:var ie=y(),de=v[d++],pe=[],E;for(ee=0;ee<de;ee++){E=Y.components[v[d++]];var U=v[d++];E.huffmanTableDC=$[U>>4],E.huffmanTableAC=j[U&15],pe.push(E);}var V=v[d++],ge=v[d++],ae=v[d++],ce=p(v,d,Y,pe,J,V,ge,ae>>4,ae&15,this.opts);d+=ce;break;case 65535:v[d]!==255&&d--;break;default:if(v[d-3]==255&&v[d-2]>=192&&v[d-2]<=254){d-=3;break;}else if(K===224||K==225){if(ye!==-1)throw new Error(`first unknown JPEG marker at offset ${ye.toString(16)}, second unknown JPEG marker ${K.toString(16)} at offset ${(d-1).toString(16)}`);ye=d-1;var re=y();if(v[d+re-2]===255){d+=re-2;break;}}throw new Error("unknown JPEG marker "+K.toString(16));}K=y();}if(W.length!=1)throw new Error("only single frame JPEGs supported");for(var ee=0;ee<W.length;ee++){var me=W[ee].components;for(var te in me)me[te].quantizationTable=L[me[te].quantizationIdx],delete me[te].quantizationIdx;}this.width=Y.samplesPerLine,this.height=Y.scanLines,this.jfif=N,this.adobe=O,this.components=[];for(var ee=0;ee<Y.componentsOrder.length;ee++){var E=Y.components[Y.componentsOrder[ee]];this.components.push({lines:m(Y,E),scaleX:E.h/Y.maxH,scaleY:E.v/Y.maxV});}},getData:function(v,x){var d=this.width/v,M=this.height/x,y,B,C,N,O,z,Y,J,L,W,j=0,$,K,ye,ee,te,Z,w,D,le,ve,Q,se=v*x*this.components.length;g(se);var oe=new Uint8Array(se);switch(this.components.length){case 1:for(y=this.components[0],W=0;W<x;W++)for(O=y.lines[0|W*y.scaleY*M],L=0;L<v;L++)$=O[0|L*y.scaleX*d],oe[j++]=$;break;case 2:for(y=this.components[0],B=this.components[1],W=0;W<x;W++)for(O=y.lines[0|W*y.scaleY*M],z=B.lines[0|W*B.scaleY*M],L=0;L<v;L++)$=O[0|L*y.scaleX*d],oe[j++]=$,$=z[0|L*B.scaleX*d],oe[j++]=$;break;case 3:for(Q=!0,this.adobe&&this.adobe.transformCode?Q=!0:typeof this.opts.colorTransform<"u"&&(Q=!!this.opts.colorTransform),y=this.components[0],B=this.components[1],C=this.components[2],W=0;W<x;W++)for(O=y.lines[0|W*y.scaleY*M],z=B.lines[0|W*B.scaleY*M],Y=C.lines[0|W*C.scaleY*M],L=0;L<v;L++)Q?($=O[0|L*y.scaleX*d],K=z[0|L*B.scaleX*d],ye=Y[0|L*C.scaleX*d],D=_($+1.402*(ye-128)),le=_($-.3441363*(K-128)-.71413636*(ye-128)),ve=_($+1.772*(K-128))):(D=O[0|L*y.scaleX*d],le=z[0|L*B.scaleX*d],ve=Y[0|L*C.scaleX*d]),oe[j++]=D,oe[j++]=le,oe[j++]=ve;break;case 4:if(!this.adobe)throw new Error("Unsupported color mode (4 components)");for(Q=!1,this.adobe&&this.adobe.transformCode?Q=!0:typeof this.opts.colorTransform<"u"&&(Q=!!this.opts.colorTransform),y=this.components[0],B=this.components[1],C=this.components[2],N=this.components[3],W=0;W<x;W++)for(O=y.lines[0|W*y.scaleY*M],z=B.lines[0|W*B.scaleY*M],Y=C.lines[0|W*C.scaleY*M],J=N.lines[0|W*N.scaleY*M],L=0;L<v;L++)Q?($=O[0|L*y.scaleX*d],K=z[0|L*B.scaleX*d],ye=Y[0|L*C.scaleX*d],ee=J[0|L*N.scaleX*d],te=255-_($+1.402*(ye-128)),Z=255-_($-.3441363*(K-128)-.71413636*(ye-128)),w=255-_($+1.772*(K-128))):(te=O[0|L*y.scaleX*d],Z=z[0|L*B.scaleX*d],w=Y[0|L*C.scaleX*d],ee=J[0|L*N.scaleX*d]),oe[j++]=255-te,oe[j++]=255-Z,oe[j++]=255-w,oe[j++]=255-ee;break;default:throw new Error("Unsupported color mode");}return oe;},copyToImageData:function(v,x){var d=v.width,M=v.height,y=v.data,B=this.getData(d,M),C=0,N=0,O,z,Y,J,L,W,j,$,K;switch(this.components.length){case 1:for(z=0;z<M;z++)for(O=0;O<d;O++)Y=B[C++],y[N++]=Y,y[N++]=Y,y[N++]=Y,x&&(y[N++]=255);break;case 3:for(z=0;z<M;z++)for(O=0;O<d;O++)j=B[C++],$=B[C++],K=B[C++],y[N++]=j,y[N++]=$,y[N++]=K,x&&(y[N++]=255);break;case 4:for(z=0;z<M;z++)for(O=0;O<d;O++)L=B[C++],W=B[C++],Y=B[C++],J=B[C++],j=255-_(L*(1-J/255)+J),$=255-_(W*(1-J/255)+J),K=255-_(Y*(1-J/255)+J),y[N++]=j,y[N++]=$,y[N++]=K,x&&(y[N++]=255);break;default:throw new Error("Unsupported color mode");}}};var A=0,S=0;function g(k=0){var v=A+k;if(v>S){var x=Math.ceil((v-S)/1024/1024);throw new Error(`maxMemoryUsageInMB limit exceeded by at least ${x}MB`);}A=v;}return l.resetMaxMemoryUsage=function(k){A=0,S=k;},l.getBytesAllocated=function(){return A;},l.requestMemoryAllocation=g,l;}();typeof pr<"u"?pr.exports=Hn:typeof window<"u"&&(window["jpeg-js"]=window["jpeg-js"]||{},window["jpeg-js"].decode=Hn);function Hn(e,t={}){var r={colorTransform:void 0,useTArray:!1,formatAsRGBA:!0,tolerantDecoding:!0,maxResolutionInMP:100,maxMemoryUsageInMB:512},n={...r,...t},i=new Uint8Array(e),o=new dr();o.opts=n,dr.resetMaxMemoryUsage(n.maxMemoryUsageInMB*1024*1024),o.parse(i);var a=n.formatAsRGBA?4:3,s=o.width*o.height*a;try{dr.requestMemoryAllocation(s);var h={width:o.width,height:o.height,exifBuffer:o.exifBuffer,data:n.useTArray?new Uint8Array(s):Buffer.alloc(s)};o.comments.length>0&&(h.comments=o.comments);}catch(f){throw f instanceof RangeError?new Error("Could not allocate enough memory for the image. Required: "+s):f instanceof ReferenceError&&f.message==="Buffer is not defined"?new Error("Buffer is not globally defined in this environment. Consider setting useTArray to true"):f;}return o.copyToImageData(h,n.formatAsRGBA),h;}});var Yn=nt((Da,$n)=>{var _o=Gn(),So=Wn();$n.exports={encode:_o,decode:So};});var To={};ri(To,{default:()=>Uo});module.exports=ni(To);var jr=lt(Ir(),1),Kr=lt($r(),1),ct=lt(Xt(),1),{GIFEncoder:Di,quantize:Oi,applyPalette:Li}=Kr.default,Zr=e=>/^R0lGOD[dl]h/.test(e),Oe=320,qt=512*1024,Qr=()=>new Promise(e=>setTimeout(e,0));function Pi(e){var t=()=>new Error("This GIF download is incomplete. Reopen the GIF or share the original file and try again.");if(e.length<13)throw t();if(!/^GIF8[79]a$/.test(String.fromCharCode(...e.subarray(0,6))))throw new Error("This file could not be read as an animated GIF.");var r=13,n=0,i=!1;function o(f){if(r+f>e.length)throw t();var l=r;return r+=f,l;}function a(f){f&128&&o(3*(1<<(f&7)+1));}function s(){for(;;){var f=e[o(1)];if(f===0)return;o(f);}}for(a(e[10]);r<e.length;){var f=e[o(1)];if(f===59){if(!n||i)throw t();return r===e.length?e:e.subarray(0,r);}if(f===33){var l=e[o(1)];s(),l===249&&(i=!0);}else if(f===44){var _l4=o(9);if(a(e[_l4+8]),o(1),s(),i=!1,++n>250)throw new Error("Use a GIF with 250 frames or fewer.");}else throw new Error("This GIF contains an invalid data block. Share the original GIF file and try again.");}if(!n||i)throw t();var h=new Uint8Array(e.length+1);return h.set(e),h[e.length]=59,h;}function Ni(e){var t=Pi(e),r;try{r=new jr.GifReader(t);}catch{throw new Error("This file could not be read as an animated GIF.");}var{width:n,height:i}=r,o=r.numFrames();if(!n||!i||n*i>4*1024*1024)throw new Error("This GIF is too large to resize on mobile. Use a GIF below 4 megapixels.");if(!o||o>250)throw new Error("Use a GIF with 250 frames or fewer.");var a=[],s=0;for(var h=0;h<o;h++){var f=r.frameInfo(h);if(!f.width||!f.height||f.x+f.width>n||f.y+f.height>i||f.data_offset+f.data_length>t.length||f.palette_offset==null||f.palette_offset+f.palette_size*3>t.length||t[f.data_offset]<2||t[f.data_offset]>8)throw new Error("This GIF contains an invalid frame.");var l=f.delay<2?100:f.delay*10;s+=l,a.push({...f,delayMs:l});}if(s>5e3)throw new Error("Discord stickers can be at most 5 seconds long. Use a shorter GIF; it has not been trimmed or uploaded.");return{bytes:t,reader:r,width:n,height:i,frames:a,duration:s};}function Xr(e,t){if(t.transparent_index!=null||!(e[10]&128))return[0,0,0,0];var r=13+e[11]*3;return[e[r]??0,e[r+1]??0,e[r+2]??0,255];}function qr(e,t,r,n){for(var i=r.y;i<r.y+r.height;i++){var o=(i*t+r.x)*4;for(var a=0;a<r.width;a++,o+=4)e.set(n,o);}}function zi(e,t,r){var n=Math.min(Oe/t,Oe/r),i=Math.max(1,Math.round(t*n)),o=Math.max(1,Math.round(r*n)),a=Math.floor((Oe-i)/2),s=Math.floor((Oe-o)/2),h=new Uint8Array(Oe*Oe*4);for(var f=0;f<o;f++){var l=Math.min(r-1,Math.floor((f+.5)*r/o));for(var c=0;c<i;c++){var p=Math.min(t-1,Math.floor((c+.5)*t/i)),m=(l*t+p)*4,_=((f+s)*Oe+c+a)*4;h[_]=e[m],h[_+1]=e[m+1],h[_+2]=e[m+2],h[_+3]=e[m+3];}}return h;}async function Gi(e,t,r,n){var{reader:i,width:o,height:a,frames:s}=t,h=new Uint8Array(o*a*4);qr(h,o,{x:0,y:0,width:o,height:a},Xr(e,s[0]));var f=Di(),l,c;for(var p=0;p<s.length;p++){n(),l?.disposal===2?qr(h,o,l,Xr(e,l)):l?.disposal===3&&c&&h.set(c);var m=s[p];c=m.disposal===3?h.slice():null,i.decodeAndBlitFrameRGBA(p,h);var _=zi(h,o,a),A=Oi(_,r-1,{format:"rgba4444",oneBitAlpha:!0}),S=[[0,0,0,0],...A.filter(k=>k[3]!==0)];S.length===1&&S.push([0,0,0,255]);var g=Li(_,S,"rgba4444");if(f.writeFrame(g,Oe,Oe,{palette:S,delay:m.delayMs,repeat:i.loopCount()??-1,transparent:!0,transparentIndex:0,dispose:2}),f.bytesView().length>qt)return null;l=m,await Qr();}return f.finish(),f.bytesView().length<=qt?f.bytes():null;}async function Jr(e,t=()=>{}){t(),e=e.replace(/\s/g,"");var r=(0,ct.toByteArray)(e),n=Ni(r),{bytes:i}=n;if(n.width===Oe&&n.height===Oe&&i.length<=qt)return{base64:i===r?e:(0,ct.fromByteArray)(i),mimeType:"image/gif",extension:"gif"};if(n.width*n.height*n.frames.length>80*1024*1024)throw new Error("This GIF is too complex to resize on mobile. Use a smaller GIF.");for(var o of[256,128,64]){await Qr(),t();var a=await Gi(i,n,o,t);if(a)return{base64:(0,ct.fromByteArray)(a),mimeType:"image/gif",extension:"gif"};}throw new Error("This animated GIF is still over 512 KiB after resizing. Use a shorter or simpler GIF.");}async function en(e){var t=new Set();async function r(n,i){if(n==null||i>5)return;if(typeof n=="string")try{return r(JSON.parse(n),i+1);}catch{return;}if(typeof n!="object"||t.has(n))return;if(t.add(n),typeof n.then=="function")try{return r(await n,i+1);}catch{return;}if(Array.isArray(n)||typeof n.id=="string"&&n.id)return n;for(var s of["body","data","result","response","emoji","sticker","emojis","stickers","parsedBody"]){var h=await r(n[s],i+1);if(h)return h;}if(typeof n.json=="function")try{var _s3=await r(await n.json(),i+1);if(_s3)return _s3;}catch{}else{var _s4=await r(n.json,i+1);if(_s4)return _s4;}var o;try{o=typeof n.text=="function"?await n.text():n.text;}catch{}var a=await r(o,i+1);return a||(typeof n.message=="string"?n:void 0);}return r(e,0);}function tn(e,t=globalThis){var r=s=>{try{return s();}catch{}},n=(...s)=>r(()=>e.metro.findByProps(...s));function i(){var s=[()=>typeof valenced<"u"?valenced.discord?.native?.FileModule:void 0,()=>typeof revenge<"u"?revenge.discord?.native?.FileModule:void 0,()=>n("writeFile","removeFile"),...["NativeFileModule","RTNFileManager","DCDFileManager"].map(h=>()=>e.metro.common.ReactNative.NativeModules?.[h]??t.nativeModuleProxy?.[h])];for(var h of s){var f=r(h);if(typeof f?.writeFile=="function"&&typeof f?.removeFile=="function")return f;}}function o(){for(var s of[()=>e.metro.common.RestAPI,()=>e.metro.common.restAPI,()=>n("HTTP")?.HTTP,()=>n("get","post","del")]){var h=r(s);if(typeof h?.post=="function")return h;}}function a(s){if(s!=="sticker"&&s!=="emoji")throw new Error("Unknown expression type.");var h=s==="sticker"?"createGuildSticker":"uploadEmoji",f=n(h),l=typeof f?.[h]=="function",c=l?void 0:o();if(!l&&!c)throw new Error("Discord\u2019s signed-in upload API is unavailable. Restart Discord and try again.");return async(p,m=()=>{})=>{m();var _=`/guilds/${p.guildId}/${s==="sticker"?"stickers":"emojis"}`,A,S,g=async()=>{if(typeof c?.get!="function")return;m();var x=await c.get({url:_,failImmediatelyWhenRateLimited:!0});if(m(),x?.ok===!1||Number(x?.status??x?.statusCode)>=400)return;var d=await en(x);return m(),Array.isArray(d)?d:void 0;};if(l)A=await f[h](p);else{var x;if(s==="sticker"){if(typeof t.FormData!="function")throw new Error("Discord\u2019s multipart upload support is unavailable.");if(x=new t.FormData(),typeof x.getParts!="function")throw new Error("Discord\u2019s native multipart upload support is unavailable.");if(!/^(file|content):\/\//.test(p.uri))throw new Error("The sticker file is not ready to upload.");x.append("name",p.name),x.append("tags",p.tags),x.append("description",p.description??""),x.append("file",{uri:p.uri,name:p.mimeType==="image/gif"?"sticker.gif":"sticker.png",type:p.mimeType});}else x={name:p.name,image:p.image,roles:p.roles??[]};try{var d=await g();d&&(S=new Set(d.map(M=>M.id)));}catch{m();}m(),A=await c.post({url:_,body:x,oldFormErrors:!0,failImmediatelyWhenRateLimited:!0});}var k=await en(A),v=A?.status??A?.statusCode??A?.response?.status;if(A?.ok===!1||Number(v)>=400)throw{status:v,body:k??A?.body};if(m(),!k?.id&&!l&&S){var _x;try{_x=await g();}catch{m();}var _d=r(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.()?.id),M=_x?.filter(y=>typeof y.id=="string"&&y.id&&!S.has(y.id)&&y.name===p.name&&(!y.user?.id||y.user.id===_d))??[];M.length===1&&(k=M[0]);}if((!l||s==="sticker")&&!k?.id)throw new Error(`Discord did not confirm the upload. Check the server\u2019s ${s==="sticker"?"stickers":"emoji"} before trying again.`);return m(),!l&&s==="sticker"&&r(()=>e.metro.common.FluxDispatcher?.dispatch?.({type:"GUILD_STICKERS_CREATE_SUCCESS",guildId:p.guildId,sticker:{...k,user:k.user??r(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.())}})),k;};}return{resolve:a,files:i};}function rn(e,t){var{React:r,ReactNative:n}=e.metro.common,i=r.createElement,o=new Set(),a=0,s=l=>{try{return l();}catch{}},h=(...l)=>s(()=>e.metro.findByProps(...l));function f(l,c,p){var m=h("openAlert","dismissAlert");if(!n.Modal||typeof m?.openAlert!="function"||!r.useState||!r.useEffect)return!1;for(var k of[...o])k.close();var _=`${t}.panel.${Date.now().toString(36)}.${Math.random().toString(36).slice(2)}.${++a}`,A={visible:!0,listeners:new Set()},S=()=>{if(!A.visible)return;A.visible=!1;for(var x of A.listeners)x();o.delete(A),s(()=>p?.()),s(()=>m.dismissAlert(_));var k=h("useAlertStore")??s(()=>e.metro.findByImportedPath?.("design/components/AlertModal/native/useAlertStore.native.tsx")),v=k?.useAlertStore??k?.default;typeof v?.setState=="function"&&s(()=>v.setState(x=>{if(!Array.isArray(x.alerts))return x;var d=x.alerts.filter(M=>M.key!==_&&M.node!==A.node);return d.length===x.alerts.length?x:{alerts:d};}));};A.close=S;function g(){var[,k]=r.useState(0);r.useEffect(()=>{var M=()=>k(y=>y+1);return A.listeners.add(M),()=>{A.listeners.delete(M),S();};},[]);var v=n.useWindowDimensions?.()??n.Dimensions?.get?.("window")??{height:800};if(!A.visible)return null;var d=(s(()=>e.metro.findByStoreName("ThemeStore")?.theme)??n.Appearance?.getColorScheme?.())==="light"?"#ffffff":"#242429";return i(n.Modal,{visible:!0,transparent:!0,animationType:"slide",presentationStyle:"overFullScreen",onRequestClose:S,onDismiss:S,statusBarTranslucent:!1,navigationBarTranslucent:!1},i(n.KeyboardAvoidingView??n.View,{style:{flex:1},behavior:n.Platform?.OS==="ios"?"padding":"height"},i(n.View,{style:{flex:1,justifyContent:"flex-end",backgroundColor:"rgba(0,0,0,0.65)"}},i(n.Pressable??n.TouchableOpacity,{onPress:S,accessibilityRole:"button",accessibilityLabel:`Close ${c}`,style:{position:"absolute",top:0,left:0,right:0,bottom:0}}),i(n.View,{testID:t+"-panel",accessibilityViewIsModal:!0,onAccessibilityEscape:S,style:{height:Math.min(720,v.height*.86),maxHeight:"92%",backgroundColor:d,borderTopLeftRadius:20,borderTopRightRadius:20,overflow:"hidden",paddingTop:8,paddingBottom:16}},l(S)))));}A.node=i(g),o.add(A);try{var _k=m.openAlert(_,A.node,S,{dismissable:!0});return _k?.catch&&_k.catch(S),!0;}catch{return S(),!1;}}return{open:f,closeAll(){for(var l of[...o])l.close();}};}var Ce=Uint8Array,Be=Uint16Array,ir=Int32Array,Ft=new Ce([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),kt=new Ce([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),Jt=new Ce([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),ln=function(e,t){for(var r=new Be(31),n=0;n<31;++n)r[n]=t+=1<<e[n-1];for(var i=new ir(r[30]),n=1;n<30;++n)for(var o=r[n];o<r[n+1];++o)i[o]=o-r[n]<<5|n;return{b:r,r:i};},fn=ln(Ft,2),cn=fn.b,er=fn.r;cn[28]=258,er[258]=28;var hn=ln(kt,0),Hi=hn.b,nn=hn.r,tr=new Be(32768);for(Ae=0;Ae<32768;++Ae)$e=(Ae&43690)>>1|(Ae&21845)<<1,$e=($e&52428)>>2|($e&13107)<<2,$e=($e&61680)>>4|($e&3855)<<4,tr[Ae]=(($e&65280)>>8|($e&255)<<8)>>1;var $e,Ae,ze=function(e,t,r){for(var n=e.length,i=0,o=new Be(t);i<n;++i)e[i]&&++o[e[i]-1];var a=new Be(t);for(i=1;i<t;++i)a[i]=a[i-1]+o[i-1]<<1;var s;if(r){s=new Be(1<<t);var h=15-t;for(i=0;i<n;++i)if(e[i])for(var f=i<<4|e[i],l=t-e[i],c=a[e[i]-1]++<<l,p=c|(1<<l)-1;c<=p;++c)s[tr[c]>>h]=f;}else for(s=new Be(n),i=0;i<n;++i)e[i]&&(s[i]=tr[a[e[i]-1]++]>>15-e[i]);return s;},Ke=new Ce(288);for(Ae=0;Ae<144;++Ae)Ke[Ae]=8;var Ae;for(Ae=144;Ae<256;++Ae)Ke[Ae]=9;var Ae;for(Ae=256;Ae<280;++Ae)Ke[Ae]=7;var Ae;for(Ae=280;Ae<288;++Ae)Ke[Ae]=8;var Ae,dt=new Ce(32);for(Ae=0;Ae<32;++Ae)dt[Ae]=5;var Ae,Wi=ze(Ke,9,0),$i=ze(Ke,9,1),Yi=ze(dt,5,0),Vi=ze(dt,5,1),jt=function(e){for(var t=e[0],r=1;r<e.length;++r)e[r]>t&&(t=e[r]);return t;},Le=function(e,t,r){var n=t/8|0;return(e[n]|e[n+1]<<8)>>(t&7)&r;},Kt=function(e,t){var r=t/8|0;return(e[r]|e[r+1]<<8|e[r+2]<<16)>>(t&7);},or=function(e){return(e+7)/8|0;},et=function(e,t,r){return(t==null||t<0)&&(t=0),(r==null||r>e.length)&&(r=e.length),new Ce(e.subarray(t,r));};var Xi=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],Me=function(e,t,r){var n=new Error(t||Xi[e]);if(n.code=e,Error.captureStackTrace&&Error.captureStackTrace(n,Me),!r)throw n;return n;},un=function(e,t,r,n){var i=e.length,o=n?n.length:0;if(!i||t.f&&!t.l)return r||new Ce(0);var a=!r,s=a||t.i!=2,h=t.i;a&&(r=new Ce(i*3));var f=function(G){var R=r.length;if(G>R){var fe=new Ce(Math.max(R*2,G));fe.set(r),r=fe;}},l=t.f||0,c=t.p||0,p=t.b||0,m=t.l,_=t.d,A=t.m,S=t.n,g=i*8;do{if(!m){l=Le(e,c,1);var k=Le(e,c+1,3);if(c+=3,k){if(k==1)m=$i,_=Vi,A=9,S=5;else if(k==2){var M=Le(e,c,31)+257,y=Le(e,c+10,15)+4,B=M+Le(e,c+5,31)+1;c+=14;for(var C=new Ce(B),N=new Ce(19),O=0;O<y;++O)N[Jt[O]]=Le(e,c+O*3,7);c+=y*3;for(var z=jt(N),Y=(1<<z)-1,J=ze(N,z,1),O=0;O<B;){var L=J[Le(e,c,Y)];c+=L&15;var v=L>>4;if(v<16)C[O++]=v;else{var W=0,j=0;for(v==16?(j=3+Le(e,c,3),c+=2,W=C[O-1]):v==17?(j=3+Le(e,c,7),c+=3):v==18&&(j=11+Le(e,c,127),c+=7);j--;)C[O++]=W;}}var $=C.subarray(0,M),K=C.subarray(M);A=jt($),S=jt(K),m=ze($,A,1),_=ze(K,S,1);}else Me(1);}else{var v=or(c)+4,x=e[v-4]|e[v-3]<<8,d=v+x;if(d>i){h&&Me(0);break;}s&&f(p+x),r.set(e.subarray(v,d),p),t.b=p+=x,t.p=c=d*8,t.f=l;continue;}if(c>g){h&&Me(0);break;}}s&&f(p+131072);for(var ye=(1<<A)-1,ee=(1<<S)-1,te=c;;te=c){var W=m[Kt(e,c)&ye],Z=W>>4;if(c+=W&15,c>g){h&&Me(0);break;}if(W||Me(2),Z<256)r[p++]=Z;else if(Z==256){te=c,m=null;break;}else{var w=Z-254;if(Z>264){var O=Z-257,D=Ft[O];w=Le(e,c,(1<<D)-1)+cn[O],c+=D;}var le=_[Kt(e,c)&ee],ve=le>>4;le||Me(3),c+=le&15;var K=Hi[ve];if(ve>3){var D=kt[ve];K+=Kt(e,c)&(1<<D)-1,c+=D;}if(c>g){h&&Me(0);break;}s&&f(p+131072);var Q=p+w;if(p<K){var se=o-K,oe=Math.min(K,Q);for(se+p<0&&Me(3);p<oe;++p)r[p]=n[se+p];}for(;p<Q;++p)r[p]=r[p-K];}}t.l=m,t.p=te,t.b=p,t.f=l,m&&(l=1,t.m=A,t.d=_,t.n=S);}while(!l);return p!=r.length&&a?et(r,0,p):r.subarray(0,p);},Ye=function(e,t,r){r<<=t&7;var n=t/8|0;e[n]|=r,e[n+1]|=r>>8;},ht=function(e,t,r){r<<=t&7;var n=t/8|0;e[n]|=r,e[n+1]|=r>>8,e[n+2]|=r>>16;},Zt=function(e,t){for(var r=[],n=0;n<e.length;++n)e[n]&&r.push({s:n,f:e[n]});var i=r.length,o=r.slice();if(!i)return{t:pn,l:0};if(i==1){var a=new Ce(r[0].s+1);return a[r[0].s]=1,{t:a,l:1};}r.sort(function(d,M){return d.f-M.f;}),r.push({s:-1,f:25001});var s=r[0],h=r[1],f=0,l=1,c=2;for(r[0]={s:-1,f:s.f+h.f,l:s,r:h};l!=i-1;)s=r[r[f].f<r[c].f?f++:c++],h=r[f!=l&&r[f].f<r[c].f?f++:c++],r[l++]={s:-1,f:s.f+h.f,l:s,r:h};for(var p=o[0].s,n=1;n<i;++n)o[n].s>p&&(p=o[n].s);var m=new Be(p+1),_=rr(r[l-1],m,0);if(_>t){var n=0,A=0,S=_-t,g=1<<S;for(o.sort(function(M,y){return m[y.s]-m[M.s]||M.f-y.f;});n<i;++n){var k=o[n].s;if(m[k]>t)A+=g-(1<<_-m[k]),m[k]=t;else break;}for(A>>=S;A>0;){var v=o[n].s;m[v]<t?A-=1<<t-m[v]++-1:++n;}for(;n>=0&&A;--n){var x=o[n].s;m[x]==t&&(--m[x],++A);}_=t;}return{t:new Ce(m),l:_};},rr=function(e,t,r){return e.s==-1?Math.max(rr(e.l,t,r+1),rr(e.r,t,r+1)):t[e.s]=r;},on=function(e){for(var t=e.length;t&&!e[--t];);for(var r=new Be(++t),n=0,i=e[0],o=1,a=function(h){r[n++]=h;},s=1;s<=t;++s)if(e[s]==i&&s!=t)++o;else{if(!i&&o>2){for(;o>138;o-=138)a(32754);o>2&&(a(o>10?o-11<<5|28690:o-3<<5|12305),o=0);}else if(o>3){for(a(i),--o;o>6;o-=6)a(8304);o>2&&(a(o-3<<5|8208),o=0);}for(;o--;)a(i);o=1,i=e[s];}return{c:r.subarray(0,n),n:t};},ut=function(e,t){for(var r=0,n=0;n<t.length;++n)r+=e[n]*t[n];return r;},dn=function(e,t,r){var n=r.length,i=or(t+2);e[i]=n&255,e[i+1]=n>>8,e[i+2]=e[i]^255,e[i+3]=e[i+1]^255;for(var o=0;o<n;++o)e[i+o+4]=r[o];return(i+4+n)*8;},an=function(e,t,r,n,i,o,a,s,h,f,l){Ye(t,l++,r),++i[256];for(var c=Zt(i,15),p=c.t,m=c.l,_=Zt(o,15),A=_.t,S=_.l,g=on(p),k=g.c,v=g.n,x=on(A),d=x.c,M=x.n,y=new Be(19),B=0;B<k.length;++B)++y[k[B]&31];for(var B=0;B<d.length;++B)++y[d[B]&31];for(var C=Zt(y,7),N=C.t,O=C.l,z=19;z>4&&!N[Jt[z-1]];--z);var Y=f+5<<3,J=ut(i,Ke)+ut(o,dt)+a,L=ut(i,p)+ut(o,A)+a+14+3*z+ut(y,N)+2*y[16]+3*y[17]+7*y[18];if(h>=0&&Y<=J&&Y<=L)return dn(t,l,e.subarray(h,h+f));var W,j,$,K;if(Ye(t,l,1+(L<J)),l+=2,L<J){W=ze(p,m,0),j=p,$=ze(A,S,0),K=A;var ye=ze(N,O,0);Ye(t,l,v-257),Ye(t,l+5,M-1),Ye(t,l+10,z-4),l+=14;for(var B=0;B<z;++B)Ye(t,l+3*B,N[Jt[B]]);l+=3*z;for(var ee=[k,d],te=0;te<2;++te)for(var Z=ee[te],B=0;B<Z.length;++B){var w=Z[B]&31;Ye(t,l,ye[w]),l+=N[w],w>15&&(Ye(t,l,Z[B]>>5&127),l+=Z[B]>>12);}}else W=Wi,j=Ke,$=Yi,K=dt;for(var B=0;B<s;++B){var D=n[B];if(D>255){var w=D>>18&31;ht(t,l,W[w+257]),l+=j[w+257],w>7&&(Ye(t,l,D>>23&31),l+=Ft[w]);var le=D&31;ht(t,l,$[le]),l+=K[le],le>3&&(ht(t,l,D>>5&8191),l+=kt[le]);}else ht(t,l,W[D]),l+=j[D];}return ht(t,l,W[256]),l+j[256];},qi=new ir([65540,131080,131088,131104,262176,1048704,1048832,2114560,2117632]),pn=new Ce(0),ji=function(e,t,r,n,i,o){var a=o.z||e.length,s=new Ce(n+a+5*(1+Math.ceil(a/7e3))+i),h=s.subarray(n,s.length-i),f=o.l,l=(o.r||0)&7;if(t){l&&(h[0]=o.r>>3);for(var c=qi[t-1],p=c>>13,m=c&8191,_=(1<<r)-1,A=o.p||new Be(32768),S=o.h||new Be(_+1),g=Math.ceil(r/3),k=2*g,v=function(ne){return(e[ne]^e[ne+1]<<g^e[ne+2]<<k)&_;},x=new ir(25e3),d=new Be(288),M=new Be(32),y=0,B=0,C=o.i||0,N=0,O=o.w||0,z=0;C+2<a;++C){var Y=v(C),J=C&32767,L=S[Y];if(A[J]=L,S[Y]=J,O<=C){var W=a-C;if((y>7e3||N>24576)&&(W>423||!f)){l=an(e,h,0,x,d,M,B,N,z,C-z,l),N=y=B=0,z=C;for(var j=0;j<286;++j)d[j]=0;for(var j=0;j<30;++j)M[j]=0;}var $=2,K=0,ye=m,ee=J-L&32767;if(W>2&&Y==v(C-ee))for(var te=Math.min(p,W)-1,Z=Math.min(32767,C),w=Math.min(258,W);ee<=Z&&--ye&&J!=L;){if(e[C+$]==e[C+$-ee]){for(var D=0;D<w&&e[C+D]==e[C+D-ee];++D);if(D>$){if($=D,K=ee,D>te)break;for(var le=Math.min(ee,D-2),ve=0,j=0;j<le;++j){var Q=C-ee+j&32767,se=A[Q],oe=Q-se&32767;oe>ve&&(ve=oe,L=Q);}}}J=L,L=A[J],ee+=J-L&32767;}if(K){x[N++]=268435456|er[$]<<18|nn[K];var G=er[$]&31,R=nn[K]&31;B+=Ft[G]+kt[R],++d[257+G],++M[R],O=C+$,++y;}else x[N++]=e[C],++d[e[C]];}}for(C=Math.max(C,O);C<a;++C)x[N++]=e[C],++d[e[C]];l=an(e,h,f,x,d,M,B,N,z,C-z,l),f||(o.r=l&7|h[l/8|0]<<3,l-=7,o.h=S,o.p=A,o.i=C,o.w=O);}else{for(var C=o.w||0;C<a+f;C+=65535){var fe=C+65535;fe>=a&&(h[l/8|0]=f,fe=a),l=dn(h,l+1,e.subarray(C,fe));}o.i=a;}return et(s,0,n+or(l)+i);};var vn=function(){var e=1,t=0;return{p:function(r){for(var n=e,i=t,o=r.length|0,a=0;a!=o;){for(var s=Math.min(a+2655,o);a<s;++a)i+=n+=r[a];n=(n&65535)+15*(n>>16),i=(i&65535)+15*(i>>16);}e=n,t=i;},d:function(){return e%=65521,t%=65521,(e&255)<<24|(e&65280)<<8|(t&255)<<8|t>>8;}};},Ki=function(e,t,r,n,i){if(!i&&(i={l:1},t.dictionary)){var o=t.dictionary.subarray(-32768),a=new Ce(o.length+e.length);a.set(o),a.set(e,o.length),e=a,i.w=o.length;}return ji(e,t.level==null?6:t.level,t.mem==null?i.l?Math.ceil(Math.max(8,Math.min(13,Math.log(e.length)))*1.5):20:12+t.mem,r,n,i);};var gn=function(e,t,r){for(;r;++t)e[t]=r,r>>>=8;};var Zi=function(e,t){var r=t.level,n=r==0?0:r<6?1:r==9?3:2;if(e[0]=120,e[1]=n<<6|(t.dictionary&&32),e[1]|=31-(e[0]<<8|e[1])%31,t.dictionary){var i=vn();i.p(t.dictionary),gn(e,2,i.d());}},xn=function(e,t){return((e[0]&15)!=8||e[0]>>4>7||(e[0]<<8|e[1])%31)&&Me(6,"invalid zlib data"),(e[1]>>5&1)==+!t&&Me(6,"invalid zlib data: "+(e[1]&32?"need":"unexpected")+" dictionary"),(e[1]>>3&4)+2;};var Qt=function(){function e(t,r){typeof t=="function"&&(r=t,t={}),this.ondata=r;var n=t&&t.dictionary&&t.dictionary.subarray(-32768);this.s={i:0,b:n?n.length:0},this.o=new Ce(32768),this.p=new Ce(0),n&&this.o.set(n);}return e.prototype.e=function(t){if(this.ondata||Me(5),this.d&&Me(4),!this.p.length)this.p=t;else if(t.length){var r=new Ce(this.p.length+t.length);r.set(this.p),r.set(t,this.p.length),this.p=r;}},e.prototype.c=function(t){this.s.i=+(this.d=t||!1);var r=this.s.b,n=un(this.p,this.s,this.o);this.ondata(et(n,r,this.s.b),this.d),this.o=et(n,this.s.b-32768),this.s.b=this.o.length,this.p=et(this.p,this.s.p/8|0),this.s.p&=7;},e.prototype.push=function(t,r){this.e(t),this.c(r);},e;}();function yn(e,t){t||(t={});var r=vn();r.p(e);var n=Ki(e,t,t.dictionary?6:2,4);return Zi(n,t),gn(n,n.length-4,r.d()),n;}var pt=function(){function e(t,r){Qt.call(this,t,r),this.v=t&&t.dictionary?2:1;}return e.prototype.push=function(t,r){if(Qt.prototype.e.call(this,t),this.v){if(this.p.length<6&&!r)return;this.p=this.p.subarray(xn(this.p,this.v-1)),this.v=0;}r&&(this.p.length<4&&Me(6,"invalid zlib data"),this.p=this.p.subarray(0,-4)),Qt.prototype.c.call(this,r);},e;}();function wn(e,t){return un(e.subarray(xn(e,t&&t.dictionary),-4),{i:2},t&&t.out,t&&t.dictionary);}var sn=typeof TextEncoder<"u"&&new TextEncoder(),nr=typeof TextDecoder<"u"&&new TextDecoder(),Qi=0;try{nr.decode(pn,{stream:!0}),Qi=1;}catch{}var Ji=function(e){for(var t="",r=0;;){var n=e[r++],i=(n>127)+(n>223)+(n>239);if(r+i>e.length)return{s:t,r:et(e,r-1)};i?i==3?(n=((n&15)<<18|(e[r++]&63)<<12|(e[r++]&63)<<6|e[r++]&63)-65536,t+=String.fromCharCode(55296|n>>10,56320|n&1023)):i&1?t+=String.fromCharCode((n&31)<<6|e[r++]&63):t+=String.fromCharCode((n&15)<<12|(e[r++]&63)<<6|e[r++]&63):t+=String.fromCharCode(n);}};function mn(e,t){if(t){for(var r=new Ce(e.length),n=0;n<e.length;++n)r[n]=e.charCodeAt(n);return r;}if(sn)return sn.encode(e);for(var i=e.length,o=new Ce(e.length+(e.length>>1)),a=0,s=function(l){o[a++]=l;},n=0;n<i;++n){if(a+5>o.length){var h=new Ce(a+8+(i-n<<1));h.set(o),o=h;}var f=e.charCodeAt(n);f<128||t?s(f):f<2048?(s(192|f>>6),s(128|f&63)):f>55295&&f<57344?(f=65536+(f&1047552)|e.charCodeAt(++n)&1023,s(240|f>>18),s(128|f>>12&63),s(128|f>>6&63),s(128|f&63)):(s(224|f>>12),s(128|f>>6&63),s(128|f&63));}return et(o,0,a);}function An(e,t){if(t){for(var r="",n=0;n<e.length;n+=16384)r+=String.fromCharCode.apply(null,e.subarray(n,n+16384));return r;}else{if(nr)return nr.decode(e);var i=Ji(e),o=i.s,r=i.r;return r.length&&Me(8),o;}}var Ut=class{encode(t=""){return mn(String(t));}},it=class{constructor(t="utf-8"){this.latin1=/^(latin1|iso-8859-1)$/i.test(t);}decode(t=new Uint8Array()){var r=new Uint8Array(t.buffer??t,t.byteOffset??0,t.byteLength);return An(r,this.latin1);}};function ar(e,t="utf8"){return new it(t).decode(e);}var eo=new Ut();function bn(e){return eo.encode(e);}var to=1024*8,ro=(()=>{var e=new Uint8Array(4),t=new Uint32Array(e.buffer);return!((t[0]=1)&e[0]);})(),sr={int8:globalThis.Int8Array,uint8:globalThis.Uint8Array,int16:globalThis.Int16Array,uint16:globalThis.Uint16Array,int32:globalThis.Int32Array,uint32:globalThis.Uint32Array,uint64:globalThis.BigUint64Array,int64:globalThis.BigInt64Array,float32:globalThis.Float32Array,float64:globalThis.Float64Array},tt=class e{constructor(t=to,r={}){we(this,"buffer");we(this,"byteLength");we(this,"byteOffset");we(this,"length");we(this,"offset");we(this,"lastWrittenByte");we(this,"littleEndian");we(this,"_data");we(this,"_mark");we(this,"_marks");var n=!1;typeof t=="number"?t=new ArrayBuffer(t):(n=!0,this.lastWrittenByte=t.byteLength);var i=r.offset?r.offset>>>0:0,o=t.byteLength-i,a=i;(ArrayBuffer.isView(t)||t instanceof e)&&(t.byteLength!==t.buffer.byteLength&&(a=t.byteOffset+i),t=t.buffer),n?this.lastWrittenByte=o:this.lastWrittenByte=0,this.buffer=t,this.length=o,this.byteLength=o,this.byteOffset=a,this.offset=0,this.littleEndian=!0,this._data=new DataView(this.buffer,a,o),this._mark=0,this._marks=[];}available(t=1){return this.offset+t<=this.length;}isLittleEndian(){return this.littleEndian;}setLittleEndian(){return this.littleEndian=!0,this;}isBigEndian(){return!this.littleEndian;}setBigEndian(){return this.littleEndian=!1,this;}skip(t=1){return this.offset+=t,this;}back(t=1){return this.offset-=t,this;}seek(t){return this.offset=t,this;}mark(){return this._mark=this.offset,this;}reset(){return this.offset=this._mark,this;}pushMark(){return this._marks.push(this.offset),this;}popMark(){var t=this._marks.pop();if(t===void 0)throw new Error("Mark stack empty");return this.seek(t),this;}rewind(){return this.offset=0,this;}ensureAvailable(t=1){if(!this.available(t)){var n=(this.offset+t)*2,i=new Uint8Array(n);i.set(new Uint8Array(this.buffer)),this.buffer=i.buffer,this.length=n,this.byteLength=n,this._data=new DataView(this.buffer);}return this;}readBoolean(){return this.readUint8()!==0;}readInt8(){return this._data.getInt8(this.offset++);}readUint8(){return this._data.getUint8(this.offset++);}readByte(){return this.readUint8();}readBytes(t=1){return this.readArray(t,"uint8");}readArray(t,r){var n=sr[r].BYTES_PER_ELEMENT*t,i=this.byteOffset+this.offset,o=this.buffer.slice(i,i+n);if(this.littleEndian===ro&&r!=="uint8"&&r!=="int8"){var s=new Uint8Array(this.buffer.slice(i,i+n));s.reverse();var h=new sr[r](s.buffer);return this.offset+=n,h.reverse(),h;}var a=new sr[r](o);return this.offset+=n,a;}readInt16(){var t=this._data.getInt16(this.offset,this.littleEndian);return this.offset+=2,t;}readUint16(){var t=this._data.getUint16(this.offset,this.littleEndian);return this.offset+=2,t;}readInt32(){var t=this._data.getInt32(this.offset,this.littleEndian);return this.offset+=4,t;}readUint32(){var t=this._data.getUint32(this.offset,this.littleEndian);return this.offset+=4,t;}readFloat32(){var t=this._data.getFloat32(this.offset,this.littleEndian);return this.offset+=4,t;}readFloat64(){var t=this._data.getFloat64(this.offset,this.littleEndian);return this.offset+=8,t;}readBigInt64(){var t=this._data.getBigInt64(this.offset,this.littleEndian);return this.offset+=8,t;}readBigUint64(){var t=this._data.getBigUint64(this.offset,this.littleEndian);return this.offset+=8,t;}readChar(){return String.fromCharCode(this.readInt8());}readChars(t=1){var r="";for(var n=0;n<t;n++)r+=this.readChar();return r;}readUtf8(t=1){return ar(this.readBytes(t));}decodeText(t=1,r="utf8"){return ar(this.readBytes(t),r);}writeBoolean(t){return this.writeUint8(t?255:0),this;}writeInt8(t){return this.ensureAvailable(1),this._data.setInt8(this.offset++,t),this._updateLastWrittenByte(),this;}writeUint8(t){return this.ensureAvailable(1),this._data.setUint8(this.offset++,t),this._updateLastWrittenByte(),this;}writeByte(t){return this.writeUint8(t);}writeBytes(t){this.ensureAvailable(t.length);for(var r=0;r<t.length;r++)this._data.setUint8(this.offset++,t[r]);return this._updateLastWrittenByte(),this;}writeInt16(t){return this.ensureAvailable(2),this._data.setInt16(this.offset,t,this.littleEndian),this.offset+=2,this._updateLastWrittenByte(),this;}writeUint16(t){return this.ensureAvailable(2),this._data.setUint16(this.offset,t,this.littleEndian),this.offset+=2,this._updateLastWrittenByte(),this;}writeInt32(t){return this.ensureAvailable(4),this._data.setInt32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeUint32(t){return this.ensureAvailable(4),this._data.setUint32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeFloat32(t){return this.ensureAvailable(4),this._data.setFloat32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeFloat64(t){return this.ensureAvailable(8),this._data.setFloat64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeBigInt64(t){return this.ensureAvailable(8),this._data.setBigInt64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeBigUint64(t){return this.ensureAvailable(8),this._data.setBigUint64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeChar(t){return this.writeUint8(t.charCodeAt(0));}writeChars(t){for(var r=0;r<t.length;r++)this.writeUint8(t.charCodeAt(r));return this;}writeUtf8(t){return this.writeBytes(bn(t));}toArray(){return new Uint8Array(this.buffer,this.byteOffset,this.lastWrittenByte);}getWrittenByteLength(){return this.lastWrittenByte-this.byteOffset;}_updateLastWrittenByte(){this.offset>this.lastWrittenByte&&(this.lastWrittenByte=this.offset);}};var _n=[];for(var e=0;e<256;e++){var t=e;for(var r=0;r<8;r++)t&1?t=3988292384^t>>>1:t=t>>>1;_n[e]=t;}var En=4294967295;function no(e,t,r){var n=e;for(var i=0;i<r;i++)n=_n[(n^t[i])&255]^n>>>8;return n;}function Sn(e,t){return(no(En,e,t)^En)>>>0;}function lr(e,t,r){var n=e.readUint32(),i=Sn(new Uint8Array(e.buffer,e.byteOffset+e.offset-t-4,t),t);if(i!==n)throw new Error(`CRC mismatch for chunk ${r}. Expected ${n}, found ${i}`);}function Ze(e,t){e.writeUint32(Sn(new Uint8Array(e.buffer,e.byteOffset+e.offset-t,t),t));}function Tt(e,t,r){for(var n=0;n<r;n++)t[n]=e[n];}function It(e,t,r,n){var i=0;for(;i<n;i++)t[i]=e[i];for(;i<r;i++)t[i]=e[i]+t[i-n]&255;}function Mt(e,t,r,n){var i=0;if(r.length===0)for(;i<n;i++)t[i]=e[i];else for(;i<n;i++)t[i]=e[i]+r[i]&255;}function Bt(e,t,r,n,i){var o=0;if(r.length===0){for(;o<i;o++)t[o]=e[o];for(;o<n;o++)t[o]=e[o]+(t[o-i]>>1)&255;}else{for(;o<i;o++)t[o]=e[o]+(r[o]>>1)&255;for(;o<n;o++)t[o]=e[o]+(t[o-i]+r[o]>>1)&255;}}function Rt(e,t,r,n,i){var o=0;if(r.length===0){for(;o<i;o++)t[o]=e[o];for(;o<n;o++)t[o]=e[o]+t[o-i]&255;}else{for(;o<i;o++)t[o]=e[o]+r[o]&255;for(;o<n;o++)t[o]=e[o]+io(t[o-i],r[o],r[o-i])&255;}}function io(e,t,r){var n=e+t-r,i=Math.abs(n-e),o=Math.abs(n-t),a=Math.abs(n-r);return i<=o&&i<=a?e:o<=a?t:r;}function Cn(e,t,r,n,i,o){switch(e){case 0:Tt(t,r,i);break;case 1:It(t,r,i,o);break;case 2:Mt(t,r,n,i);break;case 3:Bt(t,r,n,i,o);break;case 4:Rt(t,r,n,i,o);break;default:throw new Error(`Unsupported filter: ${e}`);}}var oo=new Uint16Array([255]),ao=new Uint8Array(oo.buffer),so=ao[0]===255;function Fn(e){var{data:t,width:r,height:n,channels:i,depth:o}=e,a=[{x:0,y:0,xStep:8,yStep:8},{x:4,y:0,xStep:8,yStep:8},{x:0,y:4,xStep:4,yStep:8},{x:2,y:0,xStep:4,yStep:4},{x:0,y:2,xStep:2,yStep:4},{x:1,y:0,xStep:2,yStep:2},{x:0,y:1,xStep:1,yStep:2}],s=Math.ceil(o/8)*i,h=new Uint8Array(n*r*s),f=0;for(var l=0;l<7;l++){var c=a[l],p=Math.ceil((r-c.x)/c.xStep),m=Math.ceil((n-c.y)/c.yStep);if(p<=0||m<=0)continue;var _=p*s,A=new Uint8Array(_);for(var S=0;S<m;S++){var g=t[f++],k=t.subarray(f,f+_);f+=_;var v=new Uint8Array(_);Cn(g,k,v,A,_,s),A.set(v);for(var x=0;x<p;x++){var d=c.x+x*c.xStep,M=c.y+S*c.yStep;if(!(d>=r||M>=n))for(var y=0;y<s;y++)h[(M*r+d)*s+y]=v[x*s+y];}}}if(o===16){var _l5=new Uint16Array(h.buffer);if(so)for(var _c4=0;_c4<_l5.length;_c4++)_l5[_c4]=lo(_l5[_c4]);return _l5;}else return h;}function lo(e){return(e&255)<<8|e>>8&255;}var fo=new Uint16Array([255]),co=new Uint8Array(fo.buffer),ho=co[0]===255,uo=new Uint8Array(0);function fr(e){var{data:t,width:r,height:n,channels:i,depth:o}=e,a=Math.ceil(o/8)*i,s=Math.ceil(o/8*i*r),h=new Uint8Array(n*s),f=uo,l=0,c,p;for(var m=0;m<n;m++){switch(c=t.subarray(l+1,l+1+s),p=h.subarray(m*s,(m+1)*s),t[l]){case 0:Tt(c,p,s);break;case 1:It(c,p,s,a);break;case 2:Mt(c,p,f,s);break;case 3:Bt(c,p,f,s,a);break;case 4:Rt(c,p,f,s,a);break;default:throw new Error(`Unsupported filter: ${t[l]}`);}f=p,l+=s+1;}if(o===16){var _m2=new Uint16Array(h.buffer);if(ho)for(var _=0;_<_m2.length;_++)_m2[_]=po(_m2[_]);return _m2;}else return h;}function po(e){return(e&255)<<8|e>>8&255;}var vt=Uint8Array.of(137,80,78,71,13,10,26,10);function kn(e){e.writeBytes(vt);}function cr(e){if(!Un(e.readBytes(vt.length)))throw new Error("wrong PNG signature");}function Un(e){if(e.length<vt.length)return!1;for(var _t2=0;_t2<vt.length;_t2++)if(e[_t2]!==vt[_t2])return!1;return!0;}var hr="tEXt",Tn=0,In=new it("latin1");function Mn(e){if(Bn(e),e.length===0||e.length>79)throw new Error("keyword length must be between 1 and 79");}var vo=/^[\u0000-\u00FF]*$/;function Bn(e){if(!vo.test(e))throw new Error("invalid latin1 text");}function Rn(e,t,r){var n=ur(t);e[n]=go(t,r-n.length-1);}function Dn(e,t,r){Mn(t),Bn(r);var n=t.length+1+r.length;e.writeUint32(n),e.writeChars(hr),e.writeChars(t),e.writeByte(Tn),e.writeChars(r),Ze(e,n+4);}function ur(e){for(e.mark();e.readByte()!==Tn;);var t=e.offset;e.reset();var r=In.decode(e.readBytes(t-e.offset-1));return e.skip(1),Mn(r),r;}function go(e,t){return In.decode(e.readBytes(t));}var Fe={UNKNOWN:-1,GREYSCALE:0,TRUECOLOUR:2,INDEXED_COLOUR:3,GREYSCALE_ALPHA:4,TRUECOLOUR_ALPHA:6},ot={UNKNOWN:-1,DEFLATE:0},gt={UNKNOWN:-1,ADAPTIVE:0},Ge={UNKNOWN:-1,NO_INTERLACE:0,ADAM7:1},xt={NONE:0,BACKGROUND:1,PREVIOUS:2},Dt={SOURCE:0,OVER:1};var yt=class extends tt{constructor(r,n={}){super(r);we(this,"_checkCrc");we(this,"_inflator");we(this,"_png");we(this,"_apng");we(this,"_end");we(this,"_hasPalette");we(this,"_palette");we(this,"_hasTransparency");we(this,"_transparency");we(this,"_compressionMethod");we(this,"_filterMethod");we(this,"_interlaceMethod");we(this,"_colorType");we(this,"_isAnimated");we(this,"_numberOfFrames");we(this,"_numberOfPlays");we(this,"_frames");we(this,"_writingDataChunks");we(this,"_chunks");we(this,"_inflatorResult");var{checkCrc:i=!1}=n;this._checkCrc=i,this._inflator=new pt((o,a)=>{if(this._chunks.push(o),a){var s=this._chunks.reduce((f,l)=>f+l.length,0);this._inflatorResult=new Uint8Array(s);var h=0;for(var f of this._chunks)this._inflatorResult.set(f,h),h+=f.length;this._chunks=[];}}),this._chunks=[],this._png={width:-1,height:-1,channels:-1,data:new Uint8Array(0),depth:1,text:{}},this._apng={width:-1,height:-1,channels:-1,depth:1,numberOfFrames:1,numberOfPlays:0,text:{},frames:[]},this._end=!1,this._hasPalette=!1,this._palette=[],this._hasTransparency=!1,this._transparency=new Uint16Array(0),this._compressionMethod=ot.UNKNOWN,this._filterMethod=gt.UNKNOWN,this._interlaceMethod=Ge.UNKNOWN,this._colorType=Fe.UNKNOWN,this._isAnimated=!1,this._numberOfFrames=1,this._numberOfPlays=0,this._frames=[],this._writingDataChunks=!1,this._inflatorResult=new Uint8Array(0),this.setBigEndian();}decode(){for(cr(this);!this._end;){var _r2=this.readUint32(),n=this.readChars(4);this.decodeChunk(_r2,n);}return this._inflator.push(new Uint8Array(0),!0),this.decodeImage(),this._png;}decodeApng(){for(cr(this);!this._end;){var _r3=this.readUint32(),n=this.readChars(4);this.decodeApngChunk(_r3,n);}return this.decodeApngImage(),this._apng;}decodeChunk(r,n){var i=this.offset;switch(n){case"IHDR":this.decodeIHDR();break;case"PLTE":this.decodePLTE(r);break;case"IDAT":this.decodeIDAT(r);break;case"IEND":this._end=!0;break;case"tRNS":this.decodetRNS(r);break;case"iCCP":this.decodeiCCP(r);break;case hr:Rn(this._png.text,this,r);break;case"pHYs":this.decodepHYs();break;default:this.skip(r);break;}if(this.offset-i!==r)throw new Error(`Length mismatch while decoding chunk ${n}`);this._checkCrc?lr(this,r+4,n):this.skip(4);}decodeApngChunk(r,n){var i=this.offset;switch(n!=="fdAT"&&n!=="IDAT"&&this._writingDataChunks&&this.pushDataToFrame(),n){case"acTL":this.decodeACTL();break;case"fcTL":this.decodeFCTL();break;case"fdAT":this.decodeFDAT(r);break;default:this.decodeChunk(r,n),this.offset=i+r;break;}if(this.offset-i!==r)throw new Error(`Length mismatch while decoding chunk ${n}`);this._checkCrc?lr(this,r+4,n):this.skip(4);}decodeIHDR(){var r=this._png;r.width=this.readUint32(),r.height=this.readUint32(),r.depth=xo(this.readUint8());var n=this.readUint8();this._colorType=n;var i;switch(n){case Fe.GREYSCALE:i=1;break;case Fe.TRUECOLOUR:i=3;break;case Fe.INDEXED_COLOUR:i=1;break;case Fe.GREYSCALE_ALPHA:i=2;break;case Fe.TRUECOLOUR_ALPHA:i=4;break;case Fe.UNKNOWN:default:throw new Error(`Unknown color type: ${n}`);}if(this._png.channels=i,this._compressionMethod=this.readUint8(),this._compressionMethod!==ot.DEFLATE)throw new Error(`Unsupported compression method: ${this._compressionMethod}`);this._filterMethod=this.readUint8(),this._interlaceMethod=this.readUint8();}decodeACTL(){this._numberOfFrames=this.readUint32(),this._numberOfPlays=this.readUint32(),this._isAnimated=!0;}decodeFCTL(){var r={sequenceNumber:this.readUint32(),width:this.readUint32(),height:this.readUint32(),xOffset:this.readUint32(),yOffset:this.readUint32(),delayNumber:this.readUint16(),delayDenominator:this.readUint16(),disposeOp:this.readUint8(),blendOp:this.readUint8(),data:new Uint8Array(0)};this._frames.push(r);}decodePLTE(r){if(r%3!==0)throw new RangeError(`PLTE field length must be a multiple of 3. Got ${r}`);var n=r/3;this._hasPalette=!0;var i=[];this._palette=i;for(var o=0;o<n;o++)i.push([this.readUint8(),this.readUint8(),this.readUint8()]);}decodeIDAT(r){this._writingDataChunks=!0;var n=r,i=this.offset+this.byteOffset;try{this._inflator.push(new Uint8Array(this.buffer,i,n),!1);}catch(o){throw new Error("Error while decompressing the data:",{cause:o});}this.skip(r);}decodeFDAT(r){this._writingDataChunks=!0;var n=r,i=this.offset+this.byteOffset;i+=4,n-=4;try{this._inflator.push(new Uint8Array(this.buffer,i,n),!1);}catch(o){throw new Error("Error while decompressing the data:",{cause:o});}this.skip(r);}decodetRNS(r){switch(this._colorType){case Fe.GREYSCALE:case Fe.TRUECOLOUR:{if(r%2!==0)throw new RangeError(`tRNS chunk length must be a multiple of 2. Got ${r}`);if(r/2>this._png.width*this._png.height)throw new Error(`tRNS chunk contains more alpha values than there are pixels (${r/2} vs ${this._png.width*this._png.height})`);this._hasTransparency=!0,this._transparency=new Uint16Array(r/2);for(var n=0;n<r/2;n++)this._transparency[n]=this.readUint16();break;}case Fe.INDEXED_COLOUR:{if(r>this._palette.length)throw new Error(`tRNS chunk contains more alpha values than there are palette colors (${r} vs ${this._palette.length})`);var _n2=0;for(;_n2<r;_n2++){var i=this.readByte();this._palette[_n2].push(i);}for(;_n2<this._palette.length;_n2++)this._palette[_n2].push(255);break;}case Fe.UNKNOWN:case Fe.GREYSCALE_ALPHA:case Fe.TRUECOLOUR_ALPHA:default:throw new Error(`tRNS chunk is not supported for color type ${this._colorType}`);}}decodeiCCP(r){var n=ur(this),i=this.readUint8();if(i!==ot.DEFLATE)throw new Error(`Unsupported iCCP compression method: ${i}`);var o=this.readBytes(r-n.length-2);this._png.iccEmbeddedProfile={name:n,profile:wn(o)};}decodepHYs(){var r=this.readUint32(),n=this.readUint32(),i=this.readByte();this._png.resolution={x:r,y:n,unit:i};}decodeApngImage(){this._apng.width=this._png.width,this._apng.height=this._png.height,this._apng.channels=this._png.channels,this._apng.depth=this._png.depth,this._apng.numberOfFrames=this._numberOfFrames,this._apng.numberOfPlays=this._numberOfPlays,this._apng.text=this._png.text,this._apng.resolution=this._png.resolution;for(var _r4=0;_r4<this._numberOfFrames;_r4++){var n={sequenceNumber:this._frames[_r4].sequenceNumber,delayNumber:this._frames[_r4].delayNumber,delayDenominator:this._frames[_r4].delayDenominator,data:this._apng.depth===8?new Uint8Array(this._apng.width*this._apng.height*this._apng.channels):new Uint16Array(this._apng.width*this._apng.height*this._apng.channels)},i=this._frames.at(_r4);if(i){if(i.data=fr({data:i.data,width:i.width,height:i.height,channels:this._apng.channels,depth:this._apng.depth}),this._hasPalette&&(this._apng.palette=this._palette),this._hasTransparency&&(this._apng.transparency=this._transparency),_r4===0||i.xOffset===0&&i.yOffset===0&&i.width===this._png.width&&i.height===this._png.height)n.data=i.data;else{var o=this._apng.frames.at(_r4-1);this.disposeFrame(i,o,n),this.addFrameDataToCanvas(n,i);}this._apng.frames.push(n);}}return this._apng;}disposeFrame(r,n,i){switch(r.disposeOp){case xt.NONE:break;case xt.BACKGROUND:for(var o=0;o<this._png.height;o++)for(var a=0;a<this._png.width;a++){var s=(o*r.width+a)*this._png.channels;for(var h=0;h<this._png.channels;h++)i.data[s+h]=0;}break;case xt.PREVIOUS:i.data.set(n.data);break;default:throw new Error("Unknown disposeOp");}}addFrameDataToCanvas(r,n){var i=1<<this._png.depth,o=(a,s)=>{var h=((a+n.yOffset)*this._png.width+n.xOffset+s)*this._png.channels,f=(a*n.width+s)*this._png.channels;return{index:h,frameIndex:f};};switch(n.blendOp){case Dt.SOURCE:for(var a=0;a<n.height;a++)for(var s=0;s<n.width;s++){var{index:h,frameIndex:f}=o(a,s);for(var l=0;l<this._png.channels;l++)r.data[h+l]=n.data[f+l];}break;case Dt.OVER:for(var _a3=0;_a3<n.height;_a3++)for(var _s5=0;_s5<n.width;_s5++){var{index:_h3,frameIndex:_f4}=o(_a3,_s5);for(var _l6=0;_l6<this._png.channels;_l6++){var c=n.data[_f4+this._png.channels-1]/i,p=_l6%(this._png.channels-1)===0?1:n.data[_f4+_l6],m=Math.floor(c*p+(1-c)*r.data[_h3+_l6]);r.data[_h3+_l6]+=m;}}break;default:throw new Error("Unknown blendOp");}}decodeImage(){var r=this._inflatorResult;if(this._filterMethod!==gt.ADAPTIVE)throw new Error(`Filter method ${this._filterMethod} not supported`);if(this._interlaceMethod===Ge.NO_INTERLACE)this._png.data=fr({data:r,width:this._png.width,height:this._png.height,channels:this._png.channels,depth:this._png.depth});else if(this._interlaceMethod===Ge.ADAM7)this._png.data=Fn({data:r,width:this._png.width,height:this._png.height,channels:this._png.channels,depth:this._png.depth});else throw new Error(`Interlace method ${this._interlaceMethod} not supported`);this._hasPalette&&(this._png.palette=this._palette),this._hasTransparency&&(this._png.transparency=this._transparency);}pushDataToFrame(){this._inflator.push(new Uint8Array(0),!0);var r=this._inflatorResult,n=this._frames.at(-1);n?n.data=r:this._frames.push({sequenceNumber:0,width:this._png.width,height:this._png.height,xOffset:0,yOffset:0,delayNumber:0,delayDenominator:0,disposeOp:xt.NONE,blendOp:Dt.SOURCE,data:r}),this._inflator=new pt((i,o)=>{if(this._chunks.push(i),o){var a=this._chunks.reduce((h,f)=>h+f.length,0);this._inflatorResult=new Uint8Array(a);var s=0;for(var h of this._chunks)this._inflatorResult.set(h,s),s+=h.length;this._chunks=[];}}),this._chunks=[],this._writingDataChunks=!1;}};function xo(e){if(e!==1&&e!==2&&e!==4&&e!==8&&e!==16)throw new Error(`invalid bit depth: ${e}`);return e;}var yo={level:3},wt=class extends tt{constructor(r,n={}){super();we(this,"_png");we(this,"_zlibOptions");we(this,"_colorType");we(this,"_interlaceMethod");this._colorType=Fe.UNKNOWN,this._zlibOptions={...yo,...n.zlib},this._png=this._checkData(r),this._interlaceMethod=(n.interlace==="Adam7"?Ge.ADAM7:Ge.NO_INTERLACE)??Ge.NO_INTERLACE,this.setBigEndian();}encode(){if(kn(this),this.encodeIHDR(),this._png.palette&&(this.encodePLTE(),this._png.palette[0].length===4&&this.encodeTRNS()),this.encodeData(),this._png.text)for(var[_r5,n]of Object.entries(this._png.text))Dn(this,_r5,n);return this.encodeIEND(),this.toArray();}encodeIHDR(){this.writeUint32(13),this.writeChars("IHDR"),this.writeUint32(this._png.width),this.writeUint32(this._png.height),this.writeByte(this._png.depth),this.writeByte(this._colorType),this.writeByte(ot.DEFLATE),this.writeByte(gt.ADAPTIVE),this.writeByte(this._interlaceMethod),Ze(this,17);}encodeIEND(){this.writeUint32(0),this.writeChars("IEND"),Ze(this,4);}encodePLTE(){var r=this._png.palette?.length*3;this.writeUint32(r),this.writeChars("PLTE");for(var n of this._png.palette)this.writeByte(n[0]),this.writeByte(n[1]),this.writeByte(n[2]);Ze(this,4+r);}encodeTRNS(){var r=this._png.palette.filter(n=>n.at(-1)!==255);this.writeUint32(r.length),this.writeChars("tRNS");for(var n of r)this.writeByte(n.at(-1));Ze(this,4+r.length);}encodeIDAT(r){this.writeUint32(r.length),this.writeChars("IDAT"),this.writeBytes(r),Ze(this,r.length+4);}encodeData(){var{width:r,height:n,channels:i,depth:o,data:a}=this._png,s=o<=8?Math.ceil(r*o/8)*i:Math.ceil(r*o/8*i/2),h=new tt().setBigEndian(),f=0;if(this._interlaceMethod===Ge.NO_INTERLACE)for(var p=0;p<n;p++)h.writeByte(0),o===16?f=bo(a,h,s,f):f=mo(a,h,s,f);else this._interlaceMethod===Ge.ADAM7&&(f=Ao(this._png,a,h,f));var l=h.toArray(),c=yn(l,this._zlibOptions);this.encodeIDAT(c);}_checkData(r){var{colorType:n,channels:i,depth:o}=wo(r,r.palette),a={width:On(r.width,"width"),height:On(r.height,"height"),channels:i,data:r.data,depth:o,text:r.text,palette:r.palette};this._colorType=n;var s=o<8?Math.ceil(a.width*o/8)*a.height*i:a.width*a.height*i;if(a.data.length!==s)throw new RangeError(`wrong data size. Found ${a.data.length}, expected ${s}`);return a;}};function On(e,t){if(Number.isInteger(e)&&e>0)return e;throw new TypeError(`${t} must be a positive integer`);}function wo(e,t){var{channels:r=4,depth:n=8}=e;if(r!==4&&r!==3&&r!==2&&r!==1)throw new RangeError(`unsupported number of channels: ${r}`);var i={channels:r,depth:n,colorType:Fe.UNKNOWN};switch(r){case 4:i.colorType=Fe.TRUECOLOUR_ALPHA;break;case 3:i.colorType=Fe.TRUECOLOUR;break;case 1:t?i.colorType=Fe.INDEXED_COLOUR:i.colorType=Fe.GREYSCALE;break;case 2:i.colorType=Fe.GREYSCALE_ALPHA;break;default:throw new Error("unsupported number of channels");}return i;}function mo(e,t,r,n){for(var i=0;i<r;i++)t.writeByte(e[n++]);return n;}function Ao(e,t,r,n){var i=[{x:0,y:0,xStep:8,yStep:8},{x:4,y:0,xStep:8,yStep:8},{x:0,y:4,xStep:4,yStep:8},{x:2,y:0,xStep:4,yStep:4},{x:0,y:2,xStep:2,yStep:4},{x:1,y:0,xStep:2,yStep:2},{x:0,y:1,xStep:1,yStep:2}],{width:o,height:a,channels:s,depth:h}=e,f;h===16?f=s*h/8/2:f=s*h/8;for(var l=0;l<7;l++){var c=i[l],p=Math.floor((o-c.x+c.xStep-1)/c.xStep),m=Math.floor((a-c.y+c.yStep-1)/c.yStep);if(p<=0||m<=0)continue;var _=p*f;for(var A=0;A<m;A++){var S=c.y+A*c.yStep,g=h<=8?new Uint8Array(_):new Uint16Array(_),k=0;for(var v=0;v<p;v++){var x=c.x+v*c.xStep;if(x<o&&S<a){var d=(S*o+x)*f;for(var M=0;M<f;M++)g[k++]=t[d+M];}}if(r.writeByte(0),h===8)r.writeBytes(g);else if(h===16)for(var _v of g)r.writeByte(_v>>8&255),r.writeByte(_v&255);}}return n;}function bo(e,t,r,n){for(var i=0;i<r;i++)t.writeUint16(e[n++]);return n;}function Ln(e,t){return new yt(e,t).decode();}function Pn(e,t){return new wt(e,t).encode();}var Vn=lt(Yn(),1);var Pt=lt(Xt(),1),Ve=320,Co=16e6,Xn=[137,80,78,71,13,10,26,10],vr=(e,t)=>e[t]*16777216+e[t+1]*65536+e[t+2]*256+e[t+3],Xe=()=>new Error("This image could not be decoded. Reopen the original image and try again.");function qn(e,t){if(!Number.isInteger(e)||!Number.isInteger(t)||e<1||t<1)throw Xe();if(e>16384||t>16384||e*t>Co)throw new Error("This image is too large to prepare locally. Choose an image under 16 megapixels.");}function Fo(e,t){if(e.length<33||Xn.some((g,k)=>e[k]!==g))throw Xe();var r=vr(e,16),n=vr(e,20),i=e[24],o=e[25],a=e[28];qn(r,n);var s={0:1,2:3,3:1,4:2,6:4}[o];if(!s||![1,2,4,8,16].includes(i)||a>1)throw Xe();var h=a?[[0,0,8,8],[4,0,8,8],[0,4,4,8],[2,0,4,4],[0,2,2,4],[1,0,2,2],[0,1,1,2]]:[[0,0,1,1]],f=0;for(var[g,k,v,x]of h){var d=Math.max(0,Math.ceil((r-g)/v)),M=Math.max(0,Math.ceil((n-k)/x));d&&M&&(f+=(Math.ceil(d*s*i/8)+1)*M);}var l=[e.subarray(0,8)],c=[],p=!1;for(var _g=8;_g+12<=e.length;){t();var _k2=vr(e,_g),_v2=_g+_k2+12;if(_v2>e.length)throw Xe();var _x2=String.fromCharCode(...e.subarray(_g+4,_g+8));if(_g===8&&(_x2!=="IHDR"||_k2!==13))throw Xe();if(_x2==="acTL")throw Object.assign(new Error("Use the original 320\xD7320 APNG or an animated GIF to keep this animation."),{code:"ANIMATED_PNG"});if(["IHDR","PLTE","tRNS","IDAT","IEND"].includes(_x2)&&l.push(e.subarray(_g,_v2)),_x2==="IDAT"&&c.push(e.subarray(_g+8,_g+8+_k2)),_g=_v2,_x2==="IEND"){p=!0;break;}}if(!p||!c.length)throw Xe();var m=0,_=new pt(g=>{if(m+=g.length,m>f)throw Xe();});for(var _g2 of c)for(var _k3=0;_k3<_g2.length;_k3+=1024)t(),_.push(_g2.subarray(_k3,_k3+1024),!1);if(_.push(new Uint8Array(0),!0),m!==f)throw Xe();var A=new Uint8Array(l.reduce((g,k)=>g+k.length,0)),S=0;for(var _g3 of l)A.set(_g3,S),S+=_g3.length;return A;}function ko(e){if(!e)return 1;try{var _t3=-1;for(var a=0;a<Math.min(12,e.length-8);a++)if(e[a]===73&&e[a+1]===73||e[a]===77&&e[a+1]===77){_t3=a;break;}if(_t3<0)return 1;var _r6=new DataView(e.buffer,e.byteOffset+_t3,e.byteLength-_t3),n=e[_t3]===73,i=_r6.getUint32(4,n),o=Math.min(_r6.getUint16(i,n),256);for(var _a4=0;_a4<o;_a4++){var s=i+2+_a4*12;if(_r6.getUint16(s,n)===274){var h=_r6.getUint16(s+8,n);return h>=1&&h<=8?h:1;}}}catch{}return 1;}function Lt(e,t,r,n){var{width:i,height:o,data:a,channels:s=4,depth:h=8,palette:f,transparency:l,orientation:c=1}=e,p=t,m=r;c===2&&(p=i-1-t),c===3&&(p=i-1-t,m=o-1-r),c===4&&(m=o-1-r),c===5&&(p=r,m=t),c===6&&(p=r,m=o-1-t),c===7&&(p=i-1-r,m=o-1-t),c===8&&(p=i-1-r,m=t);var _=m*i+p;if(f||h<8){var g=p*h,k=Math.ceil(i*h/8),v=h===8?a[_]:a[m*k+(g>>3)]>>8-h-(g&7)&(1<<h)-1;if(f){var x=f[v];if(!x)throw Xe();n[0]=x[0],n[1]=x[1],n[2]=x[2],n[3]=x[3]??255;}else n[0]=n[1]=n[2]=v*255/((1<<h)-1),n[3]=l?.[0]===v?0:255;return;}var A=_*s,S=h===16?1/257:1;n[0]=a[A]*S,s<=2?(n[1]=n[2]=n[0],n[3]=s===2?a[A+1]*S:l?.[0]===a[A]?0:255):(n[1]=a[A+1]*S,n[2]=a[A+2]*S,n[3]=s===4?a[A+3]*S:l?.length===3&&l[0]===a[A]&&l[1]===a[A+1]&&l[2]===a[A+2]?0:255);}function gr(e,t=()=>{}){t();var r=(0,Pt.toByteArray)(e.replace(/\s/g,"")),n;if(Xn.every((A,S)=>r[S]===A))n=Ln(Fo(r,t),{checkCrc:!0});else if(r[0]===255&&r[1]===216)n=Vn.default.decode(r,{useTArray:!0,formatAsRGBA:!0,tolerantDecoding:!1,maxResolutionInMP:16,maxMemoryUsageInMB:128}),n={...n,channels:4,depth:8,orientation:ko(n.exifBuffer)};else throw Object.assign(new Error("This image format needs conversion to PNG."),{code:"STATIC_FORMAT_UNSUPPORTED"});t(),qn(n.width,n.height);var i=n.orientation>=5,o=i?n.height:n.width,a=i?n.width:n.height,s=Math.min(Ve/o,Ve/a),h=Math.max(1,Math.round(o*s)),f=Math.max(1,Math.round(a*s)),l=Math.floor((Ve-h)/2),c=Math.floor((Ve-f)/2),p=new Uint8Array(Ve*Ve*4),m=Array.from({length:4},()=>new Float64Array(4));for(var A=0;A<f;A++){A%16===0&&t();var S=Math.max(0,Math.min(a-1,(A+.5)*a/f-.5)),g=Math.floor(S),k=Math.min(a-1,g+1),v=S-g;for(var x=0;x<h;x++){var d=Math.max(0,Math.min(o-1,(x+.5)*o/h-.5)),M=Math.floor(d),y=Math.min(o-1,M+1),B=d-M;Lt(n,M,g,m[0]),Lt(n,y,g,m[1]),Lt(n,M,k,m[2]),Lt(n,y,k,m[3]);var C=[(1-B)*(1-v),B*(1-v),(1-B)*v,B*v],N=((A+c)*Ve+x+l)*4,O=0;for(var z=0;z<4;z++)O+=m[z][3]*C[z];if(p[N+3]=Math.round(O),O)for(var _z=0;_z<3;_z++){var Y=0;for(var J=0;J<4;J++)Y+=m[J][_z]*m[J][3]*C[J];p[N+_z]=Math.round(Y/O);}}}t();var _=Pn({width:Ve,height:Ve,data:p,channels:4,depth:8});if(_.length>512*1024)throw new Error("The prepared sticker is over 512 KiB.");return t(),{base64:(0,Pt.fromByteArray)(_),mimeType:"image/png"};}var Uo=(()=>{"use strict";var e=typeof vendetta<"u"?vendetta:globalThis.vendetta;if(!e?.metro||!e?.patcher)throw new Error("SaveAsSticker needs Revenge's Vendetta plugin support.");var{React:t,ReactNative:r,constants:n}=e.metro.common,i=t.createElement,o=tn(e),a=rn(e,"SaveAsStickerPicker"),s="SaveAsStickerPicker",h="save-as-sticker-action",f=512*1024,l=25*1024*1024,c=[5,15,30,60],p=[],m=!1,_=0,A=!1,S=(...b)=>{try{return e.metro.findByProps(...b);}catch{return;}},g=b=>{try{return e.metro.findByStoreName(b);}catch{return;}},k=(...b)=>{for(var q of b)try{var u=e.ui.assets.getAssetIDByName(q);if(u!=null)return u;}catch{}},v=(...b)=>e.logger?.error?.("[SaveAsSticker]",...b),x=b=>{try{e.ui.toasts.showToast(b,k("StickerIcon","ic_sticker_24px"));}catch{console.log("[SaveAsSticker]",b);}},d=S("openLazy","hideActionSheet"),M=S("ActionSheetRow")?.ActionSheetRow,y=e.ui.components?.Forms??{},B=S("ActionSheetTitleHeader")?.ActionSheetTitleHeader??S("BottomSheetTitleHeader")?.BottomSheetTitleHeader,C=S("ActionSheetCloseButton")?.ActionSheetCloseButton,N=S("GuildIconSizes"),O=N?.default,z=N?.GuildIconSizes,Y=S("BottomSheetFlatList")?.BottomSheetFlatList??S("BottomSheetScrollView")?.BottomSheetFlatList??r.FlatList,J=S("ActionSheet")?.ActionSheet;if(!J)try{J=e.metro.find(b=>b?.render?.name==="ActionSheet");}catch{}function L(b){var q=String(b||"sticker").replace(/\.[a-z0-9]{1,6}$/i,"").replace(/[\u0000-\u001f]/g,"").trim().slice(0,30);return q.length>=2?q:"sticker";}function W(b,q=!1){if(!b)return null;var u=String(b.content_type??b.contentType??b.mimeType??""),F=b.mediaType??b.type,I=[b.url,b.sourceURI,b.mediaUrl,b.uri,b.proxy_url,b.proxyURL,b.image?.url,b.thumbnail?.url,b.video?.url].find(ie=>typeof ie=="string"&&/\.gif(?:[?#]|$)/i.test(ie)),H=u==="image/gif"||!!I;if(!H&&(/^(video|audio)\//i.test(u)||/^(video|audio|file)$/i.test(String(F))))return null;var P=I??b.mediaUrl??b.sourceURI??b.url??b.uri??b.proxy_url??b.proxyURL;if(I&&(P=P.replace(/([?&])format=(?:webp|png|jpe?g|mp4)(?=&|$)/gi,"$1").replace(/([?&])animated=false(?=&|$)/gi,"$1").replace(/\?&/,"?").replace(/&&+/g,"&").replace(/[?&]$/,"")),typeof P!="string"||!/^https:\/\//i.test(P))return null;var X=b.filename??b.name??P.split(/[?#]/)[0].split("/").pop()??"sticker";return!q&&F!=="image"&&!u.startsWith("image/")&&!/\.(png|apng|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i.test(X)&&!/\.(png|apng|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i.test(P)?null:{url:P,proxyURL:b.proxy_url??b.proxyURL,filename:X,contentType:H?"image/gif":u,id:b.id??b.attachmentId};}function j(...b){var q=b.flatMap(F=>{if(!F||typeof F!="object")return[];var T=F.analyticsLocation;return T&&typeof T=="object"?[F,T]:[F];});for(var F of q)if(F.selectedMedia){var T=F.selectedMedia,I=W({...T.source,...T},T.mediaType==="image");return I?[I]:[];}for(var _F of q){var _T=_F.source;if(_F.syncer?.sources){var _I=_F.syncer.index?.value??_F.syncer.index??0;_T=_F.syncer.sources[_I];}if(Array.isArray(_T)&&(_T=_T[0]),_T){var _I2=W(_T);return _I2?[_I2]:[];}}var u=[];for(var _F2 of q){for(var _T2 of _F2.message?.attachments??[]){var _I3=W(_T2);_I3&&u.push(_I3);}for(var _T3 of _F2.message?.embeds??[])for(var _I4 of[_T3.image,...(_T3.images??[]),_T3.type==="image"?_T3:null,_T3.type==="gifv"&&/\.gif(?:[?#]|$)/i.test(_T3.video?.url??"")?{..._T3.video,contentType:"image/gif"}:null,_T3.type==="gifv"&&/\.gif(?:[?#]|$)/i.test(_T3.thumbnail?.url??"")?_T3.thumbnail:null]){var H=W(_I4,!0);H&&u.push(H);}}return u.filter((F,T)=>u.findIndex(I=>I.url===F.url)===T);}function $(b){if(!b?.id||b.unavailable)return!1;var q=g("UserStore")?.getCurrentUser?.()?.id;if(q&&(b.ownerId===q||b.owner_id===q))return!0;var u=n?.Permissions?.CREATE_GUILD_EXPRESSIONS??1n<<43n;try{return!!g("PermissionStore")?.can?.(u,b);}catch{return!1;}}function K(b){var q=Number(b.premiumTier??b.premium_tier??0),u=b.features,F=Array.isArray(u)?u.includes("MORE_STICKERS"):u?.has?.("MORE_STICKERS"),T=Number(b.premiumFeatures?.additionalStickerSlots??b.premium_features?.additional_sticker_slots??0),I=F&&q===3?120:c[q]??c[0],H=Number(b.maxStickers??b.max_stickers??0),P=Math.max(I+(Number.isFinite(T)?Math.max(0,T):0),H||0),ie=(g("GuildStickersStore")??g("StickersStore")??g("StickerStore"))?.getStickersByGuildId?.(b.id)??b.stickers;return ie&&!Array.isArray(ie)&&(ie=Object.values(ie)),{max:P,used:Array.isArray(ie)?ie.length:null};}function ye(){return Object.values(g("GuildStore")?.getGuilds?.()??{}).filter($).sort((b,q)=>String(b.name).localeCompare(String(q.name)));}function ee(b){var q=Number(b?.body?.code??b?.code);if(q===50013)return"You need Create Expressions permission in this server.";if(q===30039)return"This server has no free sticker slots. Choose another server.";for(var u of[b?.body?.message,b?.message,b?.text])if(!(typeof u!="string"||!u))try{return JSON.parse(u)?.message??u;}catch{return u;}return"Discord could not upload the sticker. Please try again.";}function te(){return o.files();}function Z(b){return new Promise((q,u)=>{var F=new FileReader();F.onerror=()=>u(F.error??new Error("Could not read the image.")),F.onload=()=>q(String(F.result).split(",")[1]),F.readAsDataURL(b);});}function w(b){return Math.floor(b.length*3/4)-(b.endsWith("==")?2:b.endsWith("=")?1:0);}function D(b){var q="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",u=[],F=0,T=0;for(var P of b.slice(0,44)){var X=q.indexOf(P);if(X<0)break;T=T<<6|X,F+=6,F>=8&&(F-=8,u.push(T>>>F&255));}var I=[137,80,78,71,13,10,26,10];if(u.length<24||I.some((P,X)=>u[X]!==P)||String.fromCharCode(...u.slice(12,16))!=="IHDR")return null;var H=P=>u[P]*16777216+u[P+1]*65536+u[P+2]*256+u[P+3];return{width:H(16),height:H(20)};}function le(b){if(typeof b!="string"||!b)throw new Error("Discord did not return a local image path.");return /^(file|content):\/\//.test(b)?b:"file://"+b;}async function ve(b,q){var u=te();if(!u?.writeFile||!u?.removeFile)throw new Error("Discord's image file module is unavailable on this build.");var F=[],T=S("launchCropper","cleanSingle")??S("launchCropper"),I;async function H(){if(I&&T?.cleanSingle)try{await T.cleanSingle(I);}catch{}for(var X of F)try{await u.removeFile("cache",X);}catch{}}async function P(X,ie){try{return gr(X,q).base64;}catch(de){if(de?.code!=="STATIC_FORMAT_UNSUPPORTED")throw de;var pe=b.proxyURL??ie;if(!/^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/(?:attachments|ephemeral-attachments|external)\//i.test(pe))throw new Error("Use a PNG or JPEG image, or an animated GIF. This image format could not be converted.");var E=new URL(pe.replace(/^https:\/\/cdn\.discordapp\.com/i,"https://media.discordapp.net"));E.searchParams.set("format","png"),E.searchParams.set("width","320"),E.searchParams.set("height","320"),q();var U=await(e.utils?.safeFetch??fetch)(E.toString(),{},2e4);if(!U.ok)throw new Error("Discord could not convert this image to PNG. Use the original PNG or JPEG.");var V=await U.blob();if(V.size>l)throw new Error("Choose an image smaller than 25 MB.");var ge=await Z(V);return q(),gr(ge,q).base64;}}try{var X=b.url,ie=S("maybeRefreshAttachmentUrl");if(/^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\//i.test(X))try{X=(await ie?.maybeRefreshAttachmentUrl?.(X))||X;}catch{}var de=await(e.utils?.safeFetch??fetch)(X,{},2e4);if(!de.ok)throw new Error("Image download failed (HTTP "+de.status+"). Reopen the image and try again.");if(Number(de.headers?.get?.("content-length"))>l)throw new Error("Choose an image smaller than 25 MB.");var pe=await de.blob();if(pe.size>l)throw new Error("Choose an image smaller than 25 MB.");var E=await Z(pe);if(q(),!E)throw new Error("The image is empty.");var U="save-as-sticker-"+Date.now()+"-"+Math.random().toString(36).slice(2);if(Zr(E)){x("Preparing animated GIF\u2026");var me=await Jr(E,q);q();var re=U+"-sticker.gif";F.push(re);var xe=le(await u.writeFile("cache",re,me.base64,"base64"));return q(),{uri:xe,mimeType:me.mimeType,cleanup:H};}if(b.contentType==="image/gif"||pe.type==="image/gif")throw new Error("This link returned a video or still preview. Share the original .gif file and try again.");var V=D(E);if(!V||V.width!==320||V.height!==320||w(E)>f)if(!T?.launchCropper)E=await P(E,X);else{var _me=E,_re=pe.type||b.contentType||"image/png",_xe=/jpeg/i.test(_re)?"jpg":/webp/i.test(_re)?"webp":/avif/i.test(_re)?"avif":"png",Se=U+"."+_xe;F.push(Se);var be=le(await u.writeFile("cache",Se,E,"base64"));q();var ke;try{ke=await T.launchCropper({uri:be,width:320,height:320,mimeType:"image/png",includeBase64:!0,freeStyleCropEnabled:!1});}catch(Ie){if(Ie?.code==="E_PICKER_CANCELLED"||/cancel/i.test(String(Ie?.message??"")))throw Ie;q();}I=ke?.path??ke?.uri,q(),E=ke?.data??ke?.base64,!E&&I&&u.readFile&&(E=await u.readFile(I.replace(/^file:\/\//,""),"base64")),(typeof E!="string"||!E)&&(E=_me),E=E.replace(/^data:[^,]*,/,"").replace(/\s/g,"");var Te=D(E);(!Te||Te.width!==320||Te.height!==320||w(E)>f)&&(E=await P(E,X));}var ge=D(E);if(!ge||ge.width!==320||ge.height!==320)throw new Error("The cropper did not produce a 320\xD7320 PNG. The sticker was not uploaded.");if(w(E)>f)throw new Error("The cropped sticker is over 512 KiB. Try a simpler image.");var ae=U+"-sticker.png";F.push(ae);var ce=le(await u.writeFile("cache",ae,E,"base64"));return q(),{uri:ce,mimeType:"image/png",cleanup:H};}catch(X){throw await H(),X;}}async function Q(b,q,u){if(A||!m)return;A=!0;var F=_,T=g("UserStore")?.getCurrentUser?.()?.id,I=()=>{if(!m||_!==F||!T||g("UserStore")?.getCurrentUser?.()?.id!==T)throw Object.assign(new Error("Cancelled"),{code:"E_PICKER_CANCELLED"});},H;try{if(u.length<2||u.length>30)throw new Error("Use a sticker name between 2 and 30 characters.");if(!T)throw new Error("Your Discord account is still loading. Reopen the picker and try again.");I();var P=o.resolve("sticker");d.hideActionSheet(s),r.Keyboard?.dismiss?.(),await new Promise(E=>setTimeout(E,300)),I(),x("Preparing your sticker\u2026"),H=await ve(q,I),I();var X=g("GuildStore"),ie=X?.getGuild?.(b.id)??X?.getGuilds?.()?.[b.id];if(!$(ie))throw new Error("You no longer have Create Expressions permission in this server.");var de=K(ie);if(de.used!=null&&de.used>=de.max)throw new Error("This server has no free sticker slots. Choose another server.");x("Adding sticker to "+b.name+"\u2026");var pe=await P({guildId:b.id,name:u,tags:"slight_smile",description:"",uri:H.uri,mimeType:H.mimeType,platform:"mobile",originalMd5:null},I);if(!pe?.id&&!pe?.body?.id)throw new Error("Discord did not confirm the upload. Check the server's stickers before trying again.");m&&_===F&&x("Sticker added to "+b.name);}catch(P){if(P?.code==="E_PICKER_CANCELLED"||/cancel/i.test(String(P?.message??"")))return;if(v("Upload failed",P),m&&_===F){var _X=ee(P);r.Alert?.alert?r.Alert.alert("Sticker could not be added",_X):x(_X);}}finally{await H?.cleanup?.(),A=!1;}}function se({images:b,onClose:q,inPanel:u=!1}){var[F,T]=t.useState(b.length===1?b[0]:null),[I,H]=t.useState(null),[P,X]=t.useState(L(b[0]?.filename)),[,ie]=t.useState(0),[de,pe]=t.useState(""),E=(g("ThemeStore")?.theme??r.Appearance?.getColorScheme?.())!=="light",U={text:E?"#f2f3f5":"#1e1f22",muted:E?"#b5bac1":"#4e5058",input:E?"#1e1f22":"#e3e5e8"};t.useEffect(()=>{var he=[g("GuildStore"),g("PermissionStore"),g("GuildStickersStore"),g("StickersStore")].filter(Boolean),_e=()=>ie(Ee=>Ee+1);return he.forEach(Ee=>Ee.addChangeListener?.(_e)),()=>he.forEach(Ee=>Ee.removeChangeListener?.(_e));},[]);var V=(he,_e={})=>i(r.Text,{style:{color:U.text,fontSize:16,..._e}},he),ge=(he,_e,Ee=!1)=>i(r.Pressable,{accessibilityRole:"button",accessibilityLabel:he,disabled:Ee,onPress:_e,style:{padding:14,borderRadius:8,backgroundColor:Ee?"#555967":"#5865f2",marginTop:12}},V(he,{color:"#ffffff",fontWeight:"600",textAlign:"center"})),ae={color:U.text,backgroundColor:U.input,borderRadius:8,padding:12,fontSize:16,marginTop:10},ce=q??(()=>d.hideActionSheet(s)),me=F?i(r.Image,{source:{uri:F.url},resizeMode:"contain",accessibilityLabel:"Sticker preview",style:{width:26,height:26,marginRight:12}}):null,re=I?"Sticker name":F?"Saving "+L(F.filename):"Choose image",xe=!u&&C?i(C,{onPress:ce,accessibilityLabel:"Close"}):i(r.Pressable,{onPress:ce,accessibilityRole:"button",accessibilityLabel:"Close",hitSlop:10,style:{width:40,height:40,alignItems:"center",justifyContent:"center"}},V("\xD7",{fontSize:32,lineHeight:36})),Se=!u&&B?i(B,{title:re,leading:me,trailing:xe}):i(r.View,{style:{flexDirection:"row",alignItems:"center",paddingHorizontal:28,minHeight:72}},me,i(r.Text,{numberOfLines:1,style:{flex:1,color:U.text,fontSize:20,fontWeight:"600",textAlign:"center",paddingHorizontal:8}},re),xe),be=Math.min(640,(r.Dimensions?.get?.("window")?.height??800)*.62);function ke(he){if(O)return i(O,{guild:he,size:z?.MEDIUM,animate:!1});if(he.icon)return i(r.Image,{source:{uri:"https://cdn.discordapp.com/icons/"+he.id+"/"+he.icon+".png?size=96"},style:{width:44,height:44,borderRadius:14},resizeMode:"cover"});var _e=String(he.name).trim().split(/\s+/).map(Ee=>Ee[0]).join("").slice(0,3);return i(r.View,{style:{width:44,height:44,borderRadius:14,backgroundColor:"#5865f2",alignItems:"center",justifyContent:"center"}},V(_e,{color:"#ffffff",fontWeight:"600"}));}function Te(he){var _e=K(he),Ee=_e.used!=null&&_e.used>=_e.max,Pe=Ee?"No slots available":_e.used==null?"Check slots on upload":void 0,De=()=>{var We=g("GuildStore")?.getGuild?.(he.id)??he,rt=K(We);!$(We)||rt.used!=null&&rt.used>=rt.max||H(We);},Ue=k("ic_add_24px","PlusSmallIcon","PlusIcon"),qe=y.FormIcon&&Ue!=null?i(y.FormIcon,{source:Ue,style:{opacity:1}}):V("+",{color:U.muted,fontSize:30,fontWeight:"300"});return y.FormRow?i(y.FormRow,{key:he.id,leading:ke(he),label:he.name,subLabel:Pe,trailing:qe,disabled:Ee,onPress:De,accessibilityLabel:he.name,accessibilityRole:"button",accessibilityState:{disabled:Ee}}):i(r.Pressable,{key:he.id,accessibilityRole:"button",accessibilityLabel:he.name,accessibilityState:{disabled:Ee},disabled:Ee,onPress:De,style:{minHeight:80,paddingHorizontal:32,flexDirection:"row",alignItems:"center",opacity:Ee?.4:1}},ke(he),i(r.View,{style:{flex:1,marginLeft:18,marginRight:16}},V(he.name,{fontWeight:"600",fontSize:18}),Pe?V(Pe,{color:U.muted,fontSize:13,marginTop:3}):null),qe);}if(F&&!I){var he=ye().filter(Ue=>`${Ue.name}
${Ue.id}`.toLowerCase().includes(de.trim().toLowerCase())),_e=i(r.View,{style:{padding:24}},V(de.trim()?"No servers match your search.":"No servers available. You need Create Expressions permission to add a sticker.",{color:U.muted,fontSize:14})),Ee=u?r.FlatList:Y,Pe=Ee?i(Ee,{style:{flex:1},contentContainerStyle:{paddingBottom:32},data:he,keyboardShouldPersistTaps:"handled",keyboardDismissMode:"on-drag",nestedScrollEnabled:!0,removeClippedSubviews:!1,initialNumToRender:12,renderItem:({item:Ue})=>Te(Ue),keyExtractor:Ue=>Ue.id,extraData:he.map(Ue=>Ue.id+":"+K(Ue).used).join(","),ListEmptyComponent:_e}):i(r.ScrollView,{style:{flex:1},contentContainerStyle:{paddingBottom:32}},he.length?he.map(Te):_e),De=i(r.View,{style:u?{flex:1,minHeight:0}:{height:be}},Se,i(r.TextInput,{accessibilityLabel:"Search servers",placeholder:"Search server name or ID",placeholderTextColor:U.muted,value:de,onChangeText:pe,autoCorrect:!1,autoCapitalize:"none",style:{...ae,marginHorizontal:20,marginBottom:12}}),Pe);return u?De:i(J,{scrollable:!1},De);}var Ie;if(!F)Ie=b.map((he,_e)=>i(r.Pressable,{key:he.url,accessibilityRole:"button",accessibilityLabel:"Use image "+(_e+1),onPress:()=>{T(he),X(L(he.filename));},style:{flexDirection:"row",alignItems:"center",gap:12,paddingVertical:10}},i(r.Image,{source:{uri:he.url},style:{width:64,height:64},resizeMode:"contain"}),V(he.filename,{flex:1})));else{var _he=P.trim().length>=2&&P.trim().length<=30&&!/[\u0000-\u001f]/.test(P);Ie=i(r.View,null,i(r.Image,{source:{uri:F.url},style:{height:128,width:"100%",marginBottom:12},resizeMode:"contain"}),V("Server: "+I.name,{fontWeight:"600"}),V("Sticker name",{marginTop:12}),i(r.TextInput,{value:P,onChangeText:X,maxLength:30,placeholder:"Sticker name",placeholderTextColor:U.muted,style:ae,selectTextOnFocus:!0}),V(F.contentType==="image/gif"?"GIFs keep their animation and resize automatically. Maximum 5 seconds and 512 KiB.":"Images fit inside 320\xD7320 with transparent padding. GIFs keep their animation.",{color:U.muted,fontSize:13,marginTop:12}),ge("Add sticker",()=>{ce(),Q(I,F,P.trim());},!_he),ge("Choose another server",()=>H(null)));}var He=i(r.View,{style:u?{flex:1,minHeight:0}:{}},Se,i(r.ScrollView,{keyboardShouldPersistTaps:"handled",keyboardDismissMode:"on-drag",style:u?{flex:1}:{maxHeight:be},contentContainerStyle:{padding:20,paddingBottom:40}},Ie));return u?He:i(J,{scrollable:!1},He);}function oe(b,q){if(!m)return;if(A){x("A sticker upload is already in progress.");return;}if(a.open(T=>i(se,{images:b,onClose:T,inPanel:!0}),"sticker picker")){d.hideActionSheet(q);return;}if(!J){x("The server picker is unavailable on this Discord build.");return;}d.hideActionSheet(q);var u=e.ui.components?.ErrorBoundary,F=()=>{var T=i(se,{images:b});return u?i(u,null,T):T;};d.openLazy(Promise.resolve({default:F}),s,{});}function G(b,q){var u=k("StickerIcon","ic_sticker_24px");return i(M,{key:h,label:"Save as Sticker",icon:M.Icon&&u!=null?i(M.Icon,{source:u}):void 0,iconSource:M.Icon?void 0:u,onPress:()=>oe(b,q)});}function R(b,q,u){var F=null,T=-1,I=!1,H=U=>String(U?.props?.label??U?.props?.message??""),P=U=>U?.props&&typeof U.props.onPress=="function"&&(U.type===M||U.props.label!=null||U.props.message!=null);function X(U,V=0){if(!(!U||V>40))if(Array.isArray(U)){var ge=U.filter(P);if(ge.length){var ae=ge.some(ce=>/save image/i.test(H(ce)))?1e3:ge.some(ce=>/copy image link/i.test(H(ce)))?900:10;ae+ge.length>T&&(F=U,T=ae+ge.length);}U.forEach(ae=>X(ae,V+1));}else U.props&&((U.key===h||H(U)==="Save as Sticker")&&(I=!0),X(U.props.children,V+1));}if(X(b),I||!F)return b;var ie=G(q,u),de=F.findIndex(U=>/save image/i.test(H(U))),pe=de>=0?de+1:F.length;function E(U){if(U===F)return[...F.slice(0,pe),ie,...F.slice(pe)];if(Array.isArray(U)){var V=U.map(E);return V.some((ge,ae)=>ge!==U[ae])?V:U;}if(U?.props?.children!=null){var _V=E(U.props.children);return _V!==U.props.children?t.cloneElement(U,{children:_V}):U;}return U;}return E(b);}function fe(b,q,u,F){var T=(I,H)=>{if(!m||_!==F)return H;try{var P=j(I,q);return P.length?R(H,P,u):H;}catch(P){return v("Could not add image menu action",P),H;}};return typeof b=="function"&&!b.prototype?.isReactComponent?function(...H){return T(H[0],b.apply(this,H));}:b?.$$typeof===Symbol.for("react.memo")?t.memo(fe(b.type,q,u,F),b.compare):b?.$$typeof===Symbol.for("react.forward_ref")?t.forwardRef((I,H)=>T(I,b.render(I,H))):b;}function ne(){if(!d?.openLazy||!M||!J||!g("GuildStore"))throw new Error("SaveAsSticker: required menu modules were not found on this Discord build.");m||(m=!0,_++,p.push(e.patcher.before("openLazy",d,b=>{var[q,u,F]=b;if(u!=="MessageLongPressActionSheet"&&u!=="MediaShareActionSheet"||!q?.then)return;var T=_;b[0]=Promise.resolve(q).then(I=>!m||T!==_||!I?.default?I:{...I,default:fe(I.default,F,u,T)});})),x("SaveAsSticker enabled"));}function ue(){m=!1,_++,a.closeAll();for(var b of p.splice(0).reverse())try{b();}catch{}try{d?.hideActionSheet?.(s);}catch{}}return{onLoad:ne,onUnload:ue};})();
return module.exports.default;
})()
}, "SaveAsSticker");
})()
); }, {"id": "dev.fluttershy2008.save-as-sticker", "legacyManifest": {"name": "SaveAsSticker", "description": "Save images and animated GIFs as server stickers. Pick a server, name your sticker, and automatically resize GIFs while keeping them animated.", "version": "1.3.6", "authors": [{"name": "Fluttershy2008-mlp"}], "main": "index.js", "vendetta": {"icon": "ic_sticker_24px"}, "hash": "54299924ef3a801a542f7e255d81abc669de1241b0227360140c7c7baff4fbbf"}, "repository": "https://fluttershy2008-mlp.github.io/lol/valenced/index.json", "host": "valenced", "version": "1.0.0-beta4"}) };
})()
