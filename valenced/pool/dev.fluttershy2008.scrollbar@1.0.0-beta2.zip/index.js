(() => {
  'use strict';
  // Valenced JS plug-in, no private Discord APIs for scroll commands.
  const DEFAULTS = { enabled: true, allLists: true, side: 'right', width: 7,
    opacity: 0.85, color: '#8796FF', track: true, invert: 'auto' };
  const opt = fn => { try { return fn(); } catch { return undefined; } };
  const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, Number.isFinite(n) ? n : lo));
  const normalise = data => ({
    enabled: data?.enabled !== false,
    allLists: data?.allLists !== false,
    side: data?.side === 'left' ? 'left' : 'right',
    width: [5, 7, 10, 14].includes(data?.width) ? data.width : 7,
    opacity: clamp(Number(data?.opacity ?? 0.85), 0.3, 1),
    color: typeof data?.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(data.color) ? data.color : '#8796FF',
    track: data?.track !== false,
    invert: ['auto', 'yes', 'no'].includes(data?.invert) ? data.invert : 'auto'
  });
  let current, writes = Promise.resolve();
  const watchers = new Set();
  function notify() { if (current?.active) current.revision++; for (const cb of [...watchers]) opt(cb); }
  function dispose(session) {
    if (!session || !session.active) return;
    session.active = false;
    for (const undo of session.cleanups.splice(0).reverse()) opt(undo);
    if (current === session) current = undefined;
    notify();
  }
  function start(api) {
    if (current?.active) return;
    const U = api.unscoped, React = U.react.React, RN = U.react.ReactNative;
    const h = React.createElement.bind(React);
    const session = { active: true, cleanups: [], settings: normalise(api.jsonStorage?.cache),
      hooked: 0, status: 'Waiting for a scrollable list.', misses: 0, revision: 0, kinds: { chats: 0, dms: 0, lists: 0 } };
    current = session;
    api.cleanup(() => dispose(session));
    const live = () => current === session && session.active;
    const selectedChannel = () => opt(() => U.discord.flux.Stores.SelectedChannelStore.getChannelId());
    const EMPTY = {};
    const cache = new WeakSet();
    function getName(type) {
      // React.forwardRef, memo(), lazy() and Discord's obfuscated wrappers often
      // have no direct displayName. Read their inner type without executing them.
      const raw = type?.displayName ?? type?.name ?? type?.render?.displayName ??
        type?.render?.name ?? type?.type?.displayName ?? type?.type?.name ??
        type?._result?.displayName ?? type?._result?.name ?? type;
      return typeof raw === 'string' ? raw : '';
    }
    const byType = new Map();
    for (const [name, type] of Object.entries({
      ScrollView: RN.ScrollView, FlatList: RN.FlatList,
      SectionList: RN.SectionList, VirtualizedList: RN.VirtualizedList,
    })) if (type && (typeof type === 'function' || typeof type === 'object')) byType.set(type, name);
    // FlashList comes from Shopify rather than react-native. Its exports can be
    // loaded as the plugin starts or after the first chat renders.
    const shopify = opt(() => U.externals?.shopify?.FlashList);
    if (shopify?.FlashList) byType.set(shopify.FlashList, 'FlashList');
    if (shopify && (typeof shopify === 'function' || typeof shopify === 'object'))
      byType.set(shopify, 'FlashList');
    function itemCount(props) {
      if (Array.isArray(props?.data)) return props.data.length;
      if (Array.isArray(props?.messages)) return props.messages.length;
      if (Array.isArray(props?.items)) return props.items.length;
      if (Array.isArray(props?.sections)) return props.sections.reduce((n, part) => n + (part?.data?.length ?? 0), 0);
      return opt(() => props?.dataProvider?.getSize?.()) ?? props?.itemCount ?? props?.rowCount ?? 0;
    }
    function classify(el) {
      const props = el?.props;
      if (!props || !live() || !session.settings.enabled || props.horizontal === true ||
        props.scrollEnabled === false || props.__valencedScrollbar ||
        props.accessibilityRole === 'adjustable') return '';
      const name = byType.get(el.type) ?? getName(el.type);
      if (/Horizontal|Carousel|Pager|Swipe|Header/.test(name)) return '';
      const chat = typeof props.onTapMessage === 'function' && typeof props.onLongPressMessage === 'function';
      if (chat || /^(ChatMessageList|MessagesList|MessagesListView|ChannelMessages|ChatList|MessageList)$/.test(name)) return 'chats';
      const count = itemCount(props), isList = typeof props.renderItem === 'function' ||
        typeof props.rowRenderer === 'function' || typeof props.renderRow === 'function' ||
        typeof props.renderSection === 'function' || count > 3;
      const looksScrollable = /ScrollView|FlatList|SectionList|VirtualizedList|FlashList|RecyclerListView|RecyclerList|Scrollable|Scroller/.test(name) || byType.has(el.type);
      const namedDM = /DMList|PrivateChannel|DirectMessage|ChannelList|GuildChannel|FriendsList|HomeList|InboxList/.test(name);
      if (!session.settings.allLists) return '';
      // Many Discord lists are React.memo/forwardRef components with anonymous
      // types. Real renderItem/data contracts are more reliable than names.
      if (isList && (count > 2 || looksScrollable || namedDM || typeof props.onScroll === 'function'))
        return namedDM || props.channelId === '@me' ? 'dms' : 'lists';
      if (looksScrollable && (typeof props.onScroll === 'function' ||
        typeof props.onContentSizeChange === 'function' || props.children || namedDM))
        return namedDM ? 'dms' : 'lists';
      if (namedDM && typeof props.onScroll === 'function') return 'dms';
      return '';
    }
    function ScrollOverlay({ element }) {
      // The snapshot is a revision, not a Boolean. This ensures position/colour
      // changes re-render already mounted chat, DM and channel list overlays.
      React.useSyncExternalStore(
        React.useCallback(cb => { watchers.add(cb); return () => watchers.delete(cb); }, []),
        () => session.revision, () => 0
      );
      const active = live() && session.settings.enabled;
      const ref = React.useRef(null), geomRef = React.useRef({ viewport: 0, content: 0, offset: 0 });
      const estimated = React.useRef(false);
      const [geometry, setGeometry] = React.useState({ viewport: 0, content: 0 });
      const [supported, setSupported] = React.useState(true);
      const translate = React.useRef(new RN.Animated.Value(0)).current;
      const origin = React.useRef(0);
      const props = element.props ?? EMPTY;
      const invert = session.settings.invert === 'yes' ||
        (session.settings.invert === 'auto' && !!props.inverted);
      const width = session.settings.width;
      const usable = Math.max(0, geometry.content - geometry.viewport);
      const height = Math.max(32, geometry.viewport * geometry.viewport / Math.max(1, geometry.content));
      const travel = Math.max(0, geometry.viewport - height);
      const visible = active && supported && geometry.viewport > 65 &&
        geometry.content > geometry.viewport + 10;
      function renderPosition() {
        const g = geomRef.current, range = Math.max(1, g.content - g.viewport);
        const thumb = Math.max(32, g.viewport * g.viewport / Math.max(1, g.content));
        const distance = Math.max(0, g.viewport - thumb);
        let f = clamp(g.offset / range, 0, 1);
        if (invert) f = 1 - f;
        translate.setValue(distance * f);
      }
      function setBounds(viewport, content) {
        const g = geomRef.current;
        const v = Number.isFinite(viewport) && viewport > 0 ? viewport : g.viewport;
        const c = Number.isFinite(content) && content > 0 ? content : g.content;
        // Native lists commonly report layout and content size in different
        // render frames. Retain the first measurement instead of discarding it.
        g.viewport = v; g.content = c;
        if (!v || !c) return;
        if (Math.abs(v - geometry.viewport) > 1 || Math.abs(c - geometry.content) > 1)
          setGeometry({ viewport: v, content: c });
        renderPosition();
      }
      function onScroll(event) {
        const e = event?.nativeEvent ?? event ?? EMPTY;
        const g = geomRef.current;
        if (Number.isFinite(e.contentOffset?.y)) g.offset = Math.max(0, e.contentOffset.y);
        const v = e.layoutMeasurement?.height ?? g.viewport;
        const c = e.contentSize?.height ?? g.content;
        if (Number.isFinite(c) && c > 0) estimated.current = false;
        setBounds(v, c);
        renderPosition();
        opt(() => props.onScroll?.(event));
      }
      function onContentSizeChange(w, h) {
        if (Number.isFinite(h) && h > 0) estimated.current = false;
        setBounds(geomRef.current.viewport, h);
        opt(() => props.onContentSizeChange?.(w, h));
      }
      function onLayout(e) {
        const v = e?.nativeEvent?.layout?.height;
        setBounds(v, geomRef.current.content);
        opt(() => props.onLayout?.(e));
      }
      function estimateContent(viewport) {
        // Virtualized lists can omit contentSize until first scroll. Give them a
        // provisional bar based on mounted item count. Replace it with actual
        // scroll metrics as soon as Discord emits them.
        const count = itemCount(props);
        if (!Number.isFinite(viewport) || viewport <= 65 || count < 5 ||
          geomRef.current.content > viewport + 10) return;
        const typicalHeight = Number(props.estimatedItemSize ?? props.averageItemSize ?? 64);
        const approximation = clamp(typicalHeight, 38, 180) * count;
        if (approximation > viewport + 20) {
          estimated.current = true;
          setBounds(viewport, approximation);
        }
      }
      function setRef(value) {
        ref.current = value;
        const old = element.ref ?? props.ref;
        if (typeof old === 'function') old(value);
        else if (old && typeof old === 'object') old.current = value;
      }
      function resolveList() {
        const r = ref.current;
        // Do not assume the first ref is an imperative scrolling surface.
        return [r, r?.current, r?._listRef, r?._listRef?.current,
          r?._recyclerRef, r?._recyclerRef?.current, r?._scrollRef,
          r?._scrollRef?.current, r?.scrollRef, r?.scrollRef?.current,
          r?.getNode?.(), r?.getScrollableNode?.(), r?.getScrollResponder?.(),
          props.listRef?.current, props.scrollRef?.current,
          props.scrollViewRef?.current, props.recyclerRef?.current]
          .filter(Boolean);
      }
      function sendScroll(offset, fraction) {
        const targets = resolveList();
        const count = itemCount(props);
        const index = Math.max(0, Math.min(Math.max(0, count - 1),
          Math.floor(fraction * Math.max(0, count - 1))));
        for (const target of targets) {
          try {
            if (typeof target.scrollToOffset === 'function') {
              target.scrollToOffset({ offset, animated: false }); return true;
            }
            if (typeof target.scrollTo === 'function') {
              target.scrollTo({ y: offset, animated: false }); return true;
            }
            if (typeof target.scrollToPosition === 'function') {
              target.scrollToPosition(0, offset, false); return true;
            }
            if (typeof target.scrollToIndex === 'function' && count > 0) {
              target.scrollToIndex({ index, animated: false, viewPosition: 0 }); return true;
            }
            if (typeof target.scrollToEnd === 'function' && fraction >= 0.99) {
              target.scrollToEnd({ animated: false }); return true;
            }
            if (typeof target.scrollToTop === 'function' && fraction <= 0.01) {
              target.scrollToTop(false); return true;
            }
          } catch { /* The next available ref may be the actual native list. */ }
        }
        return false;
      }
      function jump(pageY) {
        if (!live() || !visible) return;
        const g = geomRef.current;
        let fraction = clamp((pageY - origin.current - height / 2) / Math.max(1, travel), 0, 1);
        if (invert) fraction = 1 - fraction;
        const offset = fraction * Math.max(0, g.content - g.viewport);
        if (sendScroll(offset, fraction)) {
          g.offset = offset;
          renderPosition();
        } else {
          // No fake scrolling: keep the rest of Discord usable and tell the
          // user which builds need a native-list-specific compatibility patch.
          setSupported(false); session.misses++;
          session.status = 'This Discord screen uses a native list without a supported scroll command.';
          notify();
        }
      }
      // An isolated 22-32px touch zone: normal Discord swipes and taps outside stay native.
      const trackEvents = {
        onStartShouldSetResponder: () => true,
        onMoveShouldSetResponder: () => true,
        onResponderGrant: e => {
          const n = e.nativeEvent;
          origin.current = (n.pageY ?? 0) - (n.locationY ?? 0);
          jump(n.pageY ?? 0);
        },
        onResponderMove: e => jump(e.nativeEvent?.pageY ?? 0),
        onResponderTerminationRequest: () => false,
      };
      const child = React.cloneElement(element, {
        ref: setRef, __valencedScrollbar: true, onScroll, onContentSizeChange,
        onLayout, scrollEventThrottle: 16,
      });
      const side = session.settings.side;
      const trackWidth = Math.max(width + 12, 22);
      const control = visible ? h(RN.View, {
        key: 'scrollbar-zone', ...trackEvents,
        accessible: true, accessibilityRole: 'adjustable',
        accessibilityLabel: 'Draggable scrollbar',
        pointerEvents: 'auto',
        style: { position: 'absolute', top: 0, bottom: 0, [side]: 0,
          width: trackWidth, justifyContent: 'flex-start', alignItems: 'center' }
      },
      session.settings.track ? h(RN.View, { pointerEvents: 'none', style: {
        position: 'absolute', top: 0, bottom: 0, width: width + 4,
        borderRadius: width, backgroundColor: 'rgba(120,125,140,0.14)' } }) : null,
      h(RN.Animated.View, { pointerEvents: 'none', style: {
        width, height, borderRadius: width, backgroundColor: session.settings.color,
        opacity: session.settings.opacity, transform: [{ translateY: translate }] } })) : null;
      return h(RN.View, {
        __valencedScrollbar: true, style: { flex: 1, position: 'relative', minHeight: 0 },
        onLayout: e => {
          const v = e.nativeEvent?.layout?.height;
          if (v) { setBounds(v, geomRef.current.content); estimateContent(v); }
        }
      }, child, control);
    }
    // Patch element factories, rather than all scroll methods, to keep scrolling native.
    // A WeakSet prevents double wrapping when both React.createElement and jsx produce elements.
    function wrap(element) {
      const category = classify(element);
      if (!category || cache.has(element)) return element;
      cache.add(element);
      session.hooked++; session.kinds[category]++;
      session.status = 'Detected ' + category + ' scrollable area.';
      return h(ScrollOverlay, { element, key: element.key ?? undefined });
    }
    const patched = new WeakMap();
    function patchFactories(module, methods) {
      if (!module || !['object', 'function'].includes(typeof module)) return;
      let done = patched.get(module);
      if (!done) patched.set(module, done = new Set());
      for (const name of methods) if (!done.has(name) && typeof module[name] === 'function') {
        done.add(name);
        const undo = opt(() => U.patcher.instead(module, name, function(args, original) {
          const rendered = Reflect.apply(original, this, args);
          return live() ? wrap(rendered) : rendered;
        }));
        if (typeof undo === 'function') session.cleanups.push(undo);
      }
    }
    patchFactories(React, ['createElement']);
    patchFactories(U.react.ReactJSXRuntime, ['jsx', 'jsxs', 'jsxDEV']);
    const F = U.modules?.finders;
    const seen = new WeakSet();
    const watch = mod => {
      if (!mod || typeof mod !== 'object' || seen.has(mod)) return;
      seen.add(mod); patchFactories(mod, ['jsx', 'jsxs', 'jsxDEV']);
    };
    const unwatch = opt(() => F?.getModules(F.filters.withProps('jsx', 'jsxs'), watch));
    if (typeof unwatch === 'function') session.cleanups.push(unwatch);
    try { if (F) watch(F.lookupModule(F.filters.withProps('jsx', 'jsxs'), { initialize: false })?.[0]); } catch {}
    void Promise.resolve(api.jsonStorage?.get?.()).then(value => {
      if (live() && value) { session.settings = normalise(value); notify(); }
    }).catch(() => { session.status = 'Could not read preferences. Default settings used.'; });
  }
  function SettingsComponent({ api }) {
    const React = api.unscoped.react.React, RN = api.unscoped.react.ReactNative, h = React.createElement;
    const [, refresh] = React.useState(0);
    React.useEffect(() => {
      const cb = () => refresh(x => x + 1);
      watchers.add(cb); return () => watchers.delete(cb);
    }, []);
    const s = current;
    const settings = s?.settings ?? normalise(api.jsonStorage?.cache);
    const save = patch => {
      if (!s?.active) return;
      s.settings = normalise({ ...s.settings, ...patch }); notify();
      const next = { ...s.settings };
      writes = writes.catch(() => {}).then(() => api.jsonStorage.set(next, true)).catch(() => {
        opt(() => RN.ToastAndroid.show('Unable to save Scrollbar settings.', RN.ToastAndroid.SHORT));
      });
    };
    const label = (name, description) => h(RN.View, { style: { flex: 1, marginRight: 14 } },
      h(RN.Text, { style: { color: '#F2F3F5', fontSize: 16, fontWeight: '600' } }, name),
      h(RN.Text, { style: { color: '#B5BAC1', marginTop: 4, lineHeight: 19 } }, description));
    const card = child => h(RN.View, { style: { backgroundColor: '#2B2D31', borderRadius: 12,
      padding: 14, marginBottom: 10, flexDirection: 'row', alignItems: 'center' } }, child);
    const toggle = (key, title, detail) => card(h(React.Fragment, null,
      label(title, detail), h(RN.Switch, { accessibilityLabel: title, value: settings[key],
        onValueChange: value => save({ [key]: value }) })));
    const choice = (name, field, values) => h(RN.View, { key: field, style: { marginTop: 10, marginBottom: 12 } },
      h(RN.Text, { style: { color: '#F2F3F5', fontSize: 16, marginBottom: 8 } }, name),
      h(RN.View, { style: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 } }, values.map(([value, title]) =>
        h(RN.Pressable, { key: String(value), accessibilityLabel: title,
          onPress: () => save({ [field]: value }),
          style: { borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10,
            backgroundColor: settings[field] === value ? '#5865F2' : '#2B2D31' } },
          h(RN.Text, { style: { color: '#FFFFFF' } }, title)))));
    return h(RN.ScrollView, { contentContainerStyle: { padding: 18, paddingBottom: 50 } },
      h(RN.Text, { style: { color: '#FFFFFF', fontSize: 26, fontWeight: '700', marginBottom: 8 } }, 'Scrollbar'),
      h(RN.Text, { style: { color: '#B5BAC1', marginBottom: 20, lineHeight: 21 } },
        'Drag the side thumb to jump through long message histories. Ordinary finger scrolling still works.'),
      toggle('enabled', 'Enable side scrollbar', 'Show an interactive handle for compatible scrollable lists.'),
      toggle('allLists', 'Other screens and lists', 'On by default: include home DMs, channels and other long lists.'),
      toggle('track', 'Show scrollbar track', 'Display the subtle background behind the draggable thumb.'),
      choice('Position', 'side', [['right', 'Right'], ['left', 'Left']]),
      choice('Thumb thickness', 'width', [[5, 'Thin'], [7, 'Normal'], [10, 'Wide'], [14, 'Extra wide']]),
      choice('Direction', 'invert', [['auto', 'Auto'], ['no', 'Normal'], ['yes', 'Reversed']]),
      choice('Thumb colour', 'color', [['#8796FF', 'Blurple'], ['#F2F3F5', 'White'], ['#FF77AA', 'Pink'], ['#57F287', 'Green']]),
      h(RN.Text, { style: { color: '#B5BAC1', lineHeight: 20, marginTop: 12 } },
        `Status: ${s?.status ?? 'Plugin not running.'}\nLists: ${s?.hooked ?? 0}; Chat: ${s?.kinds?.chats ?? 0}; DM: ${s?.kinds?.dms ?? 0}; Other: ${s?.kinds?.lists ?? 0}. Unsupported: ${s?.misses ?? 0}.\n` +
        'Automatic scrolling handles chat, DMs and channel lists when their native list exposes scrolling commands. ' +
        'On those versions the draggable bar cannot work; it is hidden rather than intercepting your messages. ' +
        'If a view becomes cramped, disable Other screens and lists. Reopen a chat to apply settings to existing lists.'));
  }
  return { default: { jsonStorage: { load: true, default: { ...DEFAULTS } },
    start, stop() { dispose(current); }, SettingsComponent } };
})()
