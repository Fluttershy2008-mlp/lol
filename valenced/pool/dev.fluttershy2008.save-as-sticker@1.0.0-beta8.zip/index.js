(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Valenced API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const hostId = 'valenced';
    const product = 'Valenced';
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the ' + product + ' plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const pathFinders = safe(() => U.discord.utils.modules.finders);
        const source = safe(() => pathFinders.lookupModuleWithImportedPath('../discord_common/js/packages/http-utils/HTTPUtils.tsx')[0])
            ?? rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
// SPDX-License-Identifier: MIT
// Replaces openLegacyPage in the Valenced expression picker package. Settings routes
// belong to SettingsNavigator; they are not routes of the root Chat navigator.
// Uses the enclosing adapter's scoped timers, route and disposal ownership.
function openLegacyPage(navigation, params) {
    if (!active) return;
    if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
    const settings = U.discord.modules?.settings;
    if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
        throw new Error('Update Valenced to open this plugin page.');
    let cancelled = false, timer, unsubscribe, readySubscription, loadingSubscription;
    const live = () => active && !cancelled && params.__expressionOpen?.() !== false;
    const cancel = own(() => {
        cancelled = true;
        clearTimeoutScoped(timer);
        unsubscribe?.(); readySubscription?.(); loadingSubscription?.();
    });
    const navigate = () => {
        if (!live()) return;
        timer = setTimeoutScoped(() => {
            if (!live()) return;
            loadingSubscription?.(); loadingSubscription = undefined;
            navigation.navigate('settings', { screen: legacyRoute, params });
        }, 0);
    };
    const registered = () => {
        if (!live()) return;
        if (!routeRegistered) {
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
        }
        navigate();
    };
    const start = () => {
        if (!live()) return;
        // Open the real Settings navigator first when its lazy modules have not
        // loaded. Waiting for their registration without doing this deadlocks.
        if (settings.isSettingsModulesLoaded?.() === false) {
            // Back during a cold Settings load cancels this opening. A module
            // becoming available later must not navigate the user away again.
            if (navigation.getRootState && navigation.addListener) {
                let entered = false;
                const changed = () => {
                    let state = navigation.getRootState(), loading = false;
                    for (let depth = 0; depth < 12 && state?.routes?.length; depth++) {
                        const route = state.routes[state.index ?? state.routes.length - 1];
                        if (route?.params?.__expressionLoading === params.__expressionPage) loading = true;
                        state = route?.state;
                    }
                    if (loading) entered = true;
                    else if (entered && live()) { params.__expressionCancel?.(); cancel(); }
                };
                const remove = navigation.addListener('state', changed);
                loadingSubscription = typeof remove === 'function' ? remove : () => navigation.removeListener?.('state', changed);
            }
            navigation.navigate('settings', { __expressionLoading: params.__expressionPage });
        }
        unsubscribe = settings.onSettingsModulesLoaded(registered);
    };
    if (navigation.isReady?.() === false && navigation.addListener) {
        const ready = () => { readySubscription?.(); start(); };
        const remove = navigation.addListener('ready', ready);
        readySubscription = typeof remove === 'function' ? remove : () => navigation.removeListener?.('ready', ready);
    } else start();
    return cancel;
}

    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        if (props.length && props.every(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL', 'HTTP'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        const found = rawFind(...props);
        if (found) return found;
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.valenced.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    const importedPaths = safe(() => U.discord.utils.modules.finders);
    if (importedPaths?.getModuleWithImportedPath) {
        metro.findByImportedPath = path => safe(() => importedPaths.lookupModuleWithImportedPath(path)[0]);
        metro.getModuleWithImportedPath = (path, callback) => own(importedPaths.getModuleWithImportedPath(path,
            (module, id) => { if (active) callback(module, id); }));
    }
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod(hostId + '.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from ' + product + '.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.[hostId + '.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        host: { id: 'valenced' },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage, version: metadata.version },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createValencedPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createValencedPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}

return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
/*!
omggif 1.0.10
omggif is a JavaScript implementation of a GIF 89a encoder and decoder.

https://github.com/deanm/omggif


(c) Dean McNamee <dean@gmail.com>, 2013.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.


gifenc 1.0.3
The MIT License (MIT)
Copyright (c) 2017 Matt DesLauriers

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.



base64-js 1.5.1
The MIT License (MIT)

Copyright (c) 2014 Jameson Little

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


fast-png 8.0.0
MIT License

Copyright (c) 2015 Michaël Zasso

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


iobuffer 6.0.1
The MIT License (MIT)

Copyright (c) 2015 Michaël Zasso

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


jpeg-js 0.4.4
Copyright (c) 2014, Eugene Ware
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Eugene Ware nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY EUGENE WARE ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL EUGENE WARE BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


fflate 0.8.3
MIT License

Copyright (c) 2026 Arjun Barrett

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/
const module = { exports: {} };
var Qn=Object.create;var At=Object.defineProperty;var ei=Object.getOwnPropertyDescriptor;var ti=Object.getOwnPropertyNames;var ri=Object.getPrototypeOf,ni=Object.prototype.hasOwnProperty;var ii=(e,t,r)=>t in e?At(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;var ut=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports;}catch(r){throw t=0,r;}},oi=(e,t)=>{for(var r in t)At(e,r,{get:t[r],enumerable:!0});},Ir=(e,t,r,n)=>{if(t&&typeof t=="object"||typeof t=="function"){var _loop=function(i){!ni.call(e,i)&&i!==r&&At(e,i,{get:()=>t[i],enumerable:!(n=ei(t,i))||n.enumerable});};for(var i of ti(t)){_loop(i);}}return e;};var bt=(e,t,r)=>(r=e!=null?Qn(ri(e)):{},Ir(t||!e||!e.__esModule?At(r,"default",{value:e,enumerable:!0}):r,e)),si=e=>Ir(At({},"__esModule",{value:!0}),e);var ye=(e,t,r)=>ii(e,typeof t!="symbol"?t+"":t,r);var Mr=ut(Qt=>{"use strict";function ai(e,t,r,o){var i=0,o=o===void 0?{}:o,s=o.loop===void 0?null:o.loop,a=o.palette===void 0?null:o.palette;if(t<=0||r<=0||t>65535||r>65535)throw new Error("Width/Height invalid.");function c(E){var v=E.length;if(v<2||v>256||v&v-1)throw new Error("Invalid code/color length, must be power of 2 and 2 .. 256.");return v;}e[i++]=71,e[i++]=73,e[i++]=70,e[i++]=56,e[i++]=57,e[i++]=97;var f=0,l=0;if(a!==null){for(var h=c(a);h>>=1;)++f;if(h=1<<f,--f,o.background!==void 0){if(l=o.background,l>=h)throw new Error("Background index out of range.");if(l===0)throw new Error("Background index explicitly passed as 0.");}}if(e[i++]=t&255,e[i++]=t>>8&255,e[i++]=r&255,e[i++]=r>>8&255,e[i++]=(a!==null?128:0)|f,e[i++]=l,e[i++]=0,a!==null)for(var y=0,A=a.length;y<A;++y){var C=a[y];e[i++]=C>>16&255,e[i++]=C>>8&255,e[i++]=C&255;}if(s!==null){if(s<0||s>65535)throw new Error("Loop count invalid.");e[i++]=33,e[i++]=255,e[i++]=11,e[i++]=78,e[i++]=69,e[i++]=84,e[i++]=83,e[i++]=67,e[i++]=65,e[i++]=80,e[i++]=69,e[i++]=50,e[i++]=46,e[i++]=48,e[i++]=3,e[i++]=1,e[i++]=s&255,e[i++]=s>>8&255,e[i++]=0;}var x=!1;this.addFrame=function(E,v,w,u,m,d){if(x===!0&&(--i,x=!1),d=d===void 0?{}:d,E<0||v<0||E>65535||v>65535)throw new Error("x/y invalid.");if(w<=0||u<=0||w>65535||u>65535)throw new Error("Width/Height invalid.");if(m.length<w*u)throw new Error("Not enough pixels for the frame size.");var D=!0,g=d.palette;if(g==null&&(D=!1,g=a),g==null)throw new Error("Must supply either a local or global palette.");for(var B=c(g),_=0;B>>=1;)++_;B=1<<_;var U=d.delay===void 0?0:d.delay,P=d.disposal===void 0?0:d.disposal;if(P<0||P>3)throw new Error("Disposal out of range.");var L=!1,$=0;if(d.transparent!==void 0&&d.transparent!==null&&(L=!0,$=d.transparent,$<0||$>=B))throw new Error("Transparent color index.");if((P!==0||L||U!==0)&&(e[i++]=33,e[i++]=249,e[i++]=4,e[i++]=P<<2|(L===!0?1:0),e[i++]=U&255,e[i++]=U>>8&255,e[i++]=$,e[i++]=0),e[i++]=44,e[i++]=E&255,e[i++]=E>>8&255,e[i++]=v&255,e[i++]=v>>8&255,e[i++]=w&255,e[i++]=w>>8&255,e[i++]=u&255,e[i++]=u>>8&255,e[i++]=D===!0?128|_-1:0,D===!0)for(var re=0,W=g.length;re<W;++re){var K=g[re];e[i++]=K>>16&255,e[i++]=K>>8&255,e[i++]=K&255;}return i=li(e,i,_<2?2:_,m),i;},this.end=function(){return x===!1&&(e[i++]=59,x=!0),i;},this.getOutputBuffer=function(){return e;},this.setOutputBuffer=function(E){e=E;},this.getOutputBufferPosition=function(){return i;},this.setOutputBufferPosition=function(E){i=E;};}function li(e,t,r,n){e[t++]=r;var i=t++,o=1<<r,s=o-1,a=o+1,c=a+1,f=r+1,l=0,h=0;function y(d){for(;l>=d;)e[t++]=h&255,h>>=8,l-=8,t===i+256&&(e[i]=255,i=t++);}function A(d){h|=d<<l,l+=f,y(8);}var C=n[0]&s,x={};A(o);for(var E=1,v=n.length;E<v;++E){var w=n[E]&s,u=C<<8|w,m=x[u];if(m===void 0){for(h|=C<<l,l+=f;l>=8;)e[t++]=h&255,h>>=8,l-=8,t===i+256&&(e[i]=255,i=t++);c===4096?(A(o),c=a+1,f=r+1,x={}):(c>=1<<f&&++f,x[u]=c++),C=w;}else C=m;}return A(C),A(a),y(1),i+1===t?e[i]=0:(e[i]=t-i-1,e[t++]=0),t;}function ci(e){var t=0;if(e[t++]!==71||e[t++]!==73||e[t++]!==70||e[t++]!==56||(e[t++]+1&253)!==56||e[t++]!==97)throw new Error("Invalid GIF 87a/89a header.");var r=e[t++]|e[t++]<<8,n=e[t++]|e[t++]<<8,i=e[t++],o=i>>7,s=i&7,a=1<<s+1,c=e[t++];e[t++];var f=null,l=null;o&&(f=t,l=a,t+=a*3);var h=!0,y=[],A=0,C=null,x=0,E=null;for(this.width=r,this.height=n;h&&t<e.length;)switch(e[t++]){case 33:switch(e[t++]){case 255:if(e[t]!==11||e[t+1]==78&&e[t+2]==69&&e[t+3]==84&&e[t+4]==83&&e[t+5]==67&&e[t+6]==65&&e[t+7]==80&&e[t+8]==69&&e[t+9]==50&&e[t+10]==46&&e[t+11]==48&&e[t+12]==3&&e[t+13]==1&&e[t+16]==0)t+=14,E=e[t++]|e[t++]<<8,t++;else for(t+=12;;){var v=e[t++];if(!(v>=0))throw Error("Invalid block size");if(v===0)break;t+=v;}break;case 249:if(e[t++]!==4||e[t+4]!==0)throw new Error("Invalid graphics extension block.");var w=e[t++];A=e[t++]|e[t++]<<8,C=e[t++],(w&1)===0&&(C=null),x=w>>2&7,t++;break;case 254:for(;;){var v=e[t++];if(!(v>=0))throw Error("Invalid block size");if(v===0)break;t+=v;}break;default:throw new Error("Unknown graphic control label: 0x"+e[t-1].toString(16));}break;case 44:var u=e[t++]|e[t++]<<8,m=e[t++]|e[t++]<<8,d=e[t++]|e[t++]<<8,D=e[t++]|e[t++]<<8,g=e[t++],B=g>>7,_=g>>6&1,U=g&7,P=1<<U+1,L=f,$=l,re=!1;if(B){var re=!0;L=t,$=P,t+=P*3;}var W=t;for(t++;;){var v=e[t++];if(!(v>=0))throw Error("Invalid block size");if(v===0)break;t+=v;}y.push({x:u,y:m,width:d,height:D,has_local_palette:re,palette_offset:L,palette_size:$,data_offset:W,data_length:t-W,transparent_index:C,interlaced:!!_,delay:A,disposal:x});break;case 59:h=!1;break;default:throw new Error("Unknown gif block: 0x"+e[t-1].toString(16));}this.numFrames=function(){return y.length;},this.loopCount=function(){return E;},this.frameInfo=function(K){if(K<0||K>=y.length)throw new Error("Frame index out of range.");return y[K];},this.decodeAndBlitFrameBGRA=function(K,X){var j=this.frameInfo(K),q=j.width*j.height,xe=new Uint8Array(q);Br(e,j.data_offset,xe,q);var ie=j.palette_offset,ne=j.transparent_index;ne===null&&(ne=256);var Z=j.width,b=r-Z,z=Z,ce=(j.y*r+j.x)*4,ve=((j.y+j.height)*r+j.x)*4,J=ce,le=b*4;j.interlaced===!0&&(le+=r*4*7);for(var ae=8,G=0,O=xe.length;G<O;++G){var ue=xe[G];if(z===0&&(J+=le,z=Z,J>=ve&&(le=b*4+r*4*(ae-1),J=ce+(Z+b)*(ae<<1),ae>>=1)),ue===ne)J+=4;else{var se=e[ie+ue*3],de=e[ie+ue*3+1],Fe=e[ie+ue*3+2];X[J++]=Fe,X[J++]=de,X[J++]=se,X[J++]=255;}--z;}},this.decodeAndBlitFrameRGBA=function(K,X){var j=this.frameInfo(K),q=j.width*j.height,xe=new Uint8Array(q);Br(e,j.data_offset,xe,q);var ie=j.palette_offset,ne=j.transparent_index;ne===null&&(ne=256);var Z=j.width,b=r-Z,z=Z,ce=(j.y*r+j.x)*4,ve=((j.y+j.height)*r+j.x)*4,J=ce,le=b*4;j.interlaced===!0&&(le+=r*4*7);for(var ae=8,G=0,O=xe.length;G<O;++G){var ue=xe[G];if(z===0&&(J+=le,z=Z,J>=ve&&(le=b*4+r*4*(ae-1),J=ce+(Z+b)*(ae<<1),ae>>=1)),ue===ne)J+=4;else{var se=e[ie+ue*3],de=e[ie+ue*3+1],Fe=e[ie+ue*3+2];X[J++]=se,X[J++]=de,X[J++]=Fe,X[J++]=255;}--z;}};}function Br(e,t,r,n){for(var i=e[t++],o=1<<i,s=o+1,a=s+1,c=i+1,f=(1<<c)-1,l=0,h=0,y=0,A=e[t++],C=new Int32Array(4096),x=null;;){for(;l<16&&A!==0;)h|=e[t++]<<l,l+=8,A===1?A=e[t++]:--A;if(l<c)break;var E=h&f;if(h>>=c,l-=c,E===o){a=s+1,c=i+1,f=(1<<c)-1,x=null;continue;}else if(E===s)break;for(var v=E<a?E:x,w=0,u=v;u>o;)u=C[u]>>8,++w;var m=u,d=y+w+(v!==E?1:0);if(d>n){console.log("Warning, gif stream longer than expected.");return;}r[y++]=m,y+=w;var D=y;for(v!==E&&(r[y++]=m),u=v;w--;)u=C[u],r[--D]=u&255,u>>=8;x!==null&&a<4096&&(C[a++]=x<<8|m,a>=f+1&&c<12&&(++c,f=f<<1|1)),x=E;}return y!==n&&console.log("Warning, gif stream shorter than expected."),r;}try{Qt.GifWriter=ai,Qt.GifReader=ci;}catch{}});var jr=ut(nr=>{var Nr=Object.defineProperty,fi=e=>Nr(e,"__esModule",{value:!0}),hi=(e,t)=>{for(var r in t)Nr(e,r,{get:t[r],enumerable:!0});};fi(nr);hi(nr,{GIFEncoder:()=>$r,applyPalette:()=>wi,default:()=>Ui,nearestColor:()=>_i,nearestColorIndex:()=>Hr,nearestColorIndexWithDistance:()=>Wr,prequantize:()=>mi,quantize:()=>xi,snapColorsToPalette:()=>Ei});var ui={signature:"GIF",version:"89a",trailer:59,extensionIntroducer:33,applicationExtensionLabel:255,graphicControlExtensionLabel:249,imageSeparator:44,signatureSize:3,versionSize:3,globalColorTableFlagMask:128,colorResolutionMask:112,sortFlagMask:8,globalColorTableSizeMask:7,applicationIdentifierSize:8,applicationAuthCodeSize:3,disposalMethodMask:28,userInputFlagMask:2,transparentColorFlagMask:1,localColorTableFlagMask:128,interlaceFlagMask:64,idSortFlagMask:32,localColorTableSizeMask:7};function Or(e=256){var t=0,r=new Uint8Array(e);return{get buffer(){return r.buffer;},reset(){t=0;},bytesView(){return r.subarray(0,t);},bytes(){return r.slice(0,t);},writeByte(i){n(t+1),r[t]=i,t++;},writeBytes(i,o=0,s=i.length){n(t+s);for(var a=0;a<s;a++)r[t++]=i[a+o];},writeBytesView(i,o=0,s=i.byteLength){n(t+s),r.set(i.subarray(o,o+s),t),t+=s;}};function n(i){var o=r.length;if(o>=i)return;var s=1024*1024;i=Math.max(i,o*(o<s?2:1.125)>>>0),o!=0&&(i=Math.max(i,256));var a=r;r=new Uint8Array(i),t>0&&r.set(a.subarray(0,t),0);}}var er=12,Rr=5003,di=[0,1,3,7,15,31,63,127,255,511,1023,2047,4095,8191,16383,32767,65535];function pi(e,t,r,n,i=Or(512),o=new Uint8Array(256),s=new Int32Array(Rr),a=new Int32Array(Rr)){var c=s.length,f=Math.max(2,n);o.fill(0),a.fill(0),s.fill(-1);var l=0,h=0,y=f+1,A=y,C=!1,x=A,E=(1<<x)-1,v=1<<y-1,w=v+1,u=v+2,m=0,d=r[0],D=0;for(var _=c;_<65536;_*=2)++D;D=8-D,i.writeByte(f),B(v);var g=r.length;for(var _2=1;_2<g;_2++)e:{var U=r[_2],P=(U<<er)+d,L=U<<D^d;if(s[L]===P){d=a[L];break e;}var $=L===0?1:c-L;for(;s[L]>=0;)if(L-=$,L<0&&(L+=c),s[L]===P){d=a[L];break e;}B(d),d=U,u<1<<er?(a[L]=u++,s[L]=P):(s.fill(-1),u=v+2,C=!0,B(v));}return B(d),B(w),i.writeByte(0),i.bytesView();function B(_){for(l&=di[h],h>0?l|=_<<h:l=_,h+=x;h>=8;)o[m++]=l&255,m>=254&&(i.writeByte(m),i.writeBytesView(o,0,m),m=0),l>>=8,h-=8;if((u>E||C)&&(C?(x=A,E=(1<<x)-1,C=!1):(++x,E=x===er?1<<x:(1<<x)-1)),_==w){for(;h>0;)o[m++]=l&255,m>=254&&(i.writeByte(m),i.writeBytesView(o,0,m),m=0),l>>=8,h-=8;m>0&&(i.writeByte(m),i.writeBytesView(o,0,m),m=0);}}}var vi=pi;function Lr(e,t,r){return e<<8&63488|t<<2&992|r>>3;}function zr(e,t,r,n){return e>>4|t&240|(r&240)<<4|(n&240)<<8;}function Gr(e,t,r){return e>>4<<8|t&240|r>>4;}function Nt(e,t,r){return e<t?t:e>r?r:e;}function Et(e){return e*e;}function Dr(e,t,r){var n=0,i=1e100;var o=e[t],s=o.cnt,a=o.ac,c=o.rc,f=o.gc,l=o.bc;for(var h=o.fw;h!=0;h=e[h].fw){var A=e[h],C=A.cnt,x=s*C/(s+C);if(!(x>=i)){var y=0;r&&(y+=x*Et(A.ac-a),y>=i)||(y+=x*Et(A.rc-c),!(y>=i)&&(y+=x*Et(A.gc-f),!(y>=i)&&(y+=x*Et(A.bc-l),!(y>=i)&&(i=y,n=h))));}}o.err=i,o.nn=n;}function tr(){return{ac:0,rc:0,gc:0,bc:0,cnt:0,nn:0,fw:0,bk:0,tm:0,mtm:0,err:0};}function gi(e,t){var r=t==="rgb444"?4096:65536,n=new Array(r),i=e.length;if(t==="rgba4444")for(var o=0;o<i;++o){var s=e[o],a=s>>24&255,c=s>>16&255,f=s>>8&255,l=s&255,h=zr(l,f,c,a),y=h in n?n[h]:n[h]=tr();y.rc+=l,y.gc+=f,y.bc+=c,y.ac+=a,y.cnt++;}else if(t==="rgb444")for(var _o2=0;_o2<i;++_o2){var _s=e[_o2],_a=_s>>16&255,_c=_s>>8&255,_f=_s&255,_l=Gr(_f,_c,_a),_h=_l in n?n[_l]:n[_l]=tr();_h.rc+=_f,_h.gc+=_c,_h.bc+=_a,_h.cnt++;}else for(var _o3=0;_o3<i;++_o3){var _s2=e[_o3],_a2=_s2>>16&255,_c2=_s2>>8&255,_f2=_s2&255,_l2=Lr(_f2,_c2,_a2),_h2=_l2 in n?n[_l2]:n[_l2]=tr();_h2.rc+=_f2,_h2.gc+=_c2,_h2.bc+=_a2,_h2.cnt++;}return n;}function xi(e,t,r={}){var{format:n="rgb565",clearAlpha:i=!0,clearAlphaColor:o=0,clearAlphaThreshold:s=0,oneBitAlpha:a=!1}=r;if(!e||!e.buffer)throw new Error("quantize() expected RGBA Uint8Array data");if(!(e instanceof Uint8Array)&&!(e instanceof Uint8ClampedArray))throw new Error("quantize() expected RGBA Uint8Array data");var c=new Uint32Array(e.buffer),f=r.useSqrt!==!1,l=n==="rgba4444",h=gi(c,n),y=h.length,A=y-1,C=new Uint32Array(y+1);for(var x=0,v=0;v<y;++v){var W=h[v];if(W!=null){var E=1/W.cnt;l&&(W.ac*=E),W.rc*=E,W.gc*=E,W.bc*=E,h[x++]=W;}}Et(t)/x<.022&&(f=!1);for(var v=0;v<x-1;++v)h[v].fw=v+1,h[v+1].bk=v,f&&(h[v].cnt=Math.sqrt(h[v].cnt));f&&(h[v].cnt=Math.sqrt(h[v].cnt));var w,u,m;for(v=0;v<x;++v){Dr(h,v,!1);var d=h[v].err;for(u=++C[0];u>1&&(m=u>>1,!(h[w=C[m]].err<=d));u=m)C[u]=w;C[u]=v;}var D=x-t;for(v=0;v<D;){for(var g;;){var B=C[1];if(g=h[B],g.tm>=g.mtm&&h[g.nn].mtm<=g.tm)break;g.mtm==A?B=C[1]=C[C[0]--]:(Dr(h,B,!1),g.tm=v);var d=h[B].err;for(u=1;(m=u+u)<=C[0]&&(m<C[0]&&h[C[m]].err>h[C[m+1]].err&&m++,!(d<=h[w=C[m]].err));u=m)C[u]=w;C[u]=B;}var _=h[g.nn],U=g.cnt,P=_.cnt,E=1/(U+P);l&&(g.ac=E*(U*g.ac+P*_.ac)),g.rc=E*(U*g.rc+P*_.rc),g.gc=E*(U*g.gc+P*_.gc),g.bc=E*(U*g.bc+P*_.bc),g.cnt+=_.cnt,g.mtm=++v,h[_.bk].fw=_.fw,h[_.fw].bk=_.bk,_.mtm=A;}var L=[];var $=0;for(v=0;;++$){var re=Nt(Math.round(h[v].rc),0,255),_W=Nt(Math.round(h[v].gc),0,255),K=Nt(Math.round(h[v].bc),0,255),X=255;l&&(X=Nt(Math.round(h[v].ac),0,255),a&&(X=X<=(typeof a=="number"?a:127)?0:255),i&&X<=s&&(re=_W=K=o,X=0));var j=l?[re,_W,K,X]:[re,_W,K];if(yi(L,j)||L.push(j),(v=h[v].fw)==0)break;}return L;}function yi(e,t){for(var r=0;r<e.length;r++){var n=e[r],i=n[0]===t[0]&&n[1]===t[1]&&n[2]===t[2],o=n.length>=4&&t.length>=4?n[3]===t[3]:!0;if(i&&o)return!0;}return!1;}function Lt(e,t){var r=0,n;for(n=0;n<e.length;n++){var i=e[n]-t[n];r+=i*i;}return r;}function Ot(e,t){return t>1?Math.round(e/t)*t:e;}function mi(e,{roundRGB:t=5,roundAlpha:r=10,oneBitAlpha:n=null}={}){var i=new Uint32Array(e.buffer);for(var o=0;o<i.length;o++){var s=i[o],a=s>>24&255,c=s>>16&255,f=s>>8&255,l=s&255;a=Ot(a,r),n&&(a=a<=(typeof n=="number"?n:127)?0:255),l=Ot(l,t),f=Ot(f,t),c=Ot(c,t),i[o]=a<<24|c<<16|f<<8|l<<0;}}function wi(e,t,r="rgb565"){if(!e||!e.buffer)throw new Error("quantize() expected RGBA Uint8Array data");if(!(e instanceof Uint8Array)&&!(e instanceof Uint8ClampedArray))throw new Error("quantize() expected RGBA Uint8Array data");if(t.length>256)throw new Error("applyPalette() only works with 256 colors or less");var n=new Uint32Array(e.buffer),i=n.length,o=r==="rgb444"?4096:65536,s=new Uint8Array(i),a=new Array(o),c=r==="rgba4444";if(r==="rgba4444")for(var f=0;f<i;f++){var l=n[f],h=l>>24&255,y=l>>16&255,A=l>>8&255,C=l&255,x=zr(C,A,y,h),E=x in a?a[x]:a[x]=Ai(C,A,y,h,t);s[f]=E;}else{var _f3=r==="rgb444"?Gr:Lr;for(var _l3=0;_l3<i;_l3++){var _h3=n[_l3],_y=_h3>>16&255,_A=_h3>>8&255,_C=_h3&255,_x=_f3(_C,_A,_y),_E=_x in a?a[_x]:a[_x]=bi(_C,_A,_y,t);s[_l3]=_E;}}return s;}function Ai(e,t,r,n,i){var o=0,s=1e100;for(var a=0;a<i.length;a++){var c=i[a],f=c[3],l=it(f-n);if(l>s)continue;var h=c[0];if(l+=it(h-e),l>s)continue;var y=c[1];if(l+=it(y-t),l>s)continue;var A=c[2];l+=it(A-r),!(l>s)&&(s=l,o=a);}return o;}function bi(e,t,r,n){var i=0,o=1e100;for(var s=0;s<n.length;s++){var a=n[s],c=a[0],f=it(c-e);if(f>o)continue;var l=a[1];if(f+=it(l-t),f>o)continue;var h=a[2];f+=it(h-r),!(f>o)&&(o=f,i=s);}return i;}function Ei(e,t,r=5){if(!e.length||!t.length)return;var n=e.map(s=>s.slice(0,3)),i=r*r,o=e[0].length;for(var s=0;s<t.length;s++){var a=t[s];a.length<o?a=[a[0],a[1],a[2],255]:a.length>o?a=a.slice(0,3):a=a.slice();var c=Wr(n,a.slice(0,3),Lt),f=c[0],l=c[1];l>0&&l<=i&&(e[f]=a);}}function it(e){return e*e;}function Hr(e,t,r=Lt){var n=1/0,i=-1;for(var o=0;o<e.length;o++){var s=e[o],a=r(t,s);a<n&&(n=a,i=o);}return i;}function Wr(e,t,r=Lt){var n=1/0,i=-1;for(var o=0;o<e.length;o++){var s=e[o],a=r(t,s);a<n&&(n=a,i=o);}return[i,n];}function _i(e,t,r=Lt){return e[Hr(e,t,r)];}function $r(e={}){var{initialCapacity:t=4096,auto:r=!0}=e,n=Or(t),i=5003,o=new Uint8Array(256),s=new Int32Array(i),a=new Int32Array(i),c=!1;return{reset(){n.reset(),c=!1;},finish(){n.writeByte(ui.trailer);},bytes(){return n.bytes();},bytesView(){return n.bytesView();},get buffer(){return n.buffer;},get stream(){return n;},writeHeader:f,writeFrame(l,h,y,A={}){var{transparent:C=!1,transparentIndex:x=0,delay:E=0,palette:v=null,repeat:w=0,colorDepth:u=8,dispose:m=-1}=A,d=!1;if(r?c||(d=!0,f(),c=!0):d=!!A.first,h=Math.max(0,Math.floor(h)),y=Math.max(0,Math.floor(y)),d){if(!v)throw new Error("First frame must include a { palette } option");Ci(n,h,y,v,u),Pr(n,v),w>=0&&ki(n,w);}var D=Math.round(E/10);Si(n,m,D,C,x);var g=!!v&&!d;Ti(n,h,y,g?v:null),g&&Pr(n,v),Fi(n,l,h,y,u,o,s,a);}};function f(){Yr(n,"GIF89a");}}function Si(e,t,r,n,i){e.writeByte(33),e.writeByte(249),e.writeByte(4),i<0&&(i=0,n=!1);var o,s;n?(o=1,s=2):(o=0,s=0),t>=0&&(s=t&7),s<<=2,e.writeByte(0|s|0|o),Qe(e,r),e.writeByte(i||0),e.writeByte(0);}function Ci(e,t,r,n,i=8){var a=rr(n.length)-1,c=128|i-1<<4|0|a,f=0,l=0;Qe(e,t),Qe(e,r),e.writeBytes([c,f,l]);}function ki(e,t){e.writeByte(33),e.writeByte(255),e.writeByte(11),Yr(e,"NETSCAPE2.0"),e.writeByte(3),e.writeByte(1),Qe(e,t),e.writeByte(0);}function Pr(e,t){var r=1<<rr(t.length);for(var n=0;n<r;n++){var i=[0,0,0];n<t.length&&(i=t[n]),e.writeByte(i[0]),e.writeByte(i[1]),e.writeByte(i[2]);}}function Ti(e,t,r,n){if(e.writeByte(44),Qe(e,0),Qe(e,0),Qe(e,t),Qe(e,r),n){var s=rr(n.length)-1;e.writeByte(128|s);}else e.writeByte(0);}function Fi(e,t,r,n,i=8,o,s,a){vi(r,n,t,i,e,o,s,a);}function Qe(e,t){e.writeByte(t&255),e.writeByte(t>>8&255);}function Yr(e,t){for(var r=0;r<t.length;r++)e.writeByte(t.charCodeAt(r));}function rr(e){return Math.max(Math.ceil(Math.log2(e)),1);}var Ui=$r;});var or=ut(zt=>{"use strict";zt.byteLength=Bi;zt.toByteArray=Ri;zt.fromByteArray=Ni;var We=[],Oe=[],Ii=typeof Uint8Array<"u"?Uint8Array:Array,ir="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";for(ot=0,Kr=ir.length;ot<Kr;++ot)We[ot]=ir[ot],Oe[ir.charCodeAt(ot)]=ot;var ot,Kr;Oe[45]=62;Oe[95]=63;function Vr(e){var t=e.length;if(t%4>0)throw new Error("Invalid string. Length must be a multiple of 4");var r=e.indexOf("=");r===-1&&(r=t);var n=r===t?0:4-r%4;return[r,n];}function Bi(e){var t=Vr(e),r=t[0],n=t[1];return(r+n)*3/4-n;}function Mi(e,t,r){return(t+r)*3/4-r;}function Ri(e){var t,r=Vr(e),n=r[0],i=r[1],o=new Ii(Mi(e,n,i)),s=0,a=i>0?n-4:n,c;for(c=0;c<a;c+=4)t=Oe[e.charCodeAt(c)]<<18|Oe[e.charCodeAt(c+1)]<<12|Oe[e.charCodeAt(c+2)]<<6|Oe[e.charCodeAt(c+3)],o[s++]=t>>16&255,o[s++]=t>>8&255,o[s++]=t&255;return i===2&&(t=Oe[e.charCodeAt(c)]<<2|Oe[e.charCodeAt(c+1)]>>4,o[s++]=t&255),i===1&&(t=Oe[e.charCodeAt(c)]<<10|Oe[e.charCodeAt(c+1)]<<4|Oe[e.charCodeAt(c+2)]>>2,o[s++]=t>>8&255,o[s++]=t&255),o;}function Di(e){return We[e>>18&63]+We[e>>12&63]+We[e>>6&63]+We[e&63];}function Pi(e,t,r){for(var n,i=[],o=t;o<r;o+=3)n=(e[o]<<16&16711680)+(e[o+1]<<8&65280)+(e[o+2]&255),i.push(Di(n));return i.join("");}function Ni(e){for(var t,r=e.length,n=r%3,i=[],o=16383,s=0,a=r-n;s<a;s+=o)i.push(Pi(e,s,s+o>a?a:s+o));return n===1?(t=e[r-1],i.push(We[t>>2]+We[t<<4&63]+"==")):n===2&&(t=(e[r-2]<<8)+e[r-1],i.push(We[t>>10]+We[t>>4&63]+We[t<<2&63]+"=")),i.join("");}});var Yn=ut((Ls,qt)=>{var $n=$n||function(e){return Buffer.from(e).toString("base64");};function Co(e){var t=this,r=Math.round,n=Math.floor,i=new Array(64),o=new Array(64),s=new Array(64),a=new Array(64),c,f,l,h,y=new Array(65535),A=new Array(65535),C=new Array(64),x=new Array(64),E=[],v=0,w=7,u=new Array(64),m=new Array(64),d=new Array(64),D=new Array(256),g=new Array(2048),B,_=[0,1,5,6,14,15,27,28,2,4,7,13,16,26,29,42,3,8,12,17,25,30,41,43,9,11,18,24,31,40,44,53,10,19,23,32,39,45,52,54,20,22,33,38,46,51,55,60,21,34,37,47,50,56,59,61,35,36,48,49,57,58,62,63],U=[0,0,1,5,1,1,1,1,1,1,0,0,0,0,0,0,0],P=[0,1,2,3,4,5,6,7,8,9,10,11],L=[0,0,2,1,3,3,2,4,3,5,5,4,4,0,0,1,125],$=[1,2,3,0,4,17,5,18,33,49,65,6,19,81,97,7,34,113,20,50,129,145,161,8,35,66,177,193,21,82,209,240,36,51,98,114,130,9,10,22,23,24,25,26,37,38,39,40,41,42,52,53,54,55,56,57,58,67,68,69,70,71,72,73,74,83,84,85,86,87,88,89,90,99,100,101,102,103,104,105,106,115,116,117,118,119,120,121,122,131,132,133,134,135,136,137,138,146,147,148,149,150,151,152,153,154,162,163,164,165,166,167,168,169,170,178,179,180,181,182,183,184,185,186,194,195,196,197,198,199,200,201,202,210,211,212,213,214,215,216,217,218,225,226,227,228,229,230,231,232,233,234,241,242,243,244,245,246,247,248,249,250],re=[0,0,3,1,1,1,1,1,1,1,1,1,0,0,0,0,0],W=[0,1,2,3,4,5,6,7,8,9,10,11],K=[0,0,2,1,2,4,4,3,4,7,5,4,4,0,1,2,119],X=[0,1,2,3,17,4,5,33,49,6,18,65,81,7,97,113,19,34,50,129,8,20,66,145,161,177,193,9,35,51,82,240,21,98,114,209,10,22,36,52,225,37,241,23,24,25,26,38,39,40,41,42,53,54,55,56,57,58,67,68,69,70,71,72,73,74,83,84,85,86,87,88,89,90,99,100,101,102,103,104,105,106,115,116,117,118,119,120,121,122,130,131,132,133,134,135,136,137,138,146,147,148,149,150,151,152,153,154,162,163,164,165,166,167,168,169,170,178,179,180,181,182,183,184,185,186,194,195,196,197,198,199,200,201,202,210,211,212,213,214,215,216,217,218,226,227,228,229,230,231,232,233,234,242,243,244,245,246,247,248,249,250];function j(k){for(var p=[16,11,10,16,24,40,51,61,12,12,14,19,26,58,60,55,14,13,16,24,40,57,69,56,14,17,22,29,51,87,80,62,18,22,37,56,68,109,103,77,24,35,55,64,81,104,113,92,49,64,78,87,103,121,120,101,72,92,95,98,112,100,103,99],R=0;R<64;R++){var I=n((p[R]*k+50)/100);I<1?I=1:I>255&&(I=255),i[_[R]]=I;}for(var F=[17,18,24,47,99,99,99,99,18,21,26,66,99,99,99,99,24,26,56,99,99,99,99,99,47,66,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],S=0;S<64;S++){var N=n((F[S]*k+50)/100);N<1?N=1:N>255&&(N=255),o[_[S]]=N;}for(var Y=[1,1.387039845,1.306562965,1.175875602,1,.785694958,.5411961,.275899379],V=0,oe=0;oe<8;oe++)for(var T=0;T<8;T++)s[V]=1/(i[_[V]]*Y[oe]*Y[T]*8),a[V]=1/(o[_[V]]*Y[oe]*Y[T]*8),V++;}function q(k,p){for(var R=0,I=0,F=new Array(),S=1;S<=16;S++){for(var N=1;N<=k[S];N++)F[p[I]]=[],F[p[I]][0]=R,F[p[I]][1]=S,I++,R++;R*=2;}return F;}function xe(){c=q(U,P),f=q(re,W),l=q(L,$),h=q(K,X);}function ie(){for(var k=1,p=2,R=1;R<=15;R++){for(var I=k;I<p;I++)A[32767+I]=R,y[32767+I]=[],y[32767+I][1]=R,y[32767+I][0]=I;for(var F=-(p-1);F<=-k;F++)A[32767+F]=R,y[32767+F]=[],y[32767+F][1]=R,y[32767+F][0]=p-1+F;k<<=1,p<<=1;}}function ne(){for(var k=0;k<256;k++)g[k]=19595*k,g[k+256>>0]=38470*k,g[k+512>>0]=7471*k+32768,g[k+768>>0]=-11059*k,g[k+1024>>0]=-21709*k,g[k+1280>>0]=32768*k+8421375,g[k+1536>>0]=-27439*k,g[k+1792>>0]=-5329*k;}function Z(k){for(var p=k[0],R=k[1]-1;R>=0;)p&1<<R&&(v|=1<<w),R--,w--,w<0&&(v==255?(b(255),b(0)):b(v),w=7,v=0);}function b(k){E.push(k);}function z(k){b(k>>8&255),b(k&255);}function ce(k,p){var R,I,F,S,N,Y,V,oe,T=0,H,Q=8,ge=64;for(H=0;H<Q;++H){R=k[T],I=k[T+1],F=k[T+2],S=k[T+3],N=k[T+4],Y=k[T+5],V=k[T+6],oe=k[T+7];var M=R+oe,ee=R-oe,fe=I+V,te=I-V,pe=F+Y,Ee=F-Y,me=S+N,Ae=S-N,Ue=M+me,Pe=M-me,Ne=fe+pe,Ie=fe-pe;k[T]=Ue+Ne,k[T+4]=Ue-Ne;var Te=(Ie+Pe)*.707106781;k[T+2]=Pe+Te,k[T+6]=Pe-Te,Ue=Ae+Ee,Ne=Ee+te,Ie=te+ee;var _e=(Ue-Ie)*.382683433,rt=.5411961*Ue+_e,qe=1.306562965*Ie+_e,Ge=Ne*.707106781,nt=ee+Ge,Ze=ee-Ge;k[T+5]=Ze+rt,k[T+3]=Ze-rt,k[T+1]=nt+qe,k[T+7]=nt-qe,T+=8;}for(T=0,H=0;H<Q;++H){R=k[T],I=k[T+8],F=k[T+16],S=k[T+24],N=k[T+32],Y=k[T+40],V=k[T+48],oe=k[T+56];var vt=R+oe,lt=R-oe,gt=I+V,xt=I-V,yt=F+Y,mt=F-Y,ct=S+N,Dt=S-N,he=vt+ct,Se=vt-ct,be=gt+yt,He=gt-yt;k[T]=he+be,k[T+32]=he-be;var Je=(He+Se)*.707106781;k[T+16]=Se+Je,k[T+48]=Se-Je,he=Dt+mt,be=mt+xt,He=xt+lt;var Be=(he-He)*.382683433,wt=.5411961*he+Be,ft=1.306562965*He+Be,ht=be*.707106781,Fr=lt+ht,Ur=lt-ht;k[T+40]=Ur+wt,k[T+24]=Ur-wt,k[T+8]=Fr+ft,k[T+56]=Fr-ft,T++;}var Pt;for(H=0;H<ge;++H)Pt=k[H]*p[H],C[H]=Pt>0?Pt+.5|0:Pt-.5|0;return C;}function ve(){z(65504),z(16),b(74),b(70),b(73),b(70),b(0),b(1),b(1),b(0),z(1),z(1),b(0),b(0);}function J(k){if(k){z(65505),k[0]===69&&k[1]===120&&k[2]===105&&k[3]===102?z(k.length+2):(z(k.length+5+2),b(69),b(120),b(105),b(102),b(0));for(var p=0;p<k.length;p++)b(k[p]);}}function le(k,p){z(65472),z(17),b(8),z(p),z(k),b(3),b(1),b(17),b(0),b(2),b(17),b(1),b(3),b(17),b(1);}function ae(){z(65499),z(132),b(0);for(var k=0;k<64;k++)b(i[k]);b(1);for(var p=0;p<64;p++)b(o[p]);}function G(){z(65476),z(418),b(0);for(var k=0;k<16;k++)b(U[k+1]);for(var p=0;p<=11;p++)b(P[p]);b(16);for(var R=0;R<16;R++)b(L[R+1]);for(var I=0;I<=161;I++)b($[I]);b(1);for(var F=0;F<16;F++)b(re[F+1]);for(var S=0;S<=11;S++)b(W[S]);b(17);for(var N=0;N<16;N++)b(K[N+1]);for(var Y=0;Y<=161;Y++)b(X[Y]);}function O(k){typeof k>"u"||k.constructor!==Array||k.forEach(p=>{if(typeof p=="string"){z(65534);var R=p.length;z(R+2);var I;for(I=0;I<R;I++)b(p.charCodeAt(I));}});}function ue(){z(65498),z(12),b(3),b(1),b(0),b(2),b(17),b(3),b(17),b(0),b(63),b(0);}function se(k,p,R,I,F){for(var S=F[0],N=F[240],Y,V=16,oe=63,T=64,H=ce(k,p),Q=0;Q<T;++Q)x[_[Q]]=H[Q];var ge=x[0]-R;R=x[0],ge==0?Z(I[0]):(Y=32767+ge,Z(I[A[Y]]),Z(y[Y]));for(var M=63;M>0&&x[M]==0;M--);if(M==0)return Z(S),R;for(var ee=1,fe;ee<=M;){for(var te=ee;x[ee]==0&&ee<=M;++ee);var pe=ee-te;if(pe>=V){fe=pe>>4;for(var Ee=1;Ee<=fe;++Ee)Z(N);pe=pe&15;}Y=32767+x[ee],Z(F[(pe<<4)+A[Y]]),Z(y[Y]),ee++;}return M!=oe&&Z(S),R;}function de(){for(var k=String.fromCharCode,p=0;p<256;p++)D[p]=k(p);}this.encode=function(k,p){var R=new Date().getTime();p&&Fe(p),E=new Array(),v=0,w=7,z(65496),ve(),O(k.comments),J(k.exifBuffer),ae(),le(k.width,k.height),G(),ue();var I=0,F=0,S=0;v=0,w=7,this.encode.displayName="_encode_";for(var N=k.data,Y=k.width,V=k.height,oe=Y*4,T=Y*3,H,Q=0,ge,M,ee,fe,te,pe,Ee,me;Q<V;){for(H=0;H<oe;){for(fe=oe*Q+H,te=fe,pe=-1,Ee=0,me=0;me<64;me++)Ee=me>>3,pe=(me&7)*4,te=fe+Ee*oe+pe,Q+Ee>=V&&(te-=oe*(Q+1+Ee-V)),H+pe>=oe&&(te-=H+pe-oe+4),ge=N[te++],M=N[te++],ee=N[te++],u[me]=(g[ge]+g[M+256>>0]+g[ee+512>>0]>>16)-128,m[me]=(g[ge+768>>0]+g[M+1024>>0]+g[ee+1280>>0]>>16)-128,d[me]=(g[ge+1280>>0]+g[M+1536>>0]+g[ee+1792>>0]>>16)-128;I=se(u,s,I,c,l),F=se(m,a,F,f,h),S=se(d,a,S,f,h),H+=32;}Q+=8;}if(w>=0){var Ae=[];Ae[1]=w+1,Ae[0]=(1<<w+1)-1,Z(Ae);}if(z(65497),typeof qt>"u")return new Uint8Array(E);return Buffer.from(E);var Ue,Pe;};function Fe(k){if(k<=0&&(k=1),k>100&&(k=100),B!=k){var p=0;k<50?p=Math.floor(5e3/k):p=Math.floor(200-k*2),j(p),B=k;}}function Re(){var k=new Date().getTime();e||(e=50),de(),xe(),ie(),ne(),Fe(e);var p=new Date().getTime()-k;}Re();}typeof qt<"u"?qt.exports=Wn:typeof window<"u"&&(window["jpeg-js"]=window["jpeg-js"]||{},window["jpeg-js"].encode=Wn);function Wn(e,t){typeof t>"u"&&(t=50);var r=new Co(t),n=r.encode(e,t);return{data:n,width:e.width,height:e.height};}});var Kn=ut((zs,Cr)=>{var Sr=function(){"use strict";var t=new Int32Array([0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63]),r=4017,n=799,i=3406,o=2276,s=1567,a=3784,c=5793,f=2896;function l(){}function h(w,u){for(var m=0,d=[],D,g,B=16;B>0&&!w[B-1];)B--;d.push({children:[],index:0});var _=d[0],U;for(D=0;D<B;D++){for(g=0;g<w[D];g++){for(_=d.pop(),_.children[_.index]=u[m];_.index>0;){if(d.length===0)throw new Error("Could not recreate Huffman Table");_=d.pop();}for(_.index++,d.push(_);d.length<=D;)d.push(U={children:[],index:0}),_.children[_.index]=U.children,_=U;m++;}D+1<B&&(d.push(U={children:[],index:0}),_.children[_.index]=U.children,_=U);}return d[0].children;}function y(w,u,m,d,D,g,B,_,U,P){var L=m.precision,$=m.samplesPerLine,re=m.scanLines,W=m.mcusPerLine,K=m.progressive,X=m.maxH,j=m.maxV,q=u,xe=0,ie=0;function ne(){if(ie>0)return ie--,xe>>ie&1;if(xe=w[u++],xe==255){var T=w[u++];if(T)throw new Error("unexpected marker: "+(xe<<8|T).toString(16));}return ie=7,xe>>>7;}function Z(T){for(var H=T,Q;(Q=ne())!==null;){if(H=H[Q],typeof H=="number")return H;if(typeof H!="object")throw new Error("invalid huffman sequence");}return null;}function b(T){for(var H=0;T>0;){var Q=ne();if(Q===null)return;H=H<<1|Q,T--;}return H;}function z(T){var H=b(T);return H>=1<<T-1?H:H+(-1<<T)+1;}function ce(T,H){var Q=Z(T.huffmanTableDC),ge=Q===0?0:z(Q);H[0]=T.pred+=ge;for(var M=1;M<64;){var ee=Z(T.huffmanTableAC),fe=ee&15,te=ee>>4;if(fe===0){if(te<15)break;M+=16;continue;}M+=te;var pe=t[M];H[pe]=z(fe),M++;}}function ve(T,H){var Q=Z(T.huffmanTableDC),ge=Q===0?0:z(Q)<<U;H[0]=T.pred+=ge;}function J(T,H){H[0]|=ne()<<U;}var le=0;function ae(T,H){if(le>0){le--;return;}for(var Q=g,ge=B;Q<=ge;){var M=Z(T.huffmanTableAC),ee=M&15,fe=M>>4;if(ee===0){if(fe<15){le=b(fe)+(1<<fe)-1;break;}Q+=16;continue;}Q+=fe;var te=t[Q];H[te]=z(ee)*(1<<U),Q++;}}var G=0,O;function ue(T,H){for(var Q=g,ge=B,M=0;Q<=ge;){var ee=t[Q],fe=H[ee]<0?-1:1;switch(G){case 0:var te=Z(T.huffmanTableAC),pe=te&15,M=te>>4;if(pe===0)M<15?(le=b(M)+(1<<M),G=4):(M=16,G=1);else{if(pe!==1)throw new Error("invalid ACn encoding");O=z(pe),G=M?2:3;}continue;case 1:case 2:H[ee]?H[ee]+=(ne()<<U)*fe:(M--,M===0&&(G=G==2?3:0));break;case 3:H[ee]?H[ee]+=(ne()<<U)*fe:(H[ee]=O<<U,G=0);break;case 4:H[ee]&&(H[ee]+=(ne()<<U)*fe);break;}Q++;}G===4&&(le--,le===0&&(G=0));}function se(T,H,Q,ge,M){var ee=Q/W|0,fe=Q%W,te=ee*T.v+ge,pe=fe*T.h+M;T.blocks[te]===void 0&&P.tolerantDecoding||H(T,T.blocks[te][pe]);}function de(T,H,Q){var ge=Q/T.blocksPerLine|0,M=Q%T.blocksPerLine;T.blocks[ge]===void 0&&P.tolerantDecoding||H(T,T.blocks[ge][M]);}var Fe=d.length,Re,k,p,R,I,F;K?g===0?F=_===0?ve:J:F=_===0?ae:ue:F=ce;var S=0,N,Y;Fe==1?Y=d[0].blocksPerLine*d[0].blocksPerColumn:Y=W*m.mcusPerColumn,D||(D=Y);for(var V,oe;S<Y;){for(k=0;k<Fe;k++)d[k].pred=0;if(le=0,Fe==1)for(Re=d[0],I=0;I<D;I++)de(Re,F,S),S++;else for(I=0;I<D;I++){for(k=0;k<Fe;k++)for(Re=d[k],V=Re.h,oe=Re.v,p=0;p<oe;p++)for(R=0;R<V;R++)se(Re,F,S,p,R);if(S++,S===Y)break;}if(S===Y)do{if(w[u]===255&&w[u+1]!==0)break;u+=1;}while(u<w.length-2);if(ie=0,N=w[u]<<8|w[u+1],N<65280)throw new Error("marker was not found");if(N>=65488&&N<=65495)u+=2;else break;}return u-q;}function A(w,u){var m=[],d=u.blocksPerLine,D=u.blocksPerColumn,g=d<<3,B=new Int32Array(64),_=new Uint8Array(64);function U(q,xe,ie){var ne=u.quantizationTable,Z,b,z,ce,ve,J,le,ae,G,O=ie,ue;for(ue=0;ue<64;ue++)O[ue]=q[ue]*ne[ue];for(ue=0;ue<8;++ue){var se=8*ue;if(O[1+se]==0&&O[2+se]==0&&O[3+se]==0&&O[4+se]==0&&O[5+se]==0&&O[6+se]==0&&O[7+se]==0){G=c*O[0+se]+512>>10,O[0+se]=G,O[1+se]=G,O[2+se]=G,O[3+se]=G,O[4+se]=G,O[5+se]=G,O[6+se]=G,O[7+se]=G;continue;}Z=c*O[0+se]+128>>8,b=c*O[4+se]+128>>8,z=O[2+se],ce=O[6+se],ve=f*(O[1+se]-O[7+se])+128>>8,ae=f*(O[1+se]+O[7+se])+128>>8,J=O[3+se]<<4,le=O[5+se]<<4,G=Z-b+1>>1,Z=Z+b+1>>1,b=G,G=z*a+ce*s+128>>8,z=z*s-ce*a+128>>8,ce=G,G=ve-le+1>>1,ve=ve+le+1>>1,le=G,G=ae+J+1>>1,J=ae-J+1>>1,ae=G,G=Z-ce+1>>1,Z=Z+ce+1>>1,ce=G,G=b-z+1>>1,b=b+z+1>>1,z=G,G=ve*o+ae*i+2048>>12,ve=ve*i-ae*o+2048>>12,ae=G,G=J*n+le*r+2048>>12,J=J*r-le*n+2048>>12,le=G,O[0+se]=Z+ae,O[7+se]=Z-ae,O[1+se]=b+le,O[6+se]=b-le,O[2+se]=z+J,O[5+se]=z-J,O[3+se]=ce+ve,O[4+se]=ce-ve;}for(ue=0;ue<8;++ue){var de=ue;if(O[8+de]==0&&O[16+de]==0&&O[24+de]==0&&O[32+de]==0&&O[40+de]==0&&O[48+de]==0&&O[56+de]==0){G=c*ie[ue+0]+8192>>14,O[0+de]=G,O[8+de]=G,O[16+de]=G,O[24+de]=G,O[32+de]=G,O[40+de]=G,O[48+de]=G,O[56+de]=G;continue;}Z=c*O[0+de]+2048>>12,b=c*O[32+de]+2048>>12,z=O[16+de],ce=O[48+de],ve=f*(O[8+de]-O[56+de])+2048>>12,ae=f*(O[8+de]+O[56+de])+2048>>12,J=O[24+de],le=O[40+de],G=Z-b+1>>1,Z=Z+b+1>>1,b=G,G=z*a+ce*s+2048>>12,z=z*s-ce*a+2048>>12,ce=G,G=ve-le+1>>1,ve=ve+le+1>>1,le=G,G=ae+J+1>>1,J=ae-J+1>>1,ae=G,G=Z-ce+1>>1,Z=Z+ce+1>>1,ce=G,G=b-z+1>>1,b=b+z+1>>1,z=G,G=ve*o+ae*i+2048>>12,ve=ve*i-ae*o+2048>>12,ae=G,G=J*n+le*r+2048>>12,J=J*r-le*n+2048>>12,le=G,O[0+de]=Z+ae,O[56+de]=Z-ae,O[8+de]=b+le,O[48+de]=b-le,O[16+de]=z+J,O[40+de]=z-J,O[24+de]=ce+ve,O[32+de]=ce-ve;}for(ue=0;ue<64;++ue){var Fe=128+(O[ue]+8>>4);xe[ue]=Fe<0?0:Fe>255?255:Fe;}}v(g*D*8);for(var P,L,$=0;$<D;$++){var re=$<<3;for(P=0;P<8;P++)m.push(new Uint8Array(g));for(var W=0;W<d;W++){U(u.blocks[$][W],_,B);var K=0,X=W<<3;for(L=0;L<8;L++){var j=m[re+L];for(P=0;P<8;P++)j[X+P]=_[K++];}}}return m;}function C(w){return w<0?0:w>255?255:w;}l.prototype={load:function(u){var m=new XMLHttpRequest();m.open("GET",u,!0),m.responseType="arraybuffer",m.onload=function(){var d=new Uint8Array(m.response||m.mozResponseArrayBuffer);this.parse(d),this.onload&&this.onload();}.bind(this),m.send(null);},parse:function(u){var m=this.opts.maxResolutionInMP*1e3*1e3,d=0,D=u.length;function g(){var te=u[d]<<8|u[d+1];return d+=2,te;}function B(){var te=g(),pe=u.subarray(d,d+te-2);return d+=pe.length,pe;}function _(te){var pe=1,Ee=1,me,Ae;for(Ae in te.components)te.components.hasOwnProperty(Ae)&&(me=te.components[Ae],pe<me.h&&(pe=me.h),Ee<me.v&&(Ee=me.v));var Ue=Math.ceil(te.samplesPerLine/8/pe),Pe=Math.ceil(te.scanLines/8/Ee);for(Ae in te.components)if(te.components.hasOwnProperty(Ae)){me=te.components[Ae];var Ne=Math.ceil(Math.ceil(te.samplesPerLine/8)*me.h/pe),Ie=Math.ceil(Math.ceil(te.scanLines/8)*me.v/Ee),Te=Ue*me.h,_e=Pe*me.v,rt=_e*Te,qe=[];v(rt*256);for(var Ge=0;Ge<_e;Ge++){for(var nt=[],Ze=0;Ze<Te;Ze++)nt.push(new Int32Array(64));qe.push(nt);}me.blocksPerLine=Ne,me.blocksPerColumn=Ie,me.blocks=qe;}te.maxH=pe,te.maxV=Ee,te.mcusPerLine=Ue,te.mcusPerColumn=Pe;}var U=null,P=null,L=null,$,re,W=[],K=[],X=[],j=[],q=g(),xe=-1;if(this.comments=[],q!=65496)throw new Error("SOI not found");for(q=g();q!=65497;){var ie,ne,Z;switch(q){case 65280:break;case 65504:case 65505:case 65506:case 65507:case 65508:case 65509:case 65510:case 65511:case 65512:case 65513:case 65514:case 65515:case 65516:case 65517:case 65518:case 65519:case 65534:var b=B();if(q===65534){var z=String.fromCharCode.apply(null,b);this.comments.push(z);}q===65504&&b[0]===74&&b[1]===70&&b[2]===73&&b[3]===70&&b[4]===0&&(U={version:{major:b[5],minor:b[6]},densityUnits:b[7],xDensity:b[8]<<8|b[9],yDensity:b[10]<<8|b[11],thumbWidth:b[12],thumbHeight:b[13],thumbData:b.subarray(14,14+3*b[12]*b[13])}),q===65505&&b[0]===69&&b[1]===120&&b[2]===105&&b[3]===102&&b[4]===0&&(this.exifBuffer=b.subarray(5,b.length)),q===65518&&b[0]===65&&b[1]===100&&b[2]===111&&b[3]===98&&b[4]===101&&b[5]===0&&(P={version:b[6],flags0:b[7]<<8|b[8],flags1:b[9]<<8|b[10],transformCode:b[11]});break;case 65499:for(var ce=g(),ve=ce+d-2;d<ve;){var J=u[d++];v(256);var le=new Int32Array(64);if(J>>4===0)for(ne=0;ne<64;ne++){var ae=t[ne];le[ae]=u[d++];}else if(J>>4===1)for(ne=0;ne<64;ne++){var ae=t[ne];le[ae]=g();}else throw new Error("DQT: invalid table spec");W[J&15]=le;}break;case 65472:case 65473:case 65474:g(),$={},$.extended=q===65473,$.progressive=q===65474,$.precision=u[d++],$.scanLines=g(),$.samplesPerLine=g(),$.components={},$.componentsOrder=[];var G=$.scanLines*$.samplesPerLine;if(G>m){var O=Math.ceil((G-m)/1e6);throw new Error(`maxResolutionInMP limit exceeded by ${O}MP`);}var ue=u[d++],se,de=0,Fe=0;for(ie=0;ie<ue;ie++){se=u[d];var Re=u[d+1]>>4,k=u[d+1]&15,p=u[d+2];if(Re<=0||k<=0)throw new Error("Invalid sampling factor, expected values above 0");$.componentsOrder.push(se),$.components[se]={h:Re,v:k,quantizationIdx:p},d+=3;}_($),K.push($);break;case 65476:var R=g();for(ie=2;ie<R;){var I=u[d++],F=new Uint8Array(16),S=0;for(ne=0;ne<16;ne++,d++)S+=F[ne]=u[d];v(16+S);var N=new Uint8Array(S);for(ne=0;ne<S;ne++,d++)N[ne]=u[d];ie+=17+S,(I>>4===0?j:X)[I&15]=h(F,N);}break;case 65501:g(),re=g();break;case 65500:g(),g();break;case 65498:var Y=g(),V=u[d++],oe=[],T;for(ie=0;ie<V;ie++){T=$.components[u[d++]];var H=u[d++];T.huffmanTableDC=j[H>>4],T.huffmanTableAC=X[H&15],oe.push(T);}var Q=u[d++],ge=u[d++],M=u[d++],ee=y(u,d,$,oe,re,Q,ge,M>>4,M&15,this.opts);d+=ee;break;case 65535:u[d]!==255&&d--;break;default:if(u[d-3]==255&&u[d-2]>=192&&u[d-2]<=254){d-=3;break;}else if(q===224||q==225){if(xe!==-1)throw new Error(`first unknown JPEG marker at offset ${xe.toString(16)}, second unknown JPEG marker ${q.toString(16)} at offset ${(d-1).toString(16)}`);xe=d-1;var te=g();if(u[d+te-2]===255){d+=te-2;break;}}throw new Error("unknown JPEG marker "+q.toString(16));}q=g();}if(K.length!=1)throw new Error("only single frame JPEGs supported");for(var ie=0;ie<K.length;ie++){var fe=K[ie].components;for(var ne in fe)fe[ne].quantizationTable=W[fe[ne].quantizationIdx],delete fe[ne].quantizationIdx;}this.width=$.samplesPerLine,this.height=$.scanLines,this.jfif=U,this.adobe=P,this.components=[];for(var ie=0;ie<$.componentsOrder.length;ie++){var T=$.components[$.componentsOrder[ie]];this.components.push({lines:A($,T),scaleX:T.h/$.maxH,scaleY:T.v/$.maxV});}},getData:function(u,m){var d=this.width/u,D=this.height/m,g,B,_,U,P,L,$,re,W,K,X=0,j,q,xe,ie,ne,Z,b,z,ce,ve,J,le=u*m*this.components.length;v(le);var ae=new Uint8Array(le);switch(this.components.length){case 1:for(g=this.components[0],K=0;K<m;K++)for(P=g.lines[0|K*g.scaleY*D],W=0;W<u;W++)j=P[0|W*g.scaleX*d],ae[X++]=j;break;case 2:for(g=this.components[0],B=this.components[1],K=0;K<m;K++)for(P=g.lines[0|K*g.scaleY*D],L=B.lines[0|K*B.scaleY*D],W=0;W<u;W++)j=P[0|W*g.scaleX*d],ae[X++]=j,j=L[0|W*B.scaleX*d],ae[X++]=j;break;case 3:for(J=!0,this.adobe&&this.adobe.transformCode?J=!0:typeof this.opts.colorTransform<"u"&&(J=!!this.opts.colorTransform),g=this.components[0],B=this.components[1],_=this.components[2],K=0;K<m;K++)for(P=g.lines[0|K*g.scaleY*D],L=B.lines[0|K*B.scaleY*D],$=_.lines[0|K*_.scaleY*D],W=0;W<u;W++)J?(j=P[0|W*g.scaleX*d],q=L[0|W*B.scaleX*d],xe=$[0|W*_.scaleX*d],z=C(j+1.402*(xe-128)),ce=C(j-.3441363*(q-128)-.71413636*(xe-128)),ve=C(j+1.772*(q-128))):(z=P[0|W*g.scaleX*d],ce=L[0|W*B.scaleX*d],ve=$[0|W*_.scaleX*d]),ae[X++]=z,ae[X++]=ce,ae[X++]=ve;break;case 4:if(!this.adobe)throw new Error("Unsupported color mode (4 components)");for(J=!1,this.adobe&&this.adobe.transformCode?J=!0:typeof this.opts.colorTransform<"u"&&(J=!!this.opts.colorTransform),g=this.components[0],B=this.components[1],_=this.components[2],U=this.components[3],K=0;K<m;K++)for(P=g.lines[0|K*g.scaleY*D],L=B.lines[0|K*B.scaleY*D],$=_.lines[0|K*_.scaleY*D],re=U.lines[0|K*U.scaleY*D],W=0;W<u;W++)J?(j=P[0|W*g.scaleX*d],q=L[0|W*B.scaleX*d],xe=$[0|W*_.scaleX*d],ie=re[0|W*U.scaleX*d],ne=255-C(j+1.402*(xe-128)),Z=255-C(j-.3441363*(q-128)-.71413636*(xe-128)),b=255-C(j+1.772*(q-128))):(ne=P[0|W*g.scaleX*d],Z=L[0|W*B.scaleX*d],b=$[0|W*_.scaleX*d],ie=re[0|W*U.scaleX*d]),ae[X++]=255-ne,ae[X++]=255-Z,ae[X++]=255-b,ae[X++]=255-ie;break;default:throw new Error("Unsupported color mode");}return ae;},copyToImageData:function(u,m){var d=u.width,D=u.height,g=u.data,B=this.getData(d,D),_=0,U=0,P,L,$,re,W,K,X,j,q;switch(this.components.length){case 1:for(L=0;L<D;L++)for(P=0;P<d;P++)$=B[_++],g[U++]=$,g[U++]=$,g[U++]=$,m&&(g[U++]=255);break;case 3:for(L=0;L<D;L++)for(P=0;P<d;P++)X=B[_++],j=B[_++],q=B[_++],g[U++]=X,g[U++]=j,g[U++]=q,m&&(g[U++]=255);break;case 4:for(L=0;L<D;L++)for(P=0;P<d;P++)W=B[_++],K=B[_++],$=B[_++],re=B[_++],X=255-C(W*(1-re/255)+re),j=255-C(K*(1-re/255)+re),q=255-C($*(1-re/255)+re),g[U++]=X,g[U++]=j,g[U++]=q,m&&(g[U++]=255);break;default:throw new Error("Unsupported color mode");}}};var x=0,E=0;function v(w=0){var u=x+w;if(u>E){var m=Math.ceil((u-E)/1024/1024);throw new Error(`maxMemoryUsageInMB limit exceeded by at least ${m}MB`);}x=u;}return l.resetMaxMemoryUsage=function(w){x=0,E=w;},l.getBytesAllocated=function(){return x;},l.requestMemoryAllocation=v,l;}();typeof Cr<"u"?Cr.exports=jn:typeof window<"u"&&(window["jpeg-js"]=window["jpeg-js"]||{},window["jpeg-js"].decode=jn);function jn(e,t={}){var r={colorTransform:void 0,useTArray:!1,formatAsRGBA:!0,tolerantDecoding:!0,maxResolutionInMP:100,maxMemoryUsageInMB:512},n={...r,...t},i=new Uint8Array(e),o=new Sr();o.opts=n,Sr.resetMaxMemoryUsage(n.maxMemoryUsageInMB*1024*1024),o.parse(i);var s=n.formatAsRGBA?4:3,a=o.width*o.height*s;try{Sr.requestMemoryAllocation(a);var c={width:o.width,height:o.height,exifBuffer:o.exifBuffer,data:n.useTArray?new Uint8Array(a):Buffer.alloc(a)};o.comments.length>0&&(c.comments=o.comments);}catch(f){throw f instanceof RangeError?new Error("Could not allocate enough memory for the image. Required: "+a):f instanceof ReferenceError&&f.message==="Buffer is not defined"?new Error("Buffer is not globally defined in this environment. Consider setting useTArray to true"):f;}return o.copyToImageData(c,n.formatAsRGBA),c;}});var Xn=ut((Gs,Vn)=>{var ko=Yn(),To=Kn();Vn.exports={encode:ko,decode:To};});var Mo={};oi(Mo,{default:()=>Bo});module.exports=si(Mo);var Zr=bt(Mr(),1),Jr=bt(jr(),1),_t=bt(or(),1),{GIFEncoder:Oi,quantize:Li,applyPalette:zi}=Jr.default,Qr=e=>/^R0lGOD[dl]h/.test(e),Le=320,sr=512*1024,en=()=>new Promise(e=>setTimeout(e,0));function Gi(e){var t=()=>new Error("This GIF download is incomplete. Reopen the GIF or share the original file and try again.");if(e.length<13)throw t();if(!/^GIF8[79]a$/.test(String.fromCharCode(...e.subarray(0,6))))throw new Error("This file could not be read as an animated GIF.");var r=13,n=0,i=!1;function o(f){if(r+f>e.length)throw t();var l=r;return r+=f,l;}function s(f){f&128&&o(3*(1<<(f&7)+1));}function a(){for(;;){var f=e[o(1)];if(f===0)return;o(f);}}for(s(e[10]);r<e.length;){var f=e[o(1)];if(f===59){if(!n||i)throw t();return r===e.length?e:e.subarray(0,r);}if(f===33){var l=e[o(1)];a(),l===249&&(i=!0);}else if(f===44){var _l4=o(9);if(s(e[_l4+8]),o(1),a(),i=!1,++n>250)throw new Error("Use a GIF with 250 frames or fewer.");}else throw new Error("This GIF contains an invalid data block. Share the original GIF file and try again.");}if(!n||i)throw t();var c=new Uint8Array(e.length+1);return c.set(e),c[e.length]=59,c;}function Hi(e){var t=Gi(e),r;try{r=new Zr.GifReader(t);}catch{throw new Error("This file could not be read as an animated GIF.");}var{width:n,height:i}=r,o=r.numFrames();if(!n||!i||n*i>4*1024*1024)throw new Error("This GIF is too large to resize on mobile. Use a GIF below 4 megapixels.");if(!o||o>250)throw new Error("Use a GIF with 250 frames or fewer.");var s=[],a=0;for(var c=0;c<o;c++){var f=r.frameInfo(c);if(!f.width||!f.height||f.x+f.width>n||f.y+f.height>i||f.data_offset+f.data_length>t.length||f.palette_offset==null||f.palette_offset+f.palette_size*3>t.length||t[f.data_offset]<2||t[f.data_offset]>8)throw new Error("This GIF contains an invalid frame.");var l=f.delay<2?100:f.delay*10;a+=l,s.push({...f,delayMs:l});}if(a>5e3)throw new Error("Discord stickers can be at most 5 seconds long. Use a shorter GIF; it has not been trimmed or uploaded.");return{bytes:t,reader:r,width:n,height:i,frames:s,duration:a};}function Xr(e,t){if(t.transparent_index!=null||!(e[10]&128))return[0,0,0,0];var r=13+e[11]*3;return[e[r]??0,e[r+1]??0,e[r+2]??0,255];}function qr(e,t,r,n){for(var i=r.y;i<r.y+r.height;i++){var o=(i*t+r.x)*4;for(var s=0;s<r.width;s++,o+=4)e.set(n,o);}}function Wi(e,t,r){var n=Math.min(Le/t,Le/r),i=Math.max(1,Math.round(t*n)),o=Math.max(1,Math.round(r*n)),s=Math.floor((Le-i)/2),a=Math.floor((Le-o)/2),c=new Uint8Array(Le*Le*4);for(var f=0;f<o;f++){var l=Math.min(r-1,Math.floor((f+.5)*r/o));for(var h=0;h<i;h++){var y=Math.min(t-1,Math.floor((h+.5)*t/i)),A=(l*t+y)*4,C=((f+a)*Le+h+s)*4;c[C]=e[A],c[C+1]=e[A+1],c[C+2]=e[A+2],c[C+3]=e[A+3];}}return c;}async function $i(e,t,r,n){var{reader:i,width:o,height:s,frames:a}=t,c=new Uint8Array(o*s*4);qr(c,o,{x:0,y:0,width:o,height:s},Xr(e,a[0]));var f=Oi(),l,h;for(var y=0;y<a.length;y++){n(),l?.disposal===2?qr(c,o,l,Xr(e,l)):l?.disposal===3&&h&&c.set(h);var A=a[y];h=A.disposal===3?c.slice():null,i.decodeAndBlitFrameRGBA(y,c);var C=Wi(c,o,s),x=Li(C,r-1,{format:"rgba4444",oneBitAlpha:!0}),E=[[0,0,0,0],...x.filter(w=>w[3]!==0)];E.length===1&&E.push([0,0,0,255]);var v=zi(C,E,"rgba4444");if(f.writeFrame(v,Le,Le,{palette:E,delay:A.delayMs,repeat:i.loopCount()??-1,transparent:!0,transparentIndex:0,dispose:2}),f.bytesView().length>sr)return null;l=A,await en();}return f.finish(),f.bytesView().length<=sr?f.bytes():null;}async function tn(e,t=()=>{}){t(),e=e.replace(/\s/g,"");var r=(0,_t.toByteArray)(e),n=Hi(r),{bytes:i}=n;if(n.width===Le&&n.height===Le&&i.length<=sr)return{base64:i===r?e:(0,_t.fromByteArray)(i),mimeType:"image/gif",extension:"gif"};if(n.width*n.height*n.frames.length>80*1024*1024)throw new Error("This GIF is too complex to resize on mobile. Use a smaller GIF.");for(var o of[256,128,64]){await en(),t();var s=await $i(i,n,o,t);if(s)return{base64:(0,_t.fromByteArray)(s),mimeType:"image/gif",extension:"gif"};}throw new Error("This animated GIF is still over 512 KiB after resizing. Use a shorter or simpler GIF.");}async function St(e){var t=new Set();async function r(n,i){if(n==null||i>5)return;if(typeof n=="string")try{return r(JSON.parse(n),i+1);}catch{return;}if(typeof n!="object"||t.has(n))return;if(t.add(n),typeof n.then=="function")try{return r(await n,i+1);}catch{return;}if(Array.isArray(n)||typeof n.id=="string"&&n.id)return n;for(var a of["body","data","result","response","emoji","sticker","emojis","stickers","parsedBody"]){var c=await r(n[a],i+1);if(c)return c;}if(typeof n.json=="function")try{var _a3=await r(await n.json(),i+1);if(_a3)return _a3;}catch{}else{var _a4=await r(n.json,i+1);if(_a4)return _a4;}var o;try{o=typeof n.text=="function"?await n.text():n.text;}catch{}var s=await r(o,i+1);return s||(typeof n.message=="string"?n:void 0);}return r(e,0);}function rn(e,t=globalThis){var r=a=>{try{return a();}catch{}},n=(...a)=>r(()=>e.metro.findByProps(...a));function i(){var a=[()=>typeof valenced<"u"?valenced.discord?.native?.FileModule:void 0,()=>typeof revenge<"u"?revenge.discord?.native?.FileModule:void 0,()=>n("writeFile","removeFile"),...["NativeFileModule","RTNFileManager","DCDFileManager"].map(c=>()=>e.metro.common.ReactNative.NativeModules?.[c]??t.nativeModuleProxy?.[c])];for(var c of a){var f=r(c);if(typeof f?.writeFile=="function"&&typeof f?.removeFile=="function")return f;}}function o(){for(var a of[()=>e.metro.common.RestAPI,()=>e.metro.common.restAPI,()=>n("HTTP")?.HTTP,()=>n("get","post","del")]){var c=r(a);if(typeof c?.post=="function")return c;}}function s(a){if(a!=="sticker"&&a!=="emoji")throw new Error("Unknown expression type.");var c=a==="sticker"?"createGuildSticker":"uploadEmoji",f=n(c),l=typeof f?.[c]=="function",h=l?void 0:o();if(!l&&!h)throw new Error("Discord\u2019s signed-in upload API is unavailable. Restart Discord and try again.");return async(y,A=()=>{})=>{A();var C=`/guilds/${y.guildId}/${a==="sticker"?"stickers":"emojis"}`,x,E,v=async()=>{if(typeof h?.get!="function")return;A();var m=await h.get({url:C,failImmediatelyWhenRateLimited:!0});if(A(),m?.ok===!1||Number(m?.status??m?.statusCode)>=400)return;var d=await St(m);return A(),Array.isArray(d)?d:void 0;};if(l)x=await f[c](y);else{var m;if(a==="sticker"){if(typeof t.FormData!="function")throw new Error("Discord\u2019s multipart upload support is unavailable.");if(m=new t.FormData(),typeof m.getParts!="function")throw new Error("Discord\u2019s native multipart upload support is unavailable.");if(!/^(file|content):\/\//.test(y.uri))throw new Error("The sticker file is not ready to upload.");m.append("name",y.name),m.append("tags",y.tags),m.append("description",y.description??""),m.append("file",{uri:y.uri,name:y.mimeType==="image/gif"?"sticker.gif":"sticker.png",type:y.mimeType});}else m={name:y.name,image:y.image,roles:y.roles??[]};try{var d=await v();d&&(E=new Set(d.map(D=>D.id)));}catch{A();}A(),x=await h.post({url:C,body:m,oldFormErrors:!0,failImmediatelyWhenRateLimited:!0});}var w=await St(x),u=x?.status??x?.statusCode??x?.response?.status;if(x?.ok===!1||Number(u)>=400)throw{status:u,body:w??x?.body};if(A(),!w?.id&&!l&&E){var _m;try{_m=await v();}catch{A();}var _d=r(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.()?.id),D=_m?.filter(g=>typeof g.id=="string"&&g.id&&!E.has(g.id)&&g.name===y.name&&(!g.user?.id||g.user.id===_d))??[];D.length===1&&(w=D[0]);}if((!l||a==="sticker")&&!w?.id)throw new Error(`Discord did not confirm the upload. Check the server\u2019s ${a==="sticker"?"stickers":"emoji"} before trying again.`);return A(),!l&&a==="sticker"&&r(()=>e.metro.common.FluxDispatcher?.dispatch?.({type:"GUILD_STICKERS_CREATE_SUCCESS",guildId:y.guildId,sticker:{...w,user:w.user??r(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.())}})),w;};}return{resolve:s,files:i};}function nn(e){var t=e?.body??e;if(typeof t=="string")try{t=JSON.parse(t);}catch{return;}if(!t?.errors||typeof t.errors!="object")return;var r=[],n=new Set(),i=0,o={name:"Sticker name",file:"Sticker file",tags:"Sticker emoji",description:"Description"};function s(a,c,f){if(!(!a||typeof a!="object"||f>8||++i>80||r.length>=6||n.has(a))){if(n.add(a),Array.isArray(a._errors))for(var l of a._errors){if(typeof l?.message!="string"||r.length>=6)continue;var h=(o[c[0]]??c[0]??"Sticker")+(c.length>1?"."+c.slice(1).join("."):"");r.push(h.replace(/[\u0000-\u001f]/g,"").slice(0,80)+": "+l.message.replace(/[\u0000-\u001f]/g," ").slice(0,180));}for(var _l5 of Object.keys(a)){if(r.length>=6||i>=80)break;_l5!=="_errors"&&s(a[_l5],[...c,_l5],f+1);}}}return s(t.errors,[],0),r.length?`Discord rejected the sticker:
`+r.join(`
`):void 0;}function on(e,t=globalThis){var r=rn(e,t),n=c=>{try{return c();}catch{}},i=(...c)=>n(()=>e.metro.findByProps(...c)),o=()=>Object.assign(new Error("Cancelled"),{code:"E_PICKER_CANCELLED"});function s(c,f,l){return new Promise((h,y)=>{var A,C=!1,x=v=>{C||(C=!0,t.clearTimeout(A),l?.removeEventListener?.("abort",E),v?y(v):h());},E=()=>x(o());if(l?.aborted){E();return;}l?.addEventListener?.("abort",E),A=t.setTimeout(()=>{try{f(),x();}catch(v){x(v);}},c);});}function a(c){if(c!=="sticker"||e.host?.id!=="valenced")return r.resolve(c);var f=n(()=>e.metro.common.RestAPI)??n(()=>e.metro.common.restAPI)??i("HTTP")?.HTTP??i("get","post","del");if(typeof f?.post!="function")throw new Error("Discord\u2019s signed-in sticker upload API is unavailable. Restart Discord and try again.");return async(l,h=()=>{},y)=>{if(h(),y?.aborted)throw o();if(!/^(file|content):\/\//.test(l.uri))throw new Error("The sticker file is not ready to upload.");var A=[{name:"name",value:l.name},{name:"tags",value:l.tags},{name:"description",value:l.description??""}],C=[{name:"file",file:{uri:l.uri,name:l.mimeType==="image/gif"?"sticker.gif":"sticker.png",type:l.mimeType}}],x=`/guilds/${l.guildId}/stickers`,E=n(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.()?.id),v=()=>{if(h(),y?.aborted||E&&n(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.()?.id)!==E)throw o();},w=U=>Number(U?.status??U?.statusCode??U?.response?.status);async function u(){if(typeof f.get!="function")return;v();var U=await f.get({url:x,failImmediatelyWhenRateLimited:!0});if(v(),U?.ok===!1||w(U)>=400)return;var P=await St(U);return v(),Array.isArray(P)?P:void 0;}var m;try{m=await u();}catch{v();}var d=m?new Set(m.map(U=>U.id)):void 0;v();var D=await f.post({url:x,fields:A,attachments:C,oldFormErrors:!0,failImmediatelyWhenRateLimited:!0});v();var g=await St(D);v();var B=w(D);if(D?.ok===!1||B>=400||typeof g?.code=="number"&&typeof g?.message=="string")throw{status:B,body:g??D?.body};var _=U=>U&&!Array.isArray(U)&&typeof U.id=="string"&&U.id&&(U.name==null||U.name===l.name)&&(U.guild_id==null||U.guild_id===l.guildId)&&(!E||!U.user?.id||U.user.id===E)&&(!E||!U.user_id||U.user_id===E)&&(U.format_type==null||(l.mimeType==="image/gif"?U.format_type===4:[1,2].includes(U.format_type)));if(!_(g)&&(g=void 0,d)){var U=[350,750,1500];for(var P=0;P<=U.length;P++){var L=void 0;try{L=await u();}catch{v();}if(!L)break;var $=L.filter(re=>!d.has(re.id)&&re.name===l.name&&_(re));if($.length===1){g=$[0];break;}if($.length>1||P===U.length||!Number.isNaN(B)&&B!==201&&B!==202)break;await s(U[P],v,y);}}if(v(),!g?.id)throw Object.assign(new Error("Discord did not confirm the upload. The server\u2019s sticker list was checked; no upload was repeated."),{code:"STICKER_UPLOAD_UNCONFIRMED"});return n(()=>e.metro.common.FluxDispatcher?.dispatch?.({type:"GUILD_STICKERS_CREATE_SUCCESS",guildId:l.guildId,sticker:{...g,name:g.name??l.name,guild_id:g.guild_id??l.guildId,user_id:g.user_id??g.user?.id??E,user:g.user??n(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.())}})),g;};}return{files:r.files,resolve:a};}function sn(e,t){var{React:r,ReactNative:n}=e.metro.common,i=r.createElement,o=new Set(),s=0,a=l=>{try{return l();}catch{}},c=(...l)=>a(()=>e.metro.findByProps(...l));function f(l,h,y){var A=c("openAlert","dismissAlert");if(!n.Modal||typeof A?.openAlert!="function"||!r.useState||!r.useEffect)return!1;for(var w of[...o])w.close();var C=`${t}.panel.${Date.now().toString(36)}.${Math.random().toString(36).slice(2)}.${++s}`,x={visible:!0,listeners:new Set()},E=()=>{if(!x.visible)return;x.visible=!1;for(var m of x.listeners)m();o.delete(x),a(()=>y?.()),a(()=>A.dismissAlert(C));var w=c("useAlertStore")??a(()=>e.metro.findByImportedPath?.("design/components/AlertModal/native/useAlertStore.native.tsx")),u=w?.useAlertStore??w?.default;typeof u?.setState=="function"&&a(()=>u.setState(m=>{if(!Array.isArray(m.alerts))return m;var d=m.alerts.filter(D=>D.key!==C&&D.node!==x.node);return d.length===m.alerts.length?m:{alerts:d};}));};x.close=E;function v(){var[,w]=r.useState(0);r.useEffect(()=>{var D=()=>w(g=>g+1);return x.listeners.add(D),()=>{x.listeners.delete(D),E();};},[]);var u=n.useWindowDimensions?.()??n.Dimensions?.get?.("window")??{height:800};if(!x.visible)return null;var d=(a(()=>e.metro.findByStoreName("ThemeStore")?.theme)??n.Appearance?.getColorScheme?.())==="light"?"#ffffff":"#242429";return i(n.Modal,{visible:!0,transparent:!0,animationType:"slide",presentationStyle:"overFullScreen",onRequestClose:E,onDismiss:E,statusBarTranslucent:!1,navigationBarTranslucent:!1},i(n.KeyboardAvoidingView??n.View,{style:{flex:1},behavior:n.Platform?.OS==="ios"?"padding":"height"},i(n.View,{style:{flex:1,justifyContent:"flex-end",backgroundColor:"rgba(0,0,0,0.65)"}},i(n.Pressable??n.TouchableOpacity,{onPress:E,accessibilityRole:"button",accessibilityLabel:`Close ${h}`,style:{position:"absolute",top:0,left:0,right:0,bottom:0}}),i(n.View,{testID:t+"-panel",accessibilityViewIsModal:!0,onAccessibilityEscape:E,style:{height:Math.min(720,u.height*.86),maxHeight:"92%",backgroundColor:d,borderTopLeftRadius:20,borderTopRightRadius:20,overflow:"hidden",paddingTop:8,paddingBottom:16}},l(E)))));}x.node=i(v),o.add(x);try{var _w=A.openAlert(C,x.node,E,{dismissable:!0});return _w?.catch&&_w.catch(E),!0;}catch{return E(),!1;}}return{open:f,closeAll(){for(var l of[...o])l.close();}};}function an(e,{title:t,id:r,testID:n},i=globalThis){var{React:o,ReactNative:s}=e.metro.common,a=o.createElement,c=new Set(),f=0,l=A=>{try{return A();}catch{}};function h(A){var C=l(()=>A.getCurrentRoute?.());if(C)return C;var x=l(()=>A.getRootState?.()??A.getState?.()),E;for(var v=0;v<12&&x?.routes?.length;v++)E=x.routes[x.index??x.routes.length-1],x=E?.state;return E;}function y(A,C){var x=l(()=>e.metro.findByProps("getRootNavigationRef")?.getRootNavigationRef?.());if(!x?.navigate||!x.goBack||!x.getCurrentRoute&&!x.getRootState&&!x.getState)return!1;for(var _ of[...c])_.close();var E=`${r}.${Date.now().toString(36)}.${++f}.${Math.random().toString(36).slice(2)}`,v=l(()=>e.metro.common.NavigationNative?.useIsFocused),w={open:!0,listeners:new Set(),presented:!1,mounted:!1},u=()=>h(x)?.params?.__expressionPage===E,m=()=>w.open&&(!w.presented||u()),d=(_=!0)=>{if(!w.open)return;var U=u();w.open=!1,i.clearTimeout(w.timer),i.clearTimeout(w.mountTimer),l(()=>w.cancelNavigation?.()),l(()=>w.unsubscribe?.()),c.delete(w),l(()=>C?.());for(var P of w.listeners)P();_&&U&&l(()=>x.canGoBack?.())!==!1&&l(()=>x.goBack());};w.close=d,c.add(w);function D(){var[,_]=o.useState(0),U=typeof v=="function"?v():void 0;o.useEffect(()=>{var L=()=>_($=>$+1);return w.listeners.add(L),w.mounted=!0,i.clearTimeout(w.mountTimer),u()&&(w.presented=!0),!w.open&&u()&&l(()=>x.goBack()),()=>{w.listeners.delete(L),d(!1);};},[]),o.useEffect(()=>{!w.open&&u()&&l(()=>x.goBack());},[U]);var P=l(()=>e.metro.findByStoreName("ThemeStore")?.theme)!=="light";return a(s.View,{testID:n,style:{flex:1,backgroundColor:P?"#242429":"#fff"}},w.open?A(()=>d(),m):a(s.Text,{style:{padding:24,fontSize:16,color:P?"#f2f3f5":"#202127"}},t+" is closed. Use Back to return to Discord."));}var g=()=>{w.open&&(u()?w.presented=!0:w.presented&&d(!1));},B=l(()=>x.addListener?.("state",g));return w.unsubscribe=typeof B=="function"?B:()=>B?.remove?.(),w.timer=i.setTimeout(()=>{if(w.timer=void 0,!!w.open){w.mountTimer=i.setTimeout(()=>{!w.open||w.mounted||(d(!1),l(()=>e.ui.toasts.showToast(t+" could not open. Reopen the image menu and try again.")));},8e3);try{var _3=x.navigate("BUNNY_CUSTOM_PAGE",{title:t,__expressionPage:E,__expressionOpen:()=>w.open,__expressionCancel:()=>d(!1),render:D});typeof _3=="function"&&(w.cancelNavigation=_3);}catch{d(!1),l(()=>e.ui.toasts.showToast(t+" could not open. Reopen the image menu and try again."));}}},350),!0;}return{open:y,closeAll(){for(var A of[...c])A.close();}};}var Ce=Uint8Array,De=Uint16Array,gr=Int32Array,Gt=new Ce([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),Ht=new Ce([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),hr=new Ce([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),un=function(e,t){for(var r=new De(31),n=0;n<31;++n)r[n]=t+=1<<e[n-1];for(var i=new gr(r[30]),n=1;n<30;++n)for(var o=r[n];o<r[n+1];++o)i[o]=o-r[n]<<5|n;return{b:r,r:i};},dn=un(Gt,2),pn=dn.b,ur=dn.r;pn[28]=258,ur[258]=28;var vn=un(Ht,0),Yi=vn.b,ln=vn.r,dr=new De(32768);for(we=0;we<32768;++we)je=(we&43690)>>1|(we&21845)<<1,je=(je&52428)>>2|(je&13107)<<2,je=(je&61680)>>4|(je&3855)<<4,dr[we]=((je&65280)>>8|(je&255)<<8)>>1;var je,we,$e=function(e,t,r){for(var n=e.length,i=0,o=new De(t);i<n;++i)e[i]&&++o[e[i]-1];var s=new De(t);for(i=1;i<t;++i)s[i]=s[i-1]+o[i-1]<<1;var a;if(r){a=new De(1<<t);var c=15-t;for(i=0;i<n;++i)if(e[i])for(var f=i<<4|e[i],l=t-e[i],h=s[e[i]-1]++<<l,y=h|(1<<l)-1;h<=y;++h)a[dr[h]>>c]=f;}else for(a=new De(n),i=0;i<n;++i)e[i]&&(a[i]=dr[s[e[i]-1]++]>>15-e[i]);return a;},et=new Ce(288);for(we=0;we<144;++we)et[we]=8;var we;for(we=144;we<256;++we)et[we]=9;var we;for(we=256;we<280;++we)et[we]=7;var we;for(we=280;we<288;++we)et[we]=8;var we,Tt=new Ce(32);for(we=0;we<32;++we)Tt[we]=5;var we,ji=$e(et,9,0),Ki=$e(et,9,1),Vi=$e(Tt,5,0),Xi=$e(Tt,5,1),ar=function(e){for(var t=e[0],r=1;r<e.length;++r)e[r]>t&&(t=e[r]);return t;},ze=function(e,t,r){var n=t/8|0;return(e[n]|e[n+1]<<8)>>(t&7)&r;},lr=function(e,t){var r=t/8|0;return(e[r]|e[r+1]<<8|e[r+2]<<16)>>(t&7);},xr=function(e){return(e+7)/8|0;},st=function(e,t,r){return(t==null||t<0)&&(t=0),(r==null||r>e.length)&&(r=e.length),new Ce(e.subarray(t,r));};var qi=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],Me=function(e,t,r){var n=new Error(t||qi[e]);if(n.code=e,Error.captureStackTrace&&Error.captureStackTrace(n,Me),!r)throw n;return n;},gn=function(e,t,r,n){var i=e.length,o=n?n.length:0;if(!i||t.f&&!t.l)return r||new Ce(0);var s=!r,a=s||t.i!=2,c=t.i;s&&(r=new Ce(i*3));var f=function(G){var O=r.length;if(G>O){var ue=new Ce(Math.max(O*2,G));ue.set(r),r=ue;}},l=t.f||0,h=t.p||0,y=t.b||0,A=t.l,C=t.d,x=t.m,E=t.n,v=i*8;do{if(!A){l=ze(e,h,1);var w=ze(e,h+1,3);if(h+=3,w){if(w==1)A=Ki,C=Xi,x=9,E=5;else if(w==2){var D=ze(e,h,31)+257,g=ze(e,h+10,15)+4,B=D+ze(e,h+5,31)+1;h+=14;for(var _=new Ce(B),U=new Ce(19),P=0;P<g;++P)U[hr[P]]=ze(e,h+P*3,7);h+=g*3;for(var L=ar(U),$=(1<<L)-1,re=$e(U,L,1),P=0;P<B;){var W=re[ze(e,h,$)];h+=W&15;var u=W>>4;if(u<16)_[P++]=u;else{var K=0,X=0;for(u==16?(X=3+ze(e,h,3),h+=2,K=_[P-1]):u==17?(X=3+ze(e,h,7),h+=3):u==18&&(X=11+ze(e,h,127),h+=7);X--;)_[P++]=K;}}var j=_.subarray(0,D),q=_.subarray(D);x=ar(j),E=ar(q),A=$e(j,x,1),C=$e(q,E,1);}else Me(1);}else{var u=xr(h)+4,m=e[u-4]|e[u-3]<<8,d=u+m;if(d>i){c&&Me(0);break;}a&&f(y+m),r.set(e.subarray(u,d),y),t.b=y+=m,t.p=h=d*8,t.f=l;continue;}if(h>v){c&&Me(0);break;}}a&&f(y+131072);for(var xe=(1<<x)-1,ie=(1<<E)-1,ne=h;;ne=h){var K=A[lr(e,h)&xe],Z=K>>4;if(h+=K&15,h>v){c&&Me(0);break;}if(K||Me(2),Z<256)r[y++]=Z;else if(Z==256){ne=h,A=null;break;}else{var b=Z-254;if(Z>264){var P=Z-257,z=Gt[P];b=ze(e,h,(1<<z)-1)+pn[P],h+=z;}var ce=C[lr(e,h)&ie],ve=ce>>4;ce||Me(3),h+=ce&15;var q=Yi[ve];if(ve>3){var z=Ht[ve];q+=lr(e,h)&(1<<z)-1,h+=z;}if(h>v){c&&Me(0);break;}a&&f(y+131072);var J=y+b;if(y<q){var le=o-q,ae=Math.min(q,J);for(le+y<0&&Me(3);y<ae;++y)r[y]=n[le+y];}for(;y<J;++y)r[y]=r[y-q];}}t.l=A,t.p=ne,t.b=y,t.f=l,A&&(l=1,t.m=x,t.d=C,t.n=E);}while(!l);return y!=r.length&&s?st(r,0,y):r.subarray(0,y);},Ke=function(e,t,r){r<<=t&7;var n=t/8|0;e[n]|=r,e[n+1]|=r>>8;},Ct=function(e,t,r){r<<=t&7;var n=t/8|0;e[n]|=r,e[n+1]|=r>>8,e[n+2]|=r>>16;},cr=function(e,t){for(var r=[],n=0;n<e.length;++n)e[n]&&r.push({s:n,f:e[n]});var i=r.length,o=r.slice();if(!i)return{t:yn,l:0};if(i==1){var s=new Ce(r[0].s+1);return s[r[0].s]=1,{t:s,l:1};}r.sort(function(d,D){return d.f-D.f;}),r.push({s:-1,f:25001});var a=r[0],c=r[1],f=0,l=1,h=2;for(r[0]={s:-1,f:a.f+c.f,l:a,r:c};l!=i-1;)a=r[r[f].f<r[h].f?f++:h++],c=r[f!=l&&r[f].f<r[h].f?f++:h++],r[l++]={s:-1,f:a.f+c.f,l:a,r:c};for(var y=o[0].s,n=1;n<i;++n)o[n].s>y&&(y=o[n].s);var A=new De(y+1),C=pr(r[l-1],A,0);if(C>t){var n=0,x=0,E=C-t,v=1<<E;for(o.sort(function(D,g){return A[g.s]-A[D.s]||D.f-g.f;});n<i;++n){var w=o[n].s;if(A[w]>t)x+=v-(1<<C-A[w]),A[w]=t;else break;}for(x>>=E;x>0;){var u=o[n].s;A[u]<t?x-=1<<t-A[u]++-1:++n;}for(;n>=0&&x;--n){var m=o[n].s;A[m]==t&&(--A[m],++x);}C=t;}return{t:new Ce(A),l:C};},pr=function(e,t,r){return e.s==-1?Math.max(pr(e.l,t,r+1),pr(e.r,t,r+1)):t[e.s]=r;},cn=function(e){for(var t=e.length;t&&!e[--t];);for(var r=new De(++t),n=0,i=e[0],o=1,s=function(c){r[n++]=c;},a=1;a<=t;++a)if(e[a]==i&&a!=t)++o;else{if(!i&&o>2){for(;o>138;o-=138)s(32754);o>2&&(s(o>10?o-11<<5|28690:o-3<<5|12305),o=0);}else if(o>3){for(s(i),--o;o>6;o-=6)s(8304);o>2&&(s(o-3<<5|8208),o=0);}for(;o--;)s(i);o=1,i=e[a];}return{c:r.subarray(0,n),n:t};},kt=function(e,t){for(var r=0,n=0;n<t.length;++n)r+=e[n]*t[n];return r;},xn=function(e,t,r){var n=r.length,i=xr(t+2);e[i]=n&255,e[i+1]=n>>8,e[i+2]=e[i]^255,e[i+3]=e[i+1]^255;for(var o=0;o<n;++o)e[i+o+4]=r[o];return(i+4+n)*8;},fn=function(e,t,r,n,i,o,s,a,c,f,l){Ke(t,l++,r),++i[256];for(var h=cr(i,15),y=h.t,A=h.l,C=cr(o,15),x=C.t,E=C.l,v=cn(y),w=v.c,u=v.n,m=cn(x),d=m.c,D=m.n,g=new De(19),B=0;B<w.length;++B)++g[w[B]&31];for(var B=0;B<d.length;++B)++g[d[B]&31];for(var _=cr(g,7),U=_.t,P=_.l,L=19;L>4&&!U[hr[L-1]];--L);var $=f+5<<3,re=kt(i,et)+kt(o,Tt)+s,W=kt(i,y)+kt(o,x)+s+14+3*L+kt(g,U)+2*g[16]+3*g[17]+7*g[18];if(c>=0&&$<=re&&$<=W)return xn(t,l,e.subarray(c,c+f));var K,X,j,q;if(Ke(t,l,1+(W<re)),l+=2,W<re){K=$e(y,A,0),X=y,j=$e(x,E,0),q=x;var xe=$e(U,P,0);Ke(t,l,u-257),Ke(t,l+5,D-1),Ke(t,l+10,L-4),l+=14;for(var B=0;B<L;++B)Ke(t,l+3*B,U[hr[B]]);l+=3*L;for(var ie=[w,d],ne=0;ne<2;++ne)for(var Z=ie[ne],B=0;B<Z.length;++B){var b=Z[B]&31;Ke(t,l,xe[b]),l+=U[b],b>15&&(Ke(t,l,Z[B]>>5&127),l+=Z[B]>>12);}}else K=ji,X=et,j=Vi,q=Tt;for(var B=0;B<a;++B){var z=n[B];if(z>255){var b=z>>18&31;Ct(t,l,K[b+257]),l+=X[b+257],b>7&&(Ke(t,l,z>>23&31),l+=Gt[b]);var ce=z&31;Ct(t,l,j[ce]),l+=q[ce],ce>3&&(Ct(t,l,z>>5&8191),l+=Ht[ce]);}else Ct(t,l,K[z]),l+=X[z];}return Ct(t,l,K[256]),l+X[256];},Zi=new gr([65540,131080,131088,131104,262176,1048704,1048832,2114560,2117632]),yn=new Ce(0),Ji=function(e,t,r,n,i,o){var s=o.z||e.length,a=new Ce(n+s+5*(1+Math.ceil(s/7e3))+i),c=a.subarray(n,a.length-i),f=o.l,l=(o.r||0)&7;if(t){l&&(c[0]=o.r>>3);for(var h=Zi[t-1],y=h>>13,A=h&8191,C=(1<<r)-1,x=o.p||new De(32768),E=o.h||new De(C+1),v=Math.ceil(r/3),w=2*v,u=function(se){return(e[se]^e[se+1]<<v^e[se+2]<<w)&C;},m=new gr(25e3),d=new De(288),D=new De(32),g=0,B=0,_=o.i||0,U=0,P=o.w||0,L=0;_+2<s;++_){var $=u(_),re=_&32767,W=E[$];if(x[re]=W,E[$]=re,P<=_){var K=s-_;if((g>7e3||U>24576)&&(K>423||!f)){l=fn(e,c,0,m,d,D,B,U,L,_-L,l),U=g=B=0,L=_;for(var X=0;X<286;++X)d[X]=0;for(var X=0;X<30;++X)D[X]=0;}var j=2,q=0,xe=A,ie=re-W&32767;if(K>2&&$==u(_-ie))for(var ne=Math.min(y,K)-1,Z=Math.min(32767,_),b=Math.min(258,K);ie<=Z&&--xe&&re!=W;){if(e[_+j]==e[_+j-ie]){for(var z=0;z<b&&e[_+z]==e[_+z-ie];++z);if(z>j){if(j=z,q=ie,z>ne)break;for(var ce=Math.min(ie,z-2),ve=0,X=0;X<ce;++X){var J=_-ie+X&32767,le=x[J],ae=J-le&32767;ae>ve&&(ve=ae,W=J);}}}re=W,W=x[re],ie+=re-W&32767;}if(q){m[U++]=268435456|ur[j]<<18|ln[q];var G=ur[j]&31,O=ln[q]&31;B+=Gt[G]+Ht[O],++d[257+G],++D[O],P=_+j,++g;}else m[U++]=e[_],++d[e[_]];}}for(_=Math.max(_,P);_<s;++_)m[U++]=e[_],++d[e[_]];l=fn(e,c,f,m,d,D,B,U,L,_-L,l),f||(o.r=l&7|c[l/8|0]<<3,l-=7,o.h=E,o.p=x,o.i=_,o.w=P);}else{for(var _=o.w||0;_<s+f;_+=65535){var ue=_+65535;ue>=s&&(c[l/8|0]=f,ue=s),l=xn(c,l+1,e.subarray(_,ue));}o.i=s;}return st(a,0,n+xr(l)+i);};var mn=function(){var e=1,t=0;return{p:function(r){for(var n=e,i=t,o=r.length|0,s=0;s!=o;){for(var a=Math.min(s+2655,o);s<a;++s)i+=n+=r[s];n=(n&65535)+15*(n>>16),i=(i&65535)+15*(i>>16);}e=n,t=i;},d:function(){return e%=65521,t%=65521,(e&255)<<24|(e&65280)<<8|(t&255)<<8|t>>8;}};},Qi=function(e,t,r,n,i){if(!i&&(i={l:1},t.dictionary)){var o=t.dictionary.subarray(-32768),s=new Ce(o.length+e.length);s.set(o),s.set(e,o.length),e=s,i.w=o.length;}return Ji(e,t.level==null?6:t.level,t.mem==null?i.l?Math.ceil(Math.max(8,Math.min(13,Math.log(e.length)))*1.5):20:12+t.mem,r,n,i);};var wn=function(e,t,r){for(;r;++t)e[t]=r,r>>>=8;};var eo=function(e,t){var r=t.level,n=r==0?0:r<6?1:r==9?3:2;if(e[0]=120,e[1]=n<<6|(t.dictionary&&32),e[1]|=31-(e[0]<<8|e[1])%31,t.dictionary){var i=mn();i.p(t.dictionary),wn(e,2,i.d());}},An=function(e,t){return((e[0]&15)!=8||e[0]>>4>7||(e[0]<<8|e[1])%31)&&Me(6,"invalid zlib data"),(e[1]>>5&1)==+!t&&Me(6,"invalid zlib data: "+(e[1]&32?"need":"unexpected")+" dictionary"),(e[1]>>3&4)+2;};var fr=function(){function e(t,r){typeof t=="function"&&(r=t,t={}),this.ondata=r;var n=t&&t.dictionary&&t.dictionary.subarray(-32768);this.s={i:0,b:n?n.length:0},this.o=new Ce(32768),this.p=new Ce(0),n&&this.o.set(n);}return e.prototype.e=function(t){if(this.ondata||Me(5),this.d&&Me(4),!this.p.length)this.p=t;else if(t.length){var r=new Ce(this.p.length+t.length);r.set(this.p),r.set(t,this.p.length),this.p=r;}},e.prototype.c=function(t){this.s.i=+(this.d=t||!1);var r=this.s.b,n=gn(this.p,this.s,this.o);this.ondata(st(n,r,this.s.b),this.d),this.o=st(n,this.s.b-32768),this.s.b=this.o.length,this.p=st(this.p,this.s.p/8|0),this.s.p&=7;},e.prototype.push=function(t,r){this.e(t),this.c(r);},e;}();function bn(e,t){t||(t={});var r=mn();r.p(e);var n=Qi(e,t,t.dictionary?6:2,4);return eo(n,t),wn(n,n.length-4,r.d()),n;}var Ft=function(){function e(t,r){fr.call(this,t,r),this.v=t&&t.dictionary?2:1;}return e.prototype.push=function(t,r){if(fr.prototype.e.call(this,t),this.v){if(this.p.length<6&&!r)return;this.p=this.p.subarray(An(this.p,this.v-1)),this.v=0;}r&&(this.p.length<4&&Me(6,"invalid zlib data"),this.p=this.p.subarray(0,-4)),fr.prototype.c.call(this,r);},e;}();function En(e,t){return gn(e.subarray(An(e,t&&t.dictionary),-4),{i:2},t&&t.out,t&&t.dictionary);}var hn=typeof TextEncoder<"u"&&new TextEncoder(),vr=typeof TextDecoder<"u"&&new TextDecoder(),to=0;try{vr.decode(yn,{stream:!0}),to=1;}catch{}var ro=function(e){for(var t="",r=0;;){var n=e[r++],i=(n>127)+(n>223)+(n>239);if(r+i>e.length)return{s:t,r:st(e,r-1)};i?i==3?(n=((n&15)<<18|(e[r++]&63)<<12|(e[r++]&63)<<6|e[r++]&63)-65536,t+=String.fromCharCode(55296|n>>10,56320|n&1023)):i&1?t+=String.fromCharCode((n&31)<<6|e[r++]&63):t+=String.fromCharCode((n&15)<<12|(e[r++]&63)<<6|e[r++]&63):t+=String.fromCharCode(n);}};function _n(e,t){if(t){for(var r=new Ce(e.length),n=0;n<e.length;++n)r[n]=e.charCodeAt(n);return r;}if(hn)return hn.encode(e);for(var i=e.length,o=new Ce(e.length+(e.length>>1)),s=0,a=function(l){o[s++]=l;},n=0;n<i;++n){if(s+5>o.length){var c=new Ce(s+8+(i-n<<1));c.set(o),o=c;}var f=e.charCodeAt(n);f<128||t?a(f):f<2048?(a(192|f>>6),a(128|f&63)):f>55295&&f<57344?(f=65536+(f&1047552)|e.charCodeAt(++n)&1023,a(240|f>>18),a(128|f>>12&63),a(128|f>>6&63),a(128|f&63)):(a(224|f>>12),a(128|f>>6&63),a(128|f&63));}return st(o,0,s);}function Sn(e,t){if(t){for(var r="",n=0;n<e.length;n+=16384)r+=String.fromCharCode.apply(null,e.subarray(n,n+16384));return r;}else{if(vr)return vr.decode(e);var i=ro(e),o=i.s,r=i.r;return r.length&&Me(8),o;}}var Wt=class{encode(t=""){return _n(String(t));}},dt=class{constructor(t="utf-8"){this.latin1=/^(latin1|iso-8859-1)$/i.test(t);}decode(t=new Uint8Array()){var r=new Uint8Array(t.buffer??t,t.byteOffset??0,t.byteLength);return Sn(r,this.latin1);}};function yr(e,t="utf8"){return new dt(t).decode(e);}var no=new Wt();function Cn(e){return no.encode(e);}var io=1024*8,oo=(()=>{var e=new Uint8Array(4),t=new Uint32Array(e.buffer);return!((t[0]=1)&e[0]);})(),mr={int8:globalThis.Int8Array,uint8:globalThis.Uint8Array,int16:globalThis.Int16Array,uint16:globalThis.Uint16Array,int32:globalThis.Int32Array,uint32:globalThis.Uint32Array,uint64:globalThis.BigUint64Array,int64:globalThis.BigInt64Array,float32:globalThis.Float32Array,float64:globalThis.Float64Array},at=class e{constructor(t=io,r={}){ye(this,"buffer");ye(this,"byteLength");ye(this,"byteOffset");ye(this,"length");ye(this,"offset");ye(this,"lastWrittenByte");ye(this,"littleEndian");ye(this,"_data");ye(this,"_mark");ye(this,"_marks");var n=!1;typeof t=="number"?t=new ArrayBuffer(t):(n=!0,this.lastWrittenByte=t.byteLength);var i=r.offset?r.offset>>>0:0,o=t.byteLength-i,s=i;(ArrayBuffer.isView(t)||t instanceof e)&&(t.byteLength!==t.buffer.byteLength&&(s=t.byteOffset+i),t=t.buffer),n?this.lastWrittenByte=o:this.lastWrittenByte=0,this.buffer=t,this.length=o,this.byteLength=o,this.byteOffset=s,this.offset=0,this.littleEndian=!0,this._data=new DataView(this.buffer,s,o),this._mark=0,this._marks=[];}available(t=1){return this.offset+t<=this.length;}isLittleEndian(){return this.littleEndian;}setLittleEndian(){return this.littleEndian=!0,this;}isBigEndian(){return!this.littleEndian;}setBigEndian(){return this.littleEndian=!1,this;}skip(t=1){return this.offset+=t,this;}back(t=1){return this.offset-=t,this;}seek(t){return this.offset=t,this;}mark(){return this._mark=this.offset,this;}reset(){return this.offset=this._mark,this;}pushMark(){return this._marks.push(this.offset),this;}popMark(){var t=this._marks.pop();if(t===void 0)throw new Error("Mark stack empty");return this.seek(t),this;}rewind(){return this.offset=0,this;}ensureAvailable(t=1){if(!this.available(t)){var n=(this.offset+t)*2,i=new Uint8Array(n);i.set(new Uint8Array(this.buffer)),this.buffer=i.buffer,this.length=n,this.byteLength=n,this._data=new DataView(this.buffer);}return this;}readBoolean(){return this.readUint8()!==0;}readInt8(){return this._data.getInt8(this.offset++);}readUint8(){return this._data.getUint8(this.offset++);}readByte(){return this.readUint8();}readBytes(t=1){return this.readArray(t,"uint8");}readArray(t,r){var n=mr[r].BYTES_PER_ELEMENT*t,i=this.byteOffset+this.offset,o=this.buffer.slice(i,i+n);if(this.littleEndian===oo&&r!=="uint8"&&r!=="int8"){var a=new Uint8Array(this.buffer.slice(i,i+n));a.reverse();var c=new mr[r](a.buffer);return this.offset+=n,c.reverse(),c;}var s=new mr[r](o);return this.offset+=n,s;}readInt16(){var t=this._data.getInt16(this.offset,this.littleEndian);return this.offset+=2,t;}readUint16(){var t=this._data.getUint16(this.offset,this.littleEndian);return this.offset+=2,t;}readInt32(){var t=this._data.getInt32(this.offset,this.littleEndian);return this.offset+=4,t;}readUint32(){var t=this._data.getUint32(this.offset,this.littleEndian);return this.offset+=4,t;}readFloat32(){var t=this._data.getFloat32(this.offset,this.littleEndian);return this.offset+=4,t;}readFloat64(){var t=this._data.getFloat64(this.offset,this.littleEndian);return this.offset+=8,t;}readBigInt64(){var t=this._data.getBigInt64(this.offset,this.littleEndian);return this.offset+=8,t;}readBigUint64(){var t=this._data.getBigUint64(this.offset,this.littleEndian);return this.offset+=8,t;}readChar(){return String.fromCharCode(this.readInt8());}readChars(t=1){var r="";for(var n=0;n<t;n++)r+=this.readChar();return r;}readUtf8(t=1){return yr(this.readBytes(t));}decodeText(t=1,r="utf8"){return yr(this.readBytes(t),r);}writeBoolean(t){return this.writeUint8(t?255:0),this;}writeInt8(t){return this.ensureAvailable(1),this._data.setInt8(this.offset++,t),this._updateLastWrittenByte(),this;}writeUint8(t){return this.ensureAvailable(1),this._data.setUint8(this.offset++,t),this._updateLastWrittenByte(),this;}writeByte(t){return this.writeUint8(t);}writeBytes(t){this.ensureAvailable(t.length);for(var r=0;r<t.length;r++)this._data.setUint8(this.offset++,t[r]);return this._updateLastWrittenByte(),this;}writeInt16(t){return this.ensureAvailable(2),this._data.setInt16(this.offset,t,this.littleEndian),this.offset+=2,this._updateLastWrittenByte(),this;}writeUint16(t){return this.ensureAvailable(2),this._data.setUint16(this.offset,t,this.littleEndian),this.offset+=2,this._updateLastWrittenByte(),this;}writeInt32(t){return this.ensureAvailable(4),this._data.setInt32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeUint32(t){return this.ensureAvailable(4),this._data.setUint32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeFloat32(t){return this.ensureAvailable(4),this._data.setFloat32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeFloat64(t){return this.ensureAvailable(8),this._data.setFloat64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeBigInt64(t){return this.ensureAvailable(8),this._data.setBigInt64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeBigUint64(t){return this.ensureAvailable(8),this._data.setBigUint64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeChar(t){return this.writeUint8(t.charCodeAt(0));}writeChars(t){for(var r=0;r<t.length;r++)this.writeUint8(t.charCodeAt(r));return this;}writeUtf8(t){return this.writeBytes(Cn(t));}toArray(){return new Uint8Array(this.buffer,this.byteOffset,this.lastWrittenByte);}getWrittenByteLength(){return this.lastWrittenByte-this.byteOffset;}_updateLastWrittenByte(){this.offset>this.lastWrittenByte&&(this.lastWrittenByte=this.offset);}};var Tn=[];for(var e=0;e<256;e++){var t=e;for(var r=0;r<8;r++)t&1?t=3988292384^t>>>1:t=t>>>1;Tn[e]=t;}var kn=4294967295;function so(e,t,r){var n=e;for(var i=0;i<r;i++)n=Tn[(n^t[i])&255]^n>>>8;return n;}function Fn(e,t){return(so(kn,e,t)^kn)>>>0;}function wr(e,t,r){var n=e.readUint32(),i=Fn(new Uint8Array(e.buffer,e.byteOffset+e.offset-t-4,t),t);if(i!==n)throw new Error(`CRC mismatch for chunk ${r}. Expected ${n}, found ${i}`);}function tt(e,t){e.writeUint32(Fn(new Uint8Array(e.buffer,e.byteOffset+e.offset-t,t),t));}function $t(e,t,r){for(var n=0;n<r;n++)t[n]=e[n];}function Yt(e,t,r,n){var i=0;for(;i<n;i++)t[i]=e[i];for(;i<r;i++)t[i]=e[i]+t[i-n]&255;}function jt(e,t,r,n){var i=0;if(r.length===0)for(;i<n;i++)t[i]=e[i];else for(;i<n;i++)t[i]=e[i]+r[i]&255;}function Kt(e,t,r,n,i){var o=0;if(r.length===0){for(;o<i;o++)t[o]=e[o];for(;o<n;o++)t[o]=e[o]+(t[o-i]>>1)&255;}else{for(;o<i;o++)t[o]=e[o]+(r[o]>>1)&255;for(;o<n;o++)t[o]=e[o]+(t[o-i]+r[o]>>1)&255;}}function Vt(e,t,r,n,i){var o=0;if(r.length===0){for(;o<i;o++)t[o]=e[o];for(;o<n;o++)t[o]=e[o]+t[o-i]&255;}else{for(;o<i;o++)t[o]=e[o]+r[o]&255;for(;o<n;o++)t[o]=e[o]+ao(t[o-i],r[o],r[o-i])&255;}}function ao(e,t,r){var n=e+t-r,i=Math.abs(n-e),o=Math.abs(n-t),s=Math.abs(n-r);return i<=o&&i<=s?e:o<=s?t:r;}function Un(e,t,r,n,i,o){switch(e){case 0:$t(t,r,i);break;case 1:Yt(t,r,i,o);break;case 2:jt(t,r,n,i);break;case 3:Kt(t,r,n,i,o);break;case 4:Vt(t,r,n,i,o);break;default:throw new Error(`Unsupported filter: ${e}`);}}var lo=new Uint16Array([255]),co=new Uint8Array(lo.buffer),fo=co[0]===255;function In(e){var{data:t,width:r,height:n,channels:i,depth:o}=e,s=[{x:0,y:0,xStep:8,yStep:8},{x:4,y:0,xStep:8,yStep:8},{x:0,y:4,xStep:4,yStep:8},{x:2,y:0,xStep:4,yStep:4},{x:0,y:2,xStep:2,yStep:4},{x:1,y:0,xStep:2,yStep:2},{x:0,y:1,xStep:1,yStep:2}],a=Math.ceil(o/8)*i,c=new Uint8Array(n*r*a),f=0;for(var l=0;l<7;l++){var h=s[l],y=Math.ceil((r-h.x)/h.xStep),A=Math.ceil((n-h.y)/h.yStep);if(y<=0||A<=0)continue;var C=y*a,x=new Uint8Array(C);for(var E=0;E<A;E++){var v=t[f++],w=t.subarray(f,f+C);f+=C;var u=new Uint8Array(C);Un(v,w,u,x,C,a),x.set(u);for(var m=0;m<y;m++){var d=h.x+m*h.xStep,D=h.y+E*h.yStep;if(!(d>=r||D>=n))for(var g=0;g<a;g++)c[(D*r+d)*a+g]=u[m*a+g];}}}if(o===16){var _l6=new Uint16Array(c.buffer);if(fo)for(var _h4=0;_h4<_l6.length;_h4++)_l6[_h4]=ho(_l6[_h4]);return _l6;}else return c;}function ho(e){return(e&255)<<8|e>>8&255;}var uo=new Uint16Array([255]),po=new Uint8Array(uo.buffer),vo=po[0]===255,go=new Uint8Array(0);function Ar(e){var{data:t,width:r,height:n,channels:i,depth:o}=e,s=Math.ceil(o/8)*i,a=Math.ceil(o/8*i*r),c=new Uint8Array(n*a),f=go,l=0,h,y;for(var A=0;A<n;A++){switch(h=t.subarray(l+1,l+1+a),y=c.subarray(A*a,(A+1)*a),t[l]){case 0:$t(h,y,a);break;case 1:Yt(h,y,a,s);break;case 2:jt(h,y,f,a);break;case 3:Kt(h,y,f,a,s);break;case 4:Vt(h,y,f,a,s);break;default:throw new Error(`Unsupported filter: ${t[l]}`);}f=y,l+=a+1;}if(o===16){var _A2=new Uint16Array(c.buffer);if(vo)for(var C=0;C<_A2.length;C++)_A2[C]=xo(_A2[C]);return _A2;}else return c;}function xo(e){return(e&255)<<8|e>>8&255;}var Ut=Uint8Array.of(137,80,78,71,13,10,26,10);function Bn(e){e.writeBytes(Ut);}function br(e){if(!Mn(e.readBytes(Ut.length)))throw new Error("wrong PNG signature");}function Mn(e){if(e.length<Ut.length)return!1;for(var _t2=0;_t2<Ut.length;_t2++)if(e[_t2]!==Ut[_t2])return!1;return!0;}var Er="tEXt",Rn=0,Dn=new dt("latin1");function Pn(e){if(Nn(e),e.length===0||e.length>79)throw new Error("keyword length must be between 1 and 79");}var yo=/^[\u0000-\u00FF]*$/;function Nn(e){if(!yo.test(e))throw new Error("invalid latin1 text");}function On(e,t,r){var n=_r(t);e[n]=mo(t,r-n.length-1);}function Ln(e,t,r){Pn(t),Nn(r);var n=t.length+1+r.length;e.writeUint32(n),e.writeChars(Er),e.writeChars(t),e.writeByte(Rn),e.writeChars(r),tt(e,n+4);}function _r(e){for(e.mark();e.readByte()!==Rn;);var t=e.offset;e.reset();var r=Dn.decode(e.readBytes(t-e.offset-1));return e.skip(1),Pn(r),r;}function mo(e,t){return Dn.decode(e.readBytes(t));}var ke={UNKNOWN:-1,GREYSCALE:0,TRUECOLOUR:2,INDEXED_COLOUR:3,GREYSCALE_ALPHA:4,TRUECOLOUR_ALPHA:6},pt={UNKNOWN:-1,DEFLATE:0},It={UNKNOWN:-1,ADAPTIVE:0},Ye={UNKNOWN:-1,NO_INTERLACE:0,ADAM7:1},Bt={NONE:0,BACKGROUND:1,PREVIOUS:2},Xt={SOURCE:0,OVER:1};var Mt=class extends at{constructor(r,n={}){super(r);ye(this,"_checkCrc");ye(this,"_inflator");ye(this,"_png");ye(this,"_apng");ye(this,"_end");ye(this,"_hasPalette");ye(this,"_palette");ye(this,"_hasTransparency");ye(this,"_transparency");ye(this,"_compressionMethod");ye(this,"_filterMethod");ye(this,"_interlaceMethod");ye(this,"_colorType");ye(this,"_isAnimated");ye(this,"_numberOfFrames");ye(this,"_numberOfPlays");ye(this,"_frames");ye(this,"_writingDataChunks");ye(this,"_chunks");ye(this,"_inflatorResult");var{checkCrc:i=!1}=n;this._checkCrc=i,this._inflator=new Ft((o,s)=>{if(this._chunks.push(o),s){var a=this._chunks.reduce((f,l)=>f+l.length,0);this._inflatorResult=new Uint8Array(a);var c=0;for(var f of this._chunks)this._inflatorResult.set(f,c),c+=f.length;this._chunks=[];}}),this._chunks=[],this._png={width:-1,height:-1,channels:-1,data:new Uint8Array(0),depth:1,text:{}},this._apng={width:-1,height:-1,channels:-1,depth:1,numberOfFrames:1,numberOfPlays:0,text:{},frames:[]},this._end=!1,this._hasPalette=!1,this._palette=[],this._hasTransparency=!1,this._transparency=new Uint16Array(0),this._compressionMethod=pt.UNKNOWN,this._filterMethod=It.UNKNOWN,this._interlaceMethod=Ye.UNKNOWN,this._colorType=ke.UNKNOWN,this._isAnimated=!1,this._numberOfFrames=1,this._numberOfPlays=0,this._frames=[],this._writingDataChunks=!1,this._inflatorResult=new Uint8Array(0),this.setBigEndian();}decode(){for(br(this);!this._end;){var _r2=this.readUint32(),n=this.readChars(4);this.decodeChunk(_r2,n);}return this._inflator.push(new Uint8Array(0),!0),this.decodeImage(),this._png;}decodeApng(){for(br(this);!this._end;){var _r3=this.readUint32(),n=this.readChars(4);this.decodeApngChunk(_r3,n);}return this.decodeApngImage(),this._apng;}decodeChunk(r,n){var i=this.offset;switch(n){case"IHDR":this.decodeIHDR();break;case"PLTE":this.decodePLTE(r);break;case"IDAT":this.decodeIDAT(r);break;case"IEND":this._end=!0;break;case"tRNS":this.decodetRNS(r);break;case"iCCP":this.decodeiCCP(r);break;case Er:On(this._png.text,this,r);break;case"pHYs":this.decodepHYs();break;default:this.skip(r);break;}if(this.offset-i!==r)throw new Error(`Length mismatch while decoding chunk ${n}`);this._checkCrc?wr(this,r+4,n):this.skip(4);}decodeApngChunk(r,n){var i=this.offset;switch(n!=="fdAT"&&n!=="IDAT"&&this._writingDataChunks&&this.pushDataToFrame(),n){case"acTL":this.decodeACTL();break;case"fcTL":this.decodeFCTL();break;case"fdAT":this.decodeFDAT(r);break;default:this.decodeChunk(r,n),this.offset=i+r;break;}if(this.offset-i!==r)throw new Error(`Length mismatch while decoding chunk ${n}`);this._checkCrc?wr(this,r+4,n):this.skip(4);}decodeIHDR(){var r=this._png;r.width=this.readUint32(),r.height=this.readUint32(),r.depth=wo(this.readUint8());var n=this.readUint8();this._colorType=n;var i;switch(n){case ke.GREYSCALE:i=1;break;case ke.TRUECOLOUR:i=3;break;case ke.INDEXED_COLOUR:i=1;break;case ke.GREYSCALE_ALPHA:i=2;break;case ke.TRUECOLOUR_ALPHA:i=4;break;case ke.UNKNOWN:default:throw new Error(`Unknown color type: ${n}`);}if(this._png.channels=i,this._compressionMethod=this.readUint8(),this._compressionMethod!==pt.DEFLATE)throw new Error(`Unsupported compression method: ${this._compressionMethod}`);this._filterMethod=this.readUint8(),this._interlaceMethod=this.readUint8();}decodeACTL(){this._numberOfFrames=this.readUint32(),this._numberOfPlays=this.readUint32(),this._isAnimated=!0;}decodeFCTL(){var r={sequenceNumber:this.readUint32(),width:this.readUint32(),height:this.readUint32(),xOffset:this.readUint32(),yOffset:this.readUint32(),delayNumber:this.readUint16(),delayDenominator:this.readUint16(),disposeOp:this.readUint8(),blendOp:this.readUint8(),data:new Uint8Array(0)};this._frames.push(r);}decodePLTE(r){if(r%3!==0)throw new RangeError(`PLTE field length must be a multiple of 3. Got ${r}`);var n=r/3;this._hasPalette=!0;var i=[];this._palette=i;for(var o=0;o<n;o++)i.push([this.readUint8(),this.readUint8(),this.readUint8()]);}decodeIDAT(r){this._writingDataChunks=!0;var n=r,i=this.offset+this.byteOffset;try{this._inflator.push(new Uint8Array(this.buffer,i,n),!1);}catch(o){throw new Error("Error while decompressing the data:",{cause:o});}this.skip(r);}decodeFDAT(r){this._writingDataChunks=!0;var n=r,i=this.offset+this.byteOffset;i+=4,n-=4;try{this._inflator.push(new Uint8Array(this.buffer,i,n),!1);}catch(o){throw new Error("Error while decompressing the data:",{cause:o});}this.skip(r);}decodetRNS(r){switch(this._colorType){case ke.GREYSCALE:case ke.TRUECOLOUR:{if(r%2!==0)throw new RangeError(`tRNS chunk length must be a multiple of 2. Got ${r}`);if(r/2>this._png.width*this._png.height)throw new Error(`tRNS chunk contains more alpha values than there are pixels (${r/2} vs ${this._png.width*this._png.height})`);this._hasTransparency=!0,this._transparency=new Uint16Array(r/2);for(var n=0;n<r/2;n++)this._transparency[n]=this.readUint16();break;}case ke.INDEXED_COLOUR:{if(r>this._palette.length)throw new Error(`tRNS chunk contains more alpha values than there are palette colors (${r} vs ${this._palette.length})`);var _n2=0;for(;_n2<r;_n2++){var i=this.readByte();this._palette[_n2].push(i);}for(;_n2<this._palette.length;_n2++)this._palette[_n2].push(255);break;}case ke.UNKNOWN:case ke.GREYSCALE_ALPHA:case ke.TRUECOLOUR_ALPHA:default:throw new Error(`tRNS chunk is not supported for color type ${this._colorType}`);}}decodeiCCP(r){var n=_r(this),i=this.readUint8();if(i!==pt.DEFLATE)throw new Error(`Unsupported iCCP compression method: ${i}`);var o=this.readBytes(r-n.length-2);this._png.iccEmbeddedProfile={name:n,profile:En(o)};}decodepHYs(){var r=this.readUint32(),n=this.readUint32(),i=this.readByte();this._png.resolution={x:r,y:n,unit:i};}decodeApngImage(){this._apng.width=this._png.width,this._apng.height=this._png.height,this._apng.channels=this._png.channels,this._apng.depth=this._png.depth,this._apng.numberOfFrames=this._numberOfFrames,this._apng.numberOfPlays=this._numberOfPlays,this._apng.text=this._png.text,this._apng.resolution=this._png.resolution;for(var _r4=0;_r4<this._numberOfFrames;_r4++){var n={sequenceNumber:this._frames[_r4].sequenceNumber,delayNumber:this._frames[_r4].delayNumber,delayDenominator:this._frames[_r4].delayDenominator,data:this._apng.depth===8?new Uint8Array(this._apng.width*this._apng.height*this._apng.channels):new Uint16Array(this._apng.width*this._apng.height*this._apng.channels)},i=this._frames.at(_r4);if(i){if(i.data=Ar({data:i.data,width:i.width,height:i.height,channels:this._apng.channels,depth:this._apng.depth}),this._hasPalette&&(this._apng.palette=this._palette),this._hasTransparency&&(this._apng.transparency=this._transparency),_r4===0||i.xOffset===0&&i.yOffset===0&&i.width===this._png.width&&i.height===this._png.height)n.data=i.data;else{var o=this._apng.frames.at(_r4-1);this.disposeFrame(i,o,n),this.addFrameDataToCanvas(n,i);}this._apng.frames.push(n);}}return this._apng;}disposeFrame(r,n,i){switch(r.disposeOp){case Bt.NONE:break;case Bt.BACKGROUND:for(var o=0;o<this._png.height;o++)for(var s=0;s<this._png.width;s++){var a=(o*r.width+s)*this._png.channels;for(var c=0;c<this._png.channels;c++)i.data[a+c]=0;}break;case Bt.PREVIOUS:i.data.set(n.data);break;default:throw new Error("Unknown disposeOp");}}addFrameDataToCanvas(r,n){var i=1<<this._png.depth,o=(s,a)=>{var c=((s+n.yOffset)*this._png.width+n.xOffset+a)*this._png.channels,f=(s*n.width+a)*this._png.channels;return{index:c,frameIndex:f};};switch(n.blendOp){case Xt.SOURCE:for(var s=0;s<n.height;s++)for(var a=0;a<n.width;a++){var{index:c,frameIndex:f}=o(s,a);for(var l=0;l<this._png.channels;l++)r.data[c+l]=n.data[f+l];}break;case Xt.OVER:for(var _s3=0;_s3<n.height;_s3++)for(var _a5=0;_a5<n.width;_a5++){var{index:_c3,frameIndex:_f4}=o(_s3,_a5);for(var _l7=0;_l7<this._png.channels;_l7++){var h=n.data[_f4+this._png.channels-1]/i,y=_l7%(this._png.channels-1)===0?1:n.data[_f4+_l7],A=Math.floor(h*y+(1-h)*r.data[_c3+_l7]);r.data[_c3+_l7]+=A;}}break;default:throw new Error("Unknown blendOp");}}decodeImage(){var r=this._inflatorResult;if(this._filterMethod!==It.ADAPTIVE)throw new Error(`Filter method ${this._filterMethod} not supported`);if(this._interlaceMethod===Ye.NO_INTERLACE)this._png.data=Ar({data:r,width:this._png.width,height:this._png.height,channels:this._png.channels,depth:this._png.depth});else if(this._interlaceMethod===Ye.ADAM7)this._png.data=In({data:r,width:this._png.width,height:this._png.height,channels:this._png.channels,depth:this._png.depth});else throw new Error(`Interlace method ${this._interlaceMethod} not supported`);this._hasPalette&&(this._png.palette=this._palette),this._hasTransparency&&(this._png.transparency=this._transparency);}pushDataToFrame(){this._inflator.push(new Uint8Array(0),!0);var r=this._inflatorResult,n=this._frames.at(-1);n?n.data=r:this._frames.push({sequenceNumber:0,width:this._png.width,height:this._png.height,xOffset:0,yOffset:0,delayNumber:0,delayDenominator:0,disposeOp:Bt.NONE,blendOp:Xt.SOURCE,data:r}),this._inflator=new Ft((i,o)=>{if(this._chunks.push(i),o){var s=this._chunks.reduce((c,f)=>c+f.length,0);this._inflatorResult=new Uint8Array(s);var a=0;for(var c of this._chunks)this._inflatorResult.set(c,a),a+=c.length;this._chunks=[];}}),this._chunks=[],this._writingDataChunks=!1;}};function wo(e){if(e!==1&&e!==2&&e!==4&&e!==8&&e!==16)throw new Error(`invalid bit depth: ${e}`);return e;}var Ao={level:3},Rt=class extends at{constructor(r,n={}){super();ye(this,"_png");ye(this,"_zlibOptions");ye(this,"_colorType");ye(this,"_interlaceMethod");this._colorType=ke.UNKNOWN,this._zlibOptions={...Ao,...n.zlib},this._png=this._checkData(r),this._interlaceMethod=(n.interlace==="Adam7"?Ye.ADAM7:Ye.NO_INTERLACE)??Ye.NO_INTERLACE,this.setBigEndian();}encode(){if(Bn(this),this.encodeIHDR(),this._png.palette&&(this.encodePLTE(),this._png.palette[0].length===4&&this.encodeTRNS()),this.encodeData(),this._png.text)for(var[_r5,n]of Object.entries(this._png.text))Ln(this,_r5,n);return this.encodeIEND(),this.toArray();}encodeIHDR(){this.writeUint32(13),this.writeChars("IHDR"),this.writeUint32(this._png.width),this.writeUint32(this._png.height),this.writeByte(this._png.depth),this.writeByte(this._colorType),this.writeByte(pt.DEFLATE),this.writeByte(It.ADAPTIVE),this.writeByte(this._interlaceMethod),tt(this,17);}encodeIEND(){this.writeUint32(0),this.writeChars("IEND"),tt(this,4);}encodePLTE(){var r=this._png.palette?.length*3;this.writeUint32(r),this.writeChars("PLTE");for(var n of this._png.palette)this.writeByte(n[0]),this.writeByte(n[1]),this.writeByte(n[2]);tt(this,4+r);}encodeTRNS(){var r=this._png.palette.filter(n=>n.at(-1)!==255);this.writeUint32(r.length),this.writeChars("tRNS");for(var n of r)this.writeByte(n.at(-1));tt(this,4+r.length);}encodeIDAT(r){this.writeUint32(r.length),this.writeChars("IDAT"),this.writeBytes(r),tt(this,r.length+4);}encodeData(){var{width:r,height:n,channels:i,depth:o,data:s}=this._png,a=o<=8?Math.ceil(r*o/8)*i:Math.ceil(r*o/8*i/2),c=new at().setBigEndian(),f=0;if(this._interlaceMethod===Ye.NO_INTERLACE)for(var y=0;y<n;y++)c.writeByte(0),o===16?f=So(s,c,a,f):f=Eo(s,c,a,f);else this._interlaceMethod===Ye.ADAM7&&(f=_o(this._png,s,c,f));var l=c.toArray(),h=bn(l,this._zlibOptions);this.encodeIDAT(h);}_checkData(r){var{colorType:n,channels:i,depth:o}=bo(r,r.palette),s={width:zn(r.width,"width"),height:zn(r.height,"height"),channels:i,data:r.data,depth:o,text:r.text,palette:r.palette};this._colorType=n;var a=o<8?Math.ceil(s.width*o/8)*s.height*i:s.width*s.height*i;if(s.data.length!==a)throw new RangeError(`wrong data size. Found ${s.data.length}, expected ${a}`);return s;}};function zn(e,t){if(Number.isInteger(e)&&e>0)return e;throw new TypeError(`${t} must be a positive integer`);}function bo(e,t){var{channels:r=4,depth:n=8}=e;if(r!==4&&r!==3&&r!==2&&r!==1)throw new RangeError(`unsupported number of channels: ${r}`);var i={channels:r,depth:n,colorType:ke.UNKNOWN};switch(r){case 4:i.colorType=ke.TRUECOLOUR_ALPHA;break;case 3:i.colorType=ke.TRUECOLOUR;break;case 1:t?i.colorType=ke.INDEXED_COLOUR:i.colorType=ke.GREYSCALE;break;case 2:i.colorType=ke.GREYSCALE_ALPHA;break;default:throw new Error("unsupported number of channels");}return i;}function Eo(e,t,r,n){for(var i=0;i<r;i++)t.writeByte(e[n++]);return n;}function _o(e,t,r,n){var i=[{x:0,y:0,xStep:8,yStep:8},{x:4,y:0,xStep:8,yStep:8},{x:0,y:4,xStep:4,yStep:8},{x:2,y:0,xStep:4,yStep:4},{x:0,y:2,xStep:2,yStep:4},{x:1,y:0,xStep:2,yStep:2},{x:0,y:1,xStep:1,yStep:2}],{width:o,height:s,channels:a,depth:c}=e,f;c===16?f=a*c/8/2:f=a*c/8;for(var l=0;l<7;l++){var h=i[l],y=Math.floor((o-h.x+h.xStep-1)/h.xStep),A=Math.floor((s-h.y+h.yStep-1)/h.yStep);if(y<=0||A<=0)continue;var C=y*f;for(var x=0;x<A;x++){var E=h.y+x*h.yStep,v=c<=8?new Uint8Array(C):new Uint16Array(C),w=0;for(var u=0;u<y;u++){var m=h.x+u*h.xStep;if(m<o&&E<s){var d=(E*o+m)*f;for(var D=0;D<f;D++)v[w++]=t[d+D];}}if(r.writeByte(0),c===8)r.writeBytes(v);else if(c===16)for(var _u of v)r.writeByte(_u>>8&255),r.writeByte(_u&255);}}return n;}function So(e,t,r,n){for(var i=0;i<r;i++)t.writeUint16(e[n++]);return n;}function Gn(e,t){return new Mt(e,t).decode();}function Hn(e,t){return new Rt(e,t).encode();}var qn=bt(Xn(),1);var Jt=bt(or(),1),Ve=320,Fo=16e6,Zn=[137,80,78,71,13,10,26,10],kr=(e,t)=>e[t]*16777216+e[t+1]*65536+e[t+2]*256+e[t+3],Xe=()=>new Error("This image could not be decoded. Reopen the original image and try again.");function Jn(e,t){if(!Number.isInteger(e)||!Number.isInteger(t)||e<1||t<1)throw Xe();if(e>16384||t>16384||e*t>Fo)throw new Error("This image is too large to prepare locally. Choose an image under 16 megapixels.");}function Uo(e,t){if(e.length<33||Zn.some((v,w)=>e[w]!==v))throw Xe();var r=kr(e,16),n=kr(e,20),i=e[24],o=e[25],s=e[28];Jn(r,n);var a={0:1,2:3,3:1,4:2,6:4}[o];if(!a||![1,2,4,8,16].includes(i)||s>1)throw Xe();var c=s?[[0,0,8,8],[4,0,8,8],[0,4,4,8],[2,0,4,4],[0,2,2,4],[1,0,2,2],[0,1,1,2]]:[[0,0,1,1]],f=0;for(var[v,w,u,m]of c){var d=Math.max(0,Math.ceil((r-v)/u)),D=Math.max(0,Math.ceil((n-w)/m));d&&D&&(f+=(Math.ceil(d*a*i/8)+1)*D);}var l=[e.subarray(0,8)],h=[],y=!1;for(var _v=8;_v+12<=e.length;){t();var _w2=kr(e,_v),_u2=_v+_w2+12;if(_u2>e.length)throw Xe();var _m2=String.fromCharCode(...e.subarray(_v+4,_v+8));if(_v===8&&(_m2!=="IHDR"||_w2!==13))throw Xe();if(_m2==="acTL")throw Object.assign(new Error("Use the original 320\xD7320 APNG or an animated GIF to keep this animation."),{code:"ANIMATED_PNG"});if(["IHDR","PLTE","tRNS","IDAT","IEND"].includes(_m2)&&l.push(e.subarray(_v,_u2)),_m2==="IDAT"&&h.push(e.subarray(_v+8,_v+8+_w2)),_v=_u2,_m2==="IEND"){y=!0;break;}}if(!y||!h.length)throw Xe();var A=0,C=new Ft(v=>{if(A+=v.length,A>f)throw Xe();});for(var _v2 of h)for(var _w3=0;_w3<_v2.length;_w3+=1024)t(),C.push(_v2.subarray(_w3,_w3+1024),!1);if(C.push(new Uint8Array(0),!0),A!==f)throw Xe();var x=new Uint8Array(l.reduce((v,w)=>v+w.length,0)),E=0;for(var _v3 of l)x.set(_v3,E),E+=_v3.length;return x;}function Io(e){if(!e)return 1;try{var _t3=-1;for(var s=0;s<Math.min(12,e.length-8);s++)if(e[s]===73&&e[s+1]===73||e[s]===77&&e[s+1]===77){_t3=s;break;}if(_t3<0)return 1;var _r6=new DataView(e.buffer,e.byteOffset+_t3,e.byteLength-_t3),n=e[_t3]===73,i=_r6.getUint32(4,n),o=Math.min(_r6.getUint16(i,n),256);for(var _s4=0;_s4<o;_s4++){var a=i+2+_s4*12;if(_r6.getUint16(a,n)===274){var c=_r6.getUint16(a+8,n);return c>=1&&c<=8?c:1;}}}catch{}return 1;}function Zt(e,t,r,n){var{width:i,height:o,data:s,channels:a=4,depth:c=8,palette:f,transparency:l,orientation:h=1}=e,y=t,A=r;h===2&&(y=i-1-t),h===3&&(y=i-1-t,A=o-1-r),h===4&&(A=o-1-r),h===5&&(y=r,A=t),h===6&&(y=r,A=o-1-t),h===7&&(y=i-1-r,A=o-1-t),h===8&&(y=i-1-r,A=t);var C=A*i+y;if(f||c<8){var v=y*c,w=Math.ceil(i*c/8),u=c===8?s[C]:s[A*w+(v>>3)]>>8-c-(v&7)&(1<<c)-1;if(f){var m=f[u];if(!m)throw Xe();n[0]=m[0],n[1]=m[1],n[2]=m[2],n[3]=m[3]??255;}else n[0]=n[1]=n[2]=u*255/((1<<c)-1),n[3]=l?.[0]===u?0:255;return;}var x=C*a,E=c===16?1/257:1;n[0]=s[x]*E,a<=2?(n[1]=n[2]=n[0],n[3]=a===2?s[x+1]*E:l?.[0]===s[x]?0:255):(n[1]=s[x+1]*E,n[2]=s[x+2]*E,n[3]=a===4?s[x+3]*E:l?.length===3&&l[0]===s[x]&&l[1]===s[x+1]&&l[2]===s[x+2]?0:255);}function Tr(e,t=()=>{}){t();var r=(0,Jt.toByteArray)(e.replace(/\s/g,"")),n;if(Zn.every((x,E)=>r[E]===x))n=Gn(Uo(r,t),{checkCrc:!0});else if(r[0]===255&&r[1]===216)n=qn.default.decode(r,{useTArray:!0,formatAsRGBA:!0,tolerantDecoding:!1,maxResolutionInMP:16,maxMemoryUsageInMB:128}),n={...n,channels:4,depth:8,orientation:Io(n.exifBuffer)};else throw Object.assign(new Error("This image format needs conversion to PNG."),{code:"STATIC_FORMAT_UNSUPPORTED"});t(),Jn(n.width,n.height);var i=n.orientation>=5,o=i?n.height:n.width,s=i?n.width:n.height,a=Math.min(Ve/o,Ve/s),c=Math.max(1,Math.round(o*a)),f=Math.max(1,Math.round(s*a)),l=Math.floor((Ve-c)/2),h=Math.floor((Ve-f)/2),y=new Uint8Array(Ve*Ve*4),A=Array.from({length:4},()=>new Float64Array(4));for(var x=0;x<f;x++){x%16===0&&t();var E=Math.max(0,Math.min(s-1,(x+.5)*s/f-.5)),v=Math.floor(E),w=Math.min(s-1,v+1),u=E-v;for(var m=0;m<c;m++){var d=Math.max(0,Math.min(o-1,(m+.5)*o/c-.5)),D=Math.floor(d),g=Math.min(o-1,D+1),B=d-D;Zt(n,D,v,A[0]),Zt(n,g,v,A[1]),Zt(n,D,w,A[2]),Zt(n,g,w,A[3]);var _=[(1-B)*(1-u),B*(1-u),(1-B)*u,B*u],U=((x+h)*Ve+m+l)*4,P=0;for(var L=0;L<4;L++)P+=A[L][3]*_[L];if(y[U+3]=Math.round(P),P)for(var _L=0;_L<3;_L++){var $=0;for(var re=0;re<4;re++)$+=A[re][_L]*A[re][3]*_[re];y[U+_L]=Math.round($/P);}}}t();var C=Hn({width:Ve,height:Ve,data:y,channels:4,depth:8});if(C.length>512*1024)throw new Error("The prepared sticker is over 512 KiB.");return t(),{base64:(0,Jt.fromByteArray)(C),mimeType:"image/png"};}var Bo=(()=>{"use strict";var e=typeof vendetta<"u"?vendetta:globalThis.vendetta;if(!e?.metro||!e?.patcher)throw new Error("SaveAsSticker needs Revenge's Vendetta plugin support.");var{React:t,ReactNative:r,constants:n}=e.metro.common,i=t.createElement,o=on(e),s=sn(e,"SaveAsStickerPicker"),a=an(e,{title:"Save as Sticker",id:"save-as-sticker",testID:"SaveAsStickerPage"}),c="SaveAsStickerPicker",f="save-as-sticker-action",l=512*1024,h=25*1024*1024,y=[5,15,30,60],A=[],C=new Set(),x=!1,E=0,v=!1,w,u=(...p)=>{try{return e.metro.findByProps(...p);}catch{return;}},m=p=>{try{return e.metro.findByStoreName(p);}catch{return;}},d=(...p)=>{for(var R of p)try{var I=e.ui.assets.getAssetIDByName(R);if(I!=null)return I;}catch{}},D=(...p)=>e.logger?.error?.("[SaveAsSticker]",...p),g=p=>{try{e.ui.toasts.showToast(p,d("StickerIcon","ic_sticker_24px"));}catch{console.log("[SaveAsSticker]",p);}},B=u("openLazy","hideActionSheet"),_=u("ActionSheetRow")?.ActionSheetRow,U=e.ui.components?.Forms??{},P=u("ActionSheetTitleHeader")?.ActionSheetTitleHeader??u("BottomSheetTitleHeader")?.BottomSheetTitleHeader,L=u("ActionSheetCloseButton")?.ActionSheetCloseButton,$=u("GuildIconSizes"),re=$?.default,W=$?.GuildIconSizes,K=u("BottomSheetFlatList")?.BottomSheetFlatList??u("BottomSheetScrollView")?.BottomSheetFlatList??r.FlatList,X=u("ActionSheet")?.ActionSheet;if(!X)try{X=e.metro.find(p=>p?.render?.name==="ActionSheet");}catch{}function j(p){var R=String(p||"sticker").replace(/\.[a-z0-9]{1,6}$/i,"").replace(/[\u0000-\u001f]/g,"").trim().slice(0,30);return R.length>=2?R:"sticker";}function q(p,R=!1){if(!p)return null;var I=String(p.content_type??p.contentType??p.mimeType??""),F=p.mediaType??p.type,N=[p.url,p.sourceURI,p.mediaUrl,p.uri,p.proxy_url,p.proxyURL,p.image?.url,p.thumbnail?.url,p.video?.url].find(T=>typeof T=="string"&&/\.gif(?:[?#]|$)/i.test(T)),Y=I==="image/gif"||!!N;if(!Y&&(/^(video|audio)\//i.test(I)||/^(video|audio|file)$/i.test(String(F))))return null;var V=N??p.mediaUrl??p.sourceURI??p.url??p.uri??p.proxy_url??p.proxyURL;if(N&&(V=V.replace(/([?&])format=(?:webp|png|jpe?g|mp4)(?=&|$)/gi,"$1").replace(/([?&])animated=false(?=&|$)/gi,"$1").replace(/\?&/,"?").replace(/&&+/g,"&").replace(/[?&]$/,"")),typeof V!="string"||!/^https:\/\//i.test(V))return null;var oe=p.filename??p.name??V.split(/[?#]/)[0].split("/").pop()??"sticker";return!R&&F!=="image"&&!I.startsWith("image/")&&!/\.(png|apng|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i.test(oe)&&!/\.(png|apng|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i.test(V)?null:{url:V,proxyURL:p.proxy_url??p.proxyURL,filename:oe,contentType:Y?"image/gif":I,id:p.id??p.attachmentId};}function xe(...p){var R=p.flatMap(F=>{if(!F||typeof F!="object")return[];var S=F.analyticsLocation;return S&&typeof S=="object"?[F,S]:[F];});for(var F of R)if(F.selectedMedia){var S=F.selectedMedia,N=q({...S.source,...S},S.mediaType==="image");return N?[N]:[];}for(var _F of R){var _S=_F.source;if(_F.syncer?.sources){var _N=_F.syncer.index?.value??_F.syncer.index??0;_S=_F.syncer.sources[_N];}if(Array.isArray(_S)&&(_S=_S[0]),_S){var _N2=q(_S);return _N2?[_N2]:[];}}var I=[];for(var _F2 of R){for(var _S2 of _F2.message?.attachments??[]){var _N3=q(_S2);_N3&&I.push(_N3);}for(var _S3 of _F2.message?.embeds??[])for(var _N4 of[_S3.image,...(_S3.images??[]),_S3.type==="image"?_S3:null,_S3.type==="gifv"&&/\.gif(?:[?#]|$)/i.test(_S3.video?.url??"")?{..._S3.video,contentType:"image/gif"}:null,_S3.type==="gifv"&&/\.gif(?:[?#]|$)/i.test(_S3.thumbnail?.url??"")?_S3.thumbnail:null]){var Y=q(_N4,!0);Y&&I.push(Y);}}return I.filter((F,S)=>I.findIndex(N=>N.url===F.url)===S);}function ie(p){if(!p?.id||p.unavailable)return!1;var R=m("UserStore")?.getCurrentUser?.()?.id;if(R&&(p.ownerId===R||p.owner_id===R))return!0;var I=n?.Permissions?.CREATE_GUILD_EXPRESSIONS??1n<<43n;try{return!!m("PermissionStore")?.can?.(I,p);}catch{return!1;}}function ne(p){var R=Number(p.premiumTier??p.premium_tier??0),I=p.features,F=Array.isArray(I)?I.includes("MORE_STICKERS"):I?.has?.("MORE_STICKERS"),S=Number(p.premiumFeatures?.additionalStickerSlots??p.premium_features?.additional_sticker_slots??0),N=F&&R===3?120:y[R]??y[0],Y=Number(p.maxStickers??p.max_stickers??0),V=Math.max(N+(Number.isFinite(S)?Math.max(0,S):0),Y||0),T=(m("GuildStickersStore")??m("StickersStore")??m("StickerStore"))?.getStickersByGuildId?.(p.id)??p.stickers;return T&&!Array.isArray(T)&&(T=Object.values(T)),{max:V,used:Array.isArray(T)?T.length:null};}function Z(){return Object.values(m("GuildStore")?.getGuilds?.()??{}).filter(ie).sort((p,R)=>String(p.name).localeCompare(String(R.name)));}function b(p){var R=Number(p?.body?.code??p?.code);if(R===50013)return"You need Create Expressions permission in this server.";if(R===30039)return"This server has no free sticker slots. Choose another server.";var I=nn(p);if(I)return I;for(var F of[p?.body?.message,p?.message,p?.text])if(!(typeof F!="string"||!F))try{return JSON.parse(F)?.message??F;}catch{return F;}return"Discord could not upload the sticker. Please try again.";}function z(){return o.files();}function ce(p,R){return new Promise((I,F)=>{var S=new FileReader(),N=!1,Y=(oe,T)=>{N||(N=!0,R?.removeEventListener?.("abort",V),oe(T));},V=()=>{Y(F,Object.assign(new Error("Cancelled"),{code:"E_PICKER_CANCELLED"}));try{S.abort?.();}catch{}};if(S.onerror=()=>Y(F,S.error??new Error("Could not read the image.")),S.onload=()=>Y(I,String(S.result).split(",")[1]),R?.aborted){V();return;}R?.addEventListener?.("abort",V);try{S.readAsDataURL(p);}catch(oe){Y(F,oe);}});}function ve(p){return Math.floor(p.length*3/4)-(p.endsWith("==")?2:p.endsWith("=")?1:0);}function J(p){var R="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",I=[],F=0,S=0;for(var V of p.slice(0,44)){var oe=R.indexOf(V);if(oe<0)break;S=S<<6|oe,F+=6,F>=8&&(F-=8,I.push(S>>>F&255));}var N=[137,80,78,71,13,10,26,10];if(I.length<24||N.some((V,oe)=>I[oe]!==V)||String.fromCharCode(...I.slice(12,16))!=="IHDR")return null;var Y=V=>I[V]*16777216+I[V+1]*65536+I[V+2]*256+I[V+3];return{width:Y(16),height:Y(20)};}function le(p){if(typeof p!="string"||!p)throw new Error("Discord did not return a local image path.");return /^(file|content):\/\//.test(p)?p:"file://"+p;}async function ae(p,R,I={}){var F=z();if(!F?.writeFile||!F?.removeFile)throw new Error("Discord's image file module is unavailable on this build.");var S=[],N=u("launchCropper","cleanSingle")??u("launchCropper"),Y;async function V(){if(Y&&N?.cleanSingle)try{await N.cleanSingle(Y);}catch{}for(var T of S)try{await F.removeFile("cache",T);}catch{}}async function oe(T,H){try{return Tr(T,R).base64;}catch(Q){if(Q?.code!=="STATIC_FORMAT_UNSUPPORTED")throw Q;var ge=p.proxyURL??H;if(!/^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/(?:attachments|ephemeral-attachments|external)\//i.test(ge))throw new Error("Use a PNG or JPEG image, or an animated GIF. This image format could not be converted.");var M=new URL(ge.replace(/^https:\/\/cdn\.discordapp\.com/i,"https://media.discordapp.net"));M.searchParams.set("format","png"),M.searchParams.set("width","320"),M.searchParams.set("height","320"),R();var ee=await(e.utils?.safeFetch??fetch)(M.toString(),{signal:I.controller?.signal},2e4);if(!ee.ok)throw new Error("Discord could not convert this image to PNG. Use the original PNG or JPEG.");var fe=await ee.blob();if(fe.size>h)throw new Error("Choose an image smaller than 25 MB.");var te=await ce(fe,I.controller?.signal);return R(),Tr(te,R).base64;}}try{var T=p.url,H=u("maybeRefreshAttachmentUrl");if(/^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\//i.test(T))try{T=(await H?.maybeRefreshAttachmentUrl?.(T))||T;}catch{}R();var Q=await(e.utils?.safeFetch??fetch)(T,{signal:I.controller?.signal},2e4);if(!Q.ok)throw new Error("Image download failed (HTTP "+Q.status+"). Reopen the image and try again.");if(Number(Q.headers?.get?.("content-length"))>h)throw new Error("Choose an image smaller than 25 MB.");var ge=await Q.blob();if(ge.size>h)throw new Error("Choose an image smaller than 25 MB.");var M=await ce(ge,I.controller?.signal);if(R(),!M)throw new Error("The image is empty.");var ee="save-as-sticker-"+Date.now()+"-"+Math.random().toString(36).slice(2);if(Qr(M)){g("Preparing animated GIF\u2026");var me=await tn(M,R);R();var Ae=ee+"-sticker.gif";S.push(Ae);var Ue=le(await F.writeFile("cache",Ae,me.base64,"base64"));return R(),{uri:Ue,mimeType:me.mimeType,cleanup:V};}if(p.contentType==="image/gif"||ge.type==="image/gif")throw new Error("This link returned a video or still preview. Share the original .gif file and try again.");var fe=J(M);if(!fe||fe.width!==320||fe.height!==320||ve(M)>l)if(!N?.launchCropper)M=await oe(M,T);else{var _me=M,_Ae=ge.type||p.contentType||"image/png",_Ue=/jpeg/i.test(_Ae)?"jpg":/webp/i.test(_Ae)?"webp":/avif/i.test(_Ae)?"avif":"png",Pe=ee+"."+_Ue;S.push(Pe);var Ne=le(await F.writeFile("cache",Pe,M,"base64"));R();var Ie;try{Ie=await N.launchCropper({uri:Ne,width:320,height:320,mimeType:"image/png",includeBase64:!0,freeStyleCropEnabled:!1});}catch(_e){if(_e?.code==="E_PICKER_CANCELLED"||/cancel/i.test(String(_e?.message??"")))throw _e;R();}Y=Ie?.path??Ie?.uri,R(),M=Ie?.data??Ie?.base64,!M&&Y&&F.readFile&&(M=await F.readFile(Y.replace(/^file:\/\//,""),"base64")),(typeof M!="string"||!M)&&(M=_me),M=M.replace(/^data:[^,]*,/,"").replace(/\s/g,"");var Te=J(M);(!Te||Te.width!==320||Te.height!==320||ve(M)>l)&&(M=await oe(M,T));}var te=J(M);if(!te||te.width!==320||te.height!==320)throw new Error("The cropper did not produce a 320\xD7320 PNG. The sticker was not uploaded.");if(ve(M)>l)throw new Error("The cropped sticker is over 512 KiB. Try a simpler image.");var pe=ee+"-sticker.png";S.push(pe);var Ee=le(await F.writeFile("cache",pe,M,"base64"));return R(),{uri:Ee,mimeType:"image/png",cleanup:V};}catch(T){throw await V(),T;}}async function G(p,R,I,F){if(v||!x)return;var S=F?.control??{};v=S,C.add(S);var N=E,Y=m("UserStore")?.getCurrentUser?.()?.id,V=()=>{if(!x||E!==N||S.cancelled||S.expired||F&&!F.isCurrent()||!Y||m("UserStore")?.getCurrentUser?.()?.id!==Y)throw Object.assign(new Error("Cancelled"),{code:"E_PICKER_CANCELLED"});},oe,T;S.cancel=H=>{S.cancelled=!0;try{S.controller?.abort();}catch{}S.writing&&!H||(clearTimeout(T),v===S&&(v=!1));};try{if(I.length<2||I.length>30)throw new Error("Use a sticker name between 2 and 30 characters.");if(!Y)throw new Error("Your Discord account is still loading. Reopen the picker and try again.");V();var H=o.resolve("sticker");F||(B.hideActionSheet(c),r.Keyboard?.dismiss?.(),await new Promise(fe=>setTimeout(fe,300))),V(),g("Preparing your sticker\u2026"),oe=await ae(R,V,S),V();var Q=m("GuildStore"),ge=Q?.getGuild?.(p.id)??Q?.getGuilds?.()?.[p.id];if(!ie(ge))throw new Error("You no longer have Create Expressions permission in this server.");var M=ne(ge);if(M.used!=null&&M.used>=M.max)throw new Error("This server has no free sticker slots. Choose another server.");g("Adding sticker to "+p.name+"\u2026"),S.writing=!0,F&&(T=setTimeout(()=>{S.expired=!0,v===S&&(v=!1),F.isCurrent()&&(F.onError("Discord\u2019s upload response timed out. Check the server\u2019s stickers before trying again."),F.onFinished());},45e3));var ee=await H({guildId:p.id,name:I,tags:"slight_smile",description:"",uri:oe.uri,mimeType:oe.mimeType,platform:"mobile",originalMd5:null},V,S.controller?.signal);if(V(),!ee?.id&&!ee?.body?.id)throw new Error("Discord did not confirm the upload. Check the server's stickers before trying again.");F&&F.onSuccess(),x&&E===N&&g("Sticker added to "+p.name);}catch(H){if(S.cancelled||S.expired||H?.code==="E_PICKER_CANCELLED"||/cancel/i.test(String(H?.message??"")))return;if(D("Upload failed",H),x&&E===N){var _Q=b(H);F?F.isCurrent()&&F.onError(_Q):r.Alert?.alert?r.Alert.alert("Sticker could not be added",_Q):g(_Q);}}finally{clearTimeout(T),C.delete(S),v===S&&(v=!1),F?.isCurrent()&&F.onFinished(),await oe?.cleanup?.();}}function O({images:p,onClose:R,inPanel:I=!1,page:F=!1,isOpen:S}){var[N,Y]=t.useState(p.length===1?p[0]:null),[V,oe]=t.useState(null),[T,H]=t.useState(j(p[0]?.filename)),[,Q]=t.useState(0),[ge,M]=t.useState(""),[ee,fe]=t.useState(!1),[te,pe]=t.useState(""),Ee=t.useRef(!0),me=t.useRef(!1),Ae=t.useRef(),Ue=t.useRef(!1),Pe=t.useRef(E),Ne=()=>Ee.current&&!me.current&&x&&E===Pe.current&&(!S||S()),Ie=(m("ThemeStore")?.theme??r.Appearance?.getColorScheme?.())!=="light",Te={text:Ie?"#f2f3f5":"#1e1f22",muted:Ie?"#b5bac1":"#4e5058",input:Ie?"#1e1f22":"#e3e5e8"};t.useEffect(()=>{Ee.current=!0;var he=[m("GuildStore"),m("PermissionStore"),m("GuildStickersStore"),m("StickersStore")].filter(Boolean),Se=()=>Q(be=>be+1);return he.forEach(be=>be.addChangeListener?.(Se)),()=>{Ee.current=!1,Ae.current?.cancel?.(),he.forEach(be=>be.removeChangeListener?.(Se));};},[]);var _e=(he,Se={})=>i(r.Text,{style:{color:Te.text,fontSize:16,...Se}},he),rt=(he,Se,be=!1)=>i(r.Pressable,{accessibilityRole:"button",accessibilityLabel:he,disabled:be,onPress:Se,style:{padding:14,borderRadius:8,backgroundColor:be?"#555967":"#5865f2",marginTop:12}},_e(he,{color:"#ffffff",fontWeight:"600",textAlign:"center"})),qe={color:Te.text,backgroundColor:Te.input,borderRadius:8,padding:12,fontSize:16,marginTop:10},Ge=()=>{if(!me.current){me.current=!0,Ae.current?.cancel?.();try{r.Keyboard?.dismiss?.();}catch{}(R??(()=>B.hideActionSheet(c)))();}},nt=()=>{if(!F){Ge(),G(V,N,T.trim());return;}if(!Ne()||Ue.current)return;if(v){pe("A sticker upload is already in progress. You can close this page while it finishes.");return;}try{r.Keyboard?.dismiss?.();}catch{}Ue.current=!0,fe(!0),pe("");var he={controller:typeof AbortController=="function"?new AbortController():void 0};Ae.current=he,G(V,N,T.trim(),{control:he,isCurrent:Ne,onError:pe,onSuccess:Ge,onFinished(){Ae.current===he&&(Ae.current=void 0,Ue.current=!1,fe(!1));}});},Ze=N?i(r.Image,{source:{uri:N.url},resizeMode:"contain",accessibilityLabel:"Sticker preview",style:{width:26,height:26,marginRight:12}}):null,vt=V?"Sticker name":N?"Saving "+j(N.filename):"Choose image",lt=!I&&L?i(L,{onPress:Ge,accessibilityLabel:"Close"}):i(r.Pressable,{onPress:Ge,accessibilityRole:"button",accessibilityLabel:"Close",hitSlop:10,style:{width:40,height:40,alignItems:"center",justifyContent:"center"}},_e("\xD7",{fontSize:32,lineHeight:36})),gt=!I&&P?i(P,{title:vt,leading:Ze,trailing:lt}):i(r.View,{style:{flexDirection:"row",alignItems:"center",paddingHorizontal:28,minHeight:72}},Ze,i(r.Text,{numberOfLines:1,style:{flex:1,color:Te.text,fontSize:20,fontWeight:"600",textAlign:"center",paddingHorizontal:8}},vt),lt),xt=Math.min(640,(r.Dimensions?.get?.("window")?.height??800)*.62);function yt(he){if(re)return i(re,{guild:he,size:W?.MEDIUM,animate:!1});if(he.icon)return i(r.Image,{source:{uri:"https://cdn.discordapp.com/icons/"+he.id+"/"+he.icon+".png?size=96"},style:{width:44,height:44,borderRadius:14},resizeMode:"cover"});var Se=String(he.name).trim().split(/\s+/).map(be=>be[0]).join("").slice(0,3);return i(r.View,{style:{width:44,height:44,borderRadius:14,backgroundColor:"#5865f2",alignItems:"center",justifyContent:"center"}},_e(Se,{color:"#ffffff",fontWeight:"600"}));}function mt(he){var Se=ne(he),be=Se.used!=null&&Se.used>=Se.max,He=be?"No slots available":Se.used==null?"Check slots on upload":void 0,Je=()=>{if(F&&(!Ne()||ee))return;var ft=m("GuildStore")?.getGuild?.(he.id)??he,ht=ne(ft);!ie(ft)||ht.used!=null&&ht.used>=ht.max||(oe(ft),pe(""));},Be=d("ic_add_24px","PlusSmallIcon","PlusIcon"),wt=U.FormIcon&&Be!=null?i(U.FormIcon,{source:Be,style:{opacity:1}}):_e("+",{color:Te.muted,fontSize:30,fontWeight:"300"});return U.FormRow?i(U.FormRow,{key:he.id,leading:yt(he),label:he.name,subLabel:He,trailing:wt,disabled:be,onPress:Je,accessibilityLabel:he.name,accessibilityRole:"button",accessibilityState:{disabled:be}}):i(r.Pressable,{key:he.id,accessibilityRole:"button",accessibilityLabel:he.name,accessibilityState:{disabled:be},disabled:be,onPress:Je,style:{minHeight:80,paddingHorizontal:32,flexDirection:"row",alignItems:"center",opacity:be?.4:1}},yt(he),i(r.View,{style:{flex:1,marginLeft:18,marginRight:16}},_e(he.name,{fontWeight:"600",fontSize:18}),He?_e(He,{color:Te.muted,fontSize:13,marginTop:3}):null),wt);}if(N&&!V){var he=Z().filter(Be=>`${Be.name}
${Be.id}`.toLowerCase().includes(ge.trim().toLowerCase())),Se=i(r.View,{style:{padding:24}},_e(ge.trim()?"No servers match your search.":"No servers available. You need Create Expressions permission to add a sticker.",{color:Te.muted,fontSize:14})),be=I?r.FlatList:K,He=be?i(be,{style:{flex:1},contentContainerStyle:{paddingBottom:32},data:he,keyboardShouldPersistTaps:"handled",keyboardDismissMode:"on-drag",nestedScrollEnabled:!0,removeClippedSubviews:!1,initialNumToRender:12,renderItem:({item:Be})=>mt(Be),keyExtractor:Be=>Be.id,extraData:he.map(Be=>Be.id+":"+ne(Be).used).join(","),ListEmptyComponent:Se}):i(r.ScrollView,{style:{flex:1},contentContainerStyle:{paddingBottom:32}},he.length?he.map(mt):Se),Je=i(r.View,{style:I?{flex:1,minHeight:0}:{height:xt}},gt,i(r.TextInput,{accessibilityLabel:"Search servers",placeholder:"Search server name or ID",placeholderTextColor:Te.muted,value:ge,onChangeText:M,autoCorrect:!1,autoCapitalize:"none",style:{...qe,marginHorizontal:20,marginBottom:12}}),He);return I?Je:i(X,{scrollable:!1},Je);}var ct;if(!N)ct=p.map((he,Se)=>i(r.Pressable,{key:he.url,accessibilityRole:"button",accessibilityLabel:"Use image "+(Se+1),onPress:()=>{Y(he),H(j(he.filename));},style:{flexDirection:"row",alignItems:"center",gap:12,paddingVertical:10}},i(r.Image,{source:{uri:he.url},style:{width:64,height:64},resizeMode:"contain"}),_e(he.filename,{flex:1})));else{var _he=T.trim().length>=2&&T.trim().length<=30&&!/[\u0000-\u001f]/.test(T);ct=i(r.View,null,i(r.Image,{source:{uri:N.url},style:{height:128,width:"100%",marginBottom:12},resizeMode:"contain"}),_e("Server: "+V.name,{fontWeight:"600"}),_e("Sticker name",{marginTop:12}),i(r.TextInput,{value:T,onChangeText:H,maxLength:30,placeholder:"Sticker name",placeholderTextColor:Te.muted,style:qe,selectTextOnFocus:!0,editable:!ee}),_e(N.contentType==="image/gif"?"GIFs keep their animation and resize automatically. Maximum 5 seconds and 512 KiB.":"Images fit inside 320\xD7320 with transparent padding. GIFs keep their animation.",{color:Te.muted,fontSize:13,marginTop:12}),rt("Add sticker",nt,!_he||ee),ee?_e("Preparing and adding your sticker\u2026",{color:Te.muted,marginTop:12}):null,te?_e(te,{color:"#e66b70",marginTop:12}):null,rt("Choose another server",()=>{oe(null),pe("");},ee));}var Dt=i(r.View,{style:I?{flex:1,minHeight:0}:{}},gt,i(r.ScrollView,{keyboardShouldPersistTaps:"handled",keyboardDismissMode:"on-drag",style:I?{flex:1}:{maxHeight:xt},contentContainerStyle:{padding:20,paddingBottom:40}},ct));return I?Dt:i(X,{scrollable:!1},Dt);}function ue(p,R){if(!x||w)return;if(e.host?.id==="valenced"){var S={session:E};w=S;var N=()=>{S.closed=!0,w===S&&(w=void 0);},Y=()=>x&&E===S.session&&!S.closed&&w===S;try{B.hideActionSheet(R);}catch{}var V=e.ui.components?.ErrorBoundary;if(a.open((oe,T)=>{var H=i(O,{images:p,onClose:oe,inPanel:!0,page:!0,isOpen:()=>Y()&&T()});return V?i(V,null,H):H;},N))return;N(),g("Save as Sticker could not open. Restart Discord and reopen the image menu.");return;}if(v){g("A sticker upload is already in progress.");return;}if(s.open(S=>i(O,{images:p,onClose:S,inPanel:!0}),"sticker picker")){B.hideActionSheet(R);return;}if(!X){g("The server picker is unavailable on this Discord build.");return;}B.hideActionSheet(R);var I=e.ui.components?.ErrorBoundary,F=()=>{var S=i(O,{images:p});return I?i(I,null,S):S;};B.openLazy(Promise.resolve({default:F}),c,{});}function se(p,R){var I=d("StickerIcon","ic_sticker_24px");return i(_,{key:f,label:"Save as Sticker",icon:_.Icon&&I!=null?i(_.Icon,{source:I}):void 0,iconSource:_.Icon?void 0:I,onPress:()=>ue(p,R)});}function de(p,R,I){var F=null,S=-1,N=!1,Y=M=>String(M?.props?.label??M?.props?.message??""),V=M=>M?.props&&typeof M.props.onPress=="function"&&(M.type===_||M.props.label!=null||M.props.message!=null);function oe(M,ee=0){if(!(!M||ee>40))if(Array.isArray(M)){var fe=M.filter(V);if(fe.length){var te=fe.some(pe=>/save image/i.test(Y(pe)))?1e3:fe.some(pe=>/copy image link/i.test(Y(pe)))?900:10;te+fe.length>S&&(F=M,S=te+fe.length);}M.forEach(te=>oe(te,ee+1));}else M.props&&((M.key===f||Y(M)==="Save as Sticker")&&(N=!0),oe(M.props.children,ee+1));}if(oe(p),N||!F)return p;var T=se(R,I),H=F.findIndex(M=>/save image/i.test(Y(M))),Q=H>=0?H+1:F.length;function ge(M){if(M===F)return[...F.slice(0,Q),T,...F.slice(Q)];if(Array.isArray(M)){var ee=M.map(ge);return ee.some((fe,te)=>fe!==M[te])?ee:M;}if(M?.props?.children!=null){var _ee=ge(M.props.children);return _ee!==M.props.children?t.cloneElement(M,{children:_ee}):M;}return M;}return ge(p);}function Fe(p,R,I,F){var S=(N,Y)=>{if(!x||E!==F)return Y;try{var V=xe(N,R);return V.length?de(Y,V,I):Y;}catch(V){return D("Could not add image menu action",V),Y;}};return typeof p=="function"&&!p.prototype?.isReactComponent?function(...Y){return S(Y[0],p.apply(this,Y));}:p?.$$typeof===Symbol.for("react.memo")?t.memo(Fe(p.type,R,I,F),p.compare):p?.$$typeof===Symbol.for("react.forward_ref")?t.forwardRef((N,Y)=>S(N,p.render(N,Y))):p;}function Re(){if(!B?.openLazy||!_||!X&&e.host?.id!=="valenced"||!m("GuildStore"))throw new Error("SaveAsSticker: required menu modules were not found on this Discord build.");x||(x=!0,E++,A.push(e.patcher.before("openLazy",B,p=>{var[R,I,F]=p;if(I!=="MessageLongPressActionSheet"&&I!=="MediaShareActionSheet"||!R?.then)return;var S=E;p[0]=Promise.resolve(R).then(N=>!x||S!==E||!N?.default?N:{...N,default:Fe(N.default,F,I,S)});})),void 0);}function k(){x=!1,E++,w=void 0,a.closeAll(),s.closeAll();for(var p of C)p.cancel?.(!0);C.clear(),v=!1;for(var _p of A.splice(0).reverse())try{_p();}catch{}try{B?.hideActionSheet?.(c);}catch{}}return{onLoad:Re,onUnload:k};})();
return module.exports.default;
})()
}, "SaveAsSticker");
})()
); }, {"id": "dev.fluttershy2008.save-as-sticker", "legacyManifest": {"name": "SaveAsSticker", "description": "Save images and animated GIFs as server stickers. Pick a server, name your sticker, and automatically resize GIFs while keeping them animated.", "version": "1.3.9", "authors": [{"name": "Fluttershy2008-mlp"}], "main": "index.js", "vendetta": {"icon": "ic_sticker_24px"}, "hash": "004e5954f6bd29a817d67162b8edb669ef421963697c7685e8d43b398bd5d1c5"}, "repository": "https://fluttershy2008-mlp.github.io/lol/valenced/index.json", "host": "valenced", "version": "1.0.0-beta8"}) };
})()
