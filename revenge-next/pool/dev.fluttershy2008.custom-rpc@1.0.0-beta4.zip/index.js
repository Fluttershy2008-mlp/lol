(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Revenge Next API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the Revenge Next plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const source = rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update Revenge Next to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        const found = rawFind(...props);
        if (found) return found;
        if (props.some(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.next.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod('revenge.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from Revenge Next.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.['revenge.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createNextPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createNextPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}
return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
/*! CustomRPC for Revenge v1.1.2
 * Adapted from Vencord CustomRPC, Copyright (c) 2023-2025 Vendicated and contributors.
 * Mobile adaptation Copyright (c) 2026 Fluttershy2008-mlp.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Corresponding source and license: https://github.com/Fluttershy2008-mlp/lol/tree/main/custom-rpc
 */
const module = { exports: {} };
var N=Object.defineProperty;var X=Object.getOwnPropertyDescriptor;var Z=Object.getOwnPropertyNames;var ee=Object.prototype.hasOwnProperty;var te=(t,e)=>{for(var i in e)N(t,i,{get:e[i],enumerable:!0})},ie=(t,e,i,n)=>{if(e&&typeof e=="object"||typeof e=="function")for(let a of Z(e))!ee.call(t,a)&&a!==i&&N(t,a,{get:()=>e[a],enumerable:!(n=X(e,a))||n.enumerable});return t};var ne=t=>ie(N({},"__esModule",{value:!0}),t);var se={};te(se,{default:()=>ae});module.exports=ne(se);var $=[[0,"Playing"],[1,"Streaming"],[2,"Listening"],[3,"Watching"],[5,"Competing"]],j=[["none","None"],["elapsed","Since plugin started"],["midnight","Since midnight"],["custom","Custom"]],H=Object.freeze({appID:"",appName:"",type:0,details:"",detailsURL:"",state:"",stateURL:"",streamLink:"",imageBig:"",imageBigTooltip:"",imageBigURL:"",imageSmall:"",imageSmallTooltip:"",imageSmallURL:"",buttonOneText:"",buttonOneURL:"",buttonTwoText:"",buttonTwoURL:"",timestampMode:"none",startTime:"",endTime:"",partySize:"",partyMaxSize:""});function I(t={}){let e={};for(let[i,n]of Object.entries(H)){let a=t?.[i]??n;e[i]=i==="type"?Number(a):String(a).trim()}return e}function M(t){return typeof t!="string"||/[\s\\\u0000-\u001f\u007f]/.test(t)?!1:/^https?:\/\/(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?::\d{1,5})?(?:[/?#][^\s]*)?$/i.test(t)}function B(t){let e=I(t),i={};e.appName||(i.appName="Enter an application name."),e.appID&&!/^\d{16,21}$/.test(e.appID)&&(i.appID="Use a Discord application ID (16\u201321 digits), or leave it empty for a text activity."),$.some(([n])=>n===e.type)||(i.type="Choose an activity type.");for(let[n,a]of[["appName","Application name"],["details","Details"],["state","State"],["imageBigTooltip","Large image text"],["imageSmallTooltip","Small image text"]])e[n].length>128&&(i[n]=`${a} must be at most 128 characters.`);for(let n of["detailsURL","stateURL","imageBigURL","imageSmallURL","buttonOneURL","buttonTwoURL"])e[n]&&(!M(e[n])||e[n].length>512)&&(i[n]="Enter a complete http:// or https:// link, up to 512 characters.");e.type===1&&(!/^https?:\/\/(?:www\.)?(?:twitch\.tv|youtube\.com)\/[^\s]+$/i.test(e.streamLink)||!M(e.streamLink)||e.streamLink.length>512)&&(i.streamLink="Streaming needs a Twitch or YouTube channel/video URL.");for(let[n,a]of[["buttonOneText","buttonOneURL"],["buttonTwoText","buttonTwoURL"]])e[n].length>31&&(i[n]="Button text must be at most 31 characters."),e[n]&&!e[a]&&(i[a]="Add a link for this button."),e[a]&&!e[n]&&(i[n]="Add text for this button.");for(let n of["imageBig","imageSmall"]){let a=e[n];a&&(a.length>2048?i[n]="Image URL/key must be at most 2048 characters.":/^https?:\/\//i.test(a)?M(a)?/^https?:\/\/(?:www\.)?(?:imgur|tenor)\.com\//i.test(a)&&(i[n]="Use the direct image link (i.imgur.com or media.tenor.com), not a gallery page."):i[n]="Enter a valid direct image URL.":/^mp:/.test(a)?/^mp:(?:external|attachments|app-assets)\/[^\s]+$/.test(a)||(i[n]="Enter a valid Discord media asset path."):/^[\w.-]{1,256}$/.test(a)?e.appID||(i[n]="An application ID is required when using an asset key or asset ID."):i[n]="Use a direct image URL or an uploaded application asset key.")}if(j.some(([n])=>n===e.timestampMode)||(i.timestampMode="Choose a timestamp mode."),e.timestampMode==="custom"){for(let n of["startTime","endTime"])e[n]&&(!/^\d{1,16}$/.test(e[n])||!Number.isSafeInteger(Number(e[n]))||Number(e[n])<=0)&&(i[n]="Use a positive Unix timestamp in milliseconds, or leave empty.");!e.startTime&&!e.endTime&&(i.startTime="Enter a start or end timestamp, or choose None."),e.startTime&&e.endTime&&Number(e.endTime)<=Number(e.startTime)&&(i.endTime="End time must be after the start time.")}if(e.type===0&&(e.partySize||e.partyMaxSize)){for(let n of["partySize","partyMaxSize"])(!/^\d{1,9}$/.test(e[n])||Number(e[n])<1)&&(i[n]="Enter a positive whole number for both party sizes.");Number(e.partySize)>Number(e.partyMaxSize)&&(i.partySize="Party size cannot exceed the maximum.")}return{config:e,errors:i,valid:Object.keys(i).length===0}}async function G(t,{resolveAsset:e,startedAt:i,midnightAt:n,now:a=Date.now()}={}){let{config:o,errors:s,valid:u}=B(t);if(!u)throw new Error(Object.values(s).join(`
`));let c={application_id:o.appID||"0",name:o.appName,type:o.type,flags:1},h=[];for(let[r,d]of[["details","details"],["details_url","detailsURL"],["state","state"],["state_url","stateURL"]])o[d]&&(c[r]=o[d]);o.type===1&&(c.url=o.streamLink);let l=[["buttonOneText","buttonOneURL"],["buttonTwoText","buttonTwoURL"]].filter(([r])=>o[r]);if(l.length&&(c.buttons=l.map(([r])=>o[r]),c.metadata={button_urls:l.map(([,r])=>o[r])}),o.timestampMode==="elapsed"&&(c.timestamps={start:i??a}),o.timestampMode==="midnight"){let r=new Date(a);r.setHours(0,0,0,0),c.timestamps={start:n??r.getTime()}}o.timestampMode==="custom"&&(c.timestamps={},o.startTime&&(c.timestamps.start=Number(o.startTime)),o.endTime&&(c.timestamps.end=Number(o.endTime))),o.type===0&&o.partySize&&o.partyMaxSize&&(c.party={size:[Number(o.partySize),Number(o.partyMaxSize)]});let g={};return await Promise.all([["large","imageBig"],["small","imageSmall"]].map(async([r,d])=>{if(o[d])try{let m=await e?.(c.application_id,o[d]);if(!m||typeof m!="string")throw new Error("No image was returned.");g[`${r}_image`]=m,o[`${d}Tooltip`]&&(g[`${r}_text`]=o[`${d}Tooltip`]),o[`${d}URL`]&&(g[`${r}_url`]=o[`${d}URL`])}catch{h.push(`${r==="large"?"Large":"Small"} image could not load. Check the application ID and use an uploaded asset key or a direct image URL.`)}})),Object.keys(g).length&&(c.assets=g),{activity:c,warnings:h}}function oe(t,e){return new Promise((i,n)=>{let a=setTimeout(()=>n(new Error("Image lookup timed out.")),e);Promise.resolve(t).then(o=>{clearTimeout(a),i(o)},o=>{clearTimeout(a),n(o)})})}function V(t){if(typeof t!="string"||!t)return;if(/^\d+$/.test(t)||/^mp:(?:external|attachments|app-assets)\//.test(t))return t;let e=t.replace(/^https:\/\/(?:media\.discordapp\.net|cdn\.discordapp\.com)\//i,"");if(/^(?:external|attachments|app-assets)\//.test(e))return`mp:${e}`}function F(t,{timeout:e=12e3}={}){let i=new Map;function n(){let u=[t("get","post","put"),t("getAPIBaseURL","get"),t("HTTP")?.HTTP].find(c=>typeof c?.get=="function"&&typeof c?.post=="function");if(!u)throw new Error("This Discord version does not expose image lookup.");return u}async function a(s,u){if(/^mp:/.test(u)||/^\d+$/.test(u))return u;let c=t("fetchAssetIds")??t("getAssetIds");if(c)try{let d=c.getAssetIds?.(s,[u]),m=V(d?.[0]);if(m)return m;if(typeof c.fetchAssetIds=="function"){let f=await c.fetchAssetIds(s,[u]),T=V(f?.[0]);if(T)return T}}catch{}let h=n();if(M(u)){let d=await h.post({url:`/applications/${s}/external-assets`,body:{urls:[u]}}),m=d?.body??d,f=V(m?.[0]?.external_asset_path);if(!f)throw new Error("Discord did not return an external image.");return f}let l=await h.get({url:`/oauth2/applications/${s}/assets`}),g=l?.body??l,r=Array.isArray(g)?g.find(d=>d.name===u||String(d.id)===u):void 0;if(!r?.id)throw new Error("Application image key was not found.");return String(r.id)}let o=(s,u)=>{if(!/^(?:0|\d{16,21})$/.test(s))return Promise.reject(new Error("Invalid application ID."));let c=`${s}:${u}`;if(i.has(c))return i.get(c);i.size>=64&&i.delete(i.keys().next().value);let h=oe(a(s,u),e).catch(l=>{throw i.delete(c),l});return i.set(c,h),h};return o.clear=()=>i.clear(),o}var re="CustomRPC@Fluttershy2008-mlp";function W({storage:t,dispatcher:e,resolveAsset:i,appState:n,log:a=()=>{},now:o=Date.now,minInterval:s=5e3}){let u=!1,c=0,h=o(),l,g=-1/0,r,d,m,f=!1,T={busy:!1,running:!1,message:"Ready. Add your activity and tap Save & apply.",warnings:[]},y=new Set,L=[];function v(b){T={...T,...b};for(let R of y)try{R(T)}catch{}}function z(){r&&(clearTimeout(r.timer),r.resolve(!1),r=void 0),clearTimeout(d),d=void 0}function S(b){if(typeof e?.dispatch!="function")throw new Error("The activity dispatcher is unavailable on this Discord version.");e.dispatch({type:"LOCAL_ACTIVITY_UPDATE",activity:b,socketId:re}),g=o()}function O(){try{(f||t.enabled)&&S(null)}catch(b){a(b)}f=!1}async function U(){let b=Math.max(0,g+s-o());return b?new Promise(R=>{r={resolve:R,timer:setTimeout(()=>{r=void 0,R(!0)},b)}}):!0}async function w(b=t.config,{persist:R=!0}={}){if(!u)return!1;let p=B(b);if(!p.valid)return v({message:Object.values(p.errors).join(`
`)}),!1;let C=++c;z(),v({busy:!0,message:"Preparing activity\u2026",warnings:[]});try{let x=await G(p.config,{resolveAsset:i,startedAt:h,midnightAt:l,now:o()});return!u||C!==c||!await U()||!u||C!==c?!1:(S(x.activity),f=!0,R&&(t.config=p.config,t.enabled=!0),v({busy:!1,running:!0,message:"Activity applied. Check your profile from another account.",warnings:x.warnings}),!0)}catch(x){return u&&C===c&&(a(x),v({busy:!1,message:x?.message||"Could not apply the activity. Try again."})),!1}}function P(){++c,z(),O(),t.enabled=!1,v({busy:!1,running:!1,message:"Activity stopped. Your settings are saved.",warnings:[]})}function E(){!u||!t.enabled||(clearTimeout(d),d=setTimeout(()=>{d=void 0,u&&t.enabled&&!T.busy&&w(t.config,{persist:!1})},750))}let A=b=>{b==="active"&&E()};return{getStatus:()=>T,subscribe(b){return y.add(b),()=>y.delete(b)},apply:w,stop:P,restartTimer(){return h=o(),t.enabled?w(t.config,{persist:!1}):(v({message:"Timer reset. Tap Save & apply to start your activity."}),Promise.resolve(!0))},load(){if(u)return;u=!0,h=o();let b=new Date(h);b.setHours(0,0,0,0),l=b.getTime(),t.config=I(t.config),t.draft=I(t.draft??t.config),t.enabled=t.enabled===!0;for(let R of["CONNECTION_OPEN","CONNECTION_RESUMED"])try{typeof e?.subscribe=="function"&&typeof e?.unsubscribe=="function"&&(e.subscribe(R,E),L.push(R))}catch{}try{m=n?.addEventListener?.("change",A)}catch{}t.enabled&&w(t.config,{persist:!1})},unload(){u=!1,++c,z(),O();for(let b of L.splice(0))try{e.unsubscribe(b,E)}catch{}try{m?.remove?m.remove():n?.removeEventListener?.("change",A)}catch{}m=void 0,i?.clear?.(),v({busy:!1,running:!1}),y.clear()}}}function K({React:t,RN:e,storage:i,controller:n,openURL:a,getTheme:o}){let s=t.createElement,u=e.Pressable??e.TouchableOpacity;function c({label:g,value:r,onChange:d,placeholder:m,error:f,numeric:T,url:y,maxLength:L=128,colors:v}){return s(e.View,{style:{marginBottom:14}},s(e.Text,{style:{color:v.text,fontSize:14,fontWeight:"600",marginBottom:6}},g),s(e.TextInput,{accessibilityLabel:g,value:String(r??""),onChangeText:d,placeholder:m??"",placeholderTextColor:v.muted,selectionColor:v.accent,maxLength:L,keyboardType:T?"number-pad":y?"url":"default",autoCapitalize:y||T?"none":"sentences",autoCorrect:!y&&!T,style:{color:v.text,backgroundColor:v.input,borderWidth:1,borderColor:f?v.error:v.border,borderRadius:9,minHeight:48,paddingHorizontal:12,paddingVertical:10,fontSize:16}}),f?s(e.Text,{accessibilityRole:"alert",style:{color:v.error,marginTop:5}},f):null)}function h({title:g,colors:r,children:d,initialOpen:m=!1}){let[f,T]=t.useState(m);return s(e.View,{style:{backgroundColor:r.card,borderRadius:12,marginTop:14,overflow:"hidden"}},s(u,{accessibilityRole:"button",accessibilityState:{expanded:f},onPress:()=>T(!f),style:{padding:16,flexDirection:"row",justifyContent:"space-between"}},s(e.Text,{style:{color:r.text,fontWeight:"700",fontSize:17}},g),s(e.Text,{style:{color:r.muted,fontSize:17}},f?"\u2212":"+")),f?s(e.View,{style:{paddingHorizontal:16,paddingBottom:8}},d):null)}function l({options:g,value:r,onChange:d,colors:m}){return s(e.View,{style:{flexDirection:"row",flexWrap:"wrap",marginBottom:8}},...g.map(([f,T])=>s(u,{key:String(f),accessibilityRole:"radio",accessibilityState:{selected:r===f},onPress:()=>d(f),style:{paddingVertical:10,paddingHorizontal:12,borderRadius:20,marginRight:6,marginBottom:8,backgroundColor:r===f?m.accent:m.input}},s(e.Text,{style:{color:r===f?"#ffffff":m.text,fontWeight:"600"}},T))))}return function(){let[r,d]=t.useState(()=>I(i.draft??i.config)),[m,f]=t.useState(n.getStatus),[T,y]=t.useState({}),L=typeof e.useColorScheme=="function"?e.useColorScheme():"dark",z=(o?.()??L)!=="light",S=z?{bg:"#18191c",card:"#24262b",input:"#1b1d21",text:"#f3f4f6",muted:"#b4bac5",border:"#515660",accent:"#5865f2",error:"#ff9b9f"}:{bg:"#f2f3f5",card:"#ffffff",input:"#f5f6f8",text:"#1e2025",muted:"#626873",border:"#aeb4bf",accent:"#4752c4",error:"#ba2331"};t.useEffect(()=>n.subscribe(f),[]);function O(p,C){d(x=>{let k={...x,[p]:C};return i.draft=k,k}),y(x=>({...x,[p]:void 0}))}let U=p=>s(e.Text,{style:{color:S.muted,fontSize:14,lineHeight:20,marginBottom:12}},p),w=(p,C,x={})=>s(c,{key:p,label:C,value:r[p],onChange:k=>O(p,k),error:T[p],colors:S,...x}),P=(p,C)=>w(p,C,{url:!0,maxLength:512,placeholder:"https://\u2026"}),E=(p,C,x=!1)=>s(h,{key:p,title:p,colors:S,initialOpen:x},...C),A=(p,C,x=!1,k=!1)=>s(u,{accessibilityRole:"button",accessibilityState:{disabled:k},disabled:k,onPress:C,style:{padding:14,borderRadius:10,alignItems:"center",marginTop:10,opacity:k?.55:1,backgroundColor:x?S.accent:S.card,borderWidth:x?0:1,borderColor:S.border}},s(e.Text,{style:{color:x?"#ffffff":S.text,fontWeight:"700",fontSize:16}},p)),b=JSON.stringify(I(r))!==JSON.stringify(I(i.config));async function R(){e.Keyboard?.dismiss?.();let p=B(r);if(y(p.errors),!p.valid){e.Alert.alert("Check your activity",Object.values(p.errors).join(`

`));return}await n.apply(p.config)}return s(e.KeyboardAvoidingView,{style:{flex:1,backgroundColor:S.bg},behavior:e.Platform?.OS==="ios"?"padding":void 0},s(e.ScrollView,{keyboardShouldPersistTaps:"handled",contentContainerStyle:{padding:16,paddingBottom:64}},s(e.Text,{style:{color:S.text,fontSize:25,fontWeight:"800",marginBottom:6}},"CustomRPC"),U("Set the activity shown on your Discord profile. Enter a name, choose a type, then tap Save & apply."),s(e.View,{style:{backgroundColor:S.card,padding:16,borderRadius:12}},s(e.Text,{style:{color:m.running?z?"#85e0ad":"#176d3e":S.muted,fontWeight:"700",marginBottom:6}},m.busy?"APPLYING\u2026":m.running?"ACTIVE":"STOPPED"),s(e.Text,{accessibilityLiveRegion:"polite",style:{color:S.text,lineHeight:20}},m.message),...m.warnings.map((p,C)=>s(e.Text,{key:C,style:{color:S.error,marginTop:8,lineHeight:20}},p)),b?s(e.Text,{style:{color:S.muted,marginTop:8}},"Edits are saved as a draft. Tap Save & apply to publish them."):null),A(m.busy?"Applying\u2026":"Save & apply",R,!0,m.busy),A("Stop activity",()=>n.stop(),!1,!m.running&&!m.busy&&!i.enabled),E("Activity",[s(l,{key:"type",options:$,value:r.type,onChange:p=>O("type",p),colors:S}),w("appName","Application name",{placeholder:"Your game or activity name"}),w("appID","Application ID (optional for text)",{placeholder:"Discord application ID",numeric:!0,maxLength:21}),U("For application images, create an application in the Discord Developer Portal and copy its Application ID."),A("Open Developer Portal",()=>a("https://discord.com/developers/applications")),w("details","Details \xB7 line 1"),w("state","State \xB7 line 2"),r.type===1?P("streamLink","Stream link \xB7 Twitch or YouTube"):null],!0),E("Images",[U("Use an image key uploaded to your application or a direct image/GIF URL. Gallery links will not work. Animation depends on Discord\u2019s activity renderer."),w("imageBig","Large image URL or key",{url:!0,maxLength:2048}),w("imageBigTooltip","Large image text"),P("imageBigURL","Large image click URL (optional)"),w("imageSmall","Small image URL or key",{url:!0,maxLength:2048}),w("imageSmallTooltip","Small image text"),P("imageSmallURL","Small image click URL (optional)")]),E("Buttons",[U("Add up to two buttons. Each needs both a label and a link. Discord may hide these on your own profile; check from another account."),w("buttonOneText","Button 1 text",{maxLength:31}),P("buttonOneURL","Button 1 URL"),w("buttonTwoText","Button 2 text",{maxLength:31}),P("buttonTwoURL","Button 2 URL")]),E("Timer",[s(l,{key:"timestamp",options:j,value:r.timestampMode,onChange:p=>O("timestampMode",p),colors:S}),r.timestampMode==="elapsed"?U("The timer starts when the plugin loads. Applying edits or reconnecting does not reset it."):null,r.timestampMode==="elapsed"?A("Restart elapsed timer",()=>n.restartTimer(),!1,m.busy):null,r.timestampMode==="midnight"?U("Starts at local midnight on the day the plugin loads. It keeps counting past 24 hours until the plugin reloads."):null,r.timestampMode==="custom"?U("Use Unix timestamps in milliseconds. Leave the end empty for an elapsed timer."):null,r.timestampMode==="custom"?w("startTime","Start timestamp (milliseconds)",{numeric:!0,maxLength:16}):null,r.timestampMode==="custom"?w("endTime","End timestamp (milliseconds)",{numeric:!0,maxLength:16}):null,r.timestampMode==="custom"?A("Set start to now",()=>O("startTime",String(Date.now()))):null]),E("Party & text links",[...r.type===0?[U("Leave both sizes empty to hide the party count."),w("partySize","Current party size",{numeric:!0,maxLength:9}),w("partyMaxSize","Maximum party size",{numeric:!0,maxLength:9})]:[U("Party size is available for Playing activities.")],P("detailsURL","Details click URL (optional)"),P("stateURL","State click URL (optional)")]),s(e.View,{style:{marginTop:18}},U("Keep activity sharing enabled and your status online. Android may stop the activity when Discord is closed or suspended. Avoid running another custom RPC plugin at the same time.")),A("Discard draft changes",()=>{let p=I(i.config??H);i.draft=p,d(p),y({})},!1,m.busy||!b),A(m.busy?"Applying\u2026":"Save & apply",R,!0,m.busy),s(e.Text,{style:{color:S.muted,marginTop:20,fontSize:12,textAlign:"center"}},"CustomRPC 1.1.1 \xB7 Adapted from Vencord \xB7 GPL-3.0-or-later")))}}var D="CUSTOMRPC_FLUTTERSHY_SETTINGS",_="SETTING_RENDERER_CONFIG",q=Symbol.for("customrpc.settings.renderer.v1"),Y=Object.freeze({type:"pressable",parent:null,title:()=>"CustomRPC",useTitle:()=>"CustomRPC",usePredicate:()=>!1,onPress:()=>{},withArrow:!0});function J(t,e){if(!t)return;let i;try{i=t[q],i||(i={row:Y,getter:void 0},Object.defineProperty(t,q,{value:i,configurable:!0}))}catch{return}function n(){try{let a=Object.getOwnPropertyDescriptor(t,_);if(i.getter&&a?.get===i.getter)return t[_][D]===i.row;if(a?.configurable===!1)return!1;let o=!1,s=a?.value??t[_],u=()=>({...a?.get&&!o?a.get.call(t):s,[D]:i.row});return Object.defineProperty(t,_,{configurable:!0,enumerable:a?.enumerable??!0,get:u,set(c){a?.set?a.set.call(t,c):(o=!0,s=c)}}),i.getter=u,t[_][D]===i.row}catch{return!1}}if(i.row=e,!n()){i.row=Y;return}return{ensure:n,release(){i.row===e&&(i.row=Y)}}}function Q({settingsAPI:t,Settings:e,constants:i,treeManager:n,patcher:a,openSettings:o,renderIcon:s,getAssetID:u,log:c=()=>{}}){let h=t?.registeredSections;if(!h||typeof h!="object")return c("Settings shortcut is unavailable on this Revenge version. Use the plugin settings button."),()=>{};let l=Object.values(h).find(y=>Array.isArray(y)&&y.some(L=>L?.key==="BUNNY_PLUGINS"));if(!l||l.some(y=>y?.key===D))return()=>{};let g;for(let y of["RichActivityIcon","GameControllerIcon","WrenchIcon"])try{let L=u?.(y);if(L!=null){g=L;break}}catch{}let r=!0,d={type:"pressable",parent:null,title:()=>"CustomRPC",useTitle:()=>"CustomRPC",icon:g,IconComponent:g!=null&&s?()=>s(g):void 0,usePredicate:()=>r,onPress:()=>{r&&o?.()},withArrow:!0},m=J(i,d);if(!m)return r=!1,c("Could not register a native settings row safely. Use the plugin settings button."),()=>{};let f;try{typeof n?.getAncestors=="function"&&typeof a?.before=="function"&&(f=a.before("getAncestors",n,y=>{y[0]===D&&m.ensure()}))}catch{}let T={key:D,title:()=>"CustomRPC",icon:g,usePredicate:d.usePredicate,rawTabsConfig:d,render:async()=>({default:e})};try{l.splice(l.findIndex(y=>y?.key==="BUNNY_PLUGINS")+1,0,T)}catch{return r=!1,f?.(),m.release(),c("Could not add the settings shortcut. Use the plugin settings button."),()=>{}}return()=>{r=!1;for(let y of new Set([l,...Object.values(h)])){if(!Array.isArray(y))continue;let L=y.indexOf(T);if(L!==-1)try{y.splice(L,1)}catch{}}f?.(),f=void 0,m.release()}}var ae=(()=>{let t=typeof vendetta<"u"?vendetta:globalThis.vendetta;if(!t?.metro?.common||!t?.plugin?.storage)throw new Error("CustomRPC requires Revenge\u2019s Vendetta plugin support.");let{React:e,ReactNative:i,FluxDispatcher:n}=t.metro.common,a=t.plugin.storage,o=(...l)=>{try{return t.metro.findByProps(...l)}catch{return}},s=F(o),u=W({storage:a,dispatcher:n??o("dispatch","subscribe"),resolveAsset:s,appState:i.AppState,log:l=>t.logger?.error?.("[CustomRPC]",l?.message??String(l))}),c=K({React:e,RN:i,storage:a,controller:u,openURL:l=>{try{i.Linking.openURL(l)?.catch?.(()=>i.Alert.alert("Could not open link",l))}catch{i.Alert.alert("Could not open link",l)}},getTheme:()=>{try{return t.metro.findByStoreName("ThemeStore")?.theme}catch{return}}}),h;return{onLoad(){u.load(),h||(h=Q({settingsAPI:globalThis.bunny?.ui?.settings??globalThis.window?.bunny?.ui?.settings,Settings:c,constants:o("SETTING_RENDERER_CONFIG"),treeManager:o("getAncestors","isBlocked"),patcher:t.patcher,openSettings:()=>{try{let l=o("getRootNavigationRef")?.getRootNavigationRef?.();if(!l?.navigate)throw new Error("Settings navigation is unavailable. Open CustomRPC from the Plugins page.");l.navigate("BUNNY_CUSTOM_PAGE",{title:"CustomRPC",render:()=>e.createElement(c)})}catch(l){i.Alert.alert("CustomRPC",l?.message??"Could not open settings.")}},renderIcon:l=>{let g=o("TableRowIcon")?.TableRowIcon;return g?e.createElement(g,{source:l}):e.createElement(i.Image,{source:l,style:{width:24,height:24}})},getAssetID:l=>t.ui?.assets?.getAssetIDByName(l),log:l=>t.logger?.warn?.("[CustomRPC]",l)}))},onUnload(){try{h?.()}finally{h=void 0,u.unload()}},settings:c}})();

return module.exports.default;
})()
}, "CustomRPC");
})()
); }, {"id": "dev.fluttershy2008.custom-rpc", "legacyManifest": {"name": "CustomRPC", "description": "Custom Rich Presence for Revenge: activity text, images, buttons, timers and party size. Adapted from Vencord CustomRPC.", "version": "1.1.3", "authors": [{"name": "Fluttershy2008-mlp", "id": "753962426407452713"}, {"name": "Vencord contributors (original CustomRPC)"}], "main": "index.js", "vendetta": {"icon": "RichActivityIcon"}, "hash": "618b49ab2af1fd079463abc0de944baeb7d60dacbcd77ebb079abe095ea3a55c"}, "repository": "https://fluttershy2008-mlp.github.io/lol/index.json"}) };
})()
