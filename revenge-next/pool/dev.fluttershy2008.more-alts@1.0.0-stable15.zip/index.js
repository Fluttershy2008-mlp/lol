(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Revenge Next API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the Revenge Next plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const source = rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update Revenge Next to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        const found = rawFind(...props);
        if (found) return found;
        if (props.some(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.next.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod('revenge.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from Revenge Next.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.['revenge.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        plugin: { persistStorage: /* SPDX-License-Identifier: GPL-3.0-or-later */
// Injected only into More Alts' native adapters, inside createLegacyAdapter.
function persistMoreAltsStorage(nextStorage, isCurrent = () => true) {
    const snapshot = JSON.parse(JSON.stringify(nextStorage));
    const operation = writes.then(async () => {
        if (!active || !isCurrent()) throw new Error('Account storage is unavailable.');
        await api.jsonStorage.set(snapshot, true);
        // JsonStorage.set can resolve even when its native write failed. get()
        // reads the file, whereas cache alone cannot establish persistence.
        const saved = await api.jsonStorage.get();
        if (JSON.stringify(saved) !== JSON.stringify(snapshot))
            throw new Error('Account storage verification failed.');
        if (!active || !isCurrent()) throw new Error('Account action was cancelled.');
        // Reuse these exact objects when the controller commits the save. That
        // avoids a redundant proxy-triggered file rewrite after verification.
        raw.accounts = snapshot.accounts;
        raw.accountOrder = snapshot.accountOrder;
        return snapshot;
    });
    // Keep subsequent writes usable after a failure, while returning the real
    // rejection to the account action. Never log snapshots or session values.
    writes = operation.catch(() => {});
    return operation;
}, id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createNextPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createNextPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}

return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
'use strict';
/* SPDX-License-Identifier: GPL-3.0-or-later */
class AccountError extends Error {
    constructor(code, message, retryAfter = 0) { super(message); this.name = 'AccountError'; this.code = code; this.retryAfter = retryAfter; }
}
const validId = id => typeof id === 'string' && /^\d{15,22}$/.test(id);
const validToken = token => typeof token === 'string' && token.length >= 20 && token.length <= 4096 && !/\s/.test(token) && !/^(Bot|Bearer)\b/i.test(token);
const fail = (code, message) => { throw new AccountError(code, message); };
function normalizeStorage(storage) {
    const accounts = {};
    for (const account of Object.values(storage.accounts && typeof storage.accounts === 'object' ? storage.accounts : {})) {
        if (!validId(account?.id) || !validToken(account?.token) || typeof account.username !== 'string') continue;
        accounts[account.id] = { ...cleanAccount(account, account.token, account),
            updatedAt: Number.isFinite(account.updatedAt) ? account.updatedAt : account.addedAt };
    }
    const order = Array.isArray(storage.accountOrder) ? storage.accountOrder : [];
    storage.accounts = accounts;
    storage.accountOrder = [...new Set([...order, ...Object.keys(accounts)])].filter(id => Object.prototype.hasOwnProperty.call(accounts, id));
    storage.settings = { refreshSavedSessions: storage.settings?.refreshSavedSessions !== false,
        enableNativeSwitcher: storage.settings?.enableNativeSwitcher !== false };
    storage.schemaVersion = 3;
}
function cleanAccount(user, token, old = {}) {
    return { id: user.id, username: user.username, discriminator: String(user.discriminator ?? '0'),
        displayName: user.global_name || user.globalName || user.displayName || user.username,
        avatar: typeof user.avatar === 'string' ? user.avatar : null, token,
        addedAt: Number.isFinite(old.addedAt) ? old.addedAt : Date.now(), updatedAt: Date.now() };
}
function saveAccount(storage, user, token) {
    if (!validId(user?.id) || typeof user.username !== 'string' || !validToken(token)) fail('invalid-user', 'Discord returned an incomplete account. Please sign in again.');
    const updated = !!storage.accounts[user.id];
    storage.accounts = { ...storage.accounts, [user.id]: cleanAccount(user, token, storage.accounts[user.id]) };
    if (!storage.accountOrder.includes(user.id)) storage.accountOrder = [...storage.accountOrder, user.id];
    return { user, updated };
}
function importLegacy(storage, legacy) {
    const entries = Array.isArray(legacy) ? legacy : Object.values(legacy?.accounts || {});
    if (!entries.length) fail('empty-import', 'No saved accounts were found in the old plugin. Save an account there first.');
    let added = 0, skipped = 0;
    for (const account of entries) {
        if (!validId(account?.id) || !validToken(account?.token) || typeof account.username !== 'string' || storage.accounts[account.id]) { skipped++; continue; }
        saveAccount(storage, account, account.token); added++;
    }
    return { added, skipped };
}
function describeFailure(status, body, retryHeader, path = '') {
    const data = body && typeof body === 'object' ? body : {};
    if (status === 429) {
        const seconds = Number(data.retry_after ?? retryHeader);
        const retry = Number.isFinite(seconds) && seconds > 0 ? Math.ceil(seconds) : 60;
        return new AccountError('rate-limit', `Too many attempts. Wait ${retry} seconds before trying again.`, retry);
    }
    if (data.captcha_key || data.captcha_sitekey) return new AccountError('verification', 'Discord requires a CAPTCHA. Complete sign-in in Discord’s normal login screen, then use Save current account here.');
    if ([70007, 60003, 60006].includes(data.code)) return new AccountError('verification', 'Discord requires additional verification. Complete sign-in in Discord’s normal login screen, then save the account here.');
    if (status >= 500) return new AccountError('server', 'Discord is having trouble. Try again later.');
    if (data.code === 60008 || data.code === 60009 || data.errors?.code) return new AccountError('mfa-code', 'That verification code was rejected. Try a fresh authenticator code or an unused backup code.');
    if (status === 401) {
        if (path === '/auth/login') return new AccountError('credentials',
            'Discord did not accept these sign-in details. Check your email or phone number and password.');
        if (path === '/auth/mfa/totp') return new AccountError('mfa-code',
            'Discord did not accept that verification code. Try a new code or an unused backup code.');
        return new AccountError('expired', 'Discord no longer accepts this saved account session. Sign in again to refresh it.');
    }
    if (data.errors?.login || data.errors?.password || data.code === 50035) return new AccountError('credentials', 'Discord rejected the sign-in details. Check your email or phone number and password.');
    // Never print server messages, full HTTP errors, credentials, or response bodies.
    return new AccountError('login', 'Discord could not complete sign-in. Check your details, or sign in through Discord and save the current account.');
}
function createClient({ fetcher, now = Date.now, timeoutMs = 20000, Abort = globalThis.AbortController }) {
    const pending = new Set();
    let stopped = false, blockedUntil = 0;
    function cancel() {
        for (const entry of [...pending]) { entry.abort?.(); entry.reject(new AccountError('cancelled', 'Cancelled.')); }
    }
    async function request(path, { method = 'GET', body, token } = {}) {
        if (stopped) fail('cancelled', 'Plugin disabled.');
        if (now() < blockedUntil) throw new AccountError('rate-limit', `Wait ${Math.ceil((blockedUntil - now()) / 1000)} seconds before trying again.`, Math.ceil((blockedUntil - now()) / 1000));
        if (!['/auth/login', '/auth/mfa/totp', '/users/@me'].includes(path)) fail('endpoint', 'Unsupported sign-in request.');
        const controller = typeof Abort === 'function' ? new Abort() : null;
        let timer, entry;
        const headers = { 'Content-Type': 'application/json' };
        if (token) headers.Authorization = token;
        try {
            const response = await Promise.race([
                Promise.resolve().then(async () => {
                    const raw = await fetcher(`https://discord.com/api/v9${path}`, { method, headers,
                        body: body === undefined ? undefined : JSON.stringify(body), signal: controller?.signal });
                    let data;
                    try { data = await raw.json(); } catch { data = {}; }
                    return { ok: raw.ok, status: raw.status, data, retry: raw.headers?.get?.('retry-after') };
                }),
                new Promise((_, reject) => {
                    entry = { reject, abort: () => controller?.abort() }; pending.add(entry);
                    timer = setTimeout(() => { controller?.abort(); reject(new AccountError('timeout', 'Discord took too long to respond. Check your connection and try again.')); }, timeoutMs);
                })
            ]);
            if (stopped) fail('cancelled', 'Plugin disabled.');
            if (!response.ok || response.data.captcha_key || response.data.captcha_sitekey) {
                const error = describeFailure(response.status, response.data, response.retry, path);
                if (error.retryAfter) blockedUntil = now() + error.retryAfter * 1000;
                throw error;
            }
            return response.data;
        } catch (error) {
            if (error instanceof AccountError) throw error;
            throw new AccountError('network', 'Could not reach Discord. Check your connection and try again.');
        } finally { clearTimeout(timer); pending.delete(entry); }
    }
    return { request, cancel, stop() { stopped = true; cancel(); } };
}
function createController({ storage, client, getSession, getSwitcher, persistStorage, now = Date.now, switchTimeoutMs = 15000, pollMs = 250 }) {
    normalizeStorage(storage);
    let stopped = false, busy = false, generation = 0, challenge, refreshKey;
    const listeners = new Set(), delays = new Set();
    const notify = () => { for (const listener of listeners) { try { listener(); } catch {} } };
    const assertActive = epoch => { if (stopped || epoch !== generation) fail('cancelled', 'Cancelled.'); };
    const sameSession = (a, b) => a?.token === b?.token && a?.user?.id === b?.user?.id;
    async function exclusive(fn) {
        if (stopped) fail('cancelled', 'Plugin disabled.');
        if (busy) fail('busy', 'Another account action is still in progress.');
        busy = true; notify(); const epoch = generation;
        try { return await fn(epoch); } finally { busy = false; notify(); }
    }
    async function inspectToken(token, epoch) {
        if (!validToken(token)) fail('expired', 'No usable session was found. Sign in to Discord first.');
        const user = await client.request('/users/@me', { token }); assertActive(epoch);
        if (!validId(user?.id) || typeof user.username !== 'string') fail('invalid-user', 'Could not verify this account with Discord.');
        return user;
    }
    async function saveVerifiedAccount(user, token, epoch) {
        assertActive(epoch);
        // Stage a complete record, including the session, before changing the
        // visible list. Native hosts write and read this snapshot back from disk.
        const next = { ...storage, accounts: { ...storage.accounts }, accountOrder: [...storage.accountOrder] };
        const result = saveAccount(next, user, token);
        let committed = next;
        if (typeof persistStorage === 'function') {
            try {
                const saved = await persistStorage(next, () => !stopped && epoch === generation);
                if (saved !== undefined) {
                    if (JSON.stringify(saved) !== JSON.stringify(next)) throw new Error('Storage mismatch.');
                    committed = saved;
                }
            }
            catch {
                assertActive(epoch);
                fail('save-failed', 'Could not confirm the account was saved on this device. Your previous saved accounts are unchanged. Try Save current account again.');
            }
        }
        assertActive(epoch);
        storage.accounts = committed.accounts;
        storage.accountOrder = committed.accountOrder;
        return result;
    }
    async function saveSession(epoch, session = getSession()) {
        if (!session?.user || !validToken(session.token)) fail('no-session', 'Discord has not finished signing in. Try again after your chats load.');
        let user;
        try { user = await inspectToken(session.token, epoch); }
        catch (error) {
            if (error?.code === 'expired') fail('expired-current',
                'Discord could not verify your current session. Sign in through Discord, then use Save current account again.');
            throw error;
        }
        if (user.id !== session.user.id || !sameSession(session, getSession())) fail('session-changed', 'The active account changed. Wait for Discord to finish loading, then try again.');
        const result = await saveVerifiedAccount(user, session.token, epoch);
        refreshKey = `${user.id}:${session.token}`; notify(); return result;
    }
    async function completeLogin(data, epoch) {
        assertActive(epoch);
        if (validToken(data.token)) {
            const user = await inspectToken(data.token, epoch);
            const result = await saveVerifiedAccount(user, data.token, epoch); challenge = undefined; notify();
            return { kind: 'saved', ...result };
        }
        if (data.mfa && typeof data.ticket === 'string' && data.ticket) {
            if (data.totp === false) fail('verification', 'This account needs a passkey, SMS, or another verification method. Use Discord’s normal login screen, then save the current account.');
            challenge = { ticket: data.ticket, until: now() + 5 * 60 * 1000 };
            return { kind: 'mfa' };
        }
        fail('verification', 'Discord needs another sign-in step. Complete sign-in in Discord’s normal login screen, then save the current account.');
    }
    function delay() { return new Promise(resolve => { const item = { timer: null, resolve }; item.timer = setTimeout(() => { delays.delete(item); resolve(); }, pollMs); delays.add(item); }); }
    return {
        subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
        get busy() { return busy; },
        get accounts() { return storage.accountOrder.map(id => storage.accounts[id]).filter(Boolean); },
        saveCurrent() { return exclusive(epoch => saveSession(epoch)); },
        login(login, password) {
            return exclusive(async epoch => {
                challenge = undefined;
                if (typeof login !== 'string' || !login.trim() || typeof password !== 'string' || !password.length) fail('credentials', 'Enter your email or phone number and password.');
                const data = await client.request('/auth/login', { method: 'POST', body: { login: login.trim(), password, undelete: false } });
                return completeLogin(data, epoch);
            });
        },
        acceptQrLogin(token, expectedUserId) {
            return exclusive(async epoch => {
                if (!validId(expectedUserId)) fail('mismatch', 'The QR login did not identify the approved account.');
                const user = await inspectToken(token, epoch);
                if (user.id !== expectedUserId) fail('mismatch', 'The approved QR account does not match the returned session. Please start again.');
                const result = await saveVerifiedAccount(user, token, epoch); notify();
                return { kind: 'saved', ...result };
            });
        },
        submitCode(code) {
            return exclusive(async epoch => {
                if (!challenge || now() > challenge.until) { challenge = undefined; fail('mfa-expired', 'The verification step expired. Go back and sign in again.'); }
                const normalized = String(code).replace(/[\s-]/g, '');
                if (!normalized) fail('mfa-code', 'Enter an authenticator code or backup code.');
                const data = await client.request('/auth/mfa/totp', { method: 'POST', body: { ticket: challenge.ticket, code: normalized } });
                return completeLogin(data, epoch);
            });
        },
        switchTo(id) {
            return exclusive(async epoch => {
                const account = storage.accounts[id], original = getSession();
                if (!account) fail('missing', 'This account is no longer saved.');
                if (original?.user?.id === id) return { user: original.user, already: true };
                const switcher = getSwitcher();
                if (typeof switcher !== 'function') fail('unsupported', 'Account switching is unavailable on this Discord build. Your saved accounts are unchanged.');
                let target;
                try { target = await inspectToken(account.token, epoch); }
                catch (error) {
                    if (error?.code === 'expired') fail('expired',
                        `Saved session for @${account.username} needs to be renewed. Choose Re-sign in for this account.`);
                    throw error;
                }
                if (target.id !== id) fail('mismatch', 'This saved session belongs to a different account. Remove it and sign in again.');
                if (!sameSession(original, getSession())) fail('session-changed', 'Your active account changed. Try again.');
                if (original?.user && validToken(original.token)) await saveSession(epoch, original);
                assertActive(epoch);
                const savedToken = account.token;
                if (!sameSession(original, getSession())) fail('session-changed', 'Your active account changed. Try again.');
                // Attach a rejection handler immediately, but do not trust a resolved
                // native action as proof of a completed login. Observe the real session.
                let rejected = false;
                try { Promise.resolve(switcher(savedToken)).catch(() => { rejected = true; }); }
                catch { rejected = true; }
                const deadline = now() + switchTimeoutMs;
                while (now() < deadline) {
                    assertActive(epoch);
                    const session = getSession();
                    if (session?.user?.id === id && session.token === savedToken) {
                        await saveVerifiedAccount(target, savedToken, epoch); refreshKey = `${id}:${savedToken}`; notify();
                        return { user: target };
                    }
                    if (rejected) fail('switch-failed', 'Discord could not switch accounts. Your previous account is saved so you can select it again.');
                    await delay();
                }
                fail('switch-timeout', 'Discord has not confirmed the switch yet. Check which account is active before trying again; both saved accounts are still available.');
            });
        },
        async refreshSaved() {
            if (busy || stopped || !storage.settings.refreshSavedSessions) return;
            let session;
            try { session = getSession(); } catch { return; }
            if (!session?.user || !validToken(session.token) || !storage.accounts[session.user.id]) return;
            const key = `${session.user.id}:${session.token}`;
            if (refreshKey === key) return;
            // An unchanged, already saved session needs no startup HTTP request.
            if (storage.accounts[session.user.id].token === session.token) { refreshKey = key; return; }
            // One background attempt per observed session. Manual Save can retry.
            refreshKey = key;
            try { await exclusive(epoch => saveSession(epoch, session)); } catch {}
        },
        remove(id) {
            if (busy || stopped) return false;
            const accounts = { ...storage.accounts }; delete accounts[id]; storage.accounts = accounts;
            storage.accountOrder = storage.accountOrder.filter(value => value !== id); notify(); return true;
        },
        importAccounts(legacy) {
            if (busy || stopped) fail('busy', 'Wait for the current action to finish.');
            const result = importLegacy(storage, legacy); notify(); return result;
        },
        cancelLogin() { challenge = undefined; generation++; client.cancel(); },
        stop() {
            stopped = true; challenge = undefined; generation++; client.stop();
            for (const item of delays) { clearTimeout(item.timer); item.resolve(); } delays.clear(); listeners.clear();
        }
    };
}

/* SPDX-License-Identifier: GPL-3.0-or-later */
// Vendetta's finders require uninitialized Metro factories while searching.
// Optional features must never do that during Discord's startup.
function createModuleResolver(metro, { now = Date.now } = {}) {
    const entries = new Map();
    const modules = metro.modules;
    const loadedOnly = !!modules && typeof modules === 'object';
    function entry(kind, keys) {
        const id = JSON.stringify([kind, ...keys]);
        if (!entries.has(id)) entries.set(id, { kind, keys, value: undefined, checked: -Infinity });
        return entries.get(id);
    }
    function inspect(record, exports) {
        if (record.value || !exports) return;
        try {
            if (record.kind === 'props' ? record.keys.every(key => exports[key] != null)
                : typeof exports.getName === 'function' && exports.getName.length === 0 && exports.getName() === record.keys[0]) record.value = exports;
        } catch {}
    }
    function inspectModule(module, records) {
        // Do not invoke the factory, __r, or read exports on uninitialized modules.
        if (!module?.isInitialized || module.hasError) return;
        let exports;
        try { exports = module.publicModule?.exports; } catch { return; }
        for (const record of records) {
            try { if (exports?.__esModule) inspect(record, exports.default); } catch {}
            inspect(record, exports);
        }
    }
    function lookup(kind, keys, userAction = false) {
        const record = entry(kind, keys);
        if (record.value || (!userAction && now() - record.checked < 5000)) return record.value;
        record.checked = now();
        if (loadedOnly) {
            for (const id in modules) { try { inspectModule(modules[id], [record]); } catch {} if (record.value) break; }
        } else {
            // Older loaders without the module registry: user actions only.
            try { record.value = kind === 'props' ? metro.findByProps(...keys) : metro.findByStoreName(keys[0]); } catch {}
        }
        return record.value;
    }
    return {
        loadedOnly,
        byProps: (...keys) => lookup('props', keys),
        byStore: name => lookup('store', [name]),
        clear() { entries.clear(); },
        async prepare(queries, yieldFrame, isActive) {
            if (!loadedOnly) return;
            const records = queries.map(([kind, ...keys]) => entry(kind, keys));
            let count = 0;
            for (const id in modules) {
                if (!isActive()) return;
                try { inspectModule(modules[id], records); } catch {}
                if (records.every(record => record.value)) break;
                if (++count % 64 === 0) await yieldFrame();
            }
            if (isActive()) for (const record of records) record.checked = now();
        }
    };
}

/* SPDX-License-Identifier: GPL-3.0-or-later */

const SHORTCUT_KEY = 'MORE_ALTS_FLUTTERSHY_SETTINGS';
const CONFIG = 'SETTING_RENDERER_CONFIG';
const BRIDGE = Symbol.for('more-alts.settings.renderer.v1');
const HIDDEN_ROW = Object.freeze({
  type: 'pressable', parent: null, title: () => 'More Alts!', useTitle: () => 'More Alts!',
  usePredicate: () => false, onPress: () => {}, withArrow: true,
});

// Keep the native renderer and the menu row in sync. Other sidebar plugins may
// have replaced Revenge's dynamic getter with a captured renderer map.
function connectSettingsRenderer(constants, renderer) {
  if (!constants) return undefined;
  let state;
  try {
    state = constants[BRIDGE];
    if (!state) {
      state = { row: HIDDEN_ROW, getter: undefined };
      Object.defineProperty(constants, BRIDGE, { value: state, configurable: true });
    }
  } catch { return undefined; }

  function ensure() {
    try {
      const previous = Object.getOwnPropertyDescriptor(constants, CONFIG);
      // Another plugin can wrap our getter and still preserve this entry. Do
      // not keep wrapping each other on every settings row render.
      if (constants[CONFIG]?.[SHORTCUT_KEY] === state.row) return true;
      if (previous?.configurable === false) return false;

      // Call the prior accessor on each read. Taking a snapshot here would hide
      // later rows from Revenge or other plugins, recreating this crash.
      let assigned = false, value = previous?.value ?? constants[CONFIG];
      const getter = () => ({
        ...(previous?.get && !assigned ? previous.get.call(constants) : value),
        [SHORTCUT_KEY]: state.row,
      });
      Object.defineProperty(constants, CONFIG, {
        configurable: true, enumerable: previous?.enumerable ?? true,
        get: getter,
        set(next) {
          if (previous?.set) previous.set.call(constants, next);
          else { assigned = true; value = next; }
        },
      });
      state.getter = getter;
      return constants[CONFIG][SHORTCUT_KEY] === state.row;
    } catch { return false; }
  }

  state.row = renderer;
  if (!ensure()) { state.row = HIDDEN_ROW; return undefined; }
  return {
    ensure,
    release() {
      if (state.row === renderer) state.row = HIDDEN_ROW;
      // Native settings can retain an old array of keys while the screen is
      // open. A hidden, parentless record keeps those keys valid after unload.
      // Reuse this one bridge on re-enable rather than stacking new accessors.
    },
  };
}

/* SPDX-License-Identifier: GPL-3.0-or-later */


// Revenge exposes this registry at bunny.ui.settings.registeredSections.
// Extend the existing section; registerSection("Revenge") would replace its rows.
function registerSettingsShortcut({ settingsAPI, Settings, constants, treeManager, patcher,
  openSettings, renderIcon, getAssetID, log = () => {} }) {
  const sections = settingsAPI?.registeredSections;
  if (!sections || typeof sections !== 'object') {
    log('Settings shortcut is unavailable on this Revenge version. Use the plugin settings button.');
    return () => {};
  }
  // Match stable row keys so the shortcut also works with translated headings.
  const rows = Object.values(sections).find(items => Array.isArray(items)
    && items.some(item => item?.key === 'BUNNY_PLUGINS'));
  if (!rows || rows.some(item => item?.key === SHORTCUT_KEY)) return () => {};

  let icon;
  for (const name of ['UserIcon', 'FriendsIcon', 'WrenchIcon']) {
    try {
      const id = getAssetID?.(name);
      if (id != null) { icon = id; break; }
    } catch {}
  }
  let active = true;
  const renderer = {
    type: 'pressable', parent: null,
    title: () => 'More Alts!', useTitle: () => 'More Alts!', icon,
    IconComponent: icon != null && renderIcon ? () => renderIcon(icon) : undefined,
    usePredicate: () => active,
    onPress: () => { if (active) openSettings?.(); },
    withArrow: true,
  };
  // Do this BEFORE exposing the key in registeredSections. Otherwise Discord's
  // getAncestors reads .parent on an undefined renderer and crashes Settings.
  const bridge = connectSettingsRenderer(constants, renderer);
  if (!bridge) {
    active = false;
    log('Could not register a native settings row safely. Use the plugin settings button.');
    return () => {};
  }
  let unpatch;
  try {
    if (typeof treeManager?.getAncestors === 'function' && typeof patcher?.before === 'function') {
      unpatch = patcher.before('getAncestors', treeManager, args => {
        // Repair only our own entry if another plugin replaces the renderer
        // accessor later. Let the original tree/blocking logic run unchanged.
        if (args[0] === SHORTCUT_KEY) bridge.ensure();
      });
    }
  } catch {}
  const row = {
    key: SHORTCUT_KEY,
    title: () => 'More Alts!',
    icon,
    usePredicate: renderer.usePredicate,
    rawTabsConfig: renderer,
    // Revenge supplies the native screen header, navigation and back button.
    render: async () => ({ default: Settings }),
  };
  try {
    const anchor = rows.findIndex(item => item?.key === 'BUNNY_PLUGINS');
    rows.splice(anchor + 1, 0, row);
  } catch {
    active = false; unpatch?.(); bridge.release();
    log('Could not add the settings shortcut. Use the plugin settings button.');
    return () => {};
  }

  return () => {
    active = false;
    // Some plugins replace the section array. Remove our row wherever it moved,
    // retaining every other row (including Account Switcher).
    for (const items of new Set([rows, ...Object.values(sections)])) {
      if (!Array.isArray(items)) continue;
      const index = items.indexOf(row);
      if (index !== -1) {
        try { items.splice(index, 1); } catch {}
      }
    }
    unpatch?.(); unpatch = undefined;
    bridge.release();
  };
}

/* SPDX-License-Identifier: GPL-3.0-or-later */

// Small native login dialog with no QR login or embedded web browser.
// The account manager, login flow, and two-factor verification remain intact.
function createLoginDialog(React, RN) {
    const h = React.createElement;
    return function LoginDialog({ visible, mfa = false, light = false, busy = false, reauthUsername,
        login, password, code, error, onLoginChange, onPasswordChange, onCodeChange,
        onSubmit, onClose, onBack, onForgotPassword, onNativeLogin }) {
        if (!visible) return null;
        const c = light
            ? { card: '#ffffff', field: '#f2f3f5', border: '#d3d5da', text: '#1e1f22', muted: '#5c5e66', link: '#4752c4', danger: '#c32943', footer: '#f2f3f5' }
            : { card: '#242429', field: '#1f1f24', border: '#3a3a42', text: '#f2f3f5', muted: '#b5b5bd', link: '#8991ff', danger: '#ffb0b9', footer: '#202025' };
        const ready = !busy && (mfa ? !!code.trim() : !!login.trim() && !!password.length);
        const submit = () => { if (ready) onSubmit(); };
        const text = (value, style = {}, extra = {}) => h(RN.Text,
            { style: { color: c.text, fontSize: 15, lineHeight: 21, ...style }, ...extra }, value);
        const link = (title, action) => h(RN.TouchableOpacity, {
            accessibilityRole: 'button', accessibilityLabel: title, onPress: action,
            disabled: busy, style: { minHeight: 44, justifyContent: 'center', opacity: busy ? 0.5 : 1 }
        }, text(title, { color: c.link, fontSize: 14 }));
        const field = (label, value, onChangeText, props) => h(RN.View, { style: { marginBottom: 16 } },
            text(label, { fontWeight: '600', marginBottom: 6 }),
            h(RN.TextInput, { value, onChangeText, editable: !busy, accessibilityLabel: label,
                autoCapitalize: 'none', autoCorrect: false, selectionColor: '#8991ff',
                style: { minHeight: 48, paddingHorizontal: 12, paddingVertical: 10, fontSize: 16,
                    color: c.text, backgroundColor: c.field, borderWidth: 1, borderColor: c.border, borderRadius: 8 },
                ...props }));
        return h(RN.Modal, { visible: true, transparent: true, animationType: 'fade',
            presentationStyle: 'overFullScreen', onRequestClose: onClose, statusBarTranslucent: true },
            h(RN.KeyboardAvoidingView, { style: { flex: 1 }, behavior: RN.Platform?.OS === 'ios' ? 'padding' : 'height' },
                h(RN.View, { style: { flex: 1, backgroundColor: 'rgba(0,0,0,0.72)',
                    alignItems: 'center', justifyContent: 'center', padding: 16 } },
                    h(RN.View, { accessibilityViewIsModal: true,
                        style: { width: '100%', maxWidth: 480, maxHeight: '90%',
                            backgroundColor: c.card, borderWidth: 1, borderColor: c.border, borderRadius: 14, overflow: 'hidden' } },
                        h(RN.ScrollView, { keyboardShouldPersistTaps: 'handled', bounces: false,
                            style: { flexShrink: 1 },
                            contentContainerStyle: { paddingHorizontal: 22, paddingTop: 22, paddingBottom: 12 } },
                            h(RN.View, { style: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' } },
                                text(mfa ? 'Two-Factor Authentication' : reauthUsername ? 'Update saved account' : 'Add Account',
                                    { fontSize: 22, lineHeight: 28, fontWeight: '700' },
                                    { accessibilityRole: 'header' }),
                                h(RN.TouchableOpacity, { accessibilityRole: 'button',
                                    accessibilityLabel: 'Close add account', onPress: onClose,
                                    style: { minWidth: 44, minHeight: 44, alignItems: 'center', justifyContent: 'center' } },
                                    text('×', { color: c.muted, fontSize: 30, lineHeight: 32 }))),
                            text(mfa ? 'Enter your authenticator or backup code to finish signing in.'
                                : reauthUsername ? `Sign in to @${reauthUsername} using its email or phone number and password. Only that account will be updated.`
                                : 'Sign in to save another account and switch between profiles.',
                                { color: c.muted, marginTop: 4, marginBottom: 20 }),
                            error ? text(error, { color: c.danger, marginBottom: 16 },
                                { accessibilityRole: 'alert', accessibilityLiveRegion: 'polite' }) : null,
                            mfa ? field('Verification Code', code, onCodeChange,
                                { secureTextEntry: true, autoComplete: 'one-time-code',
                                    returnKeyType: 'done', onSubmitEditing: submit })
                                : h(RN.View, null,
                                    field('Email or Phone Number', login, onLoginChange,
                                        { autoComplete: 'username', keyboardType: 'email-address', textContentType: 'username' }),
                                    field('Password', password, onPasswordChange,
                                        { secureTextEntry: true, autoComplete: 'password',
                                            textContentType: 'password', returnKeyType: 'go', onSubmitEditing: submit }),
                                    link('Forgot your password?', onForgotPassword)),
                            link('Use Discord’s normal sign-in', onNativeLogin),
                            text('Passwords and verification codes are never saved.',
                                { color: c.muted, fontSize: 12, lineHeight: 17, marginTop: 8 })),
                        h(RN.View, { style: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
                            backgroundColor: c.footer, paddingHorizontal: 22, paddingVertical: 16 } },
                            h(RN.TouchableOpacity, { accessibilityRole: 'button', accessibilityLabel: 'Back',
                                onPress: onBack, style: { minHeight: 44, minWidth: 68, justifyContent: 'center' } },
                                text('Back', { fontWeight: '600' })),
                            h(RN.TouchableOpacity, { accessibilityRole: 'button', accessibilityLabel: mfa ? 'Verify' : 'Continue',
                                accessibilityState: { disabled: !ready, busy }, disabled: !ready, onPress: submit,
                                style: { minHeight: 44, minWidth: 112, borderRadius: 8, alignItems: 'center',
                                    justifyContent: 'center', backgroundColor: '#5865f2', opacity: ready ? 1 : 0.5 } },
                                busy ? h(RN.ActivityIndicator, { color: '#ffffff', size: 'small', accessibilityLabel: 'Signing in' })
                                    : text(mfa ? 'Verify' : 'Continue', { color: '#ffffff', fontWeight: '700' })))))));
    };
}

/* SPDX-License-Identifier: GPL-3.0-or-later */

function createAccountSwitcher(React, RN) {
    const h = React.createElement;
    return function AccountSwitcher({ accounts, currentUser, busy, light, error, notice, expiredAccountId,
        onSwitch, onSaveCurrent, onAddAccount, onManage, onReauth }) {
        const c = light
            ? { card: '#ffffff', text: '#18191c', muted: '#515460', line: '#d7dae3', selected: '#e9ecff', danger: '#a11932' }
            : { card: '#2c2e36', text: '#f3f4f7', muted: '#bec0cb', line: '#454853', selected: '#31364d', danger: '#ffb0b9' };
        const text = (value, style = {}, props = {}) => h(RN.Text,
            { style: { color: c.text, fontSize: 15, lineHeight: 21, ...style }, ...props }, value);
        const currentId = currentUser?.id;
        const savedCurrent = accounts.some(account => account.id === currentId);
        const rows = [...accounts];
        if (validId(currentId) && !savedCurrent && typeof currentUser.username === 'string') rows.unshift({
            id: currentId, username: currentUser.username,
            displayName: currentUser.global_name || currentUser.globalName || currentUser.username,
            avatar: currentUser.avatar,
        });
        rows.sort((a, b) => (a.id === currentId ? -1 : b.id === currentId ? 1 : 0));
        const action = (title, onPress, primary = false, disabled = false) => h(RN.TouchableOpacity, {
            accessibilityRole: 'button', accessibilityLabel: title, onPress, disabled: busy || disabled,
            accessibilityState: { disabled: busy || disabled },
            style: { minHeight: 48, paddingHorizontal: 16, paddingVertical: 13, marginTop: 12, borderRadius: 10,
                backgroundColor: primary ? '#4d59cd' : c.card, opacity: busy || disabled ? 0.5 : 1 },
        }, text(title, { color: primary ? '#ffffff' : c.text, fontWeight: '700', textAlign: 'center' }));
        return h(RN.View, { testID: 'more-alts-account-switcher' },
            text('Switch accounts', { fontSize: 26, fontWeight: '800', lineHeight: 32, marginBottom: 8 }),
            text('Choose the account you want to use.', { color: c.muted, marginBottom: 20 }),
            error ? text(error, { color: c.danger, marginBottom: 12 }, { accessibilityRole: 'alert' }) : null,
            notice ? text(notice, { marginBottom: 12 }, { accessibilityLiveRegion: 'polite' }) : null,
            busy ? h(RN.ActivityIndicator, { color: '#8993ff', accessibilityLabel: 'Updating accounts', style: { marginBottom: 12 } }) : null,
            rows.length ? h(RN.View, { style: { backgroundColor: c.card, borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: c.line } },
                ...rows.map((account, index) => {
                    const selected = currentId === account.id;
                    const expired = expiredAccountId === account.id;
                    const label = selected ? `@${account.username}, current account` : `Switch to @${account.username}`;
                    const avatar = validId(account.id) && typeof account.avatar === 'string' && /^[a-zA-Z0-9_]+$/.test(account.avatar);
                    return h(RN.View, { key: account.id, style: { borderTopWidth: index ? 1 : 0, borderTopColor: c.line } },
                        h(RN.TouchableOpacity, {
                            testID: `more-alts-account-${account.id}`, accessibilityRole: 'button', accessibilityLabel: label,
                            accessibilityState: { selected, disabled: busy || selected }, disabled: busy || selected,
                            onPress: () => onSwitch(account),
                            style: { flexDirection: 'row', alignItems: 'center', minHeight: 76, padding: 14,
                                backgroundColor: selected ? c.selected : c.card, opacity: busy ? 0.6 : 1 },
                        },
                        avatar ? h(RN.Image, { accessible: false, source: { uri: `https://cdn.discordapp.com/avatars/${account.id}/${account.avatar}.png?size=128` },
                            style: { width: 40, height: 40, borderRadius: 20, marginRight: 12 } })
                            : h(RN.View, { accessible: false, style: { width: 40, height: 40, borderRadius: 20, marginRight: 12,
                                backgroundColor: '#4d59cd', alignItems: 'center', justifyContent: 'center' } },
                                text((account.displayName || account.username || '?').slice(0, 1).toUpperCase(), { color: '#ffffff', fontSize: 19, fontWeight: '700' })),
                        h(RN.View, { style: { flex: 1, minWidth: 0, paddingRight: 12 } },
                            text(account.displayName || account.username, { fontWeight: '700', fontSize: 16 }, { numberOfLines: 1 }),
                            text(`@${account.username}`, { color: c.muted, fontSize: 13, lineHeight: 19 }, { numberOfLines: 1 }),
                            selected ? text(savedCurrent ? 'Current account' : 'Current account · Not saved', { color: c.muted, fontSize: 12, lineHeight: 18 }) : null,
                            expired ? text('Sign in again to refresh this account', { color: c.danger, fontSize: 12, lineHeight: 18 }) : null),
                        selected ? text('✓', { color: light ? '#197b4d' : '#66d6a0', fontSize: 24, fontWeight: '700' }, { accessible: false }) : null),
                        expired ? h(RN.View, { style: { paddingHorizontal: 14, paddingBottom: 14 } },
                            action('Re-sign in', () => onReauth(account))) : null);
                })) : text('Save your current account or add an account to get started.', { color: c.muted, marginBottom: 12 }),
            action('Add another account', onAddAccount, true),
            action('Save current account', onSaveCurrent, false, !validId(currentId)),
            action('Manage accounts', onManage),
            text(`${accounts.length} saved account${accounts.length === 1 ? '' : 's'} · More Alts!`, { color: c.muted, fontSize: 12, marginTop: 16, textAlign: 'center' }));
    };
}

/* SPDX-License-Identifier: GPL-3.0-or-later */

function createPlugin(V, host = globalThis) {
    const { React, ReactNative: RN } = V.metro.common;
    const h = React.createElement, storage = V.plugin.storage;
    const LoginDialog = createLoginDialog(React, RN);
    const AccountSwitcher = createAccountSwitcher(React, RN);
    const hasQuickSwitcher = V.host?.id === 'valenced';
    const resolver = createModuleResolver(V.metro);
    const setTimer = (fn, ms) => (host.setTimeout || setTimeout)(fn, ms);
    const clearTimer = id => (host.clearTimeout || clearTimeout)(id);
    const disposers = [];
    let active = false, controller, refreshTimer, initTimer, idleTask, nativeReady = false, optionalReady = false, epoch = 0;
    const pendingFrames = new Map();
    const byProps = resolver.byProps;
    const byStore = resolver.byStore;
    const toast = text => { try { V.ui?.toasts?.showToast(text); } catch {} };
    const log = text => { try { V.logger?.warn?.(`[More Alts] ${text}`); } catch {} };
    function getSession() {
        try { return { user: byStore('UserStore')?.getCurrentUser?.(),
            token: byStore('AuthenticationStore')?.getToken?.() ?? byProps('getToken')?.getToken?.() }; }
        catch { return {}; }
    }
    function getSwitcher() {
        const auth = byProps('switchAccountToken');
        return typeof auth?.switchAccountToken === 'function' ? token => auth.switchAccountToken(token) : undefined;
    }
    function scheduleRefresh() {
        if (!active || !optionalReady || !storage.settings.refreshSavedSessions || !storage.accountOrder.length) return;
        clearTimer(refreshTimer);
        const instance = controller;
        refreshTimer = setTimer(() => {
            if (active && controller === instance) void instance.refreshSaved().catch(() => {});
        }, 1500);
    }
    function openSettings() {
        if (!active) return;
        try {
            const nav = byProps('getRootNavigationRef')?.getRootNavigationRef?.();
            if (!nav?.navigate) throw new Error();
            nav.navigate('BUNNY_CUSTOM_PAGE', { title: 'More Alts!', render: () => h(Settings) });
        } catch { toast('Open Revenge → Plugins → More Alts! → Settings.'); }
    }
    function nativeLoginHelp() {
        RN.Alert.alert('Sign in through Discord',
            'Save your current account here first. Open Discord’s account menu and choose Add account, then complete any CAPTCHA, passkey, SMS or device verification. Once that account’s chats have loaded, return here and tap Save current account.\n\nThe native account menu depends on your Discord version. More Alts cannot bypass Discord verification.');
    }
    function forgotPassword() {
        RN.Alert.alert('Reset your Discord password',
            'Open Discord’s sign-in page and choose “Forgot your password?”. After resetting it, return here to add your account.', [
                { text: 'Back', style: 'cancel' },
                { text: 'Open Discord', onPress: () => {
                    try {
                        if (typeof RN.Linking?.openURL !== 'function') throw new Error();
                        Promise.resolve(RN.Linking.openURL('https://discord.com/login')).catch(() => toast('Open discord.com/login in your browser to reset your password.'));
                    } catch { toast('Open discord.com/login in your browser to reset your password.'); }
                } }
            ]);
    }
    async function importOld() {
        // Read only the original, installed Apex MoreAlts storage, only after
        // pressing Import. Never scan arbitrary plugin storage for sessions.
        const ids = Object.keys(V.plugins?.plugins || {}).filter(id =>
            /^https:\/\/apexteampl\.github\.io\/Apex-Plugins\/MoreAlts\/?$/i.test(id));
        if (!ids.length) throw new AccountError('no-legacy', 'Keep the original Apex More Alts installed but disabled, then try importing again.');
        if (typeof V.storage?.createMMKVBackend !== 'function' || typeof V.storage?.createStorage !== 'function')
            throw new AccountError('unsupported', 'Import is unavailable on this Revenge version. Sign in and save each account here.');
        const instance = controller;
        let added = 0, skipped = 0;
        for (const id of ids) {
            const old = await V.storage.createStorage(V.storage.createMMKVBackend(id));
            if (!active || controller !== instance) throw new AccountError('cancelled', 'Cancelled.');
            const result = instance.importAccounts(old); added += result.added; skipped += result.skipped;
        }
        return { added, skipped };
    }
    function Settings() {
        const [, redraw] = React.useState(0);
        const [page, setPage] = React.useState('accounts');
        const [view, setView] = React.useState(hasQuickSwitcher ? 'switcher' : 'accounts');
        const [login, setLogin] = React.useState(''), [password, setPassword] = React.useState('');
        const [code, setCode] = React.useState(''), [query, setQuery] = React.useState('');
        const [notice, setNotice] = React.useState(''), [error, setError] = React.useState('');
        const [expiredAccountId, setExpiredAccountId] = React.useState(null);
        const [reauthId, setReauthId] = React.useState(null);
        const [localBusy, setLocalBusy] = React.useState(false);
        const mounted = React.useRef(true), authenticating = React.useRef(false), localLock = React.useRef(false);
        const instance = controller;
        React.useEffect(() => {
            // Legacy loaders initialize compatibility features when the manager is opened.
            if (!resolver.loadedOnly && active && !optionalReady) initializeOptional();
            scheduleRefresh();
        }, [instance]);
        React.useEffect(() => {
            mounted.current = true;
            const unsubscribe = instance?.subscribe(() => { if (mounted.current) redraw(x => x + 1); });
            return () => { mounted.current = false; unsubscribe?.(); if (authenticating.current) instance?.cancelLogin(); };
        }, [instance]);
        const osScheme = RN.useColorScheme?.();
        let theme;
        try { theme = byStore('ThemeStore')?.theme; } catch {}
        const light = theme ? theme === 'light' : osScheme === 'light';
        const colors = light ? { bg: '#f5f5f8', card: '#ffffff', text: '#18191c', muted: '#515460', line: '#cbced7', error: '#a11932' }
            : { bg: '#202127', card: '#2c2e36', text: '#f3f4f7', muted: '#bec0cb', line: '#535563', error: '#ffb0b9' };
        const text = (value, style = {}) => h(RN.Text, { style: { color: colors.text, fontSize: 15, lineHeight: 22, marginBottom: 10, ...style } }, value);
        if (!instance || !active) return h(RN.View, { style: { padding: 20 } }, text('Enable More Alts! to manage your saved accounts.'));
        const busy = instance.busy || localBusy;
        const button = (title, onPress, secondary = false, allowBusy = false) => h(RN.TouchableOpacity, {
            accessibilityRole: 'button', accessibilityLabel: title, disabled: busy && !allowBusy, onPress,
            style: { backgroundColor: secondary ? colors.card : '#4d59cd', padding: 14, borderRadius: 10,
                borderColor: colors.line, borderWidth: secondary ? 1 : 0, marginBottom: 12, opacity: busy && !allowBusy ? 0.5 : 1 }
        }, text(title, { color: secondary ? colors.text : '#ffffff', fontWeight: '700', textAlign: 'center', marginBottom: 0 }));
        const input = (label, value, onChangeText, props = {}) => h(RN.View, null,
            text(label, { fontWeight: '600', marginBottom: 6 }), h(RN.TextInput, {
                value, onChangeText, editable: !busy, accessibilityLabel: label,
                autoCapitalize: 'none', autoCorrect: false, placeholderTextColor: colors.muted,
                style: { color: colors.text, backgroundColor: colors.card, borderColor: colors.line, borderWidth: 1, borderRadius: 10, padding: 14, marginBottom: 14, fontSize: 16 }, ...props
            }));
        const toggle = (title, key) => h(RN.View, { style: { flexDirection: 'row', alignItems: 'center', marginVertical: 8 } },
            h(RN.View, { style: { flex: 1, paddingRight: 12 } }, text(title, { marginBottom: 0 })),
            h(RN.Switch, { accessibilityLabel: title, disabled: busy, value: !!storage.settings[key], onValueChange: value => {
                storage.settings = { ...storage.settings, [key]: value }; redraw(x => x + 1); scheduleRefresh();
            } }));
        const clearAuth = () => { setLogin(''); setPassword(''); setCode(''); authenticating.current = false; };
        const cancel = () => { instance.cancelLogin(); clearAuth(); setReauthId(null); setPage('accounts'); setError(''); setNotice(''); };
        const stillHere = () => mounted.current && active && controller === instance;
        async function run(action, success, onError) {
            if (localLock.current || instance.busy) return;
            localLock.current = true; setLocalBusy(true); setError(''); setNotice('');
            try { const result = await action(); if (stillHere()) success?.(result); }
            catch (reason) {
                if (stillHere() && reason?.code !== 'cancelled') {
                    onError?.(reason);
                    setError(reason instanceof AccountError ? reason.message : 'The action could not be completed. Try again after Discord finishes loading.');
                }
            } finally { localLock.current = false; if (stillHere()) setLocalBusy(false); }
        }
        function handleLogin(result) {
            setPassword(''); setCode('');
            if (result.kind === 'mfa') { setPage('mfa'); return; }
            const target = reauthId;
            const refreshedTarget = target && target === result.user.id;
            if (refreshedTarget) setExpiredAccountId(null);
            clearAuth(); setReauthId(null); setPage('accounts');
            if (target && !refreshedTarget) {
                const account = instance.accounts.find(item => item.id === target);
                setNotice(`Signed in as @${result.user.username}, but @${account?.username || 'the selected account'} still needs to be signed in again.`);
            } else {
                setNotice(`Saved @${result.user.username} successfully.`);
            }
        }
        const saveCurrent = () => run(() => instance.saveCurrent(), result => {
            clearAuth(); setReauthId(null); setPage('accounts');
            if (expiredAccountId === result.user.id) setExpiredAccountId(null);
            setNotice(`Saved @${result.user.username} successfully.`);
        });
        function beginReauth(account) {
            clearAuth(); setError(''); setNotice('');
            setReauthId(account.id); setPage('login');
        }
        const switchAccount = account => run(() => instance.switchTo(account.id), result => {
            setExpiredAccountId(null); setNotice(`Switched to ${result.user.username}.`);
        }, reason => { if (reason?.code === 'expired') setExpiredAccountId(account.id); });
        const addAccount = () => { clearAuth(); setReauthId(null); setPage('login'); setError(''); setNotice(''); };
        function remove(account) {
            RN.Alert.alert('Remove saved account?', `Remove ${account.username} from More Alts? This only removes its saved session here.`, [
                { text: 'Cancel', style: 'cancel' }, { text: 'Remove', style: 'destructive', onPress: () => {
                    if (active && controller === instance && instance.remove(account.id) && mounted.current) {
                        if (expiredAccountId === account.id) setExpiredAccountId(null);
                        setNotice(`Removed ${account.username}.`);
                    }
                } }
            ]);
        }
        const currentId = getSession()?.user?.id;
        const matches = instance.accounts.filter(account => `${account.username} ${account.displayName} ${account.id}`.toLowerCase().includes(query.toLowerCase()));
        const contents = [text('More Alts!', { fontSize: 26, fontWeight: '800', lineHeight: 32 }),
            text('Save your accounts and switch between them.', { color: colors.muted }),
            error ? text(error, { color: colors.error }) : null,
            notice ? text(notice, { fontWeight: '600' }) : null,
            busy ? h(RN.ActivityIndicator, { color: '#8993ff', style: { marginBottom: 12 } }) : null];
        if (hasQuickSwitcher) contents.unshift(button('Back to account switcher', () => setView('switcher'), true));
        contents.push(button('Save current account', saveCurrent),
            button('Add another account', addAccount, true),
            input('Search saved accounts', query, setQuery, { placeholder: 'Username, display name or user ID' }),
            text(`${instance.accounts.length} saved account${instance.accounts.length === 1 ? '' : 's'}`, { fontWeight: '700' }));
        contents.push(...matches.map(account => h(RN.View, { key: account.id, style: { backgroundColor: colors.card, borderRadius: 12, padding: 14, marginBottom: 12 } },
            h(RN.View, { style: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 } },
                account.avatar && /^[a-zA-Z0-9_]+$/.test(account.avatar) ? h(RN.Image, { source: { uri: `https://cdn.discordapp.com/avatars/${account.id}/${account.avatar}.png?size=128` }, style: { width: 42, height: 42, borderRadius: 21, marginRight: 12 } }) : null,
                h(RN.View, { style: { flex: 1 } }, text(account.displayName, { fontWeight: '700', fontSize: 17, marginBottom: 2 }),
                    text(`@${account.username}${currentId === account.id ? ' · Current account' : ''}`, { color: colors.muted, marginBottom: 0 }))),
            Number.isFinite(account.updatedAt) ? text(`Last saved: ${new Date(account.updatedAt).toLocaleString()}`, { color: colors.muted, fontSize: 12 }) : null,
            currentId !== account.id ? button('Switch account', () => switchAccount(account)) : null,
            expiredAccountId === account.id ? text('Discord rejected this saved session. Sign in again to update this account without removing it.',
                { color: colors.error, fontSize: 13 }) : null,
            expiredAccountId === account.id ? button('Re-sign in', () => beginReauth(account), true) : null,
            button('Remove saved account', () => remove(account), true))));
        if (!matches.length) contents.push(text(query ? 'No matching accounts.' : 'Save your current account to get started.', { color: colors.muted }));
        contents.push(button('Import accounts from old More Alts', () => run(importOld, result => setNotice(`Imported ${result.added} account${result.added === 1 ? '' : 's'}; skipped ${result.skipped} existing or invalid entries.`)), true),
            text('For import, keep the original Apex More Alts installed but disabled.', { color: colors.muted }),
            toggle('Refresh saved sessions after signing in', 'refreshSavedSessions'),
            toggle('Enable Discord’s native account menu', 'enableNativeSwitcher'),
            text(nativeReady ? 'Reopen Discord settings after changing the native menu option.' : 'The native menu is unavailable on this build. The saved-account list above still works.', { color: colors.muted }),
            button('Help with Discord verification', nativeLoginHelp, true),
            text('Saved sessions stay in Revenge’s local plugin storage. Passwords and verification codes are never stored. Signing out or changing a password can expire a saved session.', { color: colors.muted }));
        return h(RN.KeyboardAvoidingView, { style: { flex: 1, backgroundColor: colors.bg }, behavior: RN.Platform?.OS === 'ios' ? 'padding' : undefined },
            h(RN.ScrollView, { keyboardShouldPersistTaps: 'handled', contentContainerStyle: { padding: 18, paddingBottom: 48 },
                importantForAccessibility: page === 'accounts' ? 'auto' : 'no-hide-descendants', accessibilityElementsHidden: page !== 'accounts' },
                ...(view === 'switcher' ? [h(AccountSwitcher, { accounts: instance.accounts, currentUser: getSession()?.user,
                    busy, light, error, notice, expiredAccountId, onSwitch: switchAccount, onSaveCurrent: saveCurrent,
                    onAddAccount: addAccount, onManage: () => setView('accounts'), onReauth: beginReauth })] : contents)),
            h(LoginDialog, { visible: page !== 'accounts', mfa: page === 'mfa', light, busy,
                reauthUsername: reauthId ? instance.accounts.find(account => account.id === reauthId)?.username : undefined,
                login, password, code, error, onLoginChange: setLogin, onPasswordChange: setPassword, onCodeChange: setCode,
                onClose: cancel, onBack: () => {
                    if (page !== 'mfa') { cancel(); return; }
                    instance.cancelLogin(); setPassword(''); setCode(''); setError(''); setPage('login');
                },
                onForgotPassword: forgotPassword, onNativeLogin: nativeLoginHelp,
                onSubmit: () => {
                    authenticating.current = true;
                    if (page === 'mfa') {
                        const typedCode = code; setCode(''); void run(() => instance.submitCode(typedCode), handleLogin);
                    } else {
                        const typedPassword = password; setPassword(''); void run(() => instance.login(login, typedPassword), handleLogin);
                    }
                }
            }));
    }
    function initializeOptional() {
        if (!active || optionalReady) return;
        optionalReady = true;
        try {
            const native = byProps('getCanUseMultiAccountMobile');
            if (typeof native?.getCanUseMultiAccountMobile === 'function') {
                const unpatch = V.patcher.after('getCanUseMultiAccountMobile', native, (_, result) => active && storage.settings.enableNativeSwitcher ? true : result);
                if (typeof unpatch === 'function') { nativeReady = true; disposers.push(unpatch); }
            }
        } catch { log('Native menu is unavailable; plugin settings remain accessible.'); }
        ['UserStore', 'AuthenticationStore'].forEach(name => {
            try {
                const store = byStore(name);
                if (typeof store?.addChangeListener === 'function' && typeof store?.removeChangeListener === 'function') {
                    store.addChangeListener(scheduleRefresh); disposers.push(() => store.removeChangeListener(scheduleRefresh));
                }
            } catch {}
        });
        try {
            const subscription = RN.AppState?.addEventListener?.('change', state => { if (state === 'active') scheduleRefresh(); });
            if (subscription?.remove) disposers.push(() => subscription.remove());
        } catch {}
        try {
            disposers.push(registerSettingsShortcut({
                settingsAPI: host.bunny?.ui?.settings ?? host.window?.bunny?.ui?.settings,
                Settings, constants: byProps('SETTING_RENDERER_CONFIG'), treeManager: byProps('getAncestors', 'isBlocked'),
                patcher: V.patcher, openSettings,
                renderIcon: source => h(RN.Image, { source, style: { width: 24, height: 24 } }),
                getAssetID: name => V.ui?.assets?.getAssetIDByName(name), log
            }));
        } catch { log('Use the plugin settings button to manage accounts.'); }
        try {
            // registerCommand itself resolves Discord's built-in command module.
            const register = !resolver.loadedOnly || byProps('getBuiltInCommands') ? V.commands?.registerCommand : undefined;
            const unreg = register?.({ name: 'morealts', displayName: 'morealts', type: 1, inputType: 1,
                applicationId: '-1', description: 'Open More Alts account switcher', displayDescription: 'Open More Alts account switcher',
                options: [], execute: () => { openSettings(); return undefined; } });
            if (typeof unreg === 'function') disposers.push(unreg);
        } catch {}
        scheduleRefresh();
    }
    function yieldFrame() {
        return new Promise(resolve => {
            const timer = setTimer(() => { pendingFrames.delete(timer); resolve(); }, 0);
            pendingFrames.set(timer, resolve);
        });
    }
    function onLoad() {
        if (active) return;
        controller = createController({ storage, client: createClient({ fetcher: (...args) => host.fetch(...args) }), getSession, getSwitcher,
            persistStorage: typeof V.plugin.persistStorage === 'function' ? (value, isCurrent) => V.plugin.persistStorage(value, isCurrent) : undefined });
        active = true; optionalReady = false;
        const generation = ++epoch;
        // No synchronous Discord module searches, API calls or native patches.
        // Older loaders use the settings button until the manager is opened.
        if (!resolver.loadedOnly) return;
        initTimer = setTimer(() => {
            initTimer = undefined;
            const initialize = () => {
                if (!active || epoch !== generation) return;
                const isActive = () => active && epoch === generation;
                void resolver.prepare([
                    ['props', 'getCanUseMultiAccountMobile'], ['store', 'UserStore'],
                    ['store', 'AuthenticationStore'], ['props', 'getToken'],
                    ['props', 'SETTING_RENDERER_CONFIG'], ['props', 'getAncestors', 'isBlocked'],
                    ['store', 'ThemeStore'], ['props', 'getBuiltInCommands']
                ], yieldFrame, isActive).then(() => {
                    if (isActive()) initializeOptional();
                }).catch(() => { if (isActive()) log('Optional shortcuts are unavailable. Use the plugin settings button.'); });
            };
            try {
                if (typeof RN.InteractionManager?.runAfterInteractions === 'function') {
                    idleTask = RN.InteractionManager.runAfterInteractions(initialize); return;
                }
            } catch {}
            initialize();
        }, 1500);
    }
    function onUnload() {
        active = false; epoch++; optionalReady = false; nativeReady = false;
        clearTimer(refreshTimer); clearTimer(initTimer); initTimer = undefined;
        try { idleTask?.cancel?.(); } catch {} idleTask = undefined;
        for (const [timer, resolve] of pendingFrames) { clearTimer(timer); resolve(); } pendingFrames.clear();
        controller?.stop();
        for (const dispose of disposers.splice(0).reverse()) { try { dispose?.(); } catch {} }
        resolver.clear();
    }
    return { onLoad, onUnload, settings: Settings };
}

return createPlugin(vendetta);
})()
}, "More Alts!");
})()
); }, {"id": "dev.fluttershy2008.more-alts", "legacyManifest": {"name": "More Alts!", "description": "Save and switch Discord accounts with secure session checks, account-specific sign-in recovery, email/password, 2FA and native account management. No QR login.", "version": "3.1.15", "authors": [{"name": "Win8.1VMUser", "id": "793935599702507542"}, {"name": "John"}, {"name": "cocobo1"}, {"name": "fluttershy_simper", "id": "753962426407452713"}], "main": "index.js", "vendetta": {"icon": "UserIcon"}, "hash": "373b6d66a13a22a8b5a0e88745b0f8c15d755924ff567ae1e2238c63b668185f"}, "repository": "https://fluttershy2008-mlp.github.io/lol/index.json"}) };
})()
