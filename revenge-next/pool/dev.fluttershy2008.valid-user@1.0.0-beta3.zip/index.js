(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Revenge Next API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the Revenge Next plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const source = rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update Revenge Next to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        const found = rawFind(...props);
        if (found) return found;
        if (props.some(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.next.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const list = await U.modules.native.callNativeMethod('revenge.plugins.list', []);
        if (!active || !Array.isArray(list)) return;
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list) {
            const manifest = item.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            const entry = { id: item.source?.repo ?? metadata.repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.['revenge.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createNextPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false };
            running = state;
            async function stop() {
                if (state.stopped) return;
                state.stopped = true;
                try { await state.legacy?.onUnload?.(); }
                finally { await bridge.dispose(); if (running === state) running = undefined; }
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createNextPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}
return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
"use strict";
// ValidUser: local parsing and a bounded, cancellable Discord lookup queue.
const validId = id => typeof id === "string" && /^[1-9]\d{16,19}$/.test(id);
const usableUser = (user, id) => user?.id === id && typeof user.username === "string"
    && user.username.length > 0 && !/^(unknown[- ]user|deleted user)$/i.test(user.username);

function extractMentionIds(message) {
    const ids = new Set(), seen = new Set();
    let nodes = 0, characters = 0;
    function visit(node, depth = 0) {
        if (node == null || depth > 16 || ++nodes > 4000 || ids.size >= 40) return;
        if (typeof node === "string") {
            const text = node.slice(0, Math.max(0, 100000 - characters));
            characters += text.length;
            const pattern = /<@!?([1-9]\d{16,19})>|https?:\/\/(?:www\.)?(?:(?:canary|ptb)\.)?discord(?:app)?\.com\/users\/([1-9]\d{16,19})(?!\d)/g;
            let match;
            while (ids.size < 40 && (match = pattern.exec(text))) ids.add(match[1] || match[2]);
            return;
        }
        if (typeof node !== "object" || seen.has(node)) return;
        seen.add(node);
        if (Array.isArray(node)) {
            for (const child of node) visit(child, depth + 1);
        } else {
            // Wire and MessageRecord spellings. Never walk React owners or arbitrary objects.
            for (const key of ["content", "rawContent", "title", "rawTitle", "description", "rawDescription",
                "name", "rawName", "value", "rawValue", "text", "embeds", "fields", "author", "footer",
                "components", "accessory", "message", "messageSnapshots", "message_snapshots",
                "referencedMessage", "referenced_message"]) visit(node[key], depth + 1);
        }
    }
    visit(message);
    return [...ids];
}

function classifyFailure(error, now = Date.now()) {
    const body = error?.body ?? error?.response?.body ?? {};
    const status = Number(error?.status ?? error?.statusCode ?? error?.response?.status);
    if (status === 429) {
        const seconds = Number(body.retry_after ?? error?.headers?.["retry-after"] ?? 60);
        const delay = Number.isFinite(seconds) && seconds >= 0 ? Math.max(1000, seconds * 1000 + 250) : 60000;
        return { status: "rate-limited", until: now + delay };
    }
    if (status === 401 || status === 403) return { status: "unavailable", until: now + 60000 };
    if (status === 404 || body.code === 10013) return { status: "unknown", until: now + 300000 };
    return { status: "retry", until: now + 15000 };
}

function createResolver({ getUser, request, accept, onResolved = () => {},
    isCurrent = () => true, spacing = 500, timeout = 15000, now = Date.now }) {
    const pending = new Map(), failures = new Map(), queue = [], cancellations = new Set();
    let active = true, running = false, blockedUntil = 0, nextRequestAt = 0;
    const current = () => active && isCurrent();
    const cached = id => {
        try { const user = getUser(id); return usableUser(user, id) ? user : null; } catch { return null; }
    };
    function wait(ms) {
        return new Promise(resolve => {
            const finish = () => { clearTimeout(timer); cancellations.delete(finish); resolve(); };
            const timer = setTimeout(finish, ms);
            cancellations.add(finish);
        });
    }
    function timedRequest(id) {
        return new Promise((resolve, reject) => {
            let finished = false;
            const finish = (fn, value) => {
                if (finished) return;
                finished = true; clearTimeout(timer); cancellations.delete(cancel); fn(value);
            };
            const cancel = () => finish(reject, new Error("Lookup cancelled"));
            const timer = setTimeout(() => finish(reject, new Error("Lookup timed out")), timeout);
            cancellations.add(cancel);
            Promise.resolve().then(() => current() ? request(id) : Promise.reject(new Error("Inactive")))
                .then(value => finish(resolve, value), error => finish(reject, error));
        });
    }
    async function lookup(id) {
        if (!current()) return { id, status: "cancelled" };
        const user = cached(id);
        if (user) return { id, status: "resolved", user };
        if (blockedUntil > now()) return { id, status: "rate-limited", until: blockedUntil };
        try {
            const response = await timedRequest(id);
            if (!current()) return { id, status: "cancelled" };
            if (response?.status >= 400) throw response;
            const raw = response?.body?.user ?? response?.body ?? response;
            if (!usableUser(raw, id)) throw new Error("Invalid user response");
            await accept(raw);
            if (!current()) return { id, status: "cancelled" };
            const result = { id, status: "resolved", user: cached(id) ?? raw };
            failures.delete(id);
            try { onResolved(result); } catch {}
            return result;
        } catch (error) {
            if (!current()) return { id, status: "cancelled" };
            const failure = classifyFailure(error, now());
            if (failure.status === "rate-limited") blockedUntil = failure.until;
            if (failures.size >= 500) failures.delete(failures.keys().next().value);
            failures.set(id, failure);
            return { id, ...failure };
        }
    }
    async function pump() {
        if (running) return;
        running = true;
        try {
            while (current() && queue.length) {
                if (nextRequestAt > now()) await wait(nextRequestAt - now());
                if (!current()) break;
                const job = queue.shift();
                const result = await lookup(job.id);
                pending.delete(job.id); job.resolve(result);
                nextRequestAt = now() + spacing;
            }
        } finally {
            running = false;
            if (!current()) for (const job of queue.splice(0)) {
                pending.delete(job.id); job.resolve({ id: job.id, status: "cancelled" });
            }
        }
    }
    function resolve(id) {
        if (!validId(id)) return Promise.resolve({ id, status: "invalid" });
        if (!current()) return Promise.resolve({ id, status: "cancelled" });
        const user = cached(id);
        if (user) return Promise.resolve({ id, status: "resolved", user });
        if (pending.has(id)) return pending.get(id);
        if (blockedUntil > now()) return Promise.resolve({ id, status: "rate-limited", until: blockedUntil });
        const failure = failures.get(id);
        if (failure?.until > now()) return Promise.resolve({ id, ...failure });
        if (pending.size >= 100) return Promise.resolve({ id, status: "busy" });
        const promise = new Promise(resolve => queue.push({ id, resolve }));
        pending.set(id, promise);
        void pump();
        return promise;
    }
    return {
        resolve,
        stop() {
            active = false;
            for (const cancel of [...cancellations]) cancel();
            for (const job of queue.splice(0)) job.resolve({ id: job.id, status: "cancelled" });
            pending.clear(); failures.clear();
        }
    };
}

// Bounded startup retries plus store-driven scans; no permanent polling loop.
function createAutoScanner({ scan, enabled, onError = () => {} }) {
    let active = false, pending = null;
    const retries = new Set();
    function notify(delay = 100) {
        if (!active || !enabled() || pending !== null) return;
        pending = setTimeout(() => {
            pending = null;
            if (active && enabled()) {
                try { scan(); } catch (error) { onError(error); }
            }
        }, delay);
    }
    function clear() {
        if (pending !== null) clearTimeout(pending);
        pending = null;
        for (const timer of retries) clearTimeout(timer);
        retries.clear();
    }
    function wake() {
        clear();
        if (!active || !enabled()) return;
        notify(0);
        // The selected channel, logged-in user and message cache hydrate separately.
        // Store listeners handle later changes after these startup retries finish.
        for (const delay of [500, 1500, 3000, 6000, 12000, 30000]) {
            const timer = setTimeout(() => { retries.delete(timer); notify(0); }, delay);
            retries.add(timer);
        }
    }
    return {
        notify, wake,
        start() { active = true; wake(); },
        stop() { active = false; clear(); }
    };
}


function createPlugin(V) {
    "use strict";
    const { React, ReactNative: RN } = V.metro.common;
    const h = React.createElement, storage = V.plugin?.storage ?? {};
    const unpatches = [], timers = new Set(), autoIds = new Set(), watchedStores = new Set();
    let active = false, generation = 0, resolver, resolverAccount, scanTimer, refreshTimer;
    let autoScanner, loggedOut = false;
    let users, messages, selected, dispatcher, rest, sheetHost, Row;
    const byProps = (...keys) => { try { return V.metro.findByProps(...keys); } catch {} };
    const byStore = name => { try { return V.metro.findByStoreName(name); } catch {} };
    const byName = name => { try { return V.metro.findByName(name); } catch {} };
    const toast = text => { try { V.ui.toasts.showToast(text); } catch {} };
    const log = text => { try { V.logger.warn(`[ValidUser] ${text}`); } catch {} };
    const asset = () => {
        for (const name of ["MentionIcon", "ic_mention_24px"]) {
            try { const id = V.ui.assets.getAssetIDByName(name); if (id != null) return id; } catch {}
        }
    };
    function later(fn, delay = 0) {
        const session = generation;
        const timer = setTimeout(() => {
            timers.delete(timer);
            if (active && session === generation) { try { fn(); } catch { log("A UI refresh was skipped."); } }
        }, delay);
        timers.add(timer);
        return timer;
    }
    function refresh() {
        if (refreshTimer) return;
        refreshTimer = later(() => {
            refreshTimer = null;
            // Notify subscribers only. Never fake MESSAGE_UPDATE, modify message text,
            // or reserialize embeds/attachments just to repaint a mention.
            for (const store of [users, messages]) {
                try { store?.emitChange?.(); } catch {}
            }
        }, 30);
    }
    function resetResolver() {
        resolver?.stop(); generation++;
        for (const timer of timers) clearTimeout(timer);
        timers.clear(); autoIds.clear(); scanTimer = refreshTimer = null;
        const session = generation, account = users.getCurrentUser?.()?.id;
        resolverAccount = account;
        resolver = createResolver({
            getUser: id => users.getUser(id),
            isCurrent: () => active && !loggedOut && validId(account) && generation === session && account === users.getCurrentUser?.()?.id,
            request: id => rest.get({ url: `/users/${id}` }),
            accept: raw => dispatcher.dispatch({ type: "USER_UPDATE", user: raw }),
            onResolved: refresh
        });
    }
    function ensureResolver() {
        if (!active || loggedOut) return false;
        const account = users.getCurrentUser?.()?.id;
        // onLoad may run before the signed-in account has hydrated.
        if (!resolver || account !== resolverAccount) resetResolver();
        return validId(account);
    }
    function statusText(result) {
        switch (result.status) {
            case "resolved": return "Resolved. You can open this user's profile.";
            case "unavailable": return "Discord refused this lookup. Your account may not have access to this user.";
            case "unknown": return "Discord could not find this user. The ID may be invalid, unavailable, or deleted.";
            case "rate-limited": return `Discord asked us to slow down. Try again in ${Math.max(1, Math.ceil((result.until - Date.now()) / 1000))} seconds.`;
            case "busy": return "There are too many pending lookups. Try again shortly.";
            case "invalid": return "Enter a valid user ID, mention, or Discord user link.";
            case "cancelled": return "Lookup cancelled.";
            default: return "The lookup failed or timed out. Check your connection and try again shortly.";
        }
    }
    function displayName(result) {
        const user = result.user;
        return user?.globalName || user?.global_name || user?.username || result.id;
    }
    async function openProfile(result) {
        if (!active || result.status !== "resolved") return;
        try {
            const open = byName("showUserProfileActionSheet")
                ?? byProps("showUserProfileActionSheet")?.showUserProfileActionSheet;
            if (typeof open !== "function") {
                toast("Profile opening is unavailable on this Discord version. Try the mention again.");
                return;
            }
            // Let Discord fetch the real profile. Do not invent badges, membership,
            // or a successful profile response when the server denies access.
            await open({ userId: result.id });
        } catch { toast("Discord could not open this profile. Try the mention again."); }
    }
    function showResults(results, index = 0, session = generation) {
        if (!active || session !== generation || !results.length) return;
        const result = results[index];
        const buttons = [{ text: "Done", style: "cancel" }];
        if (results.length > 1) buttons.push({ text: "Next", onPress: () => showResults(results, (index + 1) % results.length, session) });
        if (result.status === "resolved") buttons.push({ text: "Open profile", onPress: () => {
            if (active && session === generation) void openProfile(result);
        } });
        const title = `${displayName(result)}${results.length > 1 ? ` (${index + 1}/${results.length})` : ""}`;
        const text = `${result.id}\n\n${statusText(result)}${result.status === "resolved" ? "\n\nIf the old mention stays visible, switch channels and return." : ""}`;
        try { RN.Alert.alert(title, text, buttons); } catch { toast(statusText(result)); }
    }
    async function resolveMessage(message) {
        if (!ensureResolver()) return;
        const session = generation, ids = extractMentionIds(message);
        if (!active || !ids.length) return;
        toast(`Resolving ${ids.length} mention${ids.length === 1 ? "" : "s"}…`);
        try {
            const results = await Promise.all(ids.map(id => resolver.resolve(id)));
            if (active && generation === session) { refresh(); showResults(results); }
        } catch { if (active && generation === session) toast("Could not resolve these mentions."); }
    }
    function queueMessage(message, eventChannel) {
        if (!active || storage.autoResolve === false || !message) return;
        if (!ensureResolver()) return;
        const channel = message.channel_id ?? message.channelId ?? eventChannel;
        const current = selected?.getChannelId?.();
        if (!current || channel !== current) return;
        for (const id of extractMentionIds(message)) if (autoIds.size < 100) autoIds.add(id);
        if (scanTimer || !autoIds.size) return;
        // Subscriptions can execute inside a dispatch. Defer USER_UPDATE until it ends.
        scanTimer = later(() => {
            scanTimer = null;
            const ids = [...autoIds]; autoIds.clear();
            if (storage.autoResolve === false) return;
            for (const id of ids) void resolver.resolve(id).catch(() => {});
        });
    }
    function scanCurrentChannel() {
        if (storage.autoResolve === false || !ensureResolver()) return;
        if (!messages) {
            messages = byStore("MessageStore") ?? byProps("getMessage", "getMessages");
            watchStore(messages);
        }
        if (!selected) {
            selected = byStore("SelectedChannelStore") ?? byProps("getChannelId", "getVoiceChannelId")
                ?? byProps("getGuildId", "getChannelId");
            watchStore(selected);
        }
        const id = selected?.getChannelId?.();
        if (!id) return;
        let list = messages?.getMessages?.(id);
        if (typeof list?.toArray === "function") list = list.toArray();
        else if (typeof list?.values === "function") list = Array.from(list.values());
        else if (Array.isArray(list?._array)) list = list._array;
        else if (typeof list?.getMessages === "function") list = list.getMessages();
        if (Array.isArray(list)) for (const message of list.slice(-80)) queueMessage(message, id);
    }
    function watchStore(store) {
        if (watchedStores.has(store)) return;
        if (typeof store?.addChangeListener !== "function" || typeof store?.removeChangeListener !== "function") return;
        const listener = () => autoScanner?.notify();
        try {
            store.addChangeListener(listener);
            watchedStores.add(store);
            unpatches.push(() => store.removeChangeListener(listener));
        } catch { log("A store listener was unavailable; startup retries remain enabled."); }
    }
    function subscribe(event, fn) {
        const safe = value => { if (active) { try { fn(value); } catch { log(`Skipped ${event}.`); } } };
        dispatcher.subscribe(event, safe);
        unpatches.push(() => dispatcher.unsubscribe(event, safe));
    }
    function makeRow(message) {
        const icon = asset(), session = generation;
        return h(Row, {
            key: "valid-user-resolve", label: "Resolve mentions / Open profile",
            icon: Row.Icon && icon != null ? h(Row.Icon, { source: icon }) : undefined,
            iconSource: !Row.Icon ? icon : undefined,
            onPress: () => {
                if (!active || session !== generation) return;
                try { sheetHost.hideActionSheet("MessageLongPressActionSheet"); } catch {}
                later(() => { void resolveMessage(message); }, 150);
            }
        });
    }
    function injectRow(tree, message) {
        let target, best = -1, duplicate = false;
        const seen = new Set();
        function inspect(node, depth = 0) {
            if (!node || typeof node !== "object" || depth > 35 || seen.has(node)) return;
            seen.add(node);
            if (node.key === "valid-user-resolve") duplicate = true;
            if (Array.isArray(node)) {
                const score = node.filter(child => child?.props && typeof child.props.onPress === "function"
                    && (child.type === Row || child.props.label != null)).length;
                if (score > best && score > 0) { best = score; target = node; }
                node.forEach(child => inspect(child, depth + 1));
            } else if (node.props) inspect(node.props.children, depth + 1);
        }
        inspect(tree);
        if (duplicate) return tree;
        const row = makeRow(message);
        // Some versions put a single child inside a Row.Group rather than an array.
        function replace(node, depth = 0) {
            if (depth > 35 || !node) return node;
            if (node === target) return [row, ...node];
            if (!target && Row.Group && node.type === Row.Group) {
                target = node;
                return React.cloneElement(node, {}, row, node.props.children);
            }
            if (Array.isArray(node)) {
                const children = node.map(child => replace(child, depth + 1));
                return children.some((child, i) => child !== node[i]) ? children : node;
            }
            if (node.props?.children != null) {
                const children = replace(node.props.children, depth + 1);
                return children === node.props.children ? node : React.cloneElement(node, { children });
            }
            return node;
        }
        return replace(tree);
    }
    function wrapSheet(component, context, session) {
        function transform(props, tree) {
            if (!active || generation !== session) return tree;
            try {
                const message = props?.message ?? context?.message;
                return extractMentionIds(message).length ? injectRow(tree, message) : tree;
            } catch { return tree; }
        }
        if (typeof component === "function" && !component.prototype?.isReactComponent) {
            return function ValidUserSheet(...args) { return transform(args[0], component.apply(this, args)); };
        }
        if (component?.$$typeof === Symbol.for("react.memo")) return React.memo(wrapSheet(component.type, context, session), component.compare);
        if (component?.$$typeof === Symbol.for("react.forward_ref")) return React.forwardRef((props, ref) => transform(props, component.render(props, ref)));
        return component;
    }
    function Settings() {
        const [value, setValue] = React.useState("");
        const [auto, setAuto] = React.useState(storage.autoResolve !== false);
        const [busy, setBusy] = React.useState(false), [result, setResult] = React.useState(null);
        const mounted = React.useRef(true);
        React.useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
        const light = RN.useColorScheme?.() === "light";
        const color = light ? "#191919" : "#ffffff", muted = light ? "#555555" : "#b9bbc3";
        const text = (label, style = {}) => h(RN.Text, { style: { color, marginVertical: 8, ...style } }, label);
        async function lookup() {
            if (!active || busy) return;
            if (!ensureResolver()) { toast("Wait for Discord to finish signing in, then try again."); return; }
            const input = value.trim(), id = validId(input) ? input : extractMentionIds(input)[0];
            setBusy(true); setResult(null);
            const session = generation;
            try {
                const next = await resolver.resolve(id ?? input);
                if (mounted.current && active && session === generation) setResult(next);
            } finally { if (mounted.current) setBusy(false); }
        }
        return h(RN.ScrollView, { contentContainerStyle: { padding: 20, paddingBottom: 40 }, keyboardShouldPersistTaps: "handled" },
            text("ValidUser 2.1.0", { fontSize: 24, fontWeight: "700" }),
            text("Resolve unknown mentions in messages, embeds and forwarded messages."),
            h(RN.View, { style: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" } },
                text("Automatically resolve mentions"), h(RN.Switch, { value: auto, onValueChange: enabled => {
                    storage.autoResolve = enabled; setAuto(enabled);
                    resetResolver(); autoScanner?.wake();
                } })),
            text("Runs automatically when Revenge starts, messages load, you switch channels, or you return to the app.", { color: muted }),
            text("User ID, mention, or profile link"),
            h(RN.TextInput, { value, onChangeText: setValue, autoCapitalize: "none", autoCorrect: false,
                placeholder: "Paste a user ID or <@mention>", placeholderTextColor: muted,
                style: { color, borderColor: muted, borderWidth: 1, borderRadius: 8, padding: 12, marginBottom: 12 } }),
            h(RN.Button, { title: busy ? "Resolving…" : "Resolve user", disabled: busy || !value.trim(), onPress: () => { void lookup(); } }),
            result && text(`${displayName(result)}\n${statusText(result)}`),
            result?.status === "resolved" && h(RN.Button, { title: "Open profile", onPress: () => { void openProfile(result); } }),
            text("You can also long-press a message and choose Resolve mentions / Open profile. If a resolved mention has not redrawn, switch channels and return.", { color: muted }),
            text("Only information Discord makes available to your account can be loaded.", { color: muted })
        );
    }
    function onLoad() {
        if (active) return;
        users = byStore("UserStore") ?? byProps("getUser", "getCurrentUser");
        messages = byStore("MessageStore") ?? byProps("getMessage", "getMessages");
        selected = byStore("SelectedChannelStore") ?? byProps("getChannelId", "getVoiceChannelId")
            ?? byProps("getGuildId", "getChannelId");
        dispatcher = V.metro.common.FluxDispatcher ?? byProps("dispatch", "subscribe");
        rest = byProps("get", "post", "del") ?? byProps("get", "post", "patch");
        sheetHost = byProps("openLazy", "hideActionSheet");
        Row = byProps("ActionSheetRow")?.ActionSheetRow;
        if (!users?.getUser || !dispatcher?.dispatch || !rest?.get) {
            throw new Error("ValidUser: user lookup modules are unavailable on this Discord build.");
        }
        active = true; loggedOut = false;
        try {
            resetResolver();
            autoScanner = createAutoScanner({
                scan: scanCurrentChannel,
                enabled: () => active && !loggedOut && storage.autoResolve !== false,
                onError: () => log("Waiting for Discord's message cache to become available.")
            });
            for (const store of [users, messages, selected]) watchStore(store);
            if (typeof RN.AppState?.addEventListener === "function") {
                const listener = state => { if (state === "active") autoScanner.wake(); };
                try {
                    const subscription = RN.AppState.addEventListener("change", listener);
                    unpatches.push(() => {
                        if (typeof subscription?.remove === "function") subscription.remove();
                        else RN.AppState.removeEventListener?.("change", listener);
                    });
                } catch { log("App resume notifications are unavailable."); }
            }
            if (dispatcher.subscribe && dispatcher.unsubscribe) {
                for (const event of ["MESSAGE_CREATE", "MESSAGE_UPDATE"]) subscribe(event, payload => queueMessage(payload?.message));
                subscribe("LOAD_MESSAGES_SUCCESS", payload => {
                    for (const message of (Array.isArray(payload?.messages) ? payload.messages.slice(-80) : [])) {
                        queueMessage(message, payload.channelId ?? payload.channel_id);
                    }
                    autoScanner.notify();
                });
                subscribe("CHANNEL_SELECT", () => autoScanner.wake());
                subscribe("CONNECTION_OPEN", () => { loggedOut = false; autoScanner.wake(); });
                subscribe("CONNECTION_RESUMED", () => autoScanner.wake());
                subscribe("LOGOUT", () => { loggedOut = true; resetResolver(); resolver.stop(); autoScanner.wake(); });
            }
            if (sheetHost?.openLazy && Row) {
                unpatches.push(V.patcher.before("openLazy", sheetHost, args => {
                    const [lazy, key, context] = args;
                    if (key !== "MessageLongPressActionSheet" || !lazy?.then) return;
                    const session = generation;
                    // Wrap only this opening; never patch a shared React module or add hooks to it.
                    args[0] = Promise.resolve(lazy).then(module => {
                        if (!active || generation !== session || !module?.default) return module;
                        return { ...module, default: wrapSheet(module.default, context, session) };
                    });
                }));
            } else toast("ValidUser: use the plugin settings to resolve a user on this Discord version.");
            autoScanner.start();
        } catch (error) { onUnload(); throw error; }
    }
    function onUnload() {
        active = false; generation++; resolver?.stop(); autoScanner?.stop();
        for (const timer of timers) clearTimeout(timer);
        timers.clear(); autoIds.clear(); scanTimer = refreshTimer = null;
        for (const unpatch of unpatches.splice(0).reverse()) { try { unpatch(); } catch {} }
        watchedStores.clear();
    }
    return { onLoad, onUnload, settings: Settings };
}

return createPlugin(vendetta);
})()
}, "ValidUser");
})()
); }, {"id": "dev.fluttershy2008.valid-user", "legacyManifest": {"name": "ValidUser", "description": "Automatically resolve unknown mentions when Revenge starts and messages load, including embeds and forwards.", "authors": [{"name": "fshin", "id": "1381008677301129257"}, {"name": "o.oer", "id": "306810730055729152"}, {"name": "kmmiio99o", "id": "879393496627306587"}, {"name": "fluttershy_simper", "id": "753962426407452713"}], "main": "index.js", "vendetta": {"icon": "ic_mention_24px"}, "version": "2.1.2", "hash": "b5be82b964f5a54876280006a8f4de6e7fa74baf6528b10ce682ec4072862efc"}, "repository": "https://raw.githubusercontent.com/Fluttershy2008-mlp/lol/main/revenge-next/index.json"}) };
})()
