(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Revenge Next API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the Revenge Next plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    function findByProps(...props) {
        return finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.next.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: () => findByProps('HTTP')?.HTTP ?? findByProps('get', 'post', 'patch', 'del'),
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        General: Object.assign(Object.create(RN), { Button: design.Button }),
        Forms: { FormRow: design.TableRow, FormSection: design.TableRowGroup, FormSwitchRow: design.TableSwitchRow,
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const list = await U.modules.native.callNativeMethod('revenge.plugins.list', []);
        if (!active || !Array.isArray(list)) return;
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list) {
            const manifest = item.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            const entry = { id: item.source?.repo ?? metadata.repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.['revenge.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: api.logger,
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch: (...args) => host.fetch(...args),
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createNextPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false };
            running = state;
            async function stop() {
                if (state.stopped) return;
                state.stopped = true;
                try { await state.legacy?.onUnload?.(); }
                finally { await bridge.dispose(); if (running === state) running = undefined; }
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createNextPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}
return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
    "use strict";

    // PingJumper for Revenge / Vendetta-compatible Discord mobile clients.
    // Floating arrows let you move through Discord's Recent Mentions history:
    //   \u2191 older ping
    //   \u2193 newer ping

    const optional = callback => { try { return callback(); } catch { return undefined; } };
    const findByProps = (...args) => optional(() => vendetta.metro.findByProps(...args));
    const findByStoreName = (...args) => optional(() => vendetta.metro.findByStoreName(...args));
    const findByTypeName = (...args) => optional(() => vendetta.metro.findByTypeName?.(...args));
    const { React, ReactNative } = vendetta.metro.common;
    const { before, after } = vendetta.patcher;
    const { getAssetIDByName } = vendetta.ui.assets;
    const { showToast } = vendetta.ui.toasts;
    const { findInReactTree } = vendetta.utils;

    const LazyActionSheet = findByProps("openLazy", "hideActionSheet");
    const ActionSheetRow = findByProps("ActionSheetRow")?.ActionSheetRow;
    const APIUtils = findByProps("getAPIBaseURL", "get") ?? findByProps("get", "post");
    const OpenURL = findByProps("openUrl");

    const UserStore = findByStoreName("UserStore");
    const ChannelStore = findByStoreName("ChannelStore");
    const ChatView = findByTypeName("ChatView")
        ?? optional(() => vendetta.metro.findByName?.("ChatView", false));
    const chatMethod = ChatView?.type ? "type" : "default";

    const iconJump =
        getAssetIDByName("LinkIcon")
        ?? getAssetIDByName("ic_jump_to_message")
        ?? getAssetIDByName("ic_arrow_right_24px")
        ?? getAssetIDByName("ic_copy_message_link");

    const iconSuccess =
        getAssetIDByName("Check")
        ?? getAssetIDByName("CircleCheckIcon-primary")
        ?? iconJump;

    const iconError =
        getAssetIDByName("Small")
        ?? getAssetIDByName("CircleXIcon-primary")
        ?? iconJump;

    const PAGE_SIZE = 25;
    const unpatches = [];

    let commandUnregister = null;
    let mentions = [];
    let currentIndex = -1;
    let hasMore = true;
    let busy = false;
    let lastRefresh = 0;
    let active = false, generation = 0;
    function resolveSheet(promise, callback) {
        const epoch = generation;
        return Promise.resolve(promise).then(module => {
            if (active && epoch === generation) return callback(module);
        }).catch(error => logError("Could not extend this action sheet", error));
    }

    function logError(...args) {
        try {
            vendetta.logger?.error?.("[PingJumper]", ...args);
        } catch {
            console.error("[PingJumper]", ...args);
        }
    }

    function getCurrentUserId() {
        return String(UserStore?.getCurrentUser?.()?.id ?? "");
    }

    function normalizeMention(message) {
        if (!message?.id) return null;

        const channelId = String(message.channel_id ?? message.channelId ?? "");
        if (!channelId) return null;

        return {
            ...message,
            id: String(message.id),
            channel_id: channelId,
        };
    }

    function parseMentionResponse(response) {
        const body = response?.body ?? response;
        const raw = Array.isArray(body)
            ? body
            : Array.isArray(body?.messages)
                ? body.messages
                : Array.isArray(body?.mentions)
                    ? body.mentions
                    : [];

        return raw.map(normalizeMention).filter(Boolean);
    }

    function buildMentionQuery(beforeId) {
        const parts = [
            "limit=" + PAGE_SIZE,
            "roles=true",
            "everyone=true",
            "guilds=true",
        ];

        if (beforeId) parts.push("before=" + encodeURIComponent(beforeId));
        return parts.join("&");
    }

    async function fetchMentionPage(beforeId = null, reset = false) {
        if (!APIUtils?.get) throw new Error("Discord's mentions API module was not found");

        const response = await APIUtils.get({
            url: "/users/@me/mentions",
            query: buildMentionQuery(beforeId),
        });

        const batch = parseMentionResponse(response);

        if (reset) {
            mentions = [];
            currentIndex = -1;
            hasMore = true;
        }

        const known = new Set(mentions.map(message => message.id));
        let added = 0;

        for (const message of batch) {
            if (known.has(message.id)) continue;
            mentions.push(message);
            known.add(message.id);
            added++;
        }

        hasMore = batch.length === PAGE_SIZE && added > 0;
        lastRefresh = Date.now();
        return added;
    }

    function getGuildIdForMention(message) {
        const explicit = String(message?.guild_id ?? message?.guildId ?? "");
        if (explicit) return explicit;

        try {
            const channel = ChannelStore?.getChannel?.(message?.channel_id);
            return String(channel?.guild_id ?? channel?.guildId ?? "") || null;
        } catch {
            return null;
        }
    }

    function buildMessageURL(guildId, channelId, messageId) {
        return "https://discord.com/channels/" + (guildId || "@me") + "/" + channelId + "/" + messageId;
    }

    function openMention(message) {
        const channelId = String(message?.channel_id ?? message?.channelId ?? "");
        if (!channelId || !message?.id) throw new Error("This ping has no message location");

        const guildId = getGuildIdForMention(message);
        const target = buildMessageURL(guildId, channelId, String(message.id));

        if (OpenURL?.openUrl) {
            OpenURL.openUrl(target);
            return;
        }

        if (ReactNative?.Linking?.openURL) {
            ReactNative.Linking.openURL(target);
            return;
        }

        throw new Error("Could not open the ping message");
    }

    function showPositionToast() {
        if (currentIndex < 0 || !mentions[currentIndex]) return;
        const loaded = mentions.length;
        showToast(
            "Ping " + (currentIndex + 1) + " of " + loaded + (hasMore ? "+" : "") + " loaded",
            iconSuccess,
        );
    }

    async function ensureMentionsLoaded() {
        if (mentions.length) return true;
        await fetchMentionPage(null, true);
        return mentions.length > 0;
    }

    async function jumpToNewestPing(forceRefresh = false) {
        if (busy) return;
        busy = true;

        try {
            if (forceRefresh || !mentions.length) {
                await fetchMentionPage(null, true);
            }

            if (!mentions.length) {
                showToast("No recent pings found", iconError);
                return;
            }

            currentIndex = 0;
            openMention(mentions[currentIndex]);
            showPositionToast();
        } catch (error) {
            logError("Failed to jump to newest ping", error);
            showToast("Couldn't load pings: " + (error?.message ?? "Unknown error"), iconError);
        } finally {
            busy = false;
        }
    }

    async function jumpOlder() {
        if (busy) return;
        busy = true;

        try {
            const loaded = await ensureMentionsLoaded();
            if (!loaded) {
                showToast("No recent pings found", iconError);
                return;
            }

            if (currentIndex < 0) {
                currentIndex = 0;
                openMention(mentions[currentIndex]);
                showPositionToast();
                return;
            }

            let nextIndex = currentIndex + 1;

            if (nextIndex >= mentions.length && hasMore) {
                const oldest = mentions[mentions.length - 1];
                await fetchMentionPage(oldest?.id ?? null, false);
                nextIndex = currentIndex + 1;
            }

            if (nextIndex >= mentions.length) {
                showToast("No older pings", iconError);
                return;
            }

            currentIndex = nextIndex;
            openMention(mentions[currentIndex]);
            showPositionToast();
        } catch (error) {
            logError("Failed to jump to older ping", error);
            showToast("Couldn't load older ping: " + (error?.message ?? "Unknown error"), iconError);
        } finally {
            busy = false;
        }
    }

    async function jumpNewer() {
        if (busy) return;
        busy = true;

        try {
            const loaded = await ensureMentionsLoaded();
            if (!loaded) {
                showToast("No recent pings found", iconError);
                return;
            }

            if (currentIndex < 0) {
                currentIndex = 0;
                openMention(mentions[currentIndex]);
                showPositionToast();
                return;
            }

            if (currentIndex === 0) {
                if (Date.now() - lastRefresh > 10000) {
                    await fetchMentionPage(null, true);
                    if (mentions.length) {
                        currentIndex = 0;
                        openMention(mentions[0]);
                        showPositionToast();
                        return;
                    }
                }

                showToast("Already at your newest ping", iconJump);
                return;
            }

            currentIndex--;
            openMention(mentions[currentIndex]);
            showPositionToast();
        } catch (error) {
            logError("Failed to jump to newer ping", error);
            showToast("Couldn't load newer ping: " + (error?.message ?? "Unknown error"), iconError);
        } finally {
            busy = false;
        }
    }

    function ArrowButton({ direction, onPress, label }) {
        return React.createElement(
            ReactNative.TouchableOpacity,
            {
                activeOpacity: 0.72,
                accessibilityRole: "button",
                accessibilityLabel: label,
                onPress,
                style: {
                    width: 50,
                    height: 50,
                    borderRadius: 14,
                    backgroundColor: "rgba(30, 31, 34, 0.94)",
                    alignItems: "center",
                    justifyContent: "center",
                    marginVertical: 5,
                    elevation: 8,
                    shadowColor: "#000000",
                    shadowOpacity: 0.3,
                    shadowRadius: 5,
                    shadowOffset: { width: 0, height: 2 },
                },
            },
            React.createElement(
                ReactNative.Text,
                {
                    style: {
                        color: "#F2F3F5",
                        fontSize: 34,
                        lineHeight: 38,
                        fontWeight: "500",
                        textAlign: "center",
                    },
                },
                direction,
            ),
        );
    }

    function PingArrowOverlay() {
        return React.createElement(
            ReactNative.View,
            {
                pointerEvents: "box-none",
                style: {
                    position: "absolute",
                    right: 14,
                    bottom: 145,
                    zIndex: 9999,
                    alignItems: "center",
                },
            },
            React.createElement(ArrowButton, {
                direction: "\u2191",
                label: "Older ping",
                onPress: () => void jumpOlder(),
            }),
            React.createElement(ArrowButton, {
                direction: "\u2193",
                label: "Newer ping",
                onPress: () => void jumpNewer(),
            }),
        );
    }

    function patchChatArrows() {
        if (!ChatView?.[chatMethod]) return () => {};

        return after(chatMethod, ChatView, (_, rendered) => {
            try {
                return React.createElement(
                    React.Fragment,
                    null,
                    rendered,
                    React.createElement(PingArrowOverlay),
                );
            } catch (error) {
                logError("Failed to render ping arrows", error);
                return rendered;
            }
        });
    }

    function makeJumpRow() {
        if (!ActionSheetRow) return null;

        const iconProps = ActionSheetRow.Icon
            ? { icon: React.createElement(ActionSheetRow.Icon, { source: iconJump }) }
            : { iconSource: iconJump };

        return React.createElement(ActionSheetRow, {
            label: "Jump to Latest Ping",
            ...iconProps,
            onPress: () => {
                LazyActionSheet?.hideActionSheet?.();
                void jumpToNewestPing(true);
            },
        });
    }

    function patchMessageActionSheet() {
        if (!LazyActionSheet?.openLazy || !ActionSheetRow) return () => {};

        const nested = [];

        const unpatchOpen = before("openLazy", LazyActionSheet, ([componentPromise, sheetName, args]) => {
            if (sheetName !== "MessageLongPressActionSheet" || !args?.message) return;

            resolveSheet(componentPromise, module => {
                if (!module?.default) return;

                const unpatchSheet = after("default", module, (_, component) => {
                    try {
                        let buttons = findInReactTree(component, node =>
                            Array.isArray(node)
                            && node.some(child => child?.type === ActionSheetRow || child?.type?.name === "ActionSheetRow")
                        );

                        if (!buttons?.push) {
                            const groups = findInReactTree(component, node =>
                                Array.isArray(node)
                                && node.some(child => child?.type?.name === "ActionSheetRowGroup")
                            );

                            if (Array.isArray(groups)) {
                                for (const group of groups) {
                                    const candidate = findInReactTree(group, node =>
                                        Array.isArray(node)
                                        && node.some(child => child?.type === ActionSheetRow || child?.type?.name === "ActionSheetRow")
                                    );

                                    if (candidate?.push) {
                                        buttons = candidate;
                                        break;
                                    }
                                }
                            }
                        }

                        if (!buttons?.push) return;
                        if (buttons.some(child => child?.props?.label === "Jump to Latest Ping")) return;

                        const row = makeJumpRow();
                        if (!row) return;

                        const copyLinkIndex = buttons.findIndex(child => child?.props?.label === "Copy Message Link");
                        const position = copyLinkIndex >= 0 ? copyLinkIndex : Math.max(0, buttons.length - 1);
                        buttons.splice(position, 0, row);
                    } catch (error) {
                        logError("Failed to add message action", error);
                    }
                }, true);

                nested.push(unpatchSheet);
            }).catch(error => logError("Failed to patch message action sheet", error));
        });

        nested.push(unpatchOpen);

        return () => {
            for (const unpatch of nested.splice(0).reverse()) {
                try { unpatch?.(); } catch {}
            }
        };
    }

    function registerCommandIfAvailable() {
        const registerCommand = vendetta.commands?.registerCommand;
        if (typeof registerCommand !== "function") return null;

        try {
            return registerCommand({
                name: "lastping",
                displayName: "lastping",
                description: "Jump to your newest Discord ping",
                displayDescription: "Jump to your newest Discord ping",
                options: [],
                execute: async () => {
                    await jumpToNewestPing(true);
                    return null;
                },
                applicationId: "-1",
                inputType: 1,
                type: 1,
            });
        } catch (error) {
            logError("Could not register /lastping", error);
            return null;
        }
    }

    function onLoad() {
        if (active) return;
        if (!UserStore || !APIUtils?.get) {
            throw new Error("PingJumper: required Discord modules were not found on this build");
        }

        active = true;
        generation++;
        if (ChatView?.[chatMethod]) unpatches.push(patchChatArrows());
        if (LazyActionSheet && ActionSheetRow) unpatches.push(patchMessageActionSheet());
        commandUnregister = registerCommandIfAvailable();

        showToast(
            ChatView?.[chatMethod]
                ? "PingJumper enabled - use \u2191 / \u2193 in chat"
                : "PingJumper enabled - use /lastping or the message menu",
            iconJump,
        );
    }

    function onUnload() {
        active = false;
        generation++;
        try {
            commandUnregister?.();
        } catch {}
        commandUnregister = null;

        for (const unpatch of unpatches.splice(0).reverse()) {
            try { unpatch?.(); } catch (error) { logError("Failed to unpatch", error); }
        }

        mentions = [];
        currentIndex = -1;
        hasMore = true;
        busy = false;
    }

    return { onLoad, onUnload };
})()
}, "PingJumper");
})()
); }, {"id": "dev.fluttershy2008.ping-jumper", "legacyManifest": {"name": "PingJumper", "description": "Floating up/down arrows let you jump through recent Discord pings on mobile.", "version": "1.1.2", "authors": [{"name": "Fluttershy2008-mlp"}], "main": "index.js", "vendetta": {"icon": "ic_link_24px"}, "hash": "a5db088dd33507c7014b8fcebf9e4102d3fac8e66869921cb6e136c98abef68f"}, "repository": "https://raw.githubusercontent.com/Fluttershy2008-mlp/lol/main/revenge-next/index.json"}) };
})()
