(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Revenge Next API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the Revenge Next plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const source = rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update Revenge Next to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        const found = rawFind(...props);
        if (found) return found;
        if (props.some(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.next.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const response = await U.modules.native.callNativeMethod('revenge.plugins.list', []);
        if (!active) return;
        // The generic bridge unwraps its transport envelope. Plugin-system
        // methods return a second { result } or { error } envelope inside it.
        if (response && !Array.isArray(response) && Object.hasOwn(response, 'error')) {
            const detail = response.error;
            const error = new Error(detail?.message ?? 'Could not read installed plugins.');
            error.code = detail?.code ?? 'UNKNOWN';
            throw error;
        }
        const list = Array.isArray(response) ? response : response?.result;
        if (list !== null && !Array.isArray(list)) throw new Error('Invalid plugin registry response from Revenge Next.');
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list ?? []) {
            const manifest = item?.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            // A sideloaded or third-party plugin must not inherit our repo URL.
            const repository = item.source?.repo ?? (item.source === undefined && manifest.id.startsWith('dev.fluttershy2008.')
                ? metadata.repository : manifest.id);
            const entry = { id: repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.['revenge.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createNextPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false, stopping: undefined, stop };
            running = state;
            function stop() {
                if (state.stopped) return state.stopping;
                state.stopped = true;
                if (running === state) running = undefined;
                let unload;
                try { unload = Promise.resolve(state.legacy?.onUnload?.()); }
                catch (error) { unload = Promise.reject(error); }
                // Remove hooks and cancel timers/requests before waiting for a
                // legacy async unload. Next invokes registered cleanups again.
                state.stopping = Promise.all([unload, bridge.dispose()]).then(() => undefined);
                return state.stopping;
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; return running?.stop(); },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createNextPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}

return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
/*!
omggif 1.0.10
omggif is a JavaScript implementation of a GIF 89a encoder and decoder.

https://github.com/deanm/omggif


(c) Dean McNamee <dean@gmail.com>, 2013.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.


gifenc 1.0.3
The MIT License (MIT)
Copyright (c) 2017 Matt DesLauriers

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.



base64-js 1.5.1
The MIT License (MIT)

Copyright (c) 2014 Jameson Little

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


fast-png 8.0.0
MIT License

Copyright (c) 2015 Michaël Zasso

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


iobuffer 6.0.1
The MIT License (MIT)

Copyright (c) 2015 Michaël Zasso

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


jpeg-js 0.4.4
Copyright (c) 2014, Eugene Ware
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Eugene Ware nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY EUGENE WARE ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL EUGENE WARE BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


fflate 0.8.3
MIT License

Copyright (c) 2026 Arjun Barrett

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/
const module = { exports: {} };
var Zn=Object.create;var At=Object.defineProperty;var Qn=Object.getOwnPropertyDescriptor;var Jn=Object.getOwnPropertyNames;var ei=Object.getPrototypeOf,ti=Object.prototype.hasOwnProperty;var ri=(e,t,r)=>t in e?At(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;var ut=(e,t)=>()=>{try{return t||e((t={exports:{}}).exports,t),t.exports;}catch(r){throw t=0,r;}},ni=(e,t)=>{for(var r in t)At(e,r,{get:t[r],enumerable:!0});},Ur=(e,t,r,i)=>{if(t&&typeof t=="object"||typeof t=="function"){var _loop=function(n){!ti.call(e,n)&&n!==r&&At(e,n,{get:()=>t[n],enumerable:!(i=Qn(t,n))||i.enumerable});};for(var n of Jn(t)){_loop(n);}}return e;};var bt=(e,t,r)=>(r=e!=null?Zn(ei(e)):{},Ur(t||!e||!e.__esModule?At(r,"default",{value:e,enumerable:!0}):r,e)),ii=e=>Ur(At({},"__esModule",{value:!0}),e);var ye=(e,t,r)=>ri(e,typeof t!="symbol"?t+"":t,r);var Br=ut(Qt=>{"use strict";function oi(e,t,r,o){var n=0,o=o===void 0?{}:o,s=o.loop===void 0?null:o.loop,a=o.palette===void 0?null:o.palette;if(t<=0||r<=0||t>65535||r>65535)throw new Error("Width/Height invalid.");function c(_){var y=_.length;if(y<2||y>256||y&y-1)throw new Error("Invalid code/color length, must be power of 2 and 2 .. 256.");return y;}e[n++]=71,e[n++]=73,e[n++]=70,e[n++]=56,e[n++]=57,e[n++]=97;var h=0,l=0;if(a!==null){for(var f=c(a);f>>=1;)++h;if(f=1<<h,--h,o.background!==void 0){if(l=o.background,l>=f)throw new Error("Background index out of range.");if(l===0)throw new Error("Background index explicitly passed as 0.");}}if(e[n++]=t&255,e[n++]=t>>8&255,e[n++]=r&255,e[n++]=r>>8&255,e[n++]=(a!==null?128:0)|h,e[n++]=l,e[n++]=0,a!==null)for(var g=0,b=a.length;g<b;++g){var T=a[g];e[n++]=T>>16&255,e[n++]=T>>8&255,e[n++]=T&255;}if(s!==null){if(s<0||s>65535)throw new Error("Loop count invalid.");e[n++]=33,e[n++]=255,e[n++]=11,e[n++]=78,e[n++]=69,e[n++]=84,e[n++]=83,e[n++]=67,e[n++]=65,e[n++]=80,e[n++]=69,e[n++]=50,e[n++]=46,e[n++]=48,e[n++]=3,e[n++]=1,e[n++]=s&255,e[n++]=s>>8&255,e[n++]=0;}var x=!1;this.addFrame=function(_,y,m,u,v,p){if(x===!0&&(--n,x=!1),p=p===void 0?{}:p,_<0||y<0||_>65535||y>65535)throw new Error("x/y invalid.");if(m<=0||u<=0||m>65535||u>65535)throw new Error("Width/Height invalid.");if(v.length<m*u)throw new Error("Not enough pixels for the frame size.");var R=!0,w=p.palette;if(w==null&&(R=!1,w=a),w==null)throw new Error("Must supply either a local or global palette.");for(var M=c(w),E=0;M>>=1;)++E;M=1<<E;var N=p.delay===void 0?0:p.delay,P=p.disposal===void 0?0:p.disposal;if(P<0||P>3)throw new Error("Disposal out of range.");var L=!1,Y=0;if(p.transparent!==void 0&&p.transparent!==null&&(L=!0,Y=p.transparent,Y<0||Y>=M))throw new Error("Transparent color index.");if((P!==0||L||N!==0)&&(e[n++]=33,e[n++]=249,e[n++]=4,e[n++]=P<<2|(L===!0?1:0),e[n++]=N&255,e[n++]=N>>8&255,e[n++]=Y,e[n++]=0),e[n++]=44,e[n++]=_&255,e[n++]=_>>8&255,e[n++]=y&255,e[n++]=y>>8&255,e[n++]=m&255,e[n++]=m>>8&255,e[n++]=u&255,e[n++]=u>>8&255,e[n++]=R===!0?128|E-1:0,R===!0)for(var oe=0,W=w.length;oe<W;++oe){var X=w[oe];e[n++]=X>>16&255,e[n++]=X>>8&255,e[n++]=X&255;}return n=si(e,n,E<2?2:E,v),n;},this.end=function(){return x===!1&&(e[n++]=59,x=!0),n;},this.getOutputBuffer=function(){return e;},this.setOutputBuffer=function(_){e=_;},this.getOutputBufferPosition=function(){return n;},this.setOutputBufferPosition=function(_){n=_;};}function si(e,t,r,i){e[t++]=r;var n=t++,o=1<<r,s=o-1,a=o+1,c=a+1,h=r+1,l=0,f=0;function g(p){for(;l>=p;)e[t++]=f&255,f>>=8,l-=8,t===n+256&&(e[n]=255,n=t++);}function b(p){f|=p<<l,l+=h,g(8);}var T=i[0]&s,x={};b(o);for(var _=1,y=i.length;_<y;++_){var m=i[_]&s,u=T<<8|m,v=x[u];if(v===void 0){for(f|=T<<l,l+=h;l>=8;)e[t++]=f&255,f>>=8,l-=8,t===n+256&&(e[n]=255,n=t++);c===4096?(b(o),c=a+1,h=r+1,x={}):(c>=1<<h&&++h,x[u]=c++),T=m;}else T=v;}return b(T),b(a),g(1),n+1===t?e[n]=0:(e[n]=t-n-1,e[t++]=0),t;}function ai(e){var t=0;if(e[t++]!==71||e[t++]!==73||e[t++]!==70||e[t++]!==56||(e[t++]+1&253)!==56||e[t++]!==97)throw new Error("Invalid GIF 87a/89a header.");var r=e[t++]|e[t++]<<8,i=e[t++]|e[t++]<<8,n=e[t++],o=n>>7,s=n&7,a=1<<s+1,c=e[t++];e[t++];var h=null,l=null;o&&(h=t,l=a,t+=a*3);var f=!0,g=[],b=0,T=null,x=0,_=null;for(this.width=r,this.height=i;f&&t<e.length;)switch(e[t++]){case 33:switch(e[t++]){case 255:if(e[t]!==11||e[t+1]==78&&e[t+2]==69&&e[t+3]==84&&e[t+4]==83&&e[t+5]==67&&e[t+6]==65&&e[t+7]==80&&e[t+8]==69&&e[t+9]==50&&e[t+10]==46&&e[t+11]==48&&e[t+12]==3&&e[t+13]==1&&e[t+16]==0)t+=14,_=e[t++]|e[t++]<<8,t++;else for(t+=12;;){var y=e[t++];if(!(y>=0))throw Error("Invalid block size");if(y===0)break;t+=y;}break;case 249:if(e[t++]!==4||e[t+4]!==0)throw new Error("Invalid graphics extension block.");var m=e[t++];b=e[t++]|e[t++]<<8,T=e[t++],(m&1)===0&&(T=null),x=m>>2&7,t++;break;case 254:for(;;){var y=e[t++];if(!(y>=0))throw Error("Invalid block size");if(y===0)break;t+=y;}break;default:throw new Error("Unknown graphic control label: 0x"+e[t-1].toString(16));}break;case 44:var u=e[t++]|e[t++]<<8,v=e[t++]|e[t++]<<8,p=e[t++]|e[t++]<<8,R=e[t++]|e[t++]<<8,w=e[t++],M=w>>7,E=w>>6&1,N=w&7,P=1<<N+1,L=h,Y=l,oe=!1;if(M){var oe=!0;L=t,Y=P,t+=P*3;}var W=t;for(t++;;){var y=e[t++];if(!(y>=0))throw Error("Invalid block size");if(y===0)break;t+=y;}g.push({x:u,y:v,width:p,height:R,has_local_palette:oe,palette_offset:L,palette_size:Y,data_offset:W,data_length:t-W,transparent_index:T,interlaced:!!E,delay:b,disposal:x});break;case 59:f=!1;break;default:throw new Error("Unknown gif block: 0x"+e[t-1].toString(16));}this.numFrames=function(){return g.length;},this.loopCount=function(){return _;},this.frameInfo=function(X){if(X<0||X>=g.length)throw new Error("Frame index out of range.");return g[X];},this.decodeAndBlitFrameBGRA=function(X,K){var V=this.frameInfo(X),j=V.width*V.height,xe=new Uint8Array(j);Ir(e,V.data_offset,xe,j);var ne=V.palette_offset,re=V.transparent_index;re===null&&(re=256);var Z=V.width,A=r-Z,z=Z,ce=(V.y*r+V.x)*4,ve=((V.y+V.height)*r+V.x)*4,Q=ce,le=A*4;V.interlaced===!0&&(le+=r*4*7);for(var ae=8,G=0,O=xe.length;G<O;++G){var ue=xe[G];if(z===0&&(Q+=le,z=Z,Q>=ve&&(le=A*4+r*4*(ae-1),Q=ce+(Z+A)*(ae<<1),ae>>=1)),ue===re)Q+=4;else{var se=e[ne+ue*3],de=e[ne+ue*3+1],Fe=e[ne+ue*3+2];K[Q++]=Fe,K[Q++]=de,K[Q++]=se,K[Q++]=255;}--z;}},this.decodeAndBlitFrameRGBA=function(X,K){var V=this.frameInfo(X),j=V.width*V.height,xe=new Uint8Array(j);Ir(e,V.data_offset,xe,j);var ne=V.palette_offset,re=V.transparent_index;re===null&&(re=256);var Z=V.width,A=r-Z,z=Z,ce=(V.y*r+V.x)*4,ve=((V.y+V.height)*r+V.x)*4,Q=ce,le=A*4;V.interlaced===!0&&(le+=r*4*7);for(var ae=8,G=0,O=xe.length;G<O;++G){var ue=xe[G];if(z===0&&(Q+=le,z=Z,Q>=ve&&(le=A*4+r*4*(ae-1),Q=ce+(Z+A)*(ae<<1),ae>>=1)),ue===re)Q+=4;else{var se=e[ne+ue*3],de=e[ne+ue*3+1],Fe=e[ne+ue*3+2];K[Q++]=se,K[Q++]=de,K[Q++]=Fe,K[Q++]=255;}--z;}};}function Ir(e,t,r,i){for(var n=e[t++],o=1<<n,s=o+1,a=s+1,c=n+1,h=(1<<c)-1,l=0,f=0,g=0,b=e[t++],T=new Int32Array(4096),x=null;;){for(;l<16&&b!==0;)f|=e[t++]<<l,l+=8,b===1?b=e[t++]:--b;if(l<c)break;var _=f&h;if(f>>=c,l-=c,_===o){a=s+1,c=n+1,h=(1<<c)-1,x=null;continue;}else if(_===s)break;for(var y=_<a?_:x,m=0,u=y;u>o;)u=T[u]>>8,++m;var v=u,p=g+m+(y!==_?1:0);if(p>i){console.log("Warning, gif stream longer than expected.");return;}r[g++]=v,g+=m;var R=g;for(y!==_&&(r[g++]=v),u=y;m--;)u=T[u],r[--R]=u&255,u>>=8;x!==null&&a<4096&&(T[a++]=x<<8|v,a>=h+1&&c<12&&(++c,h=h<<1|1)),x=_;}return g!==i&&console.log("Warning, gif stream shorter than expected."),r;}try{Qt.GifWriter=oi,Qt.GifReader=ai;}catch{}});var Yr=ut(rr=>{var Or=Object.defineProperty,li=e=>Or(e,"__esModule",{value:!0}),ci=(e,t)=>{for(var r in t)Or(e,r,{get:t[r],enumerable:!0});};li(rr);ci(rr,{GIFEncoder:()=>Wr,applyPalette:()=>yi,default:()=>Ti,nearestColor:()=>bi,nearestColorIndex:()=>Gr,nearestColorIndexWithDistance:()=>Hr,prequantize:()=>xi,quantize:()=>vi,snapColorsToPalette:()=>Ai});var fi={signature:"GIF",version:"89a",trailer:59,extensionIntroducer:33,applicationExtensionLabel:255,graphicControlExtensionLabel:249,imageSeparator:44,signatureSize:3,versionSize:3,globalColorTableFlagMask:128,colorResolutionMask:112,sortFlagMask:8,globalColorTableSizeMask:7,applicationIdentifierSize:8,applicationAuthCodeSize:3,disposalMethodMask:28,userInputFlagMask:2,transparentColorFlagMask:1,localColorTableFlagMask:128,interlaceFlagMask:64,idSortFlagMask:32,localColorTableSizeMask:7};function Pr(e=256){var t=0,r=new Uint8Array(e);return{get buffer(){return r.buffer;},reset(){t=0;},bytesView(){return r.subarray(0,t);},bytes(){return r.slice(0,t);},writeByte(n){i(t+1),r[t]=n,t++;},writeBytes(n,o=0,s=n.length){i(t+s);for(var a=0;a<s;a++)r[t++]=n[a+o];},writeBytesView(n,o=0,s=n.byteLength){i(t+s),r.set(n.subarray(o,o+s),t),t+=s;}};function i(n){var o=r.length;if(o>=n)return;var s=1024*1024;n=Math.max(n,o*(o<s?2:1.125)>>>0),o!=0&&(n=Math.max(n,256));var a=r;r=new Uint8Array(n),t>0&&r.set(a.subarray(0,t),0);}}var Jt=12,Mr=5003,hi=[0,1,3,7,15,31,63,127,255,511,1023,2047,4095,8191,16383,32767,65535];function ui(e,t,r,i,n=Pr(512),o=new Uint8Array(256),s=new Int32Array(Mr),a=new Int32Array(Mr)){var c=s.length,h=Math.max(2,i);o.fill(0),a.fill(0),s.fill(-1);var l=0,f=0,g=h+1,b=g,T=!1,x=b,_=(1<<x)-1,y=1<<g-1,m=y+1,u=y+2,v=0,p=r[0],R=0;for(var E=c;E<65536;E*=2)++R;R=8-R,n.writeByte(h),M(y);var w=r.length;for(var _E=1;_E<w;_E++)e:{var N=r[_E],P=(N<<Jt)+p,L=N<<R^p;if(s[L]===P){p=a[L];break e;}var Y=L===0?1:c-L;for(;s[L]>=0;)if(L-=Y,L<0&&(L+=c),s[L]===P){p=a[L];break e;}M(p),p=N,u<1<<Jt?(a[L]=u++,s[L]=P):(s.fill(-1),u=y+2,T=!0,M(y));}return M(p),M(m),n.writeByte(0),n.bytesView();function M(E){for(l&=hi[f],f>0?l|=E<<f:l=E,f+=x;f>=8;)o[v++]=l&255,v>=254&&(n.writeByte(v),n.writeBytesView(o,0,v),v=0),l>>=8,f-=8;if((u>_||T)&&(T?(x=b,_=(1<<x)-1,T=!1):(++x,_=x===Jt?1<<x:(1<<x)-1)),E==m){for(;f>0;)o[v++]=l&255,v>=254&&(n.writeByte(v),n.writeBytesView(o,0,v),v=0),l>>=8,f-=8;v>0&&(n.writeByte(v),n.writeBytesView(o,0,v),v=0);}}}var di=ui;function Nr(e,t,r){return e<<8&63488|t<<2&992|r>>3;}function Lr(e,t,r,i){return e>>4|t&240|(r&240)<<4|(i&240)<<8;}function zr(e,t,r){return e>>4<<8|t&240|r>>4;}function Ot(e,t,r){return e<t?t:e>r?r:e;}function Et(e){return e*e;}function Rr(e,t,r){var i=0,n=1e100;var o=e[t],s=o.cnt,a=o.ac,c=o.rc,h=o.gc,l=o.bc;for(var f=o.fw;f!=0;f=e[f].fw){var b=e[f],T=b.cnt,x=s*T/(s+T);if(!(x>=n)){var g=0;r&&(g+=x*Et(b.ac-a),g>=n)||(g+=x*Et(b.rc-c),!(g>=n)&&(g+=x*Et(b.gc-h),!(g>=n)&&(g+=x*Et(b.bc-l),!(g>=n)&&(n=g,i=f))));}}o.err=n,o.nn=i;}function er(){return{ac:0,rc:0,gc:0,bc:0,cnt:0,nn:0,fw:0,bk:0,tm:0,mtm:0,err:0};}function pi(e,t){var r=t==="rgb444"?4096:65536,i=new Array(r),n=e.length;if(t==="rgba4444")for(var o=0;o<n;++o){var s=e[o],a=s>>24&255,c=s>>16&255,h=s>>8&255,l=s&255,f=Lr(l,h,c,a),g=f in i?i[f]:i[f]=er();g.rc+=l,g.gc+=h,g.bc+=c,g.ac+=a,g.cnt++;}else if(t==="rgb444")for(var _o2=0;_o2<n;++_o2){var _s=e[_o2],_a=_s>>16&255,_c=_s>>8&255,_h=_s&255,_l=zr(_h,_c,_a),_f=_l in i?i[_l]:i[_l]=er();_f.rc+=_h,_f.gc+=_c,_f.bc+=_a,_f.cnt++;}else for(var _o3=0;_o3<n;++_o3){var _s2=e[_o3],_a2=_s2>>16&255,_c2=_s2>>8&255,_h2=_s2&255,_l2=Nr(_h2,_c2,_a2),_f2=_l2 in i?i[_l2]:i[_l2]=er();_f2.rc+=_h2,_f2.gc+=_c2,_f2.bc+=_a2,_f2.cnt++;}return i;}function vi(e,t,r={}){var{format:i="rgb565",clearAlpha:n=!0,clearAlphaColor:o=0,clearAlphaThreshold:s=0,oneBitAlpha:a=!1}=r;if(!e||!e.buffer)throw new Error("quantize() expected RGBA Uint8Array data");if(!(e instanceof Uint8Array)&&!(e instanceof Uint8ClampedArray))throw new Error("quantize() expected RGBA Uint8Array data");var c=new Uint32Array(e.buffer),h=r.useSqrt!==!1,l=i==="rgba4444",f=pi(c,i),g=f.length,b=g-1,T=new Uint32Array(g+1);for(var x=0,y=0;y<g;++y){var W=f[y];if(W!=null){var _=1/W.cnt;l&&(W.ac*=_),W.rc*=_,W.gc*=_,W.bc*=_,f[x++]=W;}}Et(t)/x<.022&&(h=!1);for(var y=0;y<x-1;++y)f[y].fw=y+1,f[y+1].bk=y,h&&(f[y].cnt=Math.sqrt(f[y].cnt));h&&(f[y].cnt=Math.sqrt(f[y].cnt));var m,u,v;for(y=0;y<x;++y){Rr(f,y,!1);var p=f[y].err;for(u=++T[0];u>1&&(v=u>>1,!(f[m=T[v]].err<=p));u=v)T[u]=m;T[u]=y;}var R=x-t;for(y=0;y<R;){for(var w;;){var M=T[1];if(w=f[M],w.tm>=w.mtm&&f[w.nn].mtm<=w.tm)break;w.mtm==b?M=T[1]=T[T[0]--]:(Rr(f,M,!1),w.tm=y);var p=f[M].err;for(u=1;(v=u+u)<=T[0]&&(v<T[0]&&f[T[v]].err>f[T[v+1]].err&&v++,!(p<=f[m=T[v]].err));u=v)T[u]=m;T[u]=M;}var E=f[w.nn],N=w.cnt,P=E.cnt,_=1/(N+P);l&&(w.ac=_*(N*w.ac+P*E.ac)),w.rc=_*(N*w.rc+P*E.rc),w.gc=_*(N*w.gc+P*E.gc),w.bc=_*(N*w.bc+P*E.bc),w.cnt+=E.cnt,w.mtm=++y,f[E.bk].fw=E.fw,f[E.fw].bk=E.bk,E.mtm=b;}var L=[];var Y=0;for(y=0;;++Y){var oe=Ot(Math.round(f[y].rc),0,255),_W=Ot(Math.round(f[y].gc),0,255),X=Ot(Math.round(f[y].bc),0,255),K=255;l&&(K=Ot(Math.round(f[y].ac),0,255),a&&(K=K<=(typeof a=="number"?a:127)?0:255),n&&K<=s&&(oe=_W=X=o,K=0));var V=l?[oe,_W,X,K]:[oe,_W,X];if(gi(L,V)||L.push(V),(y=f[y].fw)==0)break;}return L;}function gi(e,t){for(var r=0;r<e.length;r++){var i=e[r],n=i[0]===t[0]&&i[1]===t[1]&&i[2]===t[2],o=i.length>=4&&t.length>=4?i[3]===t[3]:!0;if(n&&o)return!0;}return!1;}function Nt(e,t){var r=0,i;for(i=0;i<e.length;i++){var n=e[i]-t[i];r+=n*n;}return r;}function Pt(e,t){return t>1?Math.round(e/t)*t:e;}function xi(e,{roundRGB:t=5,roundAlpha:r=10,oneBitAlpha:i=null}={}){var n=new Uint32Array(e.buffer);for(var o=0;o<n.length;o++){var s=n[o],a=s>>24&255,c=s>>16&255,h=s>>8&255,l=s&255;a=Pt(a,r),i&&(a=a<=(typeof i=="number"?i:127)?0:255),l=Pt(l,t),h=Pt(h,t),c=Pt(c,t),n[o]=a<<24|c<<16|h<<8|l<<0;}}function yi(e,t,r="rgb565"){if(!e||!e.buffer)throw new Error("quantize() expected RGBA Uint8Array data");if(!(e instanceof Uint8Array)&&!(e instanceof Uint8ClampedArray))throw new Error("quantize() expected RGBA Uint8Array data");if(t.length>256)throw new Error("applyPalette() only works with 256 colors or less");var i=new Uint32Array(e.buffer),n=i.length,o=r==="rgb444"?4096:65536,s=new Uint8Array(n),a=new Array(o),c=r==="rgba4444";if(r==="rgba4444")for(var h=0;h<n;h++){var l=i[h],f=l>>24&255,g=l>>16&255,b=l>>8&255,T=l&255,x=Lr(T,b,g,f),_=x in a?a[x]:a[x]=wi(T,b,g,f,t);s[h]=_;}else{var _h3=r==="rgb444"?zr:Nr;for(var _l3=0;_l3<n;_l3++){var _f3=i[_l3],_g=_f3>>16&255,_b=_f3>>8&255,_T=_f3&255,_x=_h3(_T,_b,_g),_2=_x in a?a[_x]:a[_x]=mi(_T,_b,_g,t);s[_l3]=_2;}}return s;}function wi(e,t,r,i,n){var o=0,s=1e100;for(var a=0;a<n.length;a++){var c=n[a],h=c[3],l=it(h-i);if(l>s)continue;var f=c[0];if(l+=it(f-e),l>s)continue;var g=c[1];if(l+=it(g-t),l>s)continue;var b=c[2];l+=it(b-r),!(l>s)&&(s=l,o=a);}return o;}function mi(e,t,r,i){var n=0,o=1e100;for(var s=0;s<i.length;s++){var a=i[s],c=a[0],h=it(c-e);if(h>o)continue;var l=a[1];if(h+=it(l-t),h>o)continue;var f=a[2];h+=it(f-r),!(h>o)&&(o=h,n=s);}return n;}function Ai(e,t,r=5){if(!e.length||!t.length)return;var i=e.map(s=>s.slice(0,3)),n=r*r,o=e[0].length;for(var s=0;s<t.length;s++){var a=t[s];a.length<o?a=[a[0],a[1],a[2],255]:a.length>o?a=a.slice(0,3):a=a.slice();var c=Hr(i,a.slice(0,3),Nt),h=c[0],l=c[1];l>0&&l<=n&&(e[h]=a);}}function it(e){return e*e;}function Gr(e,t,r=Nt){var i=1/0,n=-1;for(var o=0;o<e.length;o++){var s=e[o],a=r(t,s);a<i&&(i=a,n=o);}return n;}function Hr(e,t,r=Nt){var i=1/0,n=-1;for(var o=0;o<e.length;o++){var s=e[o],a=r(t,s);a<i&&(i=a,n=o);}return[n,i];}function bi(e,t,r=Nt){return e[Gr(e,t,r)];}function Wr(e={}){var{initialCapacity:t=4096,auto:r=!0}=e,i=Pr(t),n=5003,o=new Uint8Array(256),s=new Int32Array(n),a=new Int32Array(n),c=!1;return{reset(){i.reset(),c=!1;},finish(){i.writeByte(fi.trailer);},bytes(){return i.bytes();},bytesView(){return i.bytesView();},get buffer(){return i.buffer;},get stream(){return i;},writeHeader:h,writeFrame(l,f,g,b={}){var{transparent:T=!1,transparentIndex:x=0,delay:_=0,palette:y=null,repeat:m=0,colorDepth:u=8,dispose:v=-1}=b,p=!1;if(r?c||(p=!0,h(),c=!0):p=!!b.first,f=Math.max(0,Math.floor(f)),g=Math.max(0,Math.floor(g)),p){if(!y)throw new Error("First frame must include a { palette } option");_i(i,f,g,y,u),Dr(i,y),m>=0&&Si(i,m);}var R=Math.round(_/10);Ei(i,v,R,T,x);var w=!!y&&!p;Ci(i,f,g,w?y:null),w&&Dr(i,y),ki(i,l,f,g,u,o,s,a);}};function h(){$r(i,"GIF89a");}}function Ei(e,t,r,i,n){e.writeByte(33),e.writeByte(249),e.writeByte(4),n<0&&(n=0,i=!1);var o,s;i?(o=1,s=2):(o=0,s=0),t>=0&&(s=t&7),s<<=2,e.writeByte(0|s|0|o),Je(e,r),e.writeByte(n||0),e.writeByte(0);}function _i(e,t,r,i,n=8){var a=tr(i.length)-1,c=128|n-1<<4|0|a,h=0,l=0;Je(e,t),Je(e,r),e.writeBytes([c,h,l]);}function Si(e,t){e.writeByte(33),e.writeByte(255),e.writeByte(11),$r(e,"NETSCAPE2.0"),e.writeByte(3),e.writeByte(1),Je(e,t),e.writeByte(0);}function Dr(e,t){var r=1<<tr(t.length);for(var i=0;i<r;i++){var n=[0,0,0];i<t.length&&(n=t[i]),e.writeByte(n[0]),e.writeByte(n[1]),e.writeByte(n[2]);}}function Ci(e,t,r,i){if(e.writeByte(44),Je(e,0),Je(e,0),Je(e,t),Je(e,r),i){var s=tr(i.length)-1;e.writeByte(128|s);}else e.writeByte(0);}function ki(e,t,r,i,n=8,o,s,a){di(r,i,t,n,e,o,s,a);}function Je(e,t){e.writeByte(t&255),e.writeByte(t>>8&255);}function $r(e,t){for(var r=0;r<t.length;r++)e.writeByte(t.charCodeAt(r));}function tr(e){return Math.max(Math.ceil(Math.log2(e)),1);}var Ti=Wr;});var ir=ut(Lt=>{"use strict";Lt.byteLength=Ui;Lt.toByteArray=Bi;Lt.fromByteArray=Di;var We=[],Ne=[],Fi=typeof Uint8Array<"u"?Uint8Array:Array,nr="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";for(ot=0,Vr=nr.length;ot<Vr;++ot)We[ot]=nr[ot],Ne[nr.charCodeAt(ot)]=ot;var ot,Vr;Ne[45]=62;Ne[95]=63;function Xr(e){var t=e.length;if(t%4>0)throw new Error("Invalid string. Length must be a multiple of 4");var r=e.indexOf("=");r===-1&&(r=t);var i=r===t?0:4-r%4;return[r,i];}function Ui(e){var t=Xr(e),r=t[0],i=t[1];return(r+i)*3/4-i;}function Ii(e,t,r){return(t+r)*3/4-r;}function Bi(e){var t,r=Xr(e),i=r[0],n=r[1],o=new Fi(Ii(e,i,n)),s=0,a=n>0?i-4:i,c;for(c=0;c<a;c+=4)t=Ne[e.charCodeAt(c)]<<18|Ne[e.charCodeAt(c+1)]<<12|Ne[e.charCodeAt(c+2)]<<6|Ne[e.charCodeAt(c+3)],o[s++]=t>>16&255,o[s++]=t>>8&255,o[s++]=t&255;return n===2&&(t=Ne[e.charCodeAt(c)]<<2|Ne[e.charCodeAt(c+1)]>>4,o[s++]=t&255),n===1&&(t=Ne[e.charCodeAt(c)]<<10|Ne[e.charCodeAt(c+1)]<<4|Ne[e.charCodeAt(c+2)]>>2,o[s++]=t>>8&255,o[s++]=t&255),o;}function Mi(e){return We[e>>18&63]+We[e>>12&63]+We[e>>6&63]+We[e&63];}function Ri(e,t,r){for(var i,n=[],o=t;o<r;o+=3)i=(e[o]<<16&16711680)+(e[o+1]<<8&65280)+(e[o+2]&255),n.push(Mi(i));return n.join("");}function Di(e){for(var t,r=e.length,i=r%3,n=[],o=16383,s=0,a=r-i;s<a;s+=o)n.push(Ri(e,s,s+o>a?a:s+o));return i===1?(t=e[r-1],n.push(We[t>>2]+We[t<<4&63]+"==")):i===2&&(t=(e[r-2]<<8)+e[r-1],n.push(We[t>>10]+We[t>>4&63]+We[t<<2&63]+"=")),n.join("");}});var Wn=ut((Ds,Kt)=>{var Hn=Hn||function(e){return Buffer.from(e).toString("base64");};function _o(e){var t=this,r=Math.round,i=Math.floor,n=new Array(64),o=new Array(64),s=new Array(64),a=new Array(64),c,h,l,f,g=new Array(65535),b=new Array(65535),T=new Array(64),x=new Array(64),_=[],y=0,m=7,u=new Array(64),v=new Array(64),p=new Array(64),R=new Array(256),w=new Array(2048),M,E=[0,1,5,6,14,15,27,28,2,4,7,13,16,26,29,42,3,8,12,17,25,30,41,43,9,11,18,24,31,40,44,53,10,19,23,32,39,45,52,54,20,22,33,38,46,51,55,60,21,34,37,47,50,56,59,61,35,36,48,49,57,58,62,63],N=[0,0,1,5,1,1,1,1,1,1,0,0,0,0,0,0,0],P=[0,1,2,3,4,5,6,7,8,9,10,11],L=[0,0,2,1,3,3,2,4,3,5,5,4,4,0,0,1,125],Y=[1,2,3,0,4,17,5,18,33,49,65,6,19,81,97,7,34,113,20,50,129,145,161,8,35,66,177,193,21,82,209,240,36,51,98,114,130,9,10,22,23,24,25,26,37,38,39,40,41,42,52,53,54,55,56,57,58,67,68,69,70,71,72,73,74,83,84,85,86,87,88,89,90,99,100,101,102,103,104,105,106,115,116,117,118,119,120,121,122,131,132,133,134,135,136,137,138,146,147,148,149,150,151,152,153,154,162,163,164,165,166,167,168,169,170,178,179,180,181,182,183,184,185,186,194,195,196,197,198,199,200,201,202,210,211,212,213,214,215,216,217,218,225,226,227,228,229,230,231,232,233,234,241,242,243,244,245,246,247,248,249,250],oe=[0,0,3,1,1,1,1,1,1,1,1,1,0,0,0,0,0],W=[0,1,2,3,4,5,6,7,8,9,10,11],X=[0,0,2,1,2,4,4,3,4,7,5,4,4,0,1,2,119],K=[0,1,2,3,17,4,5,33,49,6,18,65,81,7,97,113,19,34,50,129,8,20,66,145,161,177,193,9,35,51,82,240,21,98,114,209,10,22,36,52,225,37,241,23,24,25,26,38,39,40,41,42,53,54,55,56,57,58,67,68,69,70,71,72,73,74,83,84,85,86,87,88,89,90,99,100,101,102,103,104,105,106,115,116,117,118,119,120,121,122,130,131,132,133,134,135,136,137,138,146,147,148,149,150,151,152,153,154,162,163,164,165,166,167,168,169,170,178,179,180,181,182,183,184,185,186,194,195,196,197,198,199,200,201,202,210,211,212,213,214,215,216,217,218,226,227,228,229,230,231,232,233,234,242,243,244,245,246,247,248,249,250];function V(C){for(var d=[16,11,10,16,24,40,51,61,12,12,14,19,26,58,60,55,14,13,16,24,40,57,69,56,14,17,22,29,51,87,80,62,18,22,37,56,68,109,103,77,24,35,55,64,81,104,113,92,49,64,78,87,103,121,120,101,72,92,95,98,112,100,103,99],B=0;B<64;B++){var F=i((d[B]*C+50)/100);F<1?F=1:F>255&&(F=255),n[E[B]]=F;}for(var U=[17,18,24,47,99,99,99,99,18,21,26,66,99,99,99,99,24,26,56,99,99,99,99,99,47,66,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],S=0;S<64;S++){var D=i((U[S]*C+50)/100);D<1?D=1:D>255&&(D=255),o[E[S]]=D;}for(var $=[1,1.387039845,1.306562965,1.175875602,1,.785694958,.5411961,.275899379],q=0,ie=0;ie<8;ie++)for(var k=0;k<8;k++)s[q]=1/(n[E[q]]*$[ie]*$[k]*8),a[q]=1/(o[E[q]]*$[ie]*$[k]*8),q++;}function j(C,d){for(var B=0,F=0,U=new Array(),S=1;S<=16;S++){for(var D=1;D<=C[S];D++)U[d[F]]=[],U[d[F]][0]=B,U[d[F]][1]=S,F++,B++;B*=2;}return U;}function xe(){c=j(N,P),h=j(oe,W),l=j(L,Y),f=j(X,K);}function ne(){for(var C=1,d=2,B=1;B<=15;B++){for(var F=C;F<d;F++)b[32767+F]=B,g[32767+F]=[],g[32767+F][1]=B,g[32767+F][0]=F;for(var U=-(d-1);U<=-C;U++)b[32767+U]=B,g[32767+U]=[],g[32767+U][1]=B,g[32767+U][0]=d-1+U;C<<=1,d<<=1;}}function re(){for(var C=0;C<256;C++)w[C]=19595*C,w[C+256>>0]=38470*C,w[C+512>>0]=7471*C+32768,w[C+768>>0]=-11059*C,w[C+1024>>0]=-21709*C,w[C+1280>>0]=32768*C+8421375,w[C+1536>>0]=-27439*C,w[C+1792>>0]=-5329*C;}function Z(C){for(var d=C[0],B=C[1]-1;B>=0;)d&1<<B&&(y|=1<<m),B--,m--,m<0&&(y==255?(A(255),A(0)):A(y),m=7,y=0);}function A(C){_.push(C);}function z(C){A(C>>8&255),A(C&255);}function ce(C,d){var B,F,U,S,D,$,q,ie,k=0,H,J=8,ge=64;for(H=0;H<J;++H){B=C[k],F=C[k+1],U=C[k+2],S=C[k+3],D=C[k+4],$=C[k+5],q=C[k+6],ie=C[k+7];var I=B+ie,ee=B-ie,fe=F+q,te=F-q,pe=U+$,Ee=U-$,we=S+D,Ae=S-D,Ue=I+we,Oe=I-we,Pe=fe+pe,Ie=fe-pe;C[k]=Ue+Pe,C[k+4]=Ue-Pe;var Te=(Ie+Oe)*.707106781;C[k+2]=Oe+Te,C[k+6]=Oe-Te,Ue=Ae+Ee,Pe=Ee+te,Ie=te+ee;var _e=(Ue-Ie)*.382683433,rt=.5411961*Ue+_e,je=1.306562965*Ie+_e,Ge=Pe*.707106781,nt=ee+Ge,Ze=ee-Ge;C[k+5]=Ze+rt,C[k+3]=Ze-rt,C[k+1]=nt+je,C[k+7]=nt-je,k+=8;}for(k=0,H=0;H<J;++H){B=C[k],F=C[k+8],U=C[k+16],S=C[k+24],D=C[k+32],$=C[k+40],q=C[k+48],ie=C[k+56];var vt=B+ie,lt=B-ie,gt=F+q,xt=F-q,yt=U+$,wt=U-$,ct=S+D,Rt=S-D,he=vt+ct,Se=vt-ct,be=gt+yt,He=gt-yt;C[k]=he+be,C[k+32]=he-be;var Qe=(He+Se)*.707106781;C[k+16]=Se+Qe,C[k+48]=Se-Qe,he=Rt+wt,be=wt+xt,He=xt+lt;var Be=(he-He)*.382683433,mt=.5411961*he+Be,ft=1.306562965*He+Be,ht=be*.707106781,Tr=lt+ht,Fr=lt-ht;C[k+40]=Fr+mt,C[k+24]=Fr-mt,C[k+8]=Tr+ft,C[k+56]=Tr-ft,k++;}var Dt;for(H=0;H<ge;++H)Dt=C[H]*d[H],T[H]=Dt>0?Dt+.5|0:Dt-.5|0;return T;}function ve(){z(65504),z(16),A(74),A(70),A(73),A(70),A(0),A(1),A(1),A(0),z(1),z(1),A(0),A(0);}function Q(C){if(C){z(65505),C[0]===69&&C[1]===120&&C[2]===105&&C[3]===102?z(C.length+2):(z(C.length+5+2),A(69),A(120),A(105),A(102),A(0));for(var d=0;d<C.length;d++)A(C[d]);}}function le(C,d){z(65472),z(17),A(8),z(d),z(C),A(3),A(1),A(17),A(0),A(2),A(17),A(1),A(3),A(17),A(1);}function ae(){z(65499),z(132),A(0);for(var C=0;C<64;C++)A(n[C]);A(1);for(var d=0;d<64;d++)A(o[d]);}function G(){z(65476),z(418),A(0);for(var C=0;C<16;C++)A(N[C+1]);for(var d=0;d<=11;d++)A(P[d]);A(16);for(var B=0;B<16;B++)A(L[B+1]);for(var F=0;F<=161;F++)A(Y[F]);A(1);for(var U=0;U<16;U++)A(oe[U+1]);for(var S=0;S<=11;S++)A(W[S]);A(17);for(var D=0;D<16;D++)A(X[D+1]);for(var $=0;$<=161;$++)A(K[$]);}function O(C){typeof C>"u"||C.constructor!==Array||C.forEach(d=>{if(typeof d=="string"){z(65534);var B=d.length;z(B+2);var F;for(F=0;F<B;F++)A(d.charCodeAt(F));}});}function ue(){z(65498),z(12),A(3),A(1),A(0),A(2),A(17),A(3),A(17),A(0),A(63),A(0);}function se(C,d,B,F,U){for(var S=U[0],D=U[240],$,q=16,ie=63,k=64,H=ce(C,d),J=0;J<k;++J)x[E[J]]=H[J];var ge=x[0]-B;B=x[0],ge==0?Z(F[0]):($=32767+ge,Z(F[b[$]]),Z(g[$]));for(var I=63;I>0&&x[I]==0;I--);if(I==0)return Z(S),B;for(var ee=1,fe;ee<=I;){for(var te=ee;x[ee]==0&&ee<=I;++ee);var pe=ee-te;if(pe>=q){fe=pe>>4;for(var Ee=1;Ee<=fe;++Ee)Z(D);pe=pe&15;}$=32767+x[ee],Z(U[(pe<<4)+b[$]]),Z(g[$]),ee++;}return I!=ie&&Z(S),B;}function de(){for(var C=String.fromCharCode,d=0;d<256;d++)R[d]=C(d);}this.encode=function(C,d){var B=new Date().getTime();d&&Fe(d),_=new Array(),y=0,m=7,z(65496),ve(),O(C.comments),Q(C.exifBuffer),ae(),le(C.width,C.height),G(),ue();var F=0,U=0,S=0;y=0,m=7,this.encode.displayName="_encode_";for(var D=C.data,$=C.width,q=C.height,ie=$*4,k=$*3,H,J=0,ge,I,ee,fe,te,pe,Ee,we;J<q;){for(H=0;H<ie;){for(fe=ie*J+H,te=fe,pe=-1,Ee=0,we=0;we<64;we++)Ee=we>>3,pe=(we&7)*4,te=fe+Ee*ie+pe,J+Ee>=q&&(te-=ie*(J+1+Ee-q)),H+pe>=ie&&(te-=H+pe-ie+4),ge=D[te++],I=D[te++],ee=D[te++],u[we]=(w[ge]+w[I+256>>0]+w[ee+512>>0]>>16)-128,v[we]=(w[ge+768>>0]+w[I+1024>>0]+w[ee+1280>>0]>>16)-128,p[we]=(w[ge+1280>>0]+w[I+1536>>0]+w[ee+1792>>0]>>16)-128;F=se(u,s,F,c,l),U=se(v,a,U,h,f),S=se(p,a,S,h,f),H+=32;}J+=8;}if(m>=0){var Ae=[];Ae[1]=m+1,Ae[0]=(1<<m+1)-1,Z(Ae);}if(z(65497),typeof Kt>"u")return new Uint8Array(_);return Buffer.from(_);var Ue,Oe;};function Fe(C){if(C<=0&&(C=1),C>100&&(C=100),M!=C){var d=0;C<50?d=Math.floor(5e3/C):d=Math.floor(200-C*2),V(d),M=C;}}function Re(){var C=new Date().getTime();e||(e=50),de(),xe(),ne(),re(),Fe(e);var d=new Date().getTime()-C;}Re();}typeof Kt<"u"?Kt.exports=Gn:typeof window<"u"&&(window["jpeg-js"]=window["jpeg-js"]||{},window["jpeg-js"].encode=Gn);function Gn(e,t){typeof t>"u"&&(t=50);var r=new _o(t),i=r.encode(e,t);return{data:i,width:e.width,height:e.height};}});var Yn=ut((Os,Sr)=>{var _r=function(){"use strict";var t=new Int32Array([0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63]),r=4017,i=799,n=3406,o=2276,s=1567,a=3784,c=5793,h=2896;function l(){}function f(m,u){for(var v=0,p=[],R,w,M=16;M>0&&!m[M-1];)M--;p.push({children:[],index:0});var E=p[0],N;for(R=0;R<M;R++){for(w=0;w<m[R];w++){for(E=p.pop(),E.children[E.index]=u[v];E.index>0;){if(p.length===0)throw new Error("Could not recreate Huffman Table");E=p.pop();}for(E.index++,p.push(E);p.length<=R;)p.push(N={children:[],index:0}),E.children[E.index]=N.children,E=N;v++;}R+1<M&&(p.push(N={children:[],index:0}),E.children[E.index]=N.children,E=N);}return p[0].children;}function g(m,u,v,p,R,w,M,E,N,P){var L=v.precision,Y=v.samplesPerLine,oe=v.scanLines,W=v.mcusPerLine,X=v.progressive,K=v.maxH,V=v.maxV,j=u,xe=0,ne=0;function re(){if(ne>0)return ne--,xe>>ne&1;if(xe=m[u++],xe==255){var k=m[u++];if(k)throw new Error("unexpected marker: "+(xe<<8|k).toString(16));}return ne=7,xe>>>7;}function Z(k){for(var H=k,J;(J=re())!==null;){if(H=H[J],typeof H=="number")return H;if(typeof H!="object")throw new Error("invalid huffman sequence");}return null;}function A(k){for(var H=0;k>0;){var J=re();if(J===null)return;H=H<<1|J,k--;}return H;}function z(k){var H=A(k);return H>=1<<k-1?H:H+(-1<<k)+1;}function ce(k,H){var J=Z(k.huffmanTableDC),ge=J===0?0:z(J);H[0]=k.pred+=ge;for(var I=1;I<64;){var ee=Z(k.huffmanTableAC),fe=ee&15,te=ee>>4;if(fe===0){if(te<15)break;I+=16;continue;}I+=te;var pe=t[I];H[pe]=z(fe),I++;}}function ve(k,H){var J=Z(k.huffmanTableDC),ge=J===0?0:z(J)<<N;H[0]=k.pred+=ge;}function Q(k,H){H[0]|=re()<<N;}var le=0;function ae(k,H){if(le>0){le--;return;}for(var J=w,ge=M;J<=ge;){var I=Z(k.huffmanTableAC),ee=I&15,fe=I>>4;if(ee===0){if(fe<15){le=A(fe)+(1<<fe)-1;break;}J+=16;continue;}J+=fe;var te=t[J];H[te]=z(ee)*(1<<N),J++;}}var G=0,O;function ue(k,H){for(var J=w,ge=M,I=0;J<=ge;){var ee=t[J],fe=H[ee]<0?-1:1;switch(G){case 0:var te=Z(k.huffmanTableAC),pe=te&15,I=te>>4;if(pe===0)I<15?(le=A(I)+(1<<I),G=4):(I=16,G=1);else{if(pe!==1)throw new Error("invalid ACn encoding");O=z(pe),G=I?2:3;}continue;case 1:case 2:H[ee]?H[ee]+=(re()<<N)*fe:(I--,I===0&&(G=G==2?3:0));break;case 3:H[ee]?H[ee]+=(re()<<N)*fe:(H[ee]=O<<N,G=0);break;case 4:H[ee]&&(H[ee]+=(re()<<N)*fe);break;}J++;}G===4&&(le--,le===0&&(G=0));}function se(k,H,J,ge,I){var ee=J/W|0,fe=J%W,te=ee*k.v+ge,pe=fe*k.h+I;k.blocks[te]===void 0&&P.tolerantDecoding||H(k,k.blocks[te][pe]);}function de(k,H,J){var ge=J/k.blocksPerLine|0,I=J%k.blocksPerLine;k.blocks[ge]===void 0&&P.tolerantDecoding||H(k,k.blocks[ge][I]);}var Fe=p.length,Re,C,d,B,F,U;X?w===0?U=E===0?ve:Q:U=E===0?ae:ue:U=ce;var S=0,D,$;Fe==1?$=p[0].blocksPerLine*p[0].blocksPerColumn:$=W*v.mcusPerColumn,R||(R=$);for(var q,ie;S<$;){for(C=0;C<Fe;C++)p[C].pred=0;if(le=0,Fe==1)for(Re=p[0],F=0;F<R;F++)de(Re,U,S),S++;else for(F=0;F<R;F++){for(C=0;C<Fe;C++)for(Re=p[C],q=Re.h,ie=Re.v,d=0;d<ie;d++)for(B=0;B<q;B++)se(Re,U,S,d,B);if(S++,S===$)break;}if(S===$)do{if(m[u]===255&&m[u+1]!==0)break;u+=1;}while(u<m.length-2);if(ne=0,D=m[u]<<8|m[u+1],D<65280)throw new Error("marker was not found");if(D>=65488&&D<=65495)u+=2;else break;}return u-j;}function b(m,u){var v=[],p=u.blocksPerLine,R=u.blocksPerColumn,w=p<<3,M=new Int32Array(64),E=new Uint8Array(64);function N(j,xe,ne){var re=u.quantizationTable,Z,A,z,ce,ve,Q,le,ae,G,O=ne,ue;for(ue=0;ue<64;ue++)O[ue]=j[ue]*re[ue];for(ue=0;ue<8;++ue){var se=8*ue;if(O[1+se]==0&&O[2+se]==0&&O[3+se]==0&&O[4+se]==0&&O[5+se]==0&&O[6+se]==0&&O[7+se]==0){G=c*O[0+se]+512>>10,O[0+se]=G,O[1+se]=G,O[2+se]=G,O[3+se]=G,O[4+se]=G,O[5+se]=G,O[6+se]=G,O[7+se]=G;continue;}Z=c*O[0+se]+128>>8,A=c*O[4+se]+128>>8,z=O[2+se],ce=O[6+se],ve=h*(O[1+se]-O[7+se])+128>>8,ae=h*(O[1+se]+O[7+se])+128>>8,Q=O[3+se]<<4,le=O[5+se]<<4,G=Z-A+1>>1,Z=Z+A+1>>1,A=G,G=z*a+ce*s+128>>8,z=z*s-ce*a+128>>8,ce=G,G=ve-le+1>>1,ve=ve+le+1>>1,le=G,G=ae+Q+1>>1,Q=ae-Q+1>>1,ae=G,G=Z-ce+1>>1,Z=Z+ce+1>>1,ce=G,G=A-z+1>>1,A=A+z+1>>1,z=G,G=ve*o+ae*n+2048>>12,ve=ve*n-ae*o+2048>>12,ae=G,G=Q*i+le*r+2048>>12,Q=Q*r-le*i+2048>>12,le=G,O[0+se]=Z+ae,O[7+se]=Z-ae,O[1+se]=A+le,O[6+se]=A-le,O[2+se]=z+Q,O[5+se]=z-Q,O[3+se]=ce+ve,O[4+se]=ce-ve;}for(ue=0;ue<8;++ue){var de=ue;if(O[8+de]==0&&O[16+de]==0&&O[24+de]==0&&O[32+de]==0&&O[40+de]==0&&O[48+de]==0&&O[56+de]==0){G=c*ne[ue+0]+8192>>14,O[0+de]=G,O[8+de]=G,O[16+de]=G,O[24+de]=G,O[32+de]=G,O[40+de]=G,O[48+de]=G,O[56+de]=G;continue;}Z=c*O[0+de]+2048>>12,A=c*O[32+de]+2048>>12,z=O[16+de],ce=O[48+de],ve=h*(O[8+de]-O[56+de])+2048>>12,ae=h*(O[8+de]+O[56+de])+2048>>12,Q=O[24+de],le=O[40+de],G=Z-A+1>>1,Z=Z+A+1>>1,A=G,G=z*a+ce*s+2048>>12,z=z*s-ce*a+2048>>12,ce=G,G=ve-le+1>>1,ve=ve+le+1>>1,le=G,G=ae+Q+1>>1,Q=ae-Q+1>>1,ae=G,G=Z-ce+1>>1,Z=Z+ce+1>>1,ce=G,G=A-z+1>>1,A=A+z+1>>1,z=G,G=ve*o+ae*n+2048>>12,ve=ve*n-ae*o+2048>>12,ae=G,G=Q*i+le*r+2048>>12,Q=Q*r-le*i+2048>>12,le=G,O[0+de]=Z+ae,O[56+de]=Z-ae,O[8+de]=A+le,O[48+de]=A-le,O[16+de]=z+Q,O[40+de]=z-Q,O[24+de]=ce+ve,O[32+de]=ce-ve;}for(ue=0;ue<64;++ue){var Fe=128+(O[ue]+8>>4);xe[ue]=Fe<0?0:Fe>255?255:Fe;}}y(w*R*8);for(var P,L,Y=0;Y<R;Y++){var oe=Y<<3;for(P=0;P<8;P++)v.push(new Uint8Array(w));for(var W=0;W<p;W++){N(u.blocks[Y][W],E,M);var X=0,K=W<<3;for(L=0;L<8;L++){var V=v[oe+L];for(P=0;P<8;P++)V[K+P]=E[X++];}}}return v;}function T(m){return m<0?0:m>255?255:m;}l.prototype={load:function(u){var v=new XMLHttpRequest();v.open("GET",u,!0),v.responseType="arraybuffer",v.onload=function(){var p=new Uint8Array(v.response||v.mozResponseArrayBuffer);this.parse(p),this.onload&&this.onload();}.bind(this),v.send(null);},parse:function(u){var v=this.opts.maxResolutionInMP*1e3*1e3,p=0,R=u.length;function w(){var te=u[p]<<8|u[p+1];return p+=2,te;}function M(){var te=w(),pe=u.subarray(p,p+te-2);return p+=pe.length,pe;}function E(te){var pe=1,Ee=1,we,Ae;for(Ae in te.components)te.components.hasOwnProperty(Ae)&&(we=te.components[Ae],pe<we.h&&(pe=we.h),Ee<we.v&&(Ee=we.v));var Ue=Math.ceil(te.samplesPerLine/8/pe),Oe=Math.ceil(te.scanLines/8/Ee);for(Ae in te.components)if(te.components.hasOwnProperty(Ae)){we=te.components[Ae];var Pe=Math.ceil(Math.ceil(te.samplesPerLine/8)*we.h/pe),Ie=Math.ceil(Math.ceil(te.scanLines/8)*we.v/Ee),Te=Ue*we.h,_e=Oe*we.v,rt=_e*Te,je=[];y(rt*256);for(var Ge=0;Ge<_e;Ge++){for(var nt=[],Ze=0;Ze<Te;Ze++)nt.push(new Int32Array(64));je.push(nt);}we.blocksPerLine=Pe,we.blocksPerColumn=Ie,we.blocks=je;}te.maxH=pe,te.maxV=Ee,te.mcusPerLine=Ue,te.mcusPerColumn=Oe;}var N=null,P=null,L=null,Y,oe,W=[],X=[],K=[],V=[],j=w(),xe=-1;if(this.comments=[],j!=65496)throw new Error("SOI not found");for(j=w();j!=65497;){var ne,re,Z;switch(j){case 65280:break;case 65504:case 65505:case 65506:case 65507:case 65508:case 65509:case 65510:case 65511:case 65512:case 65513:case 65514:case 65515:case 65516:case 65517:case 65518:case 65519:case 65534:var A=M();if(j===65534){var z=String.fromCharCode.apply(null,A);this.comments.push(z);}j===65504&&A[0]===74&&A[1]===70&&A[2]===73&&A[3]===70&&A[4]===0&&(N={version:{major:A[5],minor:A[6]},densityUnits:A[7],xDensity:A[8]<<8|A[9],yDensity:A[10]<<8|A[11],thumbWidth:A[12],thumbHeight:A[13],thumbData:A.subarray(14,14+3*A[12]*A[13])}),j===65505&&A[0]===69&&A[1]===120&&A[2]===105&&A[3]===102&&A[4]===0&&(this.exifBuffer=A.subarray(5,A.length)),j===65518&&A[0]===65&&A[1]===100&&A[2]===111&&A[3]===98&&A[4]===101&&A[5]===0&&(P={version:A[6],flags0:A[7]<<8|A[8],flags1:A[9]<<8|A[10],transformCode:A[11]});break;case 65499:for(var ce=w(),ve=ce+p-2;p<ve;){var Q=u[p++];y(256);var le=new Int32Array(64);if(Q>>4===0)for(re=0;re<64;re++){var ae=t[re];le[ae]=u[p++];}else if(Q>>4===1)for(re=0;re<64;re++){var ae=t[re];le[ae]=w();}else throw new Error("DQT: invalid table spec");W[Q&15]=le;}break;case 65472:case 65473:case 65474:w(),Y={},Y.extended=j===65473,Y.progressive=j===65474,Y.precision=u[p++],Y.scanLines=w(),Y.samplesPerLine=w(),Y.components={},Y.componentsOrder=[];var G=Y.scanLines*Y.samplesPerLine;if(G>v){var O=Math.ceil((G-v)/1e6);throw new Error(`maxResolutionInMP limit exceeded by ${O}MP`);}var ue=u[p++],se,de=0,Fe=0;for(ne=0;ne<ue;ne++){se=u[p];var Re=u[p+1]>>4,C=u[p+1]&15,d=u[p+2];if(Re<=0||C<=0)throw new Error("Invalid sampling factor, expected values above 0");Y.componentsOrder.push(se),Y.components[se]={h:Re,v:C,quantizationIdx:d},p+=3;}E(Y),X.push(Y);break;case 65476:var B=w();for(ne=2;ne<B;){var F=u[p++],U=new Uint8Array(16),S=0;for(re=0;re<16;re++,p++)S+=U[re]=u[p];y(16+S);var D=new Uint8Array(S);for(re=0;re<S;re++,p++)D[re]=u[p];ne+=17+S,(F>>4===0?V:K)[F&15]=f(U,D);}break;case 65501:w(),oe=w();break;case 65500:w(),w();break;case 65498:var $=w(),q=u[p++],ie=[],k;for(ne=0;ne<q;ne++){k=Y.components[u[p++]];var H=u[p++];k.huffmanTableDC=V[H>>4],k.huffmanTableAC=K[H&15],ie.push(k);}var J=u[p++],ge=u[p++],I=u[p++],ee=g(u,p,Y,ie,oe,J,ge,I>>4,I&15,this.opts);p+=ee;break;case 65535:u[p]!==255&&p--;break;default:if(u[p-3]==255&&u[p-2]>=192&&u[p-2]<=254){p-=3;break;}else if(j===224||j==225){if(xe!==-1)throw new Error(`first unknown JPEG marker at offset ${xe.toString(16)}, second unknown JPEG marker ${j.toString(16)} at offset ${(p-1).toString(16)}`);xe=p-1;var te=w();if(u[p+te-2]===255){p+=te-2;break;}}throw new Error("unknown JPEG marker "+j.toString(16));}j=w();}if(X.length!=1)throw new Error("only single frame JPEGs supported");for(var ne=0;ne<X.length;ne++){var fe=X[ne].components;for(var re in fe)fe[re].quantizationTable=W[fe[re].quantizationIdx],delete fe[re].quantizationIdx;}this.width=Y.samplesPerLine,this.height=Y.scanLines,this.jfif=N,this.adobe=P,this.components=[];for(var ne=0;ne<Y.componentsOrder.length;ne++){var k=Y.components[Y.componentsOrder[ne]];this.components.push({lines:b(Y,k),scaleX:k.h/Y.maxH,scaleY:k.v/Y.maxV});}},getData:function(u,v){var p=this.width/u,R=this.height/v,w,M,E,N,P,L,Y,oe,W,X,K=0,V,j,xe,ne,re,Z,A,z,ce,ve,Q,le=u*v*this.components.length;y(le);var ae=new Uint8Array(le);switch(this.components.length){case 1:for(w=this.components[0],X=0;X<v;X++)for(P=w.lines[0|X*w.scaleY*R],W=0;W<u;W++)V=P[0|W*w.scaleX*p],ae[K++]=V;break;case 2:for(w=this.components[0],M=this.components[1],X=0;X<v;X++)for(P=w.lines[0|X*w.scaleY*R],L=M.lines[0|X*M.scaleY*R],W=0;W<u;W++)V=P[0|W*w.scaleX*p],ae[K++]=V,V=L[0|W*M.scaleX*p],ae[K++]=V;break;case 3:for(Q=!0,this.adobe&&this.adobe.transformCode?Q=!0:typeof this.opts.colorTransform<"u"&&(Q=!!this.opts.colorTransform),w=this.components[0],M=this.components[1],E=this.components[2],X=0;X<v;X++)for(P=w.lines[0|X*w.scaleY*R],L=M.lines[0|X*M.scaleY*R],Y=E.lines[0|X*E.scaleY*R],W=0;W<u;W++)Q?(V=P[0|W*w.scaleX*p],j=L[0|W*M.scaleX*p],xe=Y[0|W*E.scaleX*p],z=T(V+1.402*(xe-128)),ce=T(V-.3441363*(j-128)-.71413636*(xe-128)),ve=T(V+1.772*(j-128))):(z=P[0|W*w.scaleX*p],ce=L[0|W*M.scaleX*p],ve=Y[0|W*E.scaleX*p]),ae[K++]=z,ae[K++]=ce,ae[K++]=ve;break;case 4:if(!this.adobe)throw new Error("Unsupported color mode (4 components)");for(Q=!1,this.adobe&&this.adobe.transformCode?Q=!0:typeof this.opts.colorTransform<"u"&&(Q=!!this.opts.colorTransform),w=this.components[0],M=this.components[1],E=this.components[2],N=this.components[3],X=0;X<v;X++)for(P=w.lines[0|X*w.scaleY*R],L=M.lines[0|X*M.scaleY*R],Y=E.lines[0|X*E.scaleY*R],oe=N.lines[0|X*N.scaleY*R],W=0;W<u;W++)Q?(V=P[0|W*w.scaleX*p],j=L[0|W*M.scaleX*p],xe=Y[0|W*E.scaleX*p],ne=oe[0|W*N.scaleX*p],re=255-T(V+1.402*(xe-128)),Z=255-T(V-.3441363*(j-128)-.71413636*(xe-128)),A=255-T(V+1.772*(j-128))):(re=P[0|W*w.scaleX*p],Z=L[0|W*M.scaleX*p],A=Y[0|W*E.scaleX*p],ne=oe[0|W*N.scaleX*p]),ae[K++]=255-re,ae[K++]=255-Z,ae[K++]=255-A,ae[K++]=255-ne;break;default:throw new Error("Unsupported color mode");}return ae;},copyToImageData:function(u,v){var p=u.width,R=u.height,w=u.data,M=this.getData(p,R),E=0,N=0,P,L,Y,oe,W,X,K,V,j;switch(this.components.length){case 1:for(L=0;L<R;L++)for(P=0;P<p;P++)Y=M[E++],w[N++]=Y,w[N++]=Y,w[N++]=Y,v&&(w[N++]=255);break;case 3:for(L=0;L<R;L++)for(P=0;P<p;P++)K=M[E++],V=M[E++],j=M[E++],w[N++]=K,w[N++]=V,w[N++]=j,v&&(w[N++]=255);break;case 4:for(L=0;L<R;L++)for(P=0;P<p;P++)W=M[E++],X=M[E++],Y=M[E++],oe=M[E++],K=255-T(W*(1-oe/255)+oe),V=255-T(X*(1-oe/255)+oe),j=255-T(Y*(1-oe/255)+oe),w[N++]=K,w[N++]=V,w[N++]=j,v&&(w[N++]=255);break;default:throw new Error("Unsupported color mode");}}};var x=0,_=0;function y(m=0){var u=x+m;if(u>_){var v=Math.ceil((u-_)/1024/1024);throw new Error(`maxMemoryUsageInMB limit exceeded by at least ${v}MB`);}x=u;}return l.resetMaxMemoryUsage=function(m){x=0,_=m;},l.getBytesAllocated=function(){return x;},l.requestMemoryAllocation=y,l;}();typeof Sr<"u"?Sr.exports=$n:typeof window<"u"&&(window["jpeg-js"]=window["jpeg-js"]||{},window["jpeg-js"].decode=$n);function $n(e,t={}){var r={colorTransform:void 0,useTArray:!1,formatAsRGBA:!0,tolerantDecoding:!0,maxResolutionInMP:100,maxMemoryUsageInMB:512},i={...r,...t},n=new Uint8Array(e),o=new _r();o.opts=i,_r.resetMaxMemoryUsage(i.maxMemoryUsageInMB*1024*1024),o.parse(n);var s=i.formatAsRGBA?4:3,a=o.width*o.height*s;try{_r.requestMemoryAllocation(a);var c={width:o.width,height:o.height,exifBuffer:o.exifBuffer,data:i.useTArray?new Uint8Array(a):Buffer.alloc(a)};o.comments.length>0&&(c.comments=o.comments);}catch(h){throw h instanceof RangeError?new Error("Could not allocate enough memory for the image. Required: "+a):h instanceof ReferenceError&&h.message==="Buffer is not defined"?new Error("Buffer is not globally defined in this environment. Consider setting useTArray to true"):h;}return o.copyToImageData(c,i.formatAsRGBA),c;}});var Xn=ut((Ps,Vn)=>{var So=Wn(),Co=Yn();Vn.exports={encode:So,decode:Co};});var Io={};ni(Io,{default:()=>Uo});module.exports=ii(Io);var jr=bt(Br(),1),Zr=bt(Yr(),1),_t=bt(ir(),1),{GIFEncoder:Oi,quantize:Pi,applyPalette:Ni}=Zr.default,Qr=e=>/^R0lGOD[dl]h/.test(e),Le=320,or=512*1024,Jr=()=>new Promise(e=>setTimeout(e,0));function Li(e){var t=()=>new Error("This GIF download is incomplete. Reopen the GIF or share the original file and try again.");if(e.length<13)throw t();if(!/^GIF8[79]a$/.test(String.fromCharCode(...e.subarray(0,6))))throw new Error("This file could not be read as an animated GIF.");var r=13,i=0,n=!1;function o(h){if(r+h>e.length)throw t();var l=r;return r+=h,l;}function s(h){h&128&&o(3*(1<<(h&7)+1));}function a(){for(;;){var h=e[o(1)];if(h===0)return;o(h);}}for(s(e[10]);r<e.length;){var h=e[o(1)];if(h===59){if(!i||n)throw t();return r===e.length?e:e.subarray(0,r);}if(h===33){var l=e[o(1)];a(),l===249&&(n=!0);}else if(h===44){var _l4=o(9);if(s(e[_l4+8]),o(1),a(),n=!1,++i>250)throw new Error("Use a GIF with 250 frames or fewer.");}else throw new Error("This GIF contains an invalid data block. Share the original GIF file and try again.");}if(!i||n)throw t();var c=new Uint8Array(e.length+1);return c.set(e),c[e.length]=59,c;}function zi(e){var t=Li(e),r;try{r=new jr.GifReader(t);}catch{throw new Error("This file could not be read as an animated GIF.");}var{width:i,height:n}=r,o=r.numFrames();if(!i||!n||i*n>4*1024*1024)throw new Error("This GIF is too large to resize on mobile. Use a GIF below 4 megapixels.");if(!o||o>250)throw new Error("Use a GIF with 250 frames or fewer.");var s=[],a=0;for(var c=0;c<o;c++){var h=r.frameInfo(c);if(!h.width||!h.height||h.x+h.width>i||h.y+h.height>n||h.data_offset+h.data_length>t.length||h.palette_offset==null||h.palette_offset+h.palette_size*3>t.length||t[h.data_offset]<2||t[h.data_offset]>8)throw new Error("This GIF contains an invalid frame.");var l=h.delay<2?100:h.delay*10;a+=l,s.push({...h,delayMs:l});}if(a>5e3)throw new Error("Discord stickers can be at most 5 seconds long. Use a shorter GIF; it has not been trimmed or uploaded.");return{bytes:t,reader:r,width:i,height:n,frames:s,duration:a};}function qr(e,t){if(t.transparent_index!=null||!(e[10]&128))return[0,0,0,0];var r=13+e[11]*3;return[e[r]??0,e[r+1]??0,e[r+2]??0,255];}function Kr(e,t,r,i){for(var n=r.y;n<r.y+r.height;n++){var o=(n*t+r.x)*4;for(var s=0;s<r.width;s++,o+=4)e.set(i,o);}}function Gi(e,t,r){var i=Math.min(Le/t,Le/r),n=Math.max(1,Math.round(t*i)),o=Math.max(1,Math.round(r*i)),s=Math.floor((Le-n)/2),a=Math.floor((Le-o)/2),c=new Uint8Array(Le*Le*4);for(var h=0;h<o;h++){var l=Math.min(r-1,Math.floor((h+.5)*r/o));for(var f=0;f<n;f++){var g=Math.min(t-1,Math.floor((f+.5)*t/n)),b=(l*t+g)*4,T=((h+a)*Le+f+s)*4;c[T]=e[b],c[T+1]=e[b+1],c[T+2]=e[b+2],c[T+3]=e[b+3];}}return c;}async function Hi(e,t,r,i){var{reader:n,width:o,height:s,frames:a}=t,c=new Uint8Array(o*s*4);Kr(c,o,{x:0,y:0,width:o,height:s},qr(e,a[0]));var h=Oi(),l,f;for(var g=0;g<a.length;g++){i(),l?.disposal===2?Kr(c,o,l,qr(e,l)):l?.disposal===3&&f&&c.set(f);var b=a[g];f=b.disposal===3?c.slice():null,n.decodeAndBlitFrameRGBA(g,c);var T=Gi(c,o,s),x=Pi(T,r-1,{format:"rgba4444",oneBitAlpha:!0}),_=[[0,0,0,0],...x.filter(m=>m[3]!==0)];_.length===1&&_.push([0,0,0,255]);var y=Ni(T,_,"rgba4444");if(h.writeFrame(y,Le,Le,{palette:_,delay:b.delayMs,repeat:n.loopCount()??-1,transparent:!0,transparentIndex:0,dispose:2}),h.bytesView().length>or)return null;l=b,await Jr();}return h.finish(),h.bytesView().length<=or?h.bytes():null;}async function en(e,t=()=>{}){t(),e=e.replace(/\s/g,"");var r=(0,_t.toByteArray)(e),i=zi(r),{bytes:n}=i;if(i.width===Le&&i.height===Le&&n.length<=or)return{base64:n===r?e:(0,_t.fromByteArray)(n),mimeType:"image/gif",extension:"gif"};if(i.width*i.height*i.frames.length>80*1024*1024)throw new Error("This GIF is too complex to resize on mobile. Use a smaller GIF.");for(var o of[256,128,64]){await Jr(),t();var s=await Hi(n,i,o,t);if(s)return{base64:(0,_t.fromByteArray)(s),mimeType:"image/gif",extension:"gif"};}throw new Error("This animated GIF is still over 512 KiB after resizing. Use a shorter or simpler GIF.");}async function tn(e){var t=new Set();async function r(i,n){if(i==null||n>5)return;if(typeof i=="string")try{return r(JSON.parse(i),n+1);}catch{return;}if(typeof i!="object"||t.has(i))return;if(t.add(i),typeof i.then=="function")try{return r(await i,n+1);}catch{return;}if(Array.isArray(i)||typeof i.id=="string"&&i.id)return i;for(var a of["body","data","result","response","emoji","sticker","emojis","stickers","parsedBody"]){var c=await r(i[a],n+1);if(c)return c;}if(typeof i.json=="function")try{var _a3=await r(await i.json(),n+1);if(_a3)return _a3;}catch{}else{var _a4=await r(i.json,n+1);if(_a4)return _a4;}var o;try{o=typeof i.text=="function"?await i.text():i.text;}catch{}var s=await r(o,n+1);return s||(typeof i.message=="string"?i:void 0);}return r(e,0);}function rn(e,t=globalThis){var r=a=>{try{return a();}catch{}},i=(...a)=>r(()=>e.metro.findByProps(...a));function n(){var a=[()=>typeof valenced<"u"?valenced.discord?.native?.FileModule:void 0,()=>typeof revenge<"u"?revenge.discord?.native?.FileModule:void 0,()=>i("writeFile","removeFile"),...["NativeFileModule","RTNFileManager","DCDFileManager"].map(c=>()=>e.metro.common.ReactNative.NativeModules?.[c]??t.nativeModuleProxy?.[c])];for(var c of a){var h=r(c);if(typeof h?.writeFile=="function"&&typeof h?.removeFile=="function")return h;}}function o(){for(var a of[()=>e.metro.common.RestAPI,()=>e.metro.common.restAPI,()=>i("HTTP")?.HTTP,()=>i("get","post","del")]){var c=r(a);if(typeof c?.post=="function")return c;}}function s(a){if(a!=="sticker"&&a!=="emoji")throw new Error("Unknown expression type.");var c=a==="sticker"?"createGuildSticker":"uploadEmoji",h=i(c),l=typeof h?.[c]=="function",f=l?void 0:o();if(!l&&!f)throw new Error("Discord\u2019s signed-in upload API is unavailable. Restart Discord and try again.");return async(g,b=()=>{})=>{b();var T=`/guilds/${g.guildId}/${a==="sticker"?"stickers":"emojis"}`,x,_,y=async()=>{if(typeof f?.get!="function")return;b();var v=await f.get({url:T,failImmediatelyWhenRateLimited:!0});if(b(),v?.ok===!1||Number(v?.status??v?.statusCode)>=400)return;var p=await tn(v);return b(),Array.isArray(p)?p:void 0;};if(l)x=await h[c](g);else{var v;if(a==="sticker"){if(typeof t.FormData!="function")throw new Error("Discord\u2019s multipart upload support is unavailable.");if(v=new t.FormData(),typeof v.getParts!="function")throw new Error("Discord\u2019s native multipart upload support is unavailable.");if(!/^(file|content):\/\//.test(g.uri))throw new Error("The sticker file is not ready to upload.");v.append("name",g.name),v.append("tags",g.tags),v.append("description",g.description??""),v.append("file",{uri:g.uri,name:g.mimeType==="image/gif"?"sticker.gif":"sticker.png",type:g.mimeType});}else v={name:g.name,image:g.image,roles:g.roles??[]};try{var p=await y();p&&(_=new Set(p.map(R=>R.id)));}catch{b();}b(),x=await f.post({url:T,body:v,oldFormErrors:!0,failImmediatelyWhenRateLimited:!0});}var m=await tn(x),u=x?.status??x?.statusCode??x?.response?.status;if(x?.ok===!1||Number(u)>=400)throw{status:u,body:m??x?.body};if(b(),!m?.id&&!l&&_){var _v;try{_v=await y();}catch{b();}var _p=r(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.()?.id),R=_v?.filter(w=>typeof w.id=="string"&&w.id&&!_.has(w.id)&&w.name===g.name&&(!w.user?.id||w.user.id===_p))??[];R.length===1&&(m=R[0]);}if((!l||a==="sticker")&&!m?.id)throw new Error(`Discord did not confirm the upload. Check the server\u2019s ${a==="sticker"?"stickers":"emoji"} before trying again.`);return b(),!l&&a==="sticker"&&r(()=>e.metro.common.FluxDispatcher?.dispatch?.({type:"GUILD_STICKERS_CREATE_SUCCESS",guildId:g.guildId,sticker:{...m,user:m.user??r(()=>e.metro.findByStoreName("UserStore")?.getCurrentUser?.())}})),m;};}return{resolve:s,files:n};}function nn(e,t){var{React:r,ReactNative:i}=e.metro.common,n=r.createElement,o=new Set(),s=0,a=l=>{try{return l();}catch{}},c=(...l)=>a(()=>e.metro.findByProps(...l));function h(l,f,g){var b=c("openAlert","dismissAlert");if(!i.Modal||typeof b?.openAlert!="function"||!r.useState||!r.useEffect)return!1;for(var m of[...o])m.close();var T=`${t}.panel.${Date.now().toString(36)}.${Math.random().toString(36).slice(2)}.${++s}`,x={visible:!0,listeners:new Set()},_=()=>{if(!x.visible)return;x.visible=!1;for(var v of x.listeners)v();o.delete(x),a(()=>g?.()),a(()=>b.dismissAlert(T));var m=c("useAlertStore")??a(()=>e.metro.findByImportedPath?.("design/components/AlertModal/native/useAlertStore.native.tsx")),u=m?.useAlertStore??m?.default;typeof u?.setState=="function"&&a(()=>u.setState(v=>{if(!Array.isArray(v.alerts))return v;var p=v.alerts.filter(R=>R.key!==T&&R.node!==x.node);return p.length===v.alerts.length?v:{alerts:p};}));};x.close=_;function y(){var[,m]=r.useState(0);r.useEffect(()=>{var R=()=>m(w=>w+1);return x.listeners.add(R),()=>{x.listeners.delete(R),_();};},[]);var u=i.useWindowDimensions?.()??i.Dimensions?.get?.("window")??{height:800};if(!x.visible)return null;var p=(a(()=>e.metro.findByStoreName("ThemeStore")?.theme)??i.Appearance?.getColorScheme?.())==="light"?"#ffffff":"#242429";return n(i.Modal,{visible:!0,transparent:!0,animationType:"slide",presentationStyle:"overFullScreen",onRequestClose:_,onDismiss:_,statusBarTranslucent:!1,navigationBarTranslucent:!1},n(i.KeyboardAvoidingView??i.View,{style:{flex:1},behavior:i.Platform?.OS==="ios"?"padding":"height"},n(i.View,{style:{flex:1,justifyContent:"flex-end",backgroundColor:"rgba(0,0,0,0.65)"}},n(i.Pressable??i.TouchableOpacity,{onPress:_,accessibilityRole:"button",accessibilityLabel:`Close ${f}`,style:{position:"absolute",top:0,left:0,right:0,bottom:0}}),n(i.View,{testID:t+"-panel",accessibilityViewIsModal:!0,onAccessibilityEscape:_,style:{height:Math.min(720,u.height*.86),maxHeight:"92%",backgroundColor:p,borderTopLeftRadius:20,borderTopRightRadius:20,overflow:"hidden",paddingTop:8,paddingBottom:16}},l(_)))));}x.node=n(y),o.add(x);try{var _m=b.openAlert(T,x.node,_,{dismissable:!0});return _m?.catch&&_m.catch(_),!0;}catch{return _(),!1;}}return{open:h,closeAll(){for(var l of[...o])l.close();}};}function on(e,{title:t,id:r,testID:i},n=globalThis){var{React:o,ReactNative:s}=e.metro.common,a=o.createElement,c=new Set(),h=0,l=b=>{try{return b();}catch{}};function f(b){var T=l(()=>b.getCurrentRoute?.());if(T)return T;var x=l(()=>b.getRootState?.()??b.getState?.()),_;for(var y=0;y<12&&x?.routes?.length;y++)_=x.routes[x.index??x.routes.length-1],x=_?.state;return _;}function g(b,T){var x=l(()=>e.metro.findByProps("getRootNavigationRef")?.getRootNavigationRef?.());if(!x?.navigate||!x.goBack||!x.getCurrentRoute&&!x.getRootState&&!x.getState)return!1;for(var E of[...c])E.close();var _=`${r}.${Date.now().toString(36)}.${++h}.${Math.random().toString(36).slice(2)}`,y=l(()=>e.metro.common.NavigationNative?.useIsFocused),m={open:!0,listeners:new Set(),presented:!1,mounted:!1},u=()=>f(x)?.params?.__expressionPage===_,v=()=>m.open&&(!m.presented||u()),p=(E=!0)=>{if(!m.open)return;var N=u();m.open=!1,n.clearTimeout(m.timer),n.clearTimeout(m.mountTimer),l(()=>m.cancelNavigation?.()),l(()=>m.unsubscribe?.()),c.delete(m),l(()=>T?.());for(var P of m.listeners)P();E&&N&&l(()=>x.canGoBack?.())!==!1&&l(()=>x.goBack());};m.close=p,c.add(m);function R(){var[,E]=o.useState(0),N=typeof y=="function"?y():void 0;o.useEffect(()=>{var L=()=>E(Y=>Y+1);return m.listeners.add(L),m.mounted=!0,n.clearTimeout(m.mountTimer),u()&&(m.presented=!0),!m.open&&u()&&l(()=>x.goBack()),()=>{m.listeners.delete(L),p(!1);};},[]),o.useEffect(()=>{!m.open&&u()&&l(()=>x.goBack());},[N]);var P=l(()=>e.metro.findByStoreName("ThemeStore")?.theme)!=="light";return a(s.View,{testID:i,style:{flex:1,backgroundColor:P?"#242429":"#fff"}},m.open?b(()=>p(),v):a(s.Text,{style:{padding:24,fontSize:16,color:P?"#f2f3f5":"#202127"}},t+" is closed. Use Back to return to Discord."));}var w=()=>{m.open&&(u()?m.presented=!0:m.presented&&p(!1));},M=l(()=>x.addListener?.("state",w));return m.unsubscribe=typeof M=="function"?M:()=>M?.remove?.(),m.timer=n.setTimeout(()=>{if(m.timer=void 0,!!m.open){m.mountTimer=n.setTimeout(()=>{!m.open||m.mounted||(p(!1),l(()=>e.ui.toasts.showToast(t+" could not open. Reopen the image menu and try again.")));},8e3);try{var _E2=x.navigate("BUNNY_CUSTOM_PAGE",{title:t,__expressionPage:_,__expressionOpen:()=>m.open,__expressionCancel:()=>p(!1),render:R});typeof _E2=="function"&&(m.cancelNavigation=_E2);}catch{p(!1),l(()=>e.ui.toasts.showToast(t+" could not open. Reopen the image menu and try again."));}}},350),!0;}return{open:g,closeAll(){for(var b of[...c])b.close();}};}var Ce=Uint8Array,De=Uint16Array,vr=Int32Array,zt=new Ce([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),Gt=new Ce([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),fr=new Ce([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),fn=function(e,t){for(var r=new De(31),i=0;i<31;++i)r[i]=t+=1<<e[i-1];for(var n=new vr(r[30]),i=1;i<30;++i)for(var o=r[i];o<r[i+1];++o)n[o]=o-r[i]<<5|i;return{b:r,r:n};},hn=fn(zt,2),un=hn.b,hr=hn.r;un[28]=258,hr[258]=28;var dn=fn(Gt,0),Wi=dn.b,sn=dn.r,ur=new De(32768);for(me=0;me<32768;++me)Ve=(me&43690)>>1|(me&21845)<<1,Ve=(Ve&52428)>>2|(Ve&13107)<<2,Ve=(Ve&61680)>>4|(Ve&3855)<<4,ur[me]=((Ve&65280)>>8|(Ve&255)<<8)>>1;var Ve,me,$e=function(e,t,r){for(var i=e.length,n=0,o=new De(t);n<i;++n)e[n]&&++o[e[n]-1];var s=new De(t);for(n=1;n<t;++n)s[n]=s[n-1]+o[n-1]<<1;var a;if(r){a=new De(1<<t);var c=15-t;for(n=0;n<i;++n)if(e[n])for(var h=n<<4|e[n],l=t-e[n],f=s[e[n]-1]++<<l,g=f|(1<<l)-1;f<=g;++f)a[ur[f]>>c]=h;}else for(a=new De(i),n=0;n<i;++n)e[n]&&(a[n]=ur[s[e[n]-1]++]>>15-e[n]);return a;},et=new Ce(288);for(me=0;me<144;++me)et[me]=8;var me;for(me=144;me<256;++me)et[me]=9;var me;for(me=256;me<280;++me)et[me]=7;var me;for(me=280;me<288;++me)et[me]=8;var me,kt=new Ce(32);for(me=0;me<32;++me)kt[me]=5;var me,$i=$e(et,9,0),Yi=$e(et,9,1),Vi=$e(kt,5,0),Xi=$e(kt,5,1),sr=function(e){for(var t=e[0],r=1;r<e.length;++r)e[r]>t&&(t=e[r]);return t;},ze=function(e,t,r){var i=t/8|0;return(e[i]|e[i+1]<<8)>>(t&7)&r;},ar=function(e,t){var r=t/8|0;return(e[r]|e[r+1]<<8|e[r+2]<<16)>>(t&7);},gr=function(e){return(e+7)/8|0;},st=function(e,t,r){return(t==null||t<0)&&(t=0),(r==null||r>e.length)&&(r=e.length),new Ce(e.subarray(t,r));};var qi=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],Me=function(e,t,r){var i=new Error(t||qi[e]);if(i.code=e,Error.captureStackTrace&&Error.captureStackTrace(i,Me),!r)throw i;return i;},pn=function(e,t,r,i){var n=e.length,o=i?i.length:0;if(!n||t.f&&!t.l)return r||new Ce(0);var s=!r,a=s||t.i!=2,c=t.i;s&&(r=new Ce(n*3));var h=function(G){var O=r.length;if(G>O){var ue=new Ce(Math.max(O*2,G));ue.set(r),r=ue;}},l=t.f||0,f=t.p||0,g=t.b||0,b=t.l,T=t.d,x=t.m,_=t.n,y=n*8;do{if(!b){l=ze(e,f,1);var m=ze(e,f+1,3);if(f+=3,m){if(m==1)b=Yi,T=Xi,x=9,_=5;else if(m==2){var R=ze(e,f,31)+257,w=ze(e,f+10,15)+4,M=R+ze(e,f+5,31)+1;f+=14;for(var E=new Ce(M),N=new Ce(19),P=0;P<w;++P)N[fr[P]]=ze(e,f+P*3,7);f+=w*3;for(var L=sr(N),Y=(1<<L)-1,oe=$e(N,L,1),P=0;P<M;){var W=oe[ze(e,f,Y)];f+=W&15;var u=W>>4;if(u<16)E[P++]=u;else{var X=0,K=0;for(u==16?(K=3+ze(e,f,3),f+=2,X=E[P-1]):u==17?(K=3+ze(e,f,7),f+=3):u==18&&(K=11+ze(e,f,127),f+=7);K--;)E[P++]=X;}}var V=E.subarray(0,R),j=E.subarray(R);x=sr(V),_=sr(j),b=$e(V,x,1),T=$e(j,_,1);}else Me(1);}else{var u=gr(f)+4,v=e[u-4]|e[u-3]<<8,p=u+v;if(p>n){c&&Me(0);break;}a&&h(g+v),r.set(e.subarray(u,p),g),t.b=g+=v,t.p=f=p*8,t.f=l;continue;}if(f>y){c&&Me(0);break;}}a&&h(g+131072);for(var xe=(1<<x)-1,ne=(1<<_)-1,re=f;;re=f){var X=b[ar(e,f)&xe],Z=X>>4;if(f+=X&15,f>y){c&&Me(0);break;}if(X||Me(2),Z<256)r[g++]=Z;else if(Z==256){re=f,b=null;break;}else{var A=Z-254;if(Z>264){var P=Z-257,z=zt[P];A=ze(e,f,(1<<z)-1)+un[P],f+=z;}var ce=T[ar(e,f)&ne],ve=ce>>4;ce||Me(3),f+=ce&15;var j=Wi[ve];if(ve>3){var z=Gt[ve];j+=ar(e,f)&(1<<z)-1,f+=z;}if(f>y){c&&Me(0);break;}a&&h(g+131072);var Q=g+A;if(g<j){var le=o-j,ae=Math.min(j,Q);for(le+g<0&&Me(3);g<ae;++g)r[g]=i[le+g];}for(;g<Q;++g)r[g]=r[g-j];}}t.l=b,t.p=re,t.b=g,t.f=l,b&&(l=1,t.m=x,t.d=T,t.n=_);}while(!l);return g!=r.length&&s?st(r,0,g):r.subarray(0,g);},Xe=function(e,t,r){r<<=t&7;var i=t/8|0;e[i]|=r,e[i+1]|=r>>8;},St=function(e,t,r){r<<=t&7;var i=t/8|0;e[i]|=r,e[i+1]|=r>>8,e[i+2]|=r>>16;},lr=function(e,t){for(var r=[],i=0;i<e.length;++i)e[i]&&r.push({s:i,f:e[i]});var n=r.length,o=r.slice();if(!n)return{t:gn,l:0};if(n==1){var s=new Ce(r[0].s+1);return s[r[0].s]=1,{t:s,l:1};}r.sort(function(p,R){return p.f-R.f;}),r.push({s:-1,f:25001});var a=r[0],c=r[1],h=0,l=1,f=2;for(r[0]={s:-1,f:a.f+c.f,l:a,r:c};l!=n-1;)a=r[r[h].f<r[f].f?h++:f++],c=r[h!=l&&r[h].f<r[f].f?h++:f++],r[l++]={s:-1,f:a.f+c.f,l:a,r:c};for(var g=o[0].s,i=1;i<n;++i)o[i].s>g&&(g=o[i].s);var b=new De(g+1),T=dr(r[l-1],b,0);if(T>t){var i=0,x=0,_=T-t,y=1<<_;for(o.sort(function(R,w){return b[w.s]-b[R.s]||R.f-w.f;});i<n;++i){var m=o[i].s;if(b[m]>t)x+=y-(1<<T-b[m]),b[m]=t;else break;}for(x>>=_;x>0;){var u=o[i].s;b[u]<t?x-=1<<t-b[u]++-1:++i;}for(;i>=0&&x;--i){var v=o[i].s;b[v]==t&&(--b[v],++x);}T=t;}return{t:new Ce(b),l:T};},dr=function(e,t,r){return e.s==-1?Math.max(dr(e.l,t,r+1),dr(e.r,t,r+1)):t[e.s]=r;},an=function(e){for(var t=e.length;t&&!e[--t];);for(var r=new De(++t),i=0,n=e[0],o=1,s=function(c){r[i++]=c;},a=1;a<=t;++a)if(e[a]==n&&a!=t)++o;else{if(!n&&o>2){for(;o>138;o-=138)s(32754);o>2&&(s(o>10?o-11<<5|28690:o-3<<5|12305),o=0);}else if(o>3){for(s(n),--o;o>6;o-=6)s(8304);o>2&&(s(o-3<<5|8208),o=0);}for(;o--;)s(n);o=1,n=e[a];}return{c:r.subarray(0,i),n:t};},Ct=function(e,t){for(var r=0,i=0;i<t.length;++i)r+=e[i]*t[i];return r;},vn=function(e,t,r){var i=r.length,n=gr(t+2);e[n]=i&255,e[n+1]=i>>8,e[n+2]=e[n]^255,e[n+3]=e[n+1]^255;for(var o=0;o<i;++o)e[n+o+4]=r[o];return(n+4+i)*8;},ln=function(e,t,r,i,n,o,s,a,c,h,l){Xe(t,l++,r),++n[256];for(var f=lr(n,15),g=f.t,b=f.l,T=lr(o,15),x=T.t,_=T.l,y=an(g),m=y.c,u=y.n,v=an(x),p=v.c,R=v.n,w=new De(19),M=0;M<m.length;++M)++w[m[M]&31];for(var M=0;M<p.length;++M)++w[p[M]&31];for(var E=lr(w,7),N=E.t,P=E.l,L=19;L>4&&!N[fr[L-1]];--L);var Y=h+5<<3,oe=Ct(n,et)+Ct(o,kt)+s,W=Ct(n,g)+Ct(o,x)+s+14+3*L+Ct(w,N)+2*w[16]+3*w[17]+7*w[18];if(c>=0&&Y<=oe&&Y<=W)return vn(t,l,e.subarray(c,c+h));var X,K,V,j;if(Xe(t,l,1+(W<oe)),l+=2,W<oe){X=$e(g,b,0),K=g,V=$e(x,_,0),j=x;var xe=$e(N,P,0);Xe(t,l,u-257),Xe(t,l+5,R-1),Xe(t,l+10,L-4),l+=14;for(var M=0;M<L;++M)Xe(t,l+3*M,N[fr[M]]);l+=3*L;for(var ne=[m,p],re=0;re<2;++re)for(var Z=ne[re],M=0;M<Z.length;++M){var A=Z[M]&31;Xe(t,l,xe[A]),l+=N[A],A>15&&(Xe(t,l,Z[M]>>5&127),l+=Z[M]>>12);}}else X=$i,K=et,V=Vi,j=kt;for(var M=0;M<a;++M){var z=i[M];if(z>255){var A=z>>18&31;St(t,l,X[A+257]),l+=K[A+257],A>7&&(Xe(t,l,z>>23&31),l+=zt[A]);var ce=z&31;St(t,l,V[ce]),l+=j[ce],ce>3&&(St(t,l,z>>5&8191),l+=Gt[ce]);}else St(t,l,X[z]),l+=K[z];}return St(t,l,X[256]),l+K[256];},Ki=new vr([65540,131080,131088,131104,262176,1048704,1048832,2114560,2117632]),gn=new Ce(0),ji=function(e,t,r,i,n,o){var s=o.z||e.length,a=new Ce(i+s+5*(1+Math.ceil(s/7e3))+n),c=a.subarray(i,a.length-n),h=o.l,l=(o.r||0)&7;if(t){l&&(c[0]=o.r>>3);for(var f=Ki[t-1],g=f>>13,b=f&8191,T=(1<<r)-1,x=o.p||new De(32768),_=o.h||new De(T+1),y=Math.ceil(r/3),m=2*y,u=function(se){return(e[se]^e[se+1]<<y^e[se+2]<<m)&T;},v=new vr(25e3),p=new De(288),R=new De(32),w=0,M=0,E=o.i||0,N=0,P=o.w||0,L=0;E+2<s;++E){var Y=u(E),oe=E&32767,W=_[Y];if(x[oe]=W,_[Y]=oe,P<=E){var X=s-E;if((w>7e3||N>24576)&&(X>423||!h)){l=ln(e,c,0,v,p,R,M,N,L,E-L,l),N=w=M=0,L=E;for(var K=0;K<286;++K)p[K]=0;for(var K=0;K<30;++K)R[K]=0;}var V=2,j=0,xe=b,ne=oe-W&32767;if(X>2&&Y==u(E-ne))for(var re=Math.min(g,X)-1,Z=Math.min(32767,E),A=Math.min(258,X);ne<=Z&&--xe&&oe!=W;){if(e[E+V]==e[E+V-ne]){for(var z=0;z<A&&e[E+z]==e[E+z-ne];++z);if(z>V){if(V=z,j=ne,z>re)break;for(var ce=Math.min(ne,z-2),ve=0,K=0;K<ce;++K){var Q=E-ne+K&32767,le=x[Q],ae=Q-le&32767;ae>ve&&(ve=ae,W=Q);}}}oe=W,W=x[oe],ne+=oe-W&32767;}if(j){v[N++]=268435456|hr[V]<<18|sn[j];var G=hr[V]&31,O=sn[j]&31;M+=zt[G]+Gt[O],++p[257+G],++R[O],P=E+V,++w;}else v[N++]=e[E],++p[e[E]];}}for(E=Math.max(E,P);E<s;++E)v[N++]=e[E],++p[e[E]];l=ln(e,c,h,v,p,R,M,N,L,E-L,l),h||(o.r=l&7|c[l/8|0]<<3,l-=7,o.h=_,o.p=x,o.i=E,o.w=P);}else{for(var E=o.w||0;E<s+h;E+=65535){var ue=E+65535;ue>=s&&(c[l/8|0]=h,ue=s),l=vn(c,l+1,e.subarray(E,ue));}o.i=s;}return st(a,0,i+gr(l)+n);};var xn=function(){var e=1,t=0;return{p:function(r){for(var i=e,n=t,o=r.length|0,s=0;s!=o;){for(var a=Math.min(s+2655,o);s<a;++s)n+=i+=r[s];i=(i&65535)+15*(i>>16),n=(n&65535)+15*(n>>16);}e=i,t=n;},d:function(){return e%=65521,t%=65521,(e&255)<<24|(e&65280)<<8|(t&255)<<8|t>>8;}};},Zi=function(e,t,r,i,n){if(!n&&(n={l:1},t.dictionary)){var o=t.dictionary.subarray(-32768),s=new Ce(o.length+e.length);s.set(o),s.set(e,o.length),e=s,n.w=o.length;}return ji(e,t.level==null?6:t.level,t.mem==null?n.l?Math.ceil(Math.max(8,Math.min(13,Math.log(e.length)))*1.5):20:12+t.mem,r,i,n);};var yn=function(e,t,r){for(;r;++t)e[t]=r,r>>>=8;};var Qi=function(e,t){var r=t.level,i=r==0?0:r<6?1:r==9?3:2;if(e[0]=120,e[1]=i<<6|(t.dictionary&&32),e[1]|=31-(e[0]<<8|e[1])%31,t.dictionary){var n=xn();n.p(t.dictionary),yn(e,2,n.d());}},wn=function(e,t){return((e[0]&15)!=8||e[0]>>4>7||(e[0]<<8|e[1])%31)&&Me(6,"invalid zlib data"),(e[1]>>5&1)==+!t&&Me(6,"invalid zlib data: "+(e[1]&32?"need":"unexpected")+" dictionary"),(e[1]>>3&4)+2;};var cr=function(){function e(t,r){typeof t=="function"&&(r=t,t={}),this.ondata=r;var i=t&&t.dictionary&&t.dictionary.subarray(-32768);this.s={i:0,b:i?i.length:0},this.o=new Ce(32768),this.p=new Ce(0),i&&this.o.set(i);}return e.prototype.e=function(t){if(this.ondata||Me(5),this.d&&Me(4),!this.p.length)this.p=t;else if(t.length){var r=new Ce(this.p.length+t.length);r.set(this.p),r.set(t,this.p.length),this.p=r;}},e.prototype.c=function(t){this.s.i=+(this.d=t||!1);var r=this.s.b,i=pn(this.p,this.s,this.o);this.ondata(st(i,r,this.s.b),this.d),this.o=st(i,this.s.b-32768),this.s.b=this.o.length,this.p=st(this.p,this.s.p/8|0),this.s.p&=7;},e.prototype.push=function(t,r){this.e(t),this.c(r);},e;}();function mn(e,t){t||(t={});var r=xn();r.p(e);var i=Zi(e,t,t.dictionary?6:2,4);return Qi(i,t),yn(i,i.length-4,r.d()),i;}var Tt=function(){function e(t,r){cr.call(this,t,r),this.v=t&&t.dictionary?2:1;}return e.prototype.push=function(t,r){if(cr.prototype.e.call(this,t),this.v){if(this.p.length<6&&!r)return;this.p=this.p.subarray(wn(this.p,this.v-1)),this.v=0;}r&&(this.p.length<4&&Me(6,"invalid zlib data"),this.p=this.p.subarray(0,-4)),cr.prototype.c.call(this,r);},e;}();function An(e,t){return pn(e.subarray(wn(e,t&&t.dictionary),-4),{i:2},t&&t.out,t&&t.dictionary);}var cn=typeof TextEncoder<"u"&&new TextEncoder(),pr=typeof TextDecoder<"u"&&new TextDecoder(),Ji=0;try{pr.decode(gn,{stream:!0}),Ji=1;}catch{}var eo=function(e){for(var t="",r=0;;){var i=e[r++],n=(i>127)+(i>223)+(i>239);if(r+n>e.length)return{s:t,r:st(e,r-1)};n?n==3?(i=((i&15)<<18|(e[r++]&63)<<12|(e[r++]&63)<<6|e[r++]&63)-65536,t+=String.fromCharCode(55296|i>>10,56320|i&1023)):n&1?t+=String.fromCharCode((i&31)<<6|e[r++]&63):t+=String.fromCharCode((i&15)<<12|(e[r++]&63)<<6|e[r++]&63):t+=String.fromCharCode(i);}};function bn(e,t){if(t){for(var r=new Ce(e.length),i=0;i<e.length;++i)r[i]=e.charCodeAt(i);return r;}if(cn)return cn.encode(e);for(var n=e.length,o=new Ce(e.length+(e.length>>1)),s=0,a=function(l){o[s++]=l;},i=0;i<n;++i){if(s+5>o.length){var c=new Ce(s+8+(n-i<<1));c.set(o),o=c;}var h=e.charCodeAt(i);h<128||t?a(h):h<2048?(a(192|h>>6),a(128|h&63)):h>55295&&h<57344?(h=65536+(h&1047552)|e.charCodeAt(++i)&1023,a(240|h>>18),a(128|h>>12&63),a(128|h>>6&63),a(128|h&63)):(a(224|h>>12),a(128|h>>6&63),a(128|h&63));}return st(o,0,s);}function En(e,t){if(t){for(var r="",i=0;i<e.length;i+=16384)r+=String.fromCharCode.apply(null,e.subarray(i,i+16384));return r;}else{if(pr)return pr.decode(e);var n=eo(e),o=n.s,r=n.r;return r.length&&Me(8),o;}}var Ht=class{encode(t=""){return bn(String(t));}},dt=class{constructor(t="utf-8"){this.latin1=/^(latin1|iso-8859-1)$/i.test(t);}decode(t=new Uint8Array()){var r=new Uint8Array(t.buffer??t,t.byteOffset??0,t.byteLength);return En(r,this.latin1);}};function xr(e,t="utf8"){return new dt(t).decode(e);}var to=new Ht();function _n(e){return to.encode(e);}var ro=1024*8,no=(()=>{var e=new Uint8Array(4),t=new Uint32Array(e.buffer);return!((t[0]=1)&e[0]);})(),yr={int8:globalThis.Int8Array,uint8:globalThis.Uint8Array,int16:globalThis.Int16Array,uint16:globalThis.Uint16Array,int32:globalThis.Int32Array,uint32:globalThis.Uint32Array,uint64:globalThis.BigUint64Array,int64:globalThis.BigInt64Array,float32:globalThis.Float32Array,float64:globalThis.Float64Array},at=class e{constructor(t=ro,r={}){ye(this,"buffer");ye(this,"byteLength");ye(this,"byteOffset");ye(this,"length");ye(this,"offset");ye(this,"lastWrittenByte");ye(this,"littleEndian");ye(this,"_data");ye(this,"_mark");ye(this,"_marks");var i=!1;typeof t=="number"?t=new ArrayBuffer(t):(i=!0,this.lastWrittenByte=t.byteLength);var n=r.offset?r.offset>>>0:0,o=t.byteLength-n,s=n;(ArrayBuffer.isView(t)||t instanceof e)&&(t.byteLength!==t.buffer.byteLength&&(s=t.byteOffset+n),t=t.buffer),i?this.lastWrittenByte=o:this.lastWrittenByte=0,this.buffer=t,this.length=o,this.byteLength=o,this.byteOffset=s,this.offset=0,this.littleEndian=!0,this._data=new DataView(this.buffer,s,o),this._mark=0,this._marks=[];}available(t=1){return this.offset+t<=this.length;}isLittleEndian(){return this.littleEndian;}setLittleEndian(){return this.littleEndian=!0,this;}isBigEndian(){return!this.littleEndian;}setBigEndian(){return this.littleEndian=!1,this;}skip(t=1){return this.offset+=t,this;}back(t=1){return this.offset-=t,this;}seek(t){return this.offset=t,this;}mark(){return this._mark=this.offset,this;}reset(){return this.offset=this._mark,this;}pushMark(){return this._marks.push(this.offset),this;}popMark(){var t=this._marks.pop();if(t===void 0)throw new Error("Mark stack empty");return this.seek(t),this;}rewind(){return this.offset=0,this;}ensureAvailable(t=1){if(!this.available(t)){var i=(this.offset+t)*2,n=new Uint8Array(i);n.set(new Uint8Array(this.buffer)),this.buffer=n.buffer,this.length=i,this.byteLength=i,this._data=new DataView(this.buffer);}return this;}readBoolean(){return this.readUint8()!==0;}readInt8(){return this._data.getInt8(this.offset++);}readUint8(){return this._data.getUint8(this.offset++);}readByte(){return this.readUint8();}readBytes(t=1){return this.readArray(t,"uint8");}readArray(t,r){var i=yr[r].BYTES_PER_ELEMENT*t,n=this.byteOffset+this.offset,o=this.buffer.slice(n,n+i);if(this.littleEndian===no&&r!=="uint8"&&r!=="int8"){var a=new Uint8Array(this.buffer.slice(n,n+i));a.reverse();var c=new yr[r](a.buffer);return this.offset+=i,c.reverse(),c;}var s=new yr[r](o);return this.offset+=i,s;}readInt16(){var t=this._data.getInt16(this.offset,this.littleEndian);return this.offset+=2,t;}readUint16(){var t=this._data.getUint16(this.offset,this.littleEndian);return this.offset+=2,t;}readInt32(){var t=this._data.getInt32(this.offset,this.littleEndian);return this.offset+=4,t;}readUint32(){var t=this._data.getUint32(this.offset,this.littleEndian);return this.offset+=4,t;}readFloat32(){var t=this._data.getFloat32(this.offset,this.littleEndian);return this.offset+=4,t;}readFloat64(){var t=this._data.getFloat64(this.offset,this.littleEndian);return this.offset+=8,t;}readBigInt64(){var t=this._data.getBigInt64(this.offset,this.littleEndian);return this.offset+=8,t;}readBigUint64(){var t=this._data.getBigUint64(this.offset,this.littleEndian);return this.offset+=8,t;}readChar(){return String.fromCharCode(this.readInt8());}readChars(t=1){var r="";for(var i=0;i<t;i++)r+=this.readChar();return r;}readUtf8(t=1){return xr(this.readBytes(t));}decodeText(t=1,r="utf8"){return xr(this.readBytes(t),r);}writeBoolean(t){return this.writeUint8(t?255:0),this;}writeInt8(t){return this.ensureAvailable(1),this._data.setInt8(this.offset++,t),this._updateLastWrittenByte(),this;}writeUint8(t){return this.ensureAvailable(1),this._data.setUint8(this.offset++,t),this._updateLastWrittenByte(),this;}writeByte(t){return this.writeUint8(t);}writeBytes(t){this.ensureAvailable(t.length);for(var r=0;r<t.length;r++)this._data.setUint8(this.offset++,t[r]);return this._updateLastWrittenByte(),this;}writeInt16(t){return this.ensureAvailable(2),this._data.setInt16(this.offset,t,this.littleEndian),this.offset+=2,this._updateLastWrittenByte(),this;}writeUint16(t){return this.ensureAvailable(2),this._data.setUint16(this.offset,t,this.littleEndian),this.offset+=2,this._updateLastWrittenByte(),this;}writeInt32(t){return this.ensureAvailable(4),this._data.setInt32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeUint32(t){return this.ensureAvailable(4),this._data.setUint32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeFloat32(t){return this.ensureAvailable(4),this._data.setFloat32(this.offset,t,this.littleEndian),this.offset+=4,this._updateLastWrittenByte(),this;}writeFloat64(t){return this.ensureAvailable(8),this._data.setFloat64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeBigInt64(t){return this.ensureAvailable(8),this._data.setBigInt64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeBigUint64(t){return this.ensureAvailable(8),this._data.setBigUint64(this.offset,t,this.littleEndian),this.offset+=8,this._updateLastWrittenByte(),this;}writeChar(t){return this.writeUint8(t.charCodeAt(0));}writeChars(t){for(var r=0;r<t.length;r++)this.writeUint8(t.charCodeAt(r));return this;}writeUtf8(t){return this.writeBytes(_n(t));}toArray(){return new Uint8Array(this.buffer,this.byteOffset,this.lastWrittenByte);}getWrittenByteLength(){return this.lastWrittenByte-this.byteOffset;}_updateLastWrittenByte(){this.offset>this.lastWrittenByte&&(this.lastWrittenByte=this.offset);}};var Cn=[];for(var e=0;e<256;e++){var t=e;for(var r=0;r<8;r++)t&1?t=3988292384^t>>>1:t=t>>>1;Cn[e]=t;}var Sn=4294967295;function io(e,t,r){var i=e;for(var n=0;n<r;n++)i=Cn[(i^t[n])&255]^i>>>8;return i;}function kn(e,t){return(io(Sn,e,t)^Sn)>>>0;}function wr(e,t,r){var i=e.readUint32(),n=kn(new Uint8Array(e.buffer,e.byteOffset+e.offset-t-4,t),t);if(n!==i)throw new Error(`CRC mismatch for chunk ${r}. Expected ${i}, found ${n}`);}function tt(e,t){e.writeUint32(kn(new Uint8Array(e.buffer,e.byteOffset+e.offset-t,t),t));}function Wt(e,t,r){for(var i=0;i<r;i++)t[i]=e[i];}function $t(e,t,r,i){var n=0;for(;n<i;n++)t[n]=e[n];for(;n<r;n++)t[n]=e[n]+t[n-i]&255;}function Yt(e,t,r,i){var n=0;if(r.length===0)for(;n<i;n++)t[n]=e[n];else for(;n<i;n++)t[n]=e[n]+r[n]&255;}function Vt(e,t,r,i,n){var o=0;if(r.length===0){for(;o<n;o++)t[o]=e[o];for(;o<i;o++)t[o]=e[o]+(t[o-n]>>1)&255;}else{for(;o<n;o++)t[o]=e[o]+(r[o]>>1)&255;for(;o<i;o++)t[o]=e[o]+(t[o-n]+r[o]>>1)&255;}}function Xt(e,t,r,i,n){var o=0;if(r.length===0){for(;o<n;o++)t[o]=e[o];for(;o<i;o++)t[o]=e[o]+t[o-n]&255;}else{for(;o<n;o++)t[o]=e[o]+r[o]&255;for(;o<i;o++)t[o]=e[o]+oo(t[o-n],r[o],r[o-n])&255;}}function oo(e,t,r){var i=e+t-r,n=Math.abs(i-e),o=Math.abs(i-t),s=Math.abs(i-r);return n<=o&&n<=s?e:o<=s?t:r;}function Tn(e,t,r,i,n,o){switch(e){case 0:Wt(t,r,n);break;case 1:$t(t,r,n,o);break;case 2:Yt(t,r,i,n);break;case 3:Vt(t,r,i,n,o);break;case 4:Xt(t,r,i,n,o);break;default:throw new Error(`Unsupported filter: ${e}`);}}var so=new Uint16Array([255]),ao=new Uint8Array(so.buffer),lo=ao[0]===255;function Fn(e){var{data:t,width:r,height:i,channels:n,depth:o}=e,s=[{x:0,y:0,xStep:8,yStep:8},{x:4,y:0,xStep:8,yStep:8},{x:0,y:4,xStep:4,yStep:8},{x:2,y:0,xStep:4,yStep:4},{x:0,y:2,xStep:2,yStep:4},{x:1,y:0,xStep:2,yStep:2},{x:0,y:1,xStep:1,yStep:2}],a=Math.ceil(o/8)*n,c=new Uint8Array(i*r*a),h=0;for(var l=0;l<7;l++){var f=s[l],g=Math.ceil((r-f.x)/f.xStep),b=Math.ceil((i-f.y)/f.yStep);if(g<=0||b<=0)continue;var T=g*a,x=new Uint8Array(T);for(var _=0;_<b;_++){var y=t[h++],m=t.subarray(h,h+T);h+=T;var u=new Uint8Array(T);Tn(y,m,u,x,T,a),x.set(u);for(var v=0;v<g;v++){var p=f.x+v*f.xStep,R=f.y+_*f.yStep;if(!(p>=r||R>=i))for(var w=0;w<a;w++)c[(R*r+p)*a+w]=u[v*a+w];}}}if(o===16){var _l5=new Uint16Array(c.buffer);if(lo)for(var _f4=0;_f4<_l5.length;_f4++)_l5[_f4]=co(_l5[_f4]);return _l5;}else return c;}function co(e){return(e&255)<<8|e>>8&255;}var fo=new Uint16Array([255]),ho=new Uint8Array(fo.buffer),uo=ho[0]===255,po=new Uint8Array(0);function mr(e){var{data:t,width:r,height:i,channels:n,depth:o}=e,s=Math.ceil(o/8)*n,a=Math.ceil(o/8*n*r),c=new Uint8Array(i*a),h=po,l=0,f,g;for(var b=0;b<i;b++){switch(f=t.subarray(l+1,l+1+a),g=c.subarray(b*a,(b+1)*a),t[l]){case 0:Wt(f,g,a);break;case 1:$t(f,g,a,s);break;case 2:Yt(f,g,h,a);break;case 3:Vt(f,g,h,a,s);break;case 4:Xt(f,g,h,a,s);break;default:throw new Error(`Unsupported filter: ${t[l]}`);}h=g,l+=a+1;}if(o===16){var _b2=new Uint16Array(c.buffer);if(uo)for(var T=0;T<_b2.length;T++)_b2[T]=vo(_b2[T]);return _b2;}else return c;}function vo(e){return(e&255)<<8|e>>8&255;}var Ft=Uint8Array.of(137,80,78,71,13,10,26,10);function Un(e){e.writeBytes(Ft);}function Ar(e){if(!In(e.readBytes(Ft.length)))throw new Error("wrong PNG signature");}function In(e){if(e.length<Ft.length)return!1;for(var _t2=0;_t2<Ft.length;_t2++)if(e[_t2]!==Ft[_t2])return!1;return!0;}var br="tEXt",Bn=0,Mn=new dt("latin1");function Rn(e){if(Dn(e),e.length===0||e.length>79)throw new Error("keyword length must be between 1 and 79");}var go=/^[\u0000-\u00FF]*$/;function Dn(e){if(!go.test(e))throw new Error("invalid latin1 text");}function On(e,t,r){var i=Er(t);e[i]=xo(t,r-i.length-1);}function Pn(e,t,r){Rn(t),Dn(r);var i=t.length+1+r.length;e.writeUint32(i),e.writeChars(br),e.writeChars(t),e.writeByte(Bn),e.writeChars(r),tt(e,i+4);}function Er(e){for(e.mark();e.readByte()!==Bn;);var t=e.offset;e.reset();var r=Mn.decode(e.readBytes(t-e.offset-1));return e.skip(1),Rn(r),r;}function xo(e,t){return Mn.decode(e.readBytes(t));}var ke={UNKNOWN:-1,GREYSCALE:0,TRUECOLOUR:2,INDEXED_COLOUR:3,GREYSCALE_ALPHA:4,TRUECOLOUR_ALPHA:6},pt={UNKNOWN:-1,DEFLATE:0},Ut={UNKNOWN:-1,ADAPTIVE:0},Ye={UNKNOWN:-1,NO_INTERLACE:0,ADAM7:1},It={NONE:0,BACKGROUND:1,PREVIOUS:2},qt={SOURCE:0,OVER:1};var Bt=class extends at{constructor(r,i={}){super(r);ye(this,"_checkCrc");ye(this,"_inflator");ye(this,"_png");ye(this,"_apng");ye(this,"_end");ye(this,"_hasPalette");ye(this,"_palette");ye(this,"_hasTransparency");ye(this,"_transparency");ye(this,"_compressionMethod");ye(this,"_filterMethod");ye(this,"_interlaceMethod");ye(this,"_colorType");ye(this,"_isAnimated");ye(this,"_numberOfFrames");ye(this,"_numberOfPlays");ye(this,"_frames");ye(this,"_writingDataChunks");ye(this,"_chunks");ye(this,"_inflatorResult");var{checkCrc:n=!1}=i;this._checkCrc=n,this._inflator=new Tt((o,s)=>{if(this._chunks.push(o),s){var a=this._chunks.reduce((h,l)=>h+l.length,0);this._inflatorResult=new Uint8Array(a);var c=0;for(var h of this._chunks)this._inflatorResult.set(h,c),c+=h.length;this._chunks=[];}}),this._chunks=[],this._png={width:-1,height:-1,channels:-1,data:new Uint8Array(0),depth:1,text:{}},this._apng={width:-1,height:-1,channels:-1,depth:1,numberOfFrames:1,numberOfPlays:0,text:{},frames:[]},this._end=!1,this._hasPalette=!1,this._palette=[],this._hasTransparency=!1,this._transparency=new Uint16Array(0),this._compressionMethod=pt.UNKNOWN,this._filterMethod=Ut.UNKNOWN,this._interlaceMethod=Ye.UNKNOWN,this._colorType=ke.UNKNOWN,this._isAnimated=!1,this._numberOfFrames=1,this._numberOfPlays=0,this._frames=[],this._writingDataChunks=!1,this._inflatorResult=new Uint8Array(0),this.setBigEndian();}decode(){for(Ar(this);!this._end;){var _r2=this.readUint32(),i=this.readChars(4);this.decodeChunk(_r2,i);}return this._inflator.push(new Uint8Array(0),!0),this.decodeImage(),this._png;}decodeApng(){for(Ar(this);!this._end;){var _r3=this.readUint32(),i=this.readChars(4);this.decodeApngChunk(_r3,i);}return this.decodeApngImage(),this._apng;}decodeChunk(r,i){var n=this.offset;switch(i){case"IHDR":this.decodeIHDR();break;case"PLTE":this.decodePLTE(r);break;case"IDAT":this.decodeIDAT(r);break;case"IEND":this._end=!0;break;case"tRNS":this.decodetRNS(r);break;case"iCCP":this.decodeiCCP(r);break;case br:On(this._png.text,this,r);break;case"pHYs":this.decodepHYs();break;default:this.skip(r);break;}if(this.offset-n!==r)throw new Error(`Length mismatch while decoding chunk ${i}`);this._checkCrc?wr(this,r+4,i):this.skip(4);}decodeApngChunk(r,i){var n=this.offset;switch(i!=="fdAT"&&i!=="IDAT"&&this._writingDataChunks&&this.pushDataToFrame(),i){case"acTL":this.decodeACTL();break;case"fcTL":this.decodeFCTL();break;case"fdAT":this.decodeFDAT(r);break;default:this.decodeChunk(r,i),this.offset=n+r;break;}if(this.offset-n!==r)throw new Error(`Length mismatch while decoding chunk ${i}`);this._checkCrc?wr(this,r+4,i):this.skip(4);}decodeIHDR(){var r=this._png;r.width=this.readUint32(),r.height=this.readUint32(),r.depth=yo(this.readUint8());var i=this.readUint8();this._colorType=i;var n;switch(i){case ke.GREYSCALE:n=1;break;case ke.TRUECOLOUR:n=3;break;case ke.INDEXED_COLOUR:n=1;break;case ke.GREYSCALE_ALPHA:n=2;break;case ke.TRUECOLOUR_ALPHA:n=4;break;case ke.UNKNOWN:default:throw new Error(`Unknown color type: ${i}`);}if(this._png.channels=n,this._compressionMethod=this.readUint8(),this._compressionMethod!==pt.DEFLATE)throw new Error(`Unsupported compression method: ${this._compressionMethod}`);this._filterMethod=this.readUint8(),this._interlaceMethod=this.readUint8();}decodeACTL(){this._numberOfFrames=this.readUint32(),this._numberOfPlays=this.readUint32(),this._isAnimated=!0;}decodeFCTL(){var r={sequenceNumber:this.readUint32(),width:this.readUint32(),height:this.readUint32(),xOffset:this.readUint32(),yOffset:this.readUint32(),delayNumber:this.readUint16(),delayDenominator:this.readUint16(),disposeOp:this.readUint8(),blendOp:this.readUint8(),data:new Uint8Array(0)};this._frames.push(r);}decodePLTE(r){if(r%3!==0)throw new RangeError(`PLTE field length must be a multiple of 3. Got ${r}`);var i=r/3;this._hasPalette=!0;var n=[];this._palette=n;for(var o=0;o<i;o++)n.push([this.readUint8(),this.readUint8(),this.readUint8()]);}decodeIDAT(r){this._writingDataChunks=!0;var i=r,n=this.offset+this.byteOffset;try{this._inflator.push(new Uint8Array(this.buffer,n,i),!1);}catch(o){throw new Error("Error while decompressing the data:",{cause:o});}this.skip(r);}decodeFDAT(r){this._writingDataChunks=!0;var i=r,n=this.offset+this.byteOffset;n+=4,i-=4;try{this._inflator.push(new Uint8Array(this.buffer,n,i),!1);}catch(o){throw new Error("Error while decompressing the data:",{cause:o});}this.skip(r);}decodetRNS(r){switch(this._colorType){case ke.GREYSCALE:case ke.TRUECOLOUR:{if(r%2!==0)throw new RangeError(`tRNS chunk length must be a multiple of 2. Got ${r}`);if(r/2>this._png.width*this._png.height)throw new Error(`tRNS chunk contains more alpha values than there are pixels (${r/2} vs ${this._png.width*this._png.height})`);this._hasTransparency=!0,this._transparency=new Uint16Array(r/2);for(var i=0;i<r/2;i++)this._transparency[i]=this.readUint16();break;}case ke.INDEXED_COLOUR:{if(r>this._palette.length)throw new Error(`tRNS chunk contains more alpha values than there are palette colors (${r} vs ${this._palette.length})`);var _i2=0;for(;_i2<r;_i2++){var n=this.readByte();this._palette[_i2].push(n);}for(;_i2<this._palette.length;_i2++)this._palette[_i2].push(255);break;}case ke.UNKNOWN:case ke.GREYSCALE_ALPHA:case ke.TRUECOLOUR_ALPHA:default:throw new Error(`tRNS chunk is not supported for color type ${this._colorType}`);}}decodeiCCP(r){var i=Er(this),n=this.readUint8();if(n!==pt.DEFLATE)throw new Error(`Unsupported iCCP compression method: ${n}`);var o=this.readBytes(r-i.length-2);this._png.iccEmbeddedProfile={name:i,profile:An(o)};}decodepHYs(){var r=this.readUint32(),i=this.readUint32(),n=this.readByte();this._png.resolution={x:r,y:i,unit:n};}decodeApngImage(){this._apng.width=this._png.width,this._apng.height=this._png.height,this._apng.channels=this._png.channels,this._apng.depth=this._png.depth,this._apng.numberOfFrames=this._numberOfFrames,this._apng.numberOfPlays=this._numberOfPlays,this._apng.text=this._png.text,this._apng.resolution=this._png.resolution;for(var _r4=0;_r4<this._numberOfFrames;_r4++){var i={sequenceNumber:this._frames[_r4].sequenceNumber,delayNumber:this._frames[_r4].delayNumber,delayDenominator:this._frames[_r4].delayDenominator,data:this._apng.depth===8?new Uint8Array(this._apng.width*this._apng.height*this._apng.channels):new Uint16Array(this._apng.width*this._apng.height*this._apng.channels)},n=this._frames.at(_r4);if(n){if(n.data=mr({data:n.data,width:n.width,height:n.height,channels:this._apng.channels,depth:this._apng.depth}),this._hasPalette&&(this._apng.palette=this._palette),this._hasTransparency&&(this._apng.transparency=this._transparency),_r4===0||n.xOffset===0&&n.yOffset===0&&n.width===this._png.width&&n.height===this._png.height)i.data=n.data;else{var o=this._apng.frames.at(_r4-1);this.disposeFrame(n,o,i),this.addFrameDataToCanvas(i,n);}this._apng.frames.push(i);}}return this._apng;}disposeFrame(r,i,n){switch(r.disposeOp){case It.NONE:break;case It.BACKGROUND:for(var o=0;o<this._png.height;o++)for(var s=0;s<this._png.width;s++){var a=(o*r.width+s)*this._png.channels;for(var c=0;c<this._png.channels;c++)n.data[a+c]=0;}break;case It.PREVIOUS:n.data.set(i.data);break;default:throw new Error("Unknown disposeOp");}}addFrameDataToCanvas(r,i){var n=1<<this._png.depth,o=(s,a)=>{var c=((s+i.yOffset)*this._png.width+i.xOffset+a)*this._png.channels,h=(s*i.width+a)*this._png.channels;return{index:c,frameIndex:h};};switch(i.blendOp){case qt.SOURCE:for(var s=0;s<i.height;s++)for(var a=0;a<i.width;a++){var{index:c,frameIndex:h}=o(s,a);for(var l=0;l<this._png.channels;l++)r.data[c+l]=i.data[h+l];}break;case qt.OVER:for(var _s3=0;_s3<i.height;_s3++)for(var _a5=0;_a5<i.width;_a5++){var{index:_c3,frameIndex:_h4}=o(_s3,_a5);for(var _l6=0;_l6<this._png.channels;_l6++){var f=i.data[_h4+this._png.channels-1]/n,g=_l6%(this._png.channels-1)===0?1:i.data[_h4+_l6],b=Math.floor(f*g+(1-f)*r.data[_c3+_l6]);r.data[_c3+_l6]+=b;}}break;default:throw new Error("Unknown blendOp");}}decodeImage(){var r=this._inflatorResult;if(this._filterMethod!==Ut.ADAPTIVE)throw new Error(`Filter method ${this._filterMethod} not supported`);if(this._interlaceMethod===Ye.NO_INTERLACE)this._png.data=mr({data:r,width:this._png.width,height:this._png.height,channels:this._png.channels,depth:this._png.depth});else if(this._interlaceMethod===Ye.ADAM7)this._png.data=Fn({data:r,width:this._png.width,height:this._png.height,channels:this._png.channels,depth:this._png.depth});else throw new Error(`Interlace method ${this._interlaceMethod} not supported`);this._hasPalette&&(this._png.palette=this._palette),this._hasTransparency&&(this._png.transparency=this._transparency);}pushDataToFrame(){this._inflator.push(new Uint8Array(0),!0);var r=this._inflatorResult,i=this._frames.at(-1);i?i.data=r:this._frames.push({sequenceNumber:0,width:this._png.width,height:this._png.height,xOffset:0,yOffset:0,delayNumber:0,delayDenominator:0,disposeOp:It.NONE,blendOp:qt.SOURCE,data:r}),this._inflator=new Tt((n,o)=>{if(this._chunks.push(n),o){var s=this._chunks.reduce((c,h)=>c+h.length,0);this._inflatorResult=new Uint8Array(s);var a=0;for(var c of this._chunks)this._inflatorResult.set(c,a),a+=c.length;this._chunks=[];}}),this._chunks=[],this._writingDataChunks=!1;}};function yo(e){if(e!==1&&e!==2&&e!==4&&e!==8&&e!==16)throw new Error(`invalid bit depth: ${e}`);return e;}var wo={level:3},Mt=class extends at{constructor(r,i={}){super();ye(this,"_png");ye(this,"_zlibOptions");ye(this,"_colorType");ye(this,"_interlaceMethod");this._colorType=ke.UNKNOWN,this._zlibOptions={...wo,...i.zlib},this._png=this._checkData(r),this._interlaceMethod=(i.interlace==="Adam7"?Ye.ADAM7:Ye.NO_INTERLACE)??Ye.NO_INTERLACE,this.setBigEndian();}encode(){if(Un(this),this.encodeIHDR(),this._png.palette&&(this.encodePLTE(),this._png.palette[0].length===4&&this.encodeTRNS()),this.encodeData(),this._png.text)for(var[_r5,i]of Object.entries(this._png.text))Pn(this,_r5,i);return this.encodeIEND(),this.toArray();}encodeIHDR(){this.writeUint32(13),this.writeChars("IHDR"),this.writeUint32(this._png.width),this.writeUint32(this._png.height),this.writeByte(this._png.depth),this.writeByte(this._colorType),this.writeByte(pt.DEFLATE),this.writeByte(Ut.ADAPTIVE),this.writeByte(this._interlaceMethod),tt(this,17);}encodeIEND(){this.writeUint32(0),this.writeChars("IEND"),tt(this,4);}encodePLTE(){var r=this._png.palette?.length*3;this.writeUint32(r),this.writeChars("PLTE");for(var i of this._png.palette)this.writeByte(i[0]),this.writeByte(i[1]),this.writeByte(i[2]);tt(this,4+r);}encodeTRNS(){var r=this._png.palette.filter(i=>i.at(-1)!==255);this.writeUint32(r.length),this.writeChars("tRNS");for(var i of r)this.writeByte(i.at(-1));tt(this,4+r.length);}encodeIDAT(r){this.writeUint32(r.length),this.writeChars("IDAT"),this.writeBytes(r),tt(this,r.length+4);}encodeData(){var{width:r,height:i,channels:n,depth:o,data:s}=this._png,a=o<=8?Math.ceil(r*o/8)*n:Math.ceil(r*o/8*n/2),c=new at().setBigEndian(),h=0;if(this._interlaceMethod===Ye.NO_INTERLACE)for(var g=0;g<i;g++)c.writeByte(0),o===16?h=Eo(s,c,a,h):h=Ao(s,c,a,h);else this._interlaceMethod===Ye.ADAM7&&(h=bo(this._png,s,c,h));var l=c.toArray(),f=mn(l,this._zlibOptions);this.encodeIDAT(f);}_checkData(r){var{colorType:i,channels:n,depth:o}=mo(r,r.palette),s={width:Nn(r.width,"width"),height:Nn(r.height,"height"),channels:n,data:r.data,depth:o,text:r.text,palette:r.palette};this._colorType=i;var a=o<8?Math.ceil(s.width*o/8)*s.height*n:s.width*s.height*n;if(s.data.length!==a)throw new RangeError(`wrong data size. Found ${s.data.length}, expected ${a}`);return s;}};function Nn(e,t){if(Number.isInteger(e)&&e>0)return e;throw new TypeError(`${t} must be a positive integer`);}function mo(e,t){var{channels:r=4,depth:i=8}=e;if(r!==4&&r!==3&&r!==2&&r!==1)throw new RangeError(`unsupported number of channels: ${r}`);var n={channels:r,depth:i,colorType:ke.UNKNOWN};switch(r){case 4:n.colorType=ke.TRUECOLOUR_ALPHA;break;case 3:n.colorType=ke.TRUECOLOUR;break;case 1:t?n.colorType=ke.INDEXED_COLOUR:n.colorType=ke.GREYSCALE;break;case 2:n.colorType=ke.GREYSCALE_ALPHA;break;default:throw new Error("unsupported number of channels");}return n;}function Ao(e,t,r,i){for(var n=0;n<r;n++)t.writeByte(e[i++]);return i;}function bo(e,t,r,i){var n=[{x:0,y:0,xStep:8,yStep:8},{x:4,y:0,xStep:8,yStep:8},{x:0,y:4,xStep:4,yStep:8},{x:2,y:0,xStep:4,yStep:4},{x:0,y:2,xStep:2,yStep:4},{x:1,y:0,xStep:2,yStep:2},{x:0,y:1,xStep:1,yStep:2}],{width:o,height:s,channels:a,depth:c}=e,h;c===16?h=a*c/8/2:h=a*c/8;for(var l=0;l<7;l++){var f=n[l],g=Math.floor((o-f.x+f.xStep-1)/f.xStep),b=Math.floor((s-f.y+f.yStep-1)/f.yStep);if(g<=0||b<=0)continue;var T=g*h;for(var x=0;x<b;x++){var _=f.y+x*f.yStep,y=c<=8?new Uint8Array(T):new Uint16Array(T),m=0;for(var u=0;u<g;u++){var v=f.x+u*f.xStep;if(v<o&&_<s){var p=(_*o+v)*h;for(var R=0;R<h;R++)y[m++]=t[p+R];}}if(r.writeByte(0),c===8)r.writeBytes(y);else if(c===16)for(var _u of y)r.writeByte(_u>>8&255),r.writeByte(_u&255);}}return i;}function Eo(e,t,r,i){for(var n=0;n<r;n++)t.writeUint16(e[i++]);return i;}function Ln(e,t){return new Bt(e,t).decode();}function zn(e,t){return new Mt(e,t).encode();}var qn=bt(Xn(),1);var Zt=bt(ir(),1),qe=320,ko=16e6,Kn=[137,80,78,71,13,10,26,10],Cr=(e,t)=>e[t]*16777216+e[t+1]*65536+e[t+2]*256+e[t+3],Ke=()=>new Error("This image could not be decoded. Reopen the original image and try again.");function jn(e,t){if(!Number.isInteger(e)||!Number.isInteger(t)||e<1||t<1)throw Ke();if(e>16384||t>16384||e*t>ko)throw new Error("This image is too large to prepare locally. Choose an image under 16 megapixels.");}function To(e,t){if(e.length<33||Kn.some((y,m)=>e[m]!==y))throw Ke();var r=Cr(e,16),i=Cr(e,20),n=e[24],o=e[25],s=e[28];jn(r,i);var a={0:1,2:3,3:1,4:2,6:4}[o];if(!a||![1,2,4,8,16].includes(n)||s>1)throw Ke();var c=s?[[0,0,8,8],[4,0,8,8],[0,4,4,8],[2,0,4,4],[0,2,2,4],[1,0,2,2],[0,1,1,2]]:[[0,0,1,1]],h=0;for(var[y,m,u,v]of c){var p=Math.max(0,Math.ceil((r-y)/u)),R=Math.max(0,Math.ceil((i-m)/v));p&&R&&(h+=(Math.ceil(p*a*n/8)+1)*R);}var l=[e.subarray(0,8)],f=[],g=!1;for(var _y=8;_y+12<=e.length;){t();var _m2=Cr(e,_y),_u2=_y+_m2+12;if(_u2>e.length)throw Ke();var _v2=String.fromCharCode(...e.subarray(_y+4,_y+8));if(_y===8&&(_v2!=="IHDR"||_m2!==13))throw Ke();if(_v2==="acTL")throw Object.assign(new Error("Use the original 320\xD7320 APNG or an animated GIF to keep this animation."),{code:"ANIMATED_PNG"});if(["IHDR","PLTE","tRNS","IDAT","IEND"].includes(_v2)&&l.push(e.subarray(_y,_u2)),_v2==="IDAT"&&f.push(e.subarray(_y+8,_y+8+_m2)),_y=_u2,_v2==="IEND"){g=!0;break;}}if(!g||!f.length)throw Ke();var b=0,T=new Tt(y=>{if(b+=y.length,b>h)throw Ke();});for(var _y2 of f)for(var _m3=0;_m3<_y2.length;_m3+=1024)t(),T.push(_y2.subarray(_m3,_m3+1024),!1);if(T.push(new Uint8Array(0),!0),b!==h)throw Ke();var x=new Uint8Array(l.reduce((y,m)=>y+m.length,0)),_=0;for(var _y3 of l)x.set(_y3,_),_+=_y3.length;return x;}function Fo(e){if(!e)return 1;try{var _t3=-1;for(var s=0;s<Math.min(12,e.length-8);s++)if(e[s]===73&&e[s+1]===73||e[s]===77&&e[s+1]===77){_t3=s;break;}if(_t3<0)return 1;var _r6=new DataView(e.buffer,e.byteOffset+_t3,e.byteLength-_t3),i=e[_t3]===73,n=_r6.getUint32(4,i),o=Math.min(_r6.getUint16(n,i),256);for(var _s4=0;_s4<o;_s4++){var a=n+2+_s4*12;if(_r6.getUint16(a,i)===274){var c=_r6.getUint16(a+8,i);return c>=1&&c<=8?c:1;}}}catch{}return 1;}function jt(e,t,r,i){var{width:n,height:o,data:s,channels:a=4,depth:c=8,palette:h,transparency:l,orientation:f=1}=e,g=t,b=r;f===2&&(g=n-1-t),f===3&&(g=n-1-t,b=o-1-r),f===4&&(b=o-1-r),f===5&&(g=r,b=t),f===6&&(g=r,b=o-1-t),f===7&&(g=n-1-r,b=o-1-t),f===8&&(g=n-1-r,b=t);var T=b*n+g;if(h||c<8){var y=g*c,m=Math.ceil(n*c/8),u=c===8?s[T]:s[b*m+(y>>3)]>>8-c-(y&7)&(1<<c)-1;if(h){var v=h[u];if(!v)throw Ke();i[0]=v[0],i[1]=v[1],i[2]=v[2],i[3]=v[3]??255;}else i[0]=i[1]=i[2]=u*255/((1<<c)-1),i[3]=l?.[0]===u?0:255;return;}var x=T*a,_=c===16?1/257:1;i[0]=s[x]*_,a<=2?(i[1]=i[2]=i[0],i[3]=a===2?s[x+1]*_:l?.[0]===s[x]?0:255):(i[1]=s[x+1]*_,i[2]=s[x+2]*_,i[3]=a===4?s[x+3]*_:l?.length===3&&l[0]===s[x]&&l[1]===s[x+1]&&l[2]===s[x+2]?0:255);}function kr(e,t=()=>{}){t();var r=(0,Zt.toByteArray)(e.replace(/\s/g,"")),i;if(Kn.every((x,_)=>r[_]===x))i=Ln(To(r,t),{checkCrc:!0});else if(r[0]===255&&r[1]===216)i=qn.default.decode(r,{useTArray:!0,formatAsRGBA:!0,tolerantDecoding:!1,maxResolutionInMP:16,maxMemoryUsageInMB:128}),i={...i,channels:4,depth:8,orientation:Fo(i.exifBuffer)};else throw Object.assign(new Error("This image format needs conversion to PNG."),{code:"STATIC_FORMAT_UNSUPPORTED"});t(),jn(i.width,i.height);var n=i.orientation>=5,o=n?i.height:i.width,s=n?i.width:i.height,a=Math.min(qe/o,qe/s),c=Math.max(1,Math.round(o*a)),h=Math.max(1,Math.round(s*a)),l=Math.floor((qe-c)/2),f=Math.floor((qe-h)/2),g=new Uint8Array(qe*qe*4),b=Array.from({length:4},()=>new Float64Array(4));for(var x=0;x<h;x++){x%16===0&&t();var _=Math.max(0,Math.min(s-1,(x+.5)*s/h-.5)),y=Math.floor(_),m=Math.min(s-1,y+1),u=_-y;for(var v=0;v<c;v++){var p=Math.max(0,Math.min(o-1,(v+.5)*o/c-.5)),R=Math.floor(p),w=Math.min(o-1,R+1),M=p-R;jt(i,R,y,b[0]),jt(i,w,y,b[1]),jt(i,R,m,b[2]),jt(i,w,m,b[3]);var E=[(1-M)*(1-u),M*(1-u),(1-M)*u,M*u],N=((x+f)*qe+v+l)*4,P=0;for(var L=0;L<4;L++)P+=b[L][3]*E[L];if(g[N+3]=Math.round(P),P)for(var _L=0;_L<3;_L++){var Y=0;for(var oe=0;oe<4;oe++)Y+=b[oe][_L]*b[oe][3]*E[oe];g[N+_L]=Math.round(Y/P);}}}t();var T=zn({width:qe,height:qe,data:g,channels:4,depth:8});if(T.length>512*1024)throw new Error("The prepared sticker is over 512 KiB.");return t(),{base64:(0,Zt.fromByteArray)(T),mimeType:"image/png"};}var Uo=(()=>{"use strict";var e=typeof vendetta<"u"?vendetta:globalThis.vendetta;if(!e?.metro||!e?.patcher)throw new Error("SaveAsSticker needs Revenge's Vendetta plugin support.");var{React:t,ReactNative:r,constants:i}=e.metro.common,n=t.createElement,o=rn(e),s=nn(e,"SaveAsStickerPicker"),a=on(e,{title:"Save as Sticker",id:"save-as-sticker",testID:"SaveAsStickerPage"}),c="SaveAsStickerPicker",h="save-as-sticker-action",l=512*1024,f=25*1024*1024,g=[5,15,30,60],b=[],T=new Set(),x=!1,_=0,y=!1,m,u=(...d)=>{try{return e.metro.findByProps(...d);}catch{return;}},v=d=>{try{return e.metro.findByStoreName(d);}catch{return;}},p=(...d)=>{for(var B of d)try{var F=e.ui.assets.getAssetIDByName(B);if(F!=null)return F;}catch{}},R=(...d)=>e.logger?.error?.("[SaveAsSticker]",...d),w=d=>{try{e.ui.toasts.showToast(d,p("StickerIcon","ic_sticker_24px"));}catch{console.log("[SaveAsSticker]",d);}},M=u("openLazy","hideActionSheet"),E=u("ActionSheetRow")?.ActionSheetRow,N=e.ui.components?.Forms??{},P=u("ActionSheetTitleHeader")?.ActionSheetTitleHeader??u("BottomSheetTitleHeader")?.BottomSheetTitleHeader,L=u("ActionSheetCloseButton")?.ActionSheetCloseButton,Y=u("GuildIconSizes"),oe=Y?.default,W=Y?.GuildIconSizes,X=u("BottomSheetFlatList")?.BottomSheetFlatList??u("BottomSheetScrollView")?.BottomSheetFlatList??r.FlatList,K=u("ActionSheet")?.ActionSheet;if(!K)try{K=e.metro.find(d=>d?.render?.name==="ActionSheet");}catch{}function V(d){var B=String(d||"sticker").replace(/\.[a-z0-9]{1,6}$/i,"").replace(/[\u0000-\u001f]/g,"").trim().slice(0,30);return B.length>=2?B:"sticker";}function j(d,B=!1){if(!d)return null;var F=String(d.content_type??d.contentType??d.mimeType??""),U=d.mediaType??d.type,D=[d.url,d.sourceURI,d.mediaUrl,d.uri,d.proxy_url,d.proxyURL,d.image?.url,d.thumbnail?.url,d.video?.url].find(k=>typeof k=="string"&&/\.gif(?:[?#]|$)/i.test(k)),$=F==="image/gif"||!!D;if(!$&&(/^(video|audio)\//i.test(F)||/^(video|audio|file)$/i.test(String(U))))return null;var q=D??d.mediaUrl??d.sourceURI??d.url??d.uri??d.proxy_url??d.proxyURL;if(D&&(q=q.replace(/([?&])format=(?:webp|png|jpe?g|mp4)(?=&|$)/gi,"$1").replace(/([?&])animated=false(?=&|$)/gi,"$1").replace(/\?&/,"?").replace(/&&+/g,"&").replace(/[?&]$/,"")),typeof q!="string"||!/^https:\/\//i.test(q))return null;var ie=d.filename??d.name??q.split(/[?#]/)[0].split("/").pop()??"sticker";return!B&&U!=="image"&&!F.startsWith("image/")&&!/\.(png|apng|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i.test(ie)&&!/\.(png|apng|jpe?g|webp|gif|avif|bmp)(?:[?#]|$)/i.test(q)?null:{url:q,proxyURL:d.proxy_url??d.proxyURL,filename:ie,contentType:$?"image/gif":F,id:d.id??d.attachmentId};}function xe(...d){var B=d.flatMap(U=>{if(!U||typeof U!="object")return[];var S=U.analyticsLocation;return S&&typeof S=="object"?[U,S]:[U];});for(var U of B)if(U.selectedMedia){var S=U.selectedMedia,D=j({...S.source,...S},S.mediaType==="image");return D?[D]:[];}for(var _U of B){var _S=_U.source;if(_U.syncer?.sources){var _D=_U.syncer.index?.value??_U.syncer.index??0;_S=_U.syncer.sources[_D];}if(Array.isArray(_S)&&(_S=_S[0]),_S){var _D2=j(_S);return _D2?[_D2]:[];}}var F=[];for(var _U2 of B){for(var _S2 of _U2.message?.attachments??[]){var _D3=j(_S2);_D3&&F.push(_D3);}for(var _S3 of _U2.message?.embeds??[])for(var _D4 of[_S3.image,...(_S3.images??[]),_S3.type==="image"?_S3:null,_S3.type==="gifv"&&/\.gif(?:[?#]|$)/i.test(_S3.video?.url??"")?{..._S3.video,contentType:"image/gif"}:null,_S3.type==="gifv"&&/\.gif(?:[?#]|$)/i.test(_S3.thumbnail?.url??"")?_S3.thumbnail:null]){var $=j(_D4,!0);$&&F.push($);}}return F.filter((U,S)=>F.findIndex(D=>D.url===U.url)===S);}function ne(d){if(!d?.id||d.unavailable)return!1;var B=v("UserStore")?.getCurrentUser?.()?.id;if(B&&(d.ownerId===B||d.owner_id===B))return!0;var F=i?.Permissions?.CREATE_GUILD_EXPRESSIONS??1n<<43n;try{return!!v("PermissionStore")?.can?.(F,d);}catch{return!1;}}function re(d){var B=Number(d.premiumTier??d.premium_tier??0),F=d.features,U=Array.isArray(F)?F.includes("MORE_STICKERS"):F?.has?.("MORE_STICKERS"),S=Number(d.premiumFeatures?.additionalStickerSlots??d.premium_features?.additional_sticker_slots??0),D=U&&B===3?120:g[B]??g[0],$=Number(d.maxStickers??d.max_stickers??0),q=Math.max(D+(Number.isFinite(S)?Math.max(0,S):0),$||0),k=(v("GuildStickersStore")??v("StickersStore")??v("StickerStore"))?.getStickersByGuildId?.(d.id)??d.stickers;return k&&!Array.isArray(k)&&(k=Object.values(k)),{max:q,used:Array.isArray(k)?k.length:null};}function Z(){return Object.values(v("GuildStore")?.getGuilds?.()??{}).filter(ne).sort((d,B)=>String(d.name).localeCompare(String(B.name)));}function A(d){var B=Number(d?.body?.code??d?.code);if(B===50013)return"You need Create Expressions permission in this server.";if(B===30039)return"This server has no free sticker slots. Choose another server.";for(var F of[d?.body?.message,d?.message,d?.text])if(!(typeof F!="string"||!F))try{return JSON.parse(F)?.message??F;}catch{return F;}return"Discord could not upload the sticker. Please try again.";}function z(){return o.files();}function ce(d,B){return new Promise((F,U)=>{var S=new FileReader(),D=!1,$=(ie,k)=>{D||(D=!0,B?.removeEventListener?.("abort",q),ie(k));},q=()=>{$(U,Object.assign(new Error("Cancelled"),{code:"E_PICKER_CANCELLED"}));try{S.abort?.();}catch{}};if(S.onerror=()=>$(U,S.error??new Error("Could not read the image.")),S.onload=()=>$(F,String(S.result).split(",")[1]),B?.aborted){q();return;}B?.addEventListener?.("abort",q);try{S.readAsDataURL(d);}catch(ie){$(U,ie);}});}function ve(d){return Math.floor(d.length*3/4)-(d.endsWith("==")?2:d.endsWith("=")?1:0);}function Q(d){var B="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",F=[],U=0,S=0;for(var q of d.slice(0,44)){var ie=B.indexOf(q);if(ie<0)break;S=S<<6|ie,U+=6,U>=8&&(U-=8,F.push(S>>>U&255));}var D=[137,80,78,71,13,10,26,10];if(F.length<24||D.some((q,ie)=>F[ie]!==q)||String.fromCharCode(...F.slice(12,16))!=="IHDR")return null;var $=q=>F[q]*16777216+F[q+1]*65536+F[q+2]*256+F[q+3];return{width:$(16),height:$(20)};}function le(d){if(typeof d!="string"||!d)throw new Error("Discord did not return a local image path.");return /^(file|content):\/\//.test(d)?d:"file://"+d;}async function ae(d,B,F={}){var U=z();if(!U?.writeFile||!U?.removeFile)throw new Error("Discord's image file module is unavailable on this build.");var S=[],D=u("launchCropper","cleanSingle")??u("launchCropper"),$;async function q(){if($&&D?.cleanSingle)try{await D.cleanSingle($);}catch{}for(var k of S)try{await U.removeFile("cache",k);}catch{}}async function ie(k,H){try{return kr(k,B).base64;}catch(J){if(J?.code!=="STATIC_FORMAT_UNSUPPORTED")throw J;var ge=d.proxyURL??H;if(!/^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/(?:attachments|ephemeral-attachments|external)\//i.test(ge))throw new Error("Use a PNG or JPEG image, or an animated GIF. This image format could not be converted.");var I=new URL(ge.replace(/^https:\/\/cdn\.discordapp\.com/i,"https://media.discordapp.net"));I.searchParams.set("format","png"),I.searchParams.set("width","320"),I.searchParams.set("height","320"),B();var ee=await(e.utils?.safeFetch??fetch)(I.toString(),{signal:F.controller?.signal},2e4);if(!ee.ok)throw new Error("Discord could not convert this image to PNG. Use the original PNG or JPEG.");var fe=await ee.blob();if(fe.size>f)throw new Error("Choose an image smaller than 25 MB.");var te=await ce(fe,F.controller?.signal);return B(),kr(te,B).base64;}}try{var k=d.url,H=u("maybeRefreshAttachmentUrl");if(/^https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\//i.test(k))try{k=(await H?.maybeRefreshAttachmentUrl?.(k))||k;}catch{}B();var J=await(e.utils?.safeFetch??fetch)(k,{signal:F.controller?.signal},2e4);if(!J.ok)throw new Error("Image download failed (HTTP "+J.status+"). Reopen the image and try again.");if(Number(J.headers?.get?.("content-length"))>f)throw new Error("Choose an image smaller than 25 MB.");var ge=await J.blob();if(ge.size>f)throw new Error("Choose an image smaller than 25 MB.");var I=await ce(ge,F.controller?.signal);if(B(),!I)throw new Error("The image is empty.");var ee="save-as-sticker-"+Date.now()+"-"+Math.random().toString(36).slice(2);if(Qr(I)){w("Preparing animated GIF\u2026");var we=await en(I,B);B();var Ae=ee+"-sticker.gif";S.push(Ae);var Ue=le(await U.writeFile("cache",Ae,we.base64,"base64"));return B(),{uri:Ue,mimeType:we.mimeType,cleanup:q};}if(d.contentType==="image/gif"||ge.type==="image/gif")throw new Error("This link returned a video or still preview. Share the original .gif file and try again.");var fe=Q(I);if(!fe||fe.width!==320||fe.height!==320||ve(I)>l)if(!D?.launchCropper)I=await ie(I,k);else{var _we=I,_Ae=ge.type||d.contentType||"image/png",_Ue=/jpeg/i.test(_Ae)?"jpg":/webp/i.test(_Ae)?"webp":/avif/i.test(_Ae)?"avif":"png",Oe=ee+"."+_Ue;S.push(Oe);var Pe=le(await U.writeFile("cache",Oe,I,"base64"));B();var Ie;try{Ie=await D.launchCropper({uri:Pe,width:320,height:320,mimeType:"image/png",includeBase64:!0,freeStyleCropEnabled:!1});}catch(_e){if(_e?.code==="E_PICKER_CANCELLED"||/cancel/i.test(String(_e?.message??"")))throw _e;B();}$=Ie?.path??Ie?.uri,B(),I=Ie?.data??Ie?.base64,!I&&$&&U.readFile&&(I=await U.readFile($.replace(/^file:\/\//,""),"base64")),(typeof I!="string"||!I)&&(I=_we),I=I.replace(/^data:[^,]*,/,"").replace(/\s/g,"");var Te=Q(I);(!Te||Te.width!==320||Te.height!==320||ve(I)>l)&&(I=await ie(I,k));}var te=Q(I);if(!te||te.width!==320||te.height!==320)throw new Error("The cropper did not produce a 320\xD7320 PNG. The sticker was not uploaded.");if(ve(I)>l)throw new Error("The cropped sticker is over 512 KiB. Try a simpler image.");var pe=ee+"-sticker.png";S.push(pe);var Ee=le(await U.writeFile("cache",pe,I,"base64"));return B(),{uri:Ee,mimeType:"image/png",cleanup:q};}catch(k){throw await q(),k;}}async function G(d,B,F,U){if(y||!x)return;var S=U?.control??{};y=S,T.add(S);var D=_,$=v("UserStore")?.getCurrentUser?.()?.id,q=()=>{if(!x||_!==D||S.cancelled||S.expired||U&&!U.isCurrent()||!$||v("UserStore")?.getCurrentUser?.()?.id!==$)throw Object.assign(new Error("Cancelled"),{code:"E_PICKER_CANCELLED"});},ie,k;S.cancel=H=>{if(!(S.writing&&!H)){S.cancelled=!0;try{S.controller?.abort();}catch{}clearTimeout(k),y===S&&(y=!1);}};try{if(F.length<2||F.length>30)throw new Error("Use a sticker name between 2 and 30 characters.");if(!$)throw new Error("Your Discord account is still loading. Reopen the picker and try again.");q();var H=o.resolve("sticker");U||(M.hideActionSheet(c),r.Keyboard?.dismiss?.(),await new Promise(fe=>setTimeout(fe,300))),q(),w("Preparing your sticker\u2026"),ie=await ae(B,q,S),q();var J=v("GuildStore"),ge=J?.getGuild?.(d.id)??J?.getGuilds?.()?.[d.id];if(!ne(ge))throw new Error("You no longer have Create Expressions permission in this server.");var I=re(ge);if(I.used!=null&&I.used>=I.max)throw new Error("This server has no free sticker slots. Choose another server.");w("Adding sticker to "+d.name+"\u2026"),S.writing=!0,U&&(k=setTimeout(()=>{S.expired=!0,y===S&&(y=!1),U.isCurrent()&&(U.onError("Discord\u2019s upload response timed out. Check the server\u2019s stickers before trying again."),U.onFinished());},45e3));var ee=await H({guildId:d.id,name:F,tags:"slight_smile",description:"",uri:ie.uri,mimeType:ie.mimeType,platform:"mobile",originalMd5:null},q);if(q(),!ee?.id&&!ee?.body?.id)throw new Error("Discord did not confirm the upload. Check the server's stickers before trying again.");U&&U.onSuccess(),x&&_===D&&w("Sticker added to "+d.name);}catch(H){if(S.cancelled||S.expired||H?.code==="E_PICKER_CANCELLED"||/cancel/i.test(String(H?.message??"")))return;if(R("Upload failed",H),x&&_===D){var _J=A(H);U?U.isCurrent()&&U.onError(_J):r.Alert?.alert?r.Alert.alert("Sticker could not be added",_J):w(_J);}}finally{clearTimeout(k),T.delete(S),y===S&&(y=!1),U?.isCurrent()&&U.onFinished(),await ie?.cleanup?.();}}function O({images:d,onClose:B,inPanel:F=!1,page:U=!1,isOpen:S}){var[D,$]=t.useState(d.length===1?d[0]:null),[q,ie]=t.useState(null),[k,H]=t.useState(V(d[0]?.filename)),[,J]=t.useState(0),[ge,I]=t.useState(""),[ee,fe]=t.useState(!1),[te,pe]=t.useState(""),Ee=t.useRef(!0),we=t.useRef(!1),Ae=t.useRef(),Ue=t.useRef(!1),Oe=t.useRef(_),Pe=()=>Ee.current&&!we.current&&x&&_===Oe.current&&(!S||S()),Ie=(v("ThemeStore")?.theme??r.Appearance?.getColorScheme?.())!=="light",Te={text:Ie?"#f2f3f5":"#1e1f22",muted:Ie?"#b5bac1":"#4e5058",input:Ie?"#1e1f22":"#e3e5e8"};t.useEffect(()=>{Ee.current=!0;var he=[v("GuildStore"),v("PermissionStore"),v("GuildStickersStore"),v("StickersStore")].filter(Boolean),Se=()=>J(be=>be+1);return he.forEach(be=>be.addChangeListener?.(Se)),()=>{Ee.current=!1,Ae.current?.cancel?.(),he.forEach(be=>be.removeChangeListener?.(Se));};},[]);var _e=(he,Se={})=>n(r.Text,{style:{color:Te.text,fontSize:16,...Se}},he),rt=(he,Se,be=!1)=>n(r.Pressable,{accessibilityRole:"button",accessibilityLabel:he,disabled:be,onPress:Se,style:{padding:14,borderRadius:8,backgroundColor:be?"#555967":"#5865f2",marginTop:12}},_e(he,{color:"#ffffff",fontWeight:"600",textAlign:"center"})),je={color:Te.text,backgroundColor:Te.input,borderRadius:8,padding:12,fontSize:16,marginTop:10},Ge=()=>{if(!we.current){we.current=!0,Ae.current?.cancel?.();try{r.Keyboard?.dismiss?.();}catch{}(B??(()=>M.hideActionSheet(c)))();}},nt=()=>{if(!U){Ge(),G(q,D,k.trim());return;}if(!Pe()||Ue.current)return;if(y){pe("A sticker upload is already in progress. You can close this page while it finishes.");return;}try{r.Keyboard?.dismiss?.();}catch{}Ue.current=!0,fe(!0),pe("");var he={controller:typeof AbortController=="function"?new AbortController():void 0};Ae.current=he,G(q,D,k.trim(),{control:he,isCurrent:Pe,onError:pe,onSuccess:Ge,onFinished(){Ae.current===he&&(Ae.current=void 0,Ue.current=!1,fe(!1));}});},Ze=D?n(r.Image,{source:{uri:D.url},resizeMode:"contain",accessibilityLabel:"Sticker preview",style:{width:26,height:26,marginRight:12}}):null,vt=q?"Sticker name":D?"Saving "+V(D.filename):"Choose image",lt=!F&&L?n(L,{onPress:Ge,accessibilityLabel:"Close"}):n(r.Pressable,{onPress:Ge,accessibilityRole:"button",accessibilityLabel:"Close",hitSlop:10,style:{width:40,height:40,alignItems:"center",justifyContent:"center"}},_e("\xD7",{fontSize:32,lineHeight:36})),gt=!F&&P?n(P,{title:vt,leading:Ze,trailing:lt}):n(r.View,{style:{flexDirection:"row",alignItems:"center",paddingHorizontal:28,minHeight:72}},Ze,n(r.Text,{numberOfLines:1,style:{flex:1,color:Te.text,fontSize:20,fontWeight:"600",textAlign:"center",paddingHorizontal:8}},vt),lt),xt=Math.min(640,(r.Dimensions?.get?.("window")?.height??800)*.62);function yt(he){if(oe)return n(oe,{guild:he,size:W?.MEDIUM,animate:!1});if(he.icon)return n(r.Image,{source:{uri:"https://cdn.discordapp.com/icons/"+he.id+"/"+he.icon+".png?size=96"},style:{width:44,height:44,borderRadius:14},resizeMode:"cover"});var Se=String(he.name).trim().split(/\s+/).map(be=>be[0]).join("").slice(0,3);return n(r.View,{style:{width:44,height:44,borderRadius:14,backgroundColor:"#5865f2",alignItems:"center",justifyContent:"center"}},_e(Se,{color:"#ffffff",fontWeight:"600"}));}function wt(he){var Se=re(he),be=Se.used!=null&&Se.used>=Se.max,He=be?"No slots available":Se.used==null?"Check slots on upload":void 0,Qe=()=>{if(U&&(!Pe()||ee))return;var ft=v("GuildStore")?.getGuild?.(he.id)??he,ht=re(ft);!ne(ft)||ht.used!=null&&ht.used>=ht.max||(ie(ft),pe(""));},Be=p("ic_add_24px","PlusSmallIcon","PlusIcon"),mt=N.FormIcon&&Be!=null?n(N.FormIcon,{source:Be,style:{opacity:1}}):_e("+",{color:Te.muted,fontSize:30,fontWeight:"300"});return N.FormRow?n(N.FormRow,{key:he.id,leading:yt(he),label:he.name,subLabel:He,trailing:mt,disabled:be,onPress:Qe,accessibilityLabel:he.name,accessibilityRole:"button",accessibilityState:{disabled:be}}):n(r.Pressable,{key:he.id,accessibilityRole:"button",accessibilityLabel:he.name,accessibilityState:{disabled:be},disabled:be,onPress:Qe,style:{minHeight:80,paddingHorizontal:32,flexDirection:"row",alignItems:"center",opacity:be?.4:1}},yt(he),n(r.View,{style:{flex:1,marginLeft:18,marginRight:16}},_e(he.name,{fontWeight:"600",fontSize:18}),He?_e(He,{color:Te.muted,fontSize:13,marginTop:3}):null),mt);}if(D&&!q){var he=Z().filter(Be=>`${Be.name}
${Be.id}`.toLowerCase().includes(ge.trim().toLowerCase())),Se=n(r.View,{style:{padding:24}},_e(ge.trim()?"No servers match your search.":"No servers available. You need Create Expressions permission to add a sticker.",{color:Te.muted,fontSize:14})),be=F?r.FlatList:X,He=be?n(be,{style:{flex:1},contentContainerStyle:{paddingBottom:32},data:he,keyboardShouldPersistTaps:"handled",keyboardDismissMode:"on-drag",nestedScrollEnabled:!0,removeClippedSubviews:!1,initialNumToRender:12,renderItem:({item:Be})=>wt(Be),keyExtractor:Be=>Be.id,extraData:he.map(Be=>Be.id+":"+re(Be).used).join(","),ListEmptyComponent:Se}):n(r.ScrollView,{style:{flex:1},contentContainerStyle:{paddingBottom:32}},he.length?he.map(wt):Se),Qe=n(r.View,{style:F?{flex:1,minHeight:0}:{height:xt}},gt,n(r.TextInput,{accessibilityLabel:"Search servers",placeholder:"Search server name or ID",placeholderTextColor:Te.muted,value:ge,onChangeText:I,autoCorrect:!1,autoCapitalize:"none",style:{...je,marginHorizontal:20,marginBottom:12}}),He);return F?Qe:n(K,{scrollable:!1},Qe);}var ct;if(!D)ct=d.map((he,Se)=>n(r.Pressable,{key:he.url,accessibilityRole:"button",accessibilityLabel:"Use image "+(Se+1),onPress:()=>{$(he),H(V(he.filename));},style:{flexDirection:"row",alignItems:"center",gap:12,paddingVertical:10}},n(r.Image,{source:{uri:he.url},style:{width:64,height:64},resizeMode:"contain"}),_e(he.filename,{flex:1})));else{var _he=k.trim().length>=2&&k.trim().length<=30&&!/[\u0000-\u001f]/.test(k);ct=n(r.View,null,n(r.Image,{source:{uri:D.url},style:{height:128,width:"100%",marginBottom:12},resizeMode:"contain"}),_e("Server: "+q.name,{fontWeight:"600"}),_e("Sticker name",{marginTop:12}),n(r.TextInput,{value:k,onChangeText:H,maxLength:30,placeholder:"Sticker name",placeholderTextColor:Te.muted,style:je,selectTextOnFocus:!0,editable:!ee}),_e(D.contentType==="image/gif"?"GIFs keep their animation and resize automatically. Maximum 5 seconds and 512 KiB.":"Images fit inside 320\xD7320 with transparent padding. GIFs keep their animation.",{color:Te.muted,fontSize:13,marginTop:12}),rt("Add sticker",nt,!_he||ee),ee?_e("Preparing and adding your sticker\u2026",{color:Te.muted,marginTop:12}):null,te?_e(te,{color:"#e66b70",marginTop:12}):null,rt("Choose another server",()=>{ie(null),pe("");},ee));}var Rt=n(r.View,{style:F?{flex:1,minHeight:0}:{}},gt,n(r.ScrollView,{keyboardShouldPersistTaps:"handled",keyboardDismissMode:"on-drag",style:F?{flex:1}:{maxHeight:xt},contentContainerStyle:{padding:20,paddingBottom:40}},ct));return F?Rt:n(K,{scrollable:!1},Rt);}function ue(d,B){if(!x||m)return;if(e.host?.id==="valenced"){var S={session:_};m=S;var D=()=>{S.closed=!0,m===S&&(m=void 0);},$=()=>x&&_===S.session&&!S.closed&&m===S;try{M.hideActionSheet(B);}catch{}var q=e.ui.components?.ErrorBoundary;if(a.open((ie,k)=>{var H=n(O,{images:d,onClose:ie,inPanel:!0,page:!0,isOpen:()=>$()&&k()});return q?n(q,null,H):H;},D))return;D(),w("Save as Sticker could not open. Restart Discord and reopen the image menu.");return;}if(y){w("A sticker upload is already in progress.");return;}if(s.open(S=>n(O,{images:d,onClose:S,inPanel:!0}),"sticker picker")){M.hideActionSheet(B);return;}if(!K){w("The server picker is unavailable on this Discord build.");return;}M.hideActionSheet(B);var F=e.ui.components?.ErrorBoundary,U=()=>{var S=n(O,{images:d});return F?n(F,null,S):S;};M.openLazy(Promise.resolve({default:U}),c,{});}function se(d,B){var F=p("StickerIcon","ic_sticker_24px");return n(E,{key:h,label:"Save as Sticker",icon:E.Icon&&F!=null?n(E.Icon,{source:F}):void 0,iconSource:E.Icon?void 0:F,onPress:()=>ue(d,B)});}function de(d,B,F){var U=null,S=-1,D=!1,$=I=>String(I?.props?.label??I?.props?.message??""),q=I=>I?.props&&typeof I.props.onPress=="function"&&(I.type===E||I.props.label!=null||I.props.message!=null);function ie(I,ee=0){if(!(!I||ee>40))if(Array.isArray(I)){var fe=I.filter(q);if(fe.length){var te=fe.some(pe=>/save image/i.test($(pe)))?1e3:fe.some(pe=>/copy image link/i.test($(pe)))?900:10;te+fe.length>S&&(U=I,S=te+fe.length);}I.forEach(te=>ie(te,ee+1));}else I.props&&((I.key===h||$(I)==="Save as Sticker")&&(D=!0),ie(I.props.children,ee+1));}if(ie(d),D||!U)return d;var k=se(B,F),H=U.findIndex(I=>/save image/i.test($(I))),J=H>=0?H+1:U.length;function ge(I){if(I===U)return[...U.slice(0,J),k,...U.slice(J)];if(Array.isArray(I)){var ee=I.map(ge);return ee.some((fe,te)=>fe!==I[te])?ee:I;}if(I?.props?.children!=null){var _ee=ge(I.props.children);return _ee!==I.props.children?t.cloneElement(I,{children:_ee}):I;}return I;}return ge(d);}function Fe(d,B,F,U){var S=(D,$)=>{if(!x||_!==U)return $;try{var q=xe(D,B);return q.length?de($,q,F):$;}catch(q){return R("Could not add image menu action",q),$;}};return typeof d=="function"&&!d.prototype?.isReactComponent?function(...$){return S($[0],d.apply(this,$));}:d?.$$typeof===Symbol.for("react.memo")?t.memo(Fe(d.type,B,F,U),d.compare):d?.$$typeof===Symbol.for("react.forward_ref")?t.forwardRef((D,$)=>S(D,d.render(D,$))):d;}function Re(){if(!M?.openLazy||!E||!K&&e.host?.id!=="valenced"||!v("GuildStore"))throw new Error("SaveAsSticker: required menu modules were not found on this Discord build.");x||(x=!0,_++,b.push(e.patcher.before("openLazy",M,d=>{var[B,F,U]=d;if(F!=="MessageLongPressActionSheet"&&F!=="MediaShareActionSheet"||!B?.then)return;var S=_;d[0]=Promise.resolve(B).then(D=>!x||S!==_||!D?.default?D:{...D,default:Fe(D.default,U,F,S)});})),w("SaveAsSticker enabled"));}function C(){x=!1,_++,m=void 0,a.closeAll(),s.closeAll();for(var d of T)d.cancel?.(!0);T.clear(),y=!1;for(var _d of b.splice(0).reverse())try{_d();}catch{}try{M?.hideActionSheet?.(c);}catch{}}return{onLoad:Re,onUnload:C};})();
return module.exports.default;
})()
}, "SaveAsSticker");
})()
); }, {"id": "dev.fluttershy2008.save-as-sticker", "legacyManifest": {"name": "SaveAsSticker", "description": "Save images and animated GIFs as server stickers. Pick a server, name your sticker, and automatically resize GIFs while keeping them animated.", "version": "1.3.7", "authors": [{"name": "Fluttershy2008-mlp"}], "main": "index.js", "vendetta": {"icon": "ic_sticker_24px"}, "hash": "70737fb825ab4a25969817d08c6c68f6e0336468372c10f02835daf2e62b9ea8"}, "repository": "https://fluttershy2008-mlp.github.io/lol/index.json"}) };
})()
