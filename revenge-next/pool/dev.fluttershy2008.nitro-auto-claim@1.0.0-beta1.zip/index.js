(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Revenge Next API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the Revenge Next plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    function findByProps(...props) {
        return finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.next.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: () => findByProps('HTTP')?.HTTP ?? findByProps('get', 'post', 'patch', 'del'),
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        General: Object.assign(Object.create(RN), { Button: design.Button }),
        Forms: { FormRow: design.TableRow, FormSection: design.TableRowGroup, FormSwitchRow: design.TableSwitchRow,
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const list = await U.modules.native.callNativeMethod('revenge.plugins.list', []);
        if (!active || !Array.isArray(list)) return;
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list) {
            const manifest = item.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            const entry = { id: item.source?.repo ?? metadata.repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.['revenge.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: api.logger,
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch: (...args) => host.fetch(...args),
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createNextPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false };
            running = state;
            async function stop() {
                if (state.stopped) return;
                state.stopped = true;
                try { await state.legacy?.onUnload?.(); }
                finally { await bridge.dispose(); if (running === state) running = undefined; }
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createNextPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}
return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
'use strict';
// Copyright (c) 2026 Fluttershy2008-mlp. SPDX-License-Identifier: MIT

function extractCodes(content) {
  if (typeof content !== 'string') return [];
  // A separator before the host prevents suffix domains, userinfo and nested
  // redirect URLs from being treated as genuine gift links.
  const pattern = /(?:^|[\s<(\["'])(?:https:\/\/)?(?:discord\.gift\/|(?:www\.)?discord(?:app)?\.com\/gifts\/)([A-Za-z0-9]{16,24})(?=$|[\s>)\]"'.,!?&#])/g;
  return [...new Set(Array.from(content.matchAll(pattern), match => match[1]))];
}

function createPlugin(V, clock = globalThis) {
  const storage = V.plugin.storage;
  const { React, ReactNative: RN } = V.metro.common;
  const listeners = new Set();
  const cleanup = [];
  let running = false, generation = 0, busy = false, owner = null;
  let started = 0, ready = true, blocked = false, nextRequest = 0;
  let timer = null, api, dispatcher, userStore, icon;
  const queue = [];
  let status = 'Plugin is disabled';
  if (typeof storage.enabled !== 'boolean') storage.enabled = true;
  if (typeof storage.ignoreOwn !== 'boolean') storage.ignoreOwn = true;
  if (typeof storage.notifications !== 'boolean') storage.notifications = true;
  if (!storage.accounts || typeof storage.accounts !== 'object') storage.accounts = {};

  const now = () => clock.Date?.now?.() ?? Date.now();
  const props = (...keys) => { try { return V.metro.findByProps(...keys); } catch { return null; } };
  const changed = () => { for (const listener of listeners) { try { listener(); } catch {} } };
  const setStatus = value => { status = value; changed(); };
  const current = () => { try { return userStore?.getCurrentUser?.()?.id || null; } catch { return null; } };
  const data = id => storage.accounts[id] ?? { seen: [], history: [] };
  const save = (id, value) => { storage.accounts = { ...storage.accounts, [id]: value }; };
  const notify = text => {
    if (!storage.notifications) return;
    try { V.ui?.toasts?.showToast?.(text, icon); } catch {}
  };
  function record(job, result, detail) {
    const account = data(job.account);
    save(job.account, { ...account, history: [
      { at: now(), result, detail, channelId: job.channelId, messageId: job.messageId },
      ...(account.history ?? []),
    ].slice(0, 50) });
    changed();
    if (current() === job.account) notify(`Nitro Auto Claim: ${detail}`);
  }
  function cancelQueue() {
    queue.length = 0;
    if (timer != null) clock.clearTimeout(timer);
    timer = null;
    changed();
  }
  function accountChanged() {
    const id = current();
    if (id !== owner) { cancelQueue(); owner = id; started = now(); }
    return id;
  }
  function classify(error) {
    const body = error?.body ?? error?.response?.body ?? {};
    const statusCode = Number(error?.status ?? error?.statusCode ?? error?.response?.status);
    if (statusCode === 429) return ['paused', 'Rate limited. Auto claim paused; try again later.'];
    if (statusCode === 401 || statusCode === 403 || body.captcha_key) return ['paused', 'Discord requires manual action. Auto claim paused.'];
    if (body.code === 10038 || statusCode === 404) return ['failed', 'Gift is invalid or expired.'];
    if (body.code === 50050 || body.code === 50051) return ['failed', 'Gift was already claimed.'];
    if (body.code === 50054) return ['failed', 'This account cannot redeem that gift.'];
    // Do not save raw error objects: they can contain request/session details.
    return ['failed', 'Could not claim gift. Check the original link in Discord.'];
  }
  function request(job) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const timeout = clock.setTimeout(() => {
        if (settled) return;
        settled = true;
        reject({ status: 429, timeout: true });
      }, 20000);
      const finish = (fn, value) => {
        if (settled) return;
        settled = true; clock.clearTimeout(timeout); fn(value);
      };
      try {
        // Discord's existing REST client supplies authentication. No token is
        // read, stored, requested from the user or sent to another service.
        const promise = api.post({
          url: `/entitlements/gift-codes/${job.code}/redeem`,
          body: { channel_id: job.channelId, payment_source_id: null },
          oldFormErrors: true,
        });
        if (!promise || typeof promise.then !== 'function') {
          finish(reject, { timeout: true }); return;
        }
        promise.then(response => {
          if (response?.ok === false || Number(response?.status) >= 400) finish(reject, response);
          else if (response && (response.ok === true || Number(response.status) >= 200 && Number(response.status) < 300 || response.body)) finish(resolve, response);
          else finish(reject, { timeout: true });
        }, error => finish(reject, error));
      } catch (error) { finish(reject, error); }
    });
  }
  function pump() {
    if (!running || busy || blocked || !ready || !storage.enabled) return;
    if (!accountChanged() || !queue.length) return;
    if (nextRequest > now()) {
      if (timer == null) timer = clock.setTimeout(() => { timer = null; pump(); }, nextRequest - now());
      return;
    }
    const job = queue.shift();
    if (job.account !== current()) { pump(); return; }
    const account = data(job.account);
    // Persist before sending so a reload or repeated embed never replays it.
    save(job.account, { ...account, seen: [...(account.seen ?? []), job.code].slice(-1000) });
    busy = true;
    const run = generation;
    setStatus('Attempting to claim a gift…');
    request(job).then(() => {
      if (!running || run !== generation) return;
      record(job, 'claimed', 'Gift claimed successfully!');
      setStatus('Watching for new gift links');
    }, error => {
      if (!running || run !== generation) return;
      const [result, detail] = error?.timeout
        ? ['paused', 'Request outcome is unknown. Auto claim paused; check the gift manually.']
        : classify(error);
      if (result === 'paused') {
        blocked = true; storage.enabled = false; cancelQueue();
      }
      record(job, result, detail);
      setStatus(detail);
    }).finally(() => {
      busy = false;
      if (!running) return;
      nextRequest = now() + 1500; changed(); pump();
    });
  }
  function message(event, edited = false) {
    if (!running || !ready || blocked || !storage.enabled || event?.optimistic) return;
    const account = accountChanged();
    const m = event?.message;
    if (!account || !m || !/^\d+$/.test(String(m.id)) || !/^\d+$/.test(String(m.channel_id))) return;
    if (m.state && m.state !== 'SENT') return;
    if (storage.ignoreOwn && (!m.author?.id || m.author.id === account)) return;
    const timestamp = new Date(edited ? m.edited_timestamp : m.timestamp).getTime();
    // History loads and old messages never trigger claims. MESSAGE_UPDATE must
    // carry a new edited timestamp, so an embed refresh cannot replay history.
    if (!Number.isFinite(timestamp) || timestamp < started) return;
    for (const code of extractCodes(m.content)) {
      if ((data(account).seen ?? []).includes(code) || queue.some(job => job.account === account && job.code === code)) continue;
      if (queue.length >= 20) { setStatus('Gift queue is full; additional links were skipped.'); break; }
      queue.push({ code, account, channelId: String(m.channel_id), messageId: String(m.id) });
    }
    changed();
    // Leave Flux dispatch before starting a REST call.
    if (timer == null && queue.length) timer = clock.setTimeout(() => { timer = null; pump(); }, 0);
  }
  function subscribe(type, callback) {
    dispatcher.subscribe(type, callback);
    cleanup.push(() => dispatcher.unsubscribe(type, callback));
  }
  function onLoad() {
    if (running) return;
    dispatcher = V.metro.common.FluxDispatcher ?? props('dispatch', 'subscribe');
    try { userStore = V.metro.findByStoreName('UserStore'); } catch {}
    userStore ??= props('getCurrentUser', 'getUser');
    api = props('getAPIBaseURL', 'get', 'post');
    if (!api?.post || !dispatcher?.subscribe || !dispatcher?.unsubscribe || !userStore?.getCurrentUser) {
      throw new Error('Nitro Auto Claim: Discord modules unavailable on this version.');
    }
    running = true; generation++; ready = true; blocked = false;
    started = now(); owner = current(); nextRequest = 0;
    try { icon = V.ui?.assets?.getAssetIDByName?.('GiftIcon'); } catch {}
    try {
      subscribe('MESSAGE_CREATE', event => message(event));
      subscribe('MESSAGE_UPDATE', event => message(event, true));
      for (const type of ['CONNECTION_CLOSED', 'CONNECTION_INTERRUPTED', 'LOGOUT', 'LOGOUT_START', 'LOGIN_SUCCESS']) {
        subscribe(type, () => { ready = false; cancelQueue(); setStatus('Waiting for Discord to connect'); });
      }
      for (const type of ['CONNECTION_OPEN', 'CONNECTION_RESUMED']) {
        subscribe(type, () => { accountChanged(); ready = true; started = now(); setStatus(storage.enabled ? 'Watching for new gift links' : 'Auto claim is paused'); });
      }
      setStatus(storage.enabled ? 'Watching for new gift links' : 'Auto claim is paused');
    } catch (error) { onUnload(); throw error; }
  }
  function onUnload() {
    running = false; generation++; cancelQueue();
    for (const dispose of cleanup.splice(0).reverse()) { try { dispose(); } catch {} }
    setStatus('Plugin is disabled');
  }
  function toggle(value) {
    // Never resume while a request is unresolved.
    if (value && busy) { notify('Wait for the current gift request to finish.'); return; }
    storage.enabled = value; blocked = false; started = now(); cancelQueue();
    setStatus(value ? 'Watching for new gift links' : 'Auto claim is paused');
  }
  function settings() {
    const h = React.createElement;
    const [, refresh] = React.useState(0);
    React.useEffect(() => { const listener = () => refresh(n => n + 1); listeners.add(listener); return () => listeners.delete(listener); }, []);
    const dark = RN.useColorScheme?.() !== 'light';
    const color = dark ? '#f4f4f5' : '#202124', muted = dark ? '#b5bac1' : '#595f68';
    const text = (value, style = {}) => h(RN.Text, { style: { color, fontSize: 15, lineHeight: 21, ...style } }, value);
    const note = value => text(value, { color: muted, marginVertical: 8 });
    const row = (title, value, action) => h(RN.View, { style: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14 } },
      h(RN.View, { style: { flex: 1 } }, text(title)), h(RN.Switch, { accessibilityLabel: title, value, onValueChange: action }));
    const history = owner ? data(owner).history ?? [] : [];
    return h(RN.ScrollView, { style: { flex: 1, backgroundColor: dark ? '#18191c' : '#fff' }, contentContainerStyle: { padding: 18, paddingBottom: 60 } },
      text('Nitro Auto Claim', { fontSize: 24, fontWeight: '700', lineHeight: 30 }),
      note(status), note(owner ? `Current account: <@${owner}>` : 'Waiting for a signed-in account'),
      row('Automatically claim new gift links', storage.enabled, toggle),
      row('Ignore my own gift links', storage.ignoreOwn, value => { storage.ignoreOwn = value; changed(); }),
      row('Show result notifications', storage.notifications, value => { storage.notifications = value; changed(); }),
      note('Watches new messages and new edits in servers and DMs received by this app. Claims use the account shown above. Revenge must be running and connected.'),
      note('Already claimed, expired and ineligible gifts cannot be redeemed. Payment, verification and promotional trial links require manual action.'),
      text('Recent attempts', { fontSize: 19, fontWeight: '700', marginTop: 18 }),
      history.length ? null : note('No gifts attempted yet.'),
      ...history.map((entry, index) => h(RN.View, { key: `${entry.at}:${index}`, style: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: dark ? '#333' : '#ddd' } },
        text(entry.detail), note(new Date(entry.at).toLocaleString()),
      )),
      h(RN.Pressable ?? RN.TouchableOpacity, { accessibilityRole: 'button', onPress: () => {
        if (owner) save(owner, { ...data(owner), history: [] }); changed();
      }, style: { paddingVertical: 18 } }, text('Clear history', { color: '#8992ff' })),
      note('Clearing history keeps duplicate protection. Version 1.0.0'),
    );
  }
  return { onLoad, onUnload, settings };
}

return createPlugin(vendetta);
})()
}, "Nitro Auto Claim");
})()
); }, {"id": "dev.fluttershy2008.nitro-auto-claim", "legacyManifest": {"name": "Nitro Auto Claim", "description": "Automatically attempts to redeem Discord gift links in new messages, with duplicate protection and result history.", "version": "1.0.2", "authors": [{"name": "Fluttershy2008-mlp", "id": "753962426407452713"}], "main": "index.js", "vendetta": {"icon": "GiftIcon"}, "hash": "dab8745668cf14dd2674916f0f8e43d72c2cb85b742e5ccb55df3f3ca1761924"}, "repository": "https://raw.githubusercontent.com/Fluttershy2008-mlp/lol/main/revenge-next/index.json"}) };
})()
