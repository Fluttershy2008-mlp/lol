(() => {
// SPDX-License-Identifier: MIT
// Per-plugin adapter for the documented Revenge Next API. No globals are replaced.
'use strict';

function createLegacyAdapter(api, metadata, host = globalThis) {
    const U = api.unscoped;
    const { React, ReactNative: RN } = U.react;
    const finders = U.modules.finders;
    const filters = finders.filters;
    if (!React?.createElement || !RN || !finders.lookupModule || !U.patcher.instead)
        throw new Error('This package requires the Revenge Next plugin API.');
    const disposers = new Set();
    const timeouts = new Set();
    const intervals = new Set();
    const listeners = new Set();
    const ownedCommands = new Set();
    const requests = new Set();
    let active = true, revision = 0, scheduled = false, writes = Promise.resolve();
    const log = (...args) => api.logger?.error?.(...args);
    const safe = fn => { try { return fn(); } catch { return undefined; } };
    const own = fn => {
        let current = fn;
        const remove = () => {
            if (!current) return;
            const dispose = current; current = undefined; disposers.delete(remove);
            try { dispose(); } catch (error) { log(error); }
        };
        if (active) disposers.add(remove); else remove();
        return remove;
    };
    const rawFind = (...props) => finders.lookupModule(filters.withProps(...props), { initialize: false })[0];
    const hasProps = (value, props) => value && props.every(key => safe(() => value[key] != null));
    // Discord has shipped both flat REST exports and { HTTP, getAPIBaseURL }.
    // Bind each method to its actual owner; a spread loses lazy getters/receivers.
    let httpSource, httpFacade;
    function legacyHTTP() {
        const source = rawFind('HTTP');
        if (!source?.HTTP) return rawFind('get', 'post', 'del');
        if (source === httpSource) return httpFacade;
        httpSource = source;
        httpFacade = new Proxy({}, {
            get(_target, key) {
                const owner = source.HTTP[key] != null ? source.HTTP : source;
                const value = owner[key];
                return typeof value === 'function' ? value.bind(owner) : value;
            },
            has: (_target, key) => key in source.HTTP || key in source,
        });
        return httpFacade;
    }
    const navigationWrappers = new WeakMap();
    let navigationSource, navigationModule;
    const legacyRoute = metadata.id + '.legacy-page';
    let routeRegistered = false, routeWaiting = false;
    function LegacyPage({ route }) {
        const Page = route?.params?.render;
        return active && typeof Page === 'function' ? React.createElement(Page) :
            React.createElement(RN.Text, { style: { padding: 20 } }, 'Reopen this page from the enabled plugin.');
    }
    function openLegacyPage(navigation, params) {
        if (!active) return;
        if (typeof params?.render !== 'function') throw new Error('The plugin page has no renderer.');
        const settings = U.discord.modules?.settings;
        if (!settings?.onSettingsModulesLoaded || !settings.registerSettingsItem)
            throw new Error('Update Revenge Next to open this plugin page.');
        const navigate = () => setTimeoutScoped(() => {
            const open = () => { if (active) navigation.navigate(legacyRoute, params); };
            if (navigation.isReady?.() === false && navigation.addListener) {
                let remove;
                const ready = () => { remove?.(); open(); };
                const unsubscribe = navigation.addListener('ready', ready);
                remove = own(typeof unsubscribe === 'function' ? unsubscribe : () => navigation.removeListener?.('ready', ready));
            } else open();
        }, 0);
        if (routeRegistered) return navigate();
        if (routeWaiting) return;
        routeWaiting = true;
        own(settings.onSettingsModulesLoaded(() => {
            if (!active) return;
            const unregister = settings.registerSettingsItem(legacyRoute, {
                type: 'route', parent: metadata.id, unsearchable: true,
                useTitle: () => metadata.legacyManifest.name,
                screen: { route: legacyRoute, getComponent: () => LegacyPage },
            });
            routeRegistered = true;
            own(() => { unregister(); routeRegistered = false; settings.refreshSettings(); });
            settings.refreshSettings();
            navigate();
        }));
    }
    function wrapNavigation(navigation) {
        if (!navigation || typeof navigation !== 'object') return navigation;
        if (navigationWrappers.has(navigation)) return navigationWrappers.get(navigation);
        const wrapper = new Proxy(navigation, {
            get(target, key) {
                if (key === 'navigate') return function (route, params, ...rest) {
                    const name = typeof route === 'object' ? route?.name : route;
                    if (name === 'BUNNY_CUSTOM_PAGE') return openLegacyPage(target, typeof route === 'object' ? route.params : params);
                    return target.navigate(route, params, ...rest);
                };
                const value = Reflect.get(target, key, target);
                return typeof value === 'function' ? value.bind(target) : value;
            },
        });
        navigationWrappers.set(navigation, wrapper); return wrapper;
    }
    function legacyNavigation() {
        const source = rawFind('getRootNavigationRef') ?? U.discord.modules?.mainTabsV2?.RootNavigationRef;
        if (!source) return;
        if (source === navigationSource) return navigationModule;
        navigationSource = source;
        navigationModule = new Proxy(source, { get(target, key) {
            if (key === 'getRootNavigationRef') return () => wrapNavigation(target.getRootNavigationRef());
            const value = Reflect.get(target, key, target);
            return typeof value === 'function' ? value.bind(target) : value;
        } });
        return navigationModule;
    }
    function findByProps(...props) {
        if (props.includes('getRootNavigationRef')) {
            const navigation = legacyNavigation();
            if (hasProps(navigation, props)) return navigation;
        }
        const found = rawFind(...props);
        if (found) return found;
        if (props.some(p => ['get', 'post', 'put', 'patch', 'del', 'getAPIBaseURL'].includes(p))) {
            const http = legacyHTTP();
            if (hasProps(http, props)) return http;
        }
        // Use Next's curated modules when the corresponding Metro barrel is lazy.
        for (const get of [() => U.discord.design.Design, () => U.discord.actions.ActionSheetActionCreators,
            () => U.discord.actions.AlertActionCreators]) {
            const candidate = safe(get);
            if (hasProps(candidate, props)) return candidate;
        }
    }
    function custom(predicate, label) {
        return filters.createFilterGenerator(
            (_, id, value) => Boolean(safe(() => predicate(value, id))),
            () => 'fluttershy.next.' + metadata.id + '.' + label,
        )();
    }
    let sequence = 0;
    const metro = {
        findByProps,
        findByPropsAll: (...props) => [...finders.lookupModules(filters.withProps(...props), { initialize: false })].map(x => x[0]),
        findByName: (name, defaultExport = true) => finders.lookupModule(filters.withName(name),
            { initialize: false, returnNamespace: !defaultExport })[0],
        findByTypeName: name => finders.lookupModule(custom(m => m?.type?.name === name || m?.type?.displayName === name,
            'type.' + name), { initialize: false })[0],
        findByDisplayName: (name, defaultExport = true) => finders.lookupModule(custom(m => m?.displayName === name,
            'display.' + name), { initialize: false, returnNamespace: !defaultExport })[0],
        findByStoreName: name => U.discord.flux.Stores[name],
        find: (predicate, defaultExport = true) => finders.lookupModule(custom(predicate, 'custom.' + sequence++),
            { cached: false, initialize: false, returnNamespace: !defaultExport })[0],
        findAll: predicate => [...finders.lookupModules(custom(predicate, 'all.' + sequence++),
            { cached: false, initialize: false })].map(x => x[0]),
    };
    // More Alts deliberately inspects initialized records instead of executing
    // arbitrary Metro factories. Supply that legacy view using Next's finders.
    let initialized = new Map();
    metro.modules = new Proxy({}, {
        ownKeys() {
            const navigation = legacyNavigation(), http = legacyHTTP();
            initialized = new Map([...finders.lookupModules(custom(() => true, 'initialized'),
                { cached: false, initialize: false, returnNamespace: true })].map(([value, id]) => [String(id),
                    navigation && value === navigationSource ? navigation : navigation && safe(() => value.default === navigationSource)
                        ? { __esModule: true, default: navigation } : value]));
            if (navigation) initialized.set('next.navigation', navigation);
            if (http) initialized.set('next.http', http);
            return [...initialized.keys()];
        },
        get: (_target, key) => initialized.has(key) ? { isInitialized: true, publicModule: { exports: initialized.get(key) } } : undefined,
        getOwnPropertyDescriptor: (_target, key) => initialized.has(key) ? { enumerable: true, configurable: true } : undefined,
    });
    function patch(kind, key, parent, hook, once) {
        if (!active) return () => {};
        if (typeof parent?.[key] !== 'function') throw new Error('Unavailable Discord method: ' + key);
        let remove, used = false;
        remove = own(U.patcher.instead(parent, key, function (args, original) {
            if (!active || (once && used)) return Reflect.apply(original, this, args);
            used = true;
            try {
                if (kind === 'instead') return hook.call(this, args, original);
                if (kind === 'before') {
                    const replacement = hook.call(this, args);
                    return Reflect.apply(original, this, Array.isArray(replacement) ? replacement : args);
                }
                const result = Reflect.apply(original, this, args);
                const replacement = hook.call(this, args, result);
                return replacement === undefined ? result : replacement;
            } finally { if (once) remove?.(); }
        }));
        return remove;
    }
    const patcher = Object.fromEntries(['before', 'after', 'instead'].map(kind =>
        [kind, (key, parent, hook, once) => patch(kind, key, parent, hook, once)]));

    // Work against a private copy: Next's cache must only be changed with set().
    const raw = JSON.parse(JSON.stringify(api.jsonStorage.cache ?? {}));
    const proxies = new WeakMap();
    const rawValues = new WeakMap();
    function notify() {
        revision++;
        for (const listener of [...listeners]) { try { listener(); } catch (error) { log(error); } }
        if (!scheduled) {
            scheduled = true;
            Promise.resolve().then(() => { scheduled = false; flush(); });
        }
    }
    function flush() {
        const value = JSON.parse(JSON.stringify(raw));
        writes = writes.then(() => api.jsonStorage.set(value, true)).catch(error => { log('Could not save plugin settings', error); });
        return writes;
    }
    function proxify(value) {
        if (!value || typeof value !== 'object') return value;
        if (proxies.has(value)) return proxies.get(value);
        const proxy = new Proxy(value, {
            get: (target, key) => proxify(Reflect.get(target, key)),
            set(target, key, next) {
                if (!active) return true;
                next = rawValues.get(next) ?? next;
                if (Object.is(target[key], next)) return true;
                const changed = Reflect.set(target, key, next);
                if (changed) notify();
                return changed;
            },
            deleteProperty(target, key) {
                if (!active) return true;
                const present = Object.hasOwn(target, key), changed = Reflect.deleteProperty(target, key);
                if (present && changed) notify();
                return changed;
            },
        });
        proxies.set(value, proxy); rawValues.set(proxy, value);
        return proxy;
    }
    const storage = proxify(raw);
    function useProxy(value) {
        const [, redraw] = React.useState(0);
        React.useEffect(() => {
            const onChange = () => redraw(revision);
            listeners.add(onChange);
            return () => listeners.delete(onChange);
        }, []);
        return value;
    }
    const common = { React, ReactNative: RN };
    const commonGetters = {
        FluxDispatcher: () => U.discord.common.flux.Dispatcher,
        Flux: () => rawFind('Store', 'connectStores') ?? U.discord.common.flux,
        constants: () => U.discord.common.constants.Constants,
        clipboard: () => U.externals.ReactNativeClipboard.Clipboard,
        RestAPI: legacyHTTP,
        commands: () => findByProps('getBuiltInCommands'),
        messageUtil: () => findByProps('sendMessage', 'receiveMessage') ?? findByProps('sendMessage'),
        i18n: () => findByProps('Messages', 'setLocale'),
        url: () => findByProps('openURL', 'openDeeplink'),
        stylesheet: () => U.discord.design.Design,
        lodash: () => findByProps('cloneDeep', 'isEqual'),
        moment: () => findByProps('isMoment'),
        chroma: () => findByProps('valid', 'rgb'),
        NavigationNative: () => U.externals.ReactNavigation?.ReactNavigationNative,
    };
    for (const [key, get] of Object.entries(commonGetters)) Object.defineProperty(common, key, { get, enumerable: true });
    metro.common = common;

    function showToast(message) {
        if (!active) return;
        const text = typeof message === 'string' ? message : String(message?.message ?? message?.text ?? message ?? '');
        if (typeof RN.ToastAndroid?.show === 'function') RN.ToastAndroid.show(text, RN.ToastAndroid.SHORT ?? 0);
        else api.logger?.log?.(text);
    }
    function findInTree(root, predicate, options = {}) {
        const seen = new Set();
        const walk = (value, depth) => {
            if (!value || typeof value !== 'object' || seen.has(value) || depth > (options.maxDepth ?? 40) || seen.size > 5000) return;
            seen.add(value);
            if (predicate(value)) return value;
            const keys = Array.isArray(value) ? Object.keys(value) : (options.walkable ?? Object.keys(value));
            for (const key of keys) {
                if (options.ignore?.includes(key)) continue;
                const match = walk(value[key], depth + 1);
                if (match) return match;
            }
        };
        return walk(root, 0);
    }
    const findInReactTree = (tree, predicate) => findInTree(tree, predicate, { walkable: ['props', 'children', 'child', 'sibling'] });
    const design = U.discord.design.Design;
    const h = React.createElement;
    function showConfirmationAlert(options) {
        const { title, content, confirmText = 'Confirm', cancelText = 'Cancel', onConfirm, onCancel } = options;
        const confirm = () => { if (active) Promise.resolve().then(() => onConfirm?.()).catch(log); };
        if (typeof content === 'string' || content == null) {
            return RN.Alert.alert(title, content ?? '', [
                { text: cancelText, style: 'cancel', onPress: () => active && onCancel?.() },
                { text: confirmText, style: options.confirmColor === 'red' ? 'destructive' : 'default', onPress: confirm },
            ]);
        }
        const alerts = U.discord.actions.AlertActionCreators;
        const key = metadata.id + '.alert.' + sequence++;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title, content, actions: h(RN.View, null,
            h(design.AlertActionButton, { text: cancelText, onPress: () => { close(); if (active) onCancel?.(); } }),
            h(design.AlertActionButton, { text: confirmText, onPress: () => { close(); confirm(); } })) }));
    }
    function showInputAlert(options) {
        function Input() {
            const [value, setValue] = React.useState(options.initialValue ?? '');
            return h(RN.View, { style: { padding: 12 } },
                h(RN.TextInput, { value, onChangeText: setValue, placeholder: options.placeholder, autoCapitalize: 'none' }),
                h(design.Button, { text: options.confirmText ?? 'Confirm', onPress: () => { close(); if (active) options.onConfirm?.(value); } }));
        }
        const key = metadata.id + '.input.' + sequence++, alerts = U.discord.actions.AlertActionCreators;
        const close = own(() => alerts.dismissAlert(key));
        alerts.openAlert(key, h(design.AlertModal, { title: options.title, content: h(Input) }));
    }
    const components = {
        // Define an own property so React Native's inherited getter is never
        // assigned to. Keep the other native exports lazy and unchanged.
        General: Object.create(RN, {
            Button: { value: design.Button, enumerable: true, writable: true, configurable: true },
        }),
        Forms: { FormRow: ({ leading, ...props }) => h(design.TableRow, { ...props, icon: props.icon ?? leading }),
            FormSection: design.TableRowGroup,
            FormSwitchRow: ({ leading, ...props }) => h(design.TableSwitchRow, { ...props, icon: props.icon ?? leading }),
            FormIcon: props => h(RN.Image, { ...props, style: [{ width: 24, height: 24 }, props.style] }),
            FormInput: design.TextInput, FormText: design.Text, FormDivider: RN.View },
        Button: design.Button,
    };
    if (React.Component) components.ErrorBoundary = class extends React.Component {
        constructor(props) { super(props); this.state = { error: null }; }
        static getDerivedStateFromError(error) { return { error }; }
        componentDidCatch(error) { log(error); }
        render() { return this.state.error ? h(RN.Text, { selectable: true }, String(this.state.error.message)) : this.props.children; }
    };
    function registerCommand(input) {
        if (!active) return () => {};
        const mod = common.commands;
        if (!mod?.getBuiltInCommands) throw new Error('Local commands are unavailable on this Discord version.');
        let builtIns;
        try { builtIns = mod.getBuiltInCommands(1, true, false); }
        catch { builtIns = mod.getBuiltInCommands([1, 2, 3], true, false); }
        const ids = (builtIns ?? []).map(c => Number(c.id)).filter(Number.isFinite);
        const id = String(Math.min(-1, ...ids) - 1);
        const command = { ...input, id, applicationId: '-1', type: input.type ?? 1, inputType: 1,
            displayName: input.displayName ?? input.name, untranslatedName: input.name,
            displayDescription: input.displayDescription ?? input.description, untranslatedDescription: input.description,
            options: (input.options ?? []).map(option => ({ ...option, displayName: option.displayName ?? option.name,
                displayDescription: option.displayDescription ?? option.description })),
            execute(...args) {
                if (!active || !ownedCommands.has(id)) return;
                return Promise.resolve().then(() => input.execute.apply(command, args)).then(result => {
                    if (active && ownedCommands.has(id) && result && typeof result === 'object') {
                        const channelId = args[1]?.channel?.id;
                        const send = common.messageUtil;
                        if (channelId && result.type === 4 && result.data) return sendLocalMessage(channelId, result.data);
                        if (channelId && send?.sendMessage) return send.sendMessage(channelId, result);
                    }
                }).catch(log);
            },
        };
        ownedCommands.add(id);
        const unpatch = patcher.after('getBuiltInCommands', mod, ([types], result) => {
            if (!active || !ownedCommands.has(id) || input.shouldHide?.() === false) return result;
            if (!(Array.isArray(types) ? types.includes(command.type) : types === command.type)) return result;
            return [...(result ?? []), command];
        });
        return own(() => { ownedCommands.delete(id); unpatch(); });
    }
    function sendLocalMessage(channelId, body, modifications) {
        if (!active) return;
        const actions = findByProps('receiveMessage'), factory = findByProps('createBotMessage');
        if (actions?.receiveMessage && factory?.createBotMessage) {
            const message = factory.createBotMessage({ ...body, channelId, channel_id: channelId });
            const author = message.author;
            Object.assign(message, modifications ?? {});
            if (modifications?.author) message.author = { ...author, ...modifications.author };
            actions.receiveMessage(channelId, message);
            return;
        }
        const bot = findByProps('sendBotMessage');
        if (bot?.sendBotMessage && typeof body.content === 'string' && !body.embeds?.length)
            return bot.sendBotMessage(channelId, body.content);
        throw new Error('Local message output is unavailable on this Discord build.');
    }
    const plugins = {}, themes = {};
    async function refreshRegistry() {
        const list = await U.modules.native.callNativeMethod('revenge.plugins.list', []);
        if (!active || !Array.isArray(list)) return;
        for (const registry of [plugins, themes]) for (const key of Object.keys(registry)) delete registry[key];
        for (const item of list) {
            const manifest = item.manifest;
            if (!manifest?.id) continue;
            const data = { ...manifest, authors: [manifest.author, ...(manifest.contributors ?? [])].filter(Boolean) };
            const entry = { id: item.source?.repo ?? metadata.repository, manifest: data, data,
                enabled: typeof item.enabled === 'boolean' ? item.enabled : undefined };
            if (manifest.dependencies?.['revenge.api.themes']) themes[manifest.id] = entry;
            else plugins[manifest.id] = entry;
        }
    }
    const adapter = {
        metro, patcher, logger: {
            ...api.logger,
            warn: (...args) => api.logger?.warn?.(...args),
            log: (...args) => api.logger?.log?.(...args),
            error(...args) {
                if (args.length <= 2 && typeof args.at(-1) === 'string' &&
                    /^(Blocked Users|Friends List|Server Leaver) shortcut is unavailable; the plugin settings page is still accessible\.$/.test(args.at(-1)))
                    api.logger?.warn?.(...args);
                else log(...args);
            },
        },
        plugin: { id: metadata.id, manifest: metadata.legacyManifest, storage },
        storage: { useProxy, awaitSyncWrapper: async value => {
            if (value === plugins || value === themes) await refreshRegistry();
            return value;
        } },
        commands: { registerCommand, sendLocalMessage }, plugins: { plugins }, themes: { themes },
        ui: { components, assets: { getAssetIDByName: name => U.assets.getAssetIdByName(name),
            getAssetByName: name => U.assets.getAssetByName(name) },
            toasts: { showToast }, alerts: { showConfirmationAlert, showInputAlert },
            semanticColors: safe(() => findByProps('unsafe_rawColors', 'colors')?.colors) ?? {},
        },
        utils: { findInTree, findInReactTree, safeFetch,
            unfreeze: value => ({ ...value }) },
    };
    function setTimeoutScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setTimeout(() => { timeouts.delete(id); if (active) fn(...args); }, delay);
        timeouts.add(id); return id;
    }
    function setIntervalScoped(fn, delay, ...args) {
        if (!active) return;
        const id = host.setInterval(() => { if (active) fn(...args); }, delay);
        intervals.add(id); return id;
    }
    function clearTimeoutScoped(id) { host.clearTimeout(id); timeouts.delete(id); }
    function clearIntervalScoped(id) { host.clearInterval(id); intervals.delete(id); }
    async function safeFetch(url, init = {}, timeout = 10000) {
        if (!active) throw new Error('Plugin is stopped.');
        if (init.signal?.aborted) throw init.signal.reason ?? new Error('Request aborted.');
        const controller = typeof host.AbortController === 'function' ? new host.AbortController() : undefined;
        let timer, rejectPending;
        const cancel = reason => { controller?.abort(reason); rejectPending(reason); };
        const abort = () => cancel(init.signal.reason ?? new Error('Request aborted.'));
        try {
            const cancelled = new Promise((_resolve, reject) => { rejectPending = reject; });
            requests.add(cancel);
            init.signal?.addEventListener?.('abort', abort, { once: true });
            if (init.signal?.aborted) abort();
            if (Number.isFinite(timeout) && timeout > 0)
                timer = setTimeoutScoped(() => cancel(new Error('Request timed out.')), timeout);
            return await Promise.race([cancelled, host.fetch(url, { ...init, ...(controller ? { signal: controller.signal } : {}) })]);
        } finally {
            clearTimeoutScoped(timer); requests.delete(cancel);
            init.signal?.removeEventListener?.('abort', abort);
        }
    }
    function dispose() {
        if (!active) return writes;
        active = false;
        for (const cancel of requests) cancel(new Error('Plugin is stopped.'));
        requests.clear();
        for (const id of timeouts) host.clearTimeout(id);
        for (const id of intervals) host.clearInterval(id);
        timeouts.clear(); intervals.clear(); ownedCommands.clear();
        for (const remove of [...disposers].reverse()) remove();
        listeners.clear();
        return flush();
    }
    return { adapter, dispose, flush, timers: [setTimeoutScoped, clearTimeoutScoped, setIntervalScoped, clearIntervalScoped] };
}

function createNextPlugin(factory, metadata, host = globalThis) {
    let running, epoch = 0;
    return {
        jsonStorage: { load: true, default: {} },
        async start(api) {
            const session = ++epoch;
            if (!api.jsonStorage.loaded) await api.jsonStorage.get();
            if (session !== epoch) return;
            const bridge = createLegacyAdapter(api, metadata, host);
            const state = { bridge, legacy: undefined, stopped: false };
            running = state;
            async function stop() {
                if (state.stopped) return;
                state.stopped = true;
                try { await state.legacy?.onUnload?.(); }
                finally { await bridge.dispose(); if (running === state) running = undefined; }
            }
            api.cleanup(stop);
            try {
                state.legacy = factory(bridge.adapter, ...bridge.timers);
                if (!state.legacy || typeof state.legacy !== 'object') throw new Error('Invalid legacy plugin exports.');
                await state.legacy.onLoad?.();
                if (session !== epoch || state.stopped) { await stop(); return; }
                if (api.plugin.startedLate) api.plugin.requireReload();
            } catch (error) { await stop(); throw error; }
        },
        stop() { epoch++; },
        SettingsComponent({ api }) {
            const React = api.unscoped.react.React;
            const Settings = running?.legacy?.settings;
            return Settings ? React.createElement(Settings) : React.createElement(api.unscoped.react.ReactNative.Text,
                { style: { padding: 20 }, selectable: true }, running
                    ? 'This plugin has no settings. Use its Discord menu items or commands.'
                    : 'Enable this plugin to open its settings.');
        },
    };
}


return { default: createNextPlugin(function(vendetta, setTimeout, clearTimeout, setInterval, clearInterval) { return (
(() => {
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
// SPDX-License-Identifier: CC0-1.0
// Shared by the separately installable Revenge bundles; no global API changes.
function withRevengeCompatibility(api, factory, pluginName) {
    var active = true;
    var generation = 0;
    var disposers = new Set();
    var warnings = new Set();
    var delayKey = Symbol.for('bunny.api.patcher.delay');
    var raw = api.patcher;
    function warn(message, error) {
        if (warnings.has(message)) return;
        warnings.add(message);
        try { api.logger?.warn?.('[' + pluginName + '] ' + message, error); } catch (_) {}
    }
    function clear() {
        active = false;
        generation++;
        Array.from(disposers).reverse().forEach(function (dispose) { dispose(); });
    }
    function patchKind(kind) {
        function patch(method, parent, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var unpatch;
            var unsubscribe;
            var uiPatch = method === 'render' || method === 'type' || method === 'default';
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                try { unsubscribe?.(); } catch (error) { warn('Could not cancel a module subscription.', error); }
                try { unpatch?.(); } catch (error) { warn('Could not remove a ' + method + ' patch.', error); }
            }
            if (!active) return dispose;
            disposers.add(dispose);
            function install(target) {
                if (cancelled || !active || epoch !== generation) return;
                try {
                    var owner = target;
                    var key = method;
                    // React memo/forwardRef exports are objects, not functions.
                    // Inspect the resolved module, not just the lazy proxy.
                    for (var depth = 0; uiPatch && depth < 8; depth++) {
                        var value = owner?.[key];
                        if (value?.$$typeof === Symbol.for('react.memo')) {
                            owner = value; key = 'type';
                        } else if (value?.$$typeof === Symbol.for('react.forward_ref')) {
                            owner = value; key = 'render';
                        } else break;
                    }
                    if (uiPatch && typeof owner?.[key] !== 'function') {
                        warn('Skipped unavailable Discord component method: ' + method);
                        dispose();
                        return;
                    }
                    var remove = raw[kind](key, owner, function () {
                        if (!active || cancelled || epoch !== generation) {
                            if (kind === 'after') return arguments[1];
                            if (kind === 'instead') return arguments[1].apply(this, arguments[0]);
                            return;
                        }
                        try { return callback.apply(this, arguments); }
                        finally { if (once) dispose(); }
                    });
                    // A module can synchronously unload the plugin while installing.
                    if (cancelled || !active || epoch !== generation) remove?.();
                    else unpatch = remove;
                } catch (error) {
                    dispose();
                    // Required data/action patches must still fail visibly.
                    // Only optional UI methods can safely be skipped.
                    if (!uiPatch) throw error;
                    warn('Skipped incompatible Discord component patch: ' + method, error);
                }
            }
            try {
                var delay = parent?.[delayKey];
                if (typeof delay === 'function') {
                    var cancel = delay.call(parent, function (target) {
                        try { install(target); }
                        catch (error) {
                            // The caller is now Discord's module loader, outside
                            // the plugin loader's onLoad error boundary.
                            warn('Deferred Discord method is unavailable: ' + method, error);
                        }
                    });
                    if (typeof cancel === 'function') {
                        if (cancelled) cancel();
                        else unsubscribe = cancel;
                    }
                } else install(parent);
            } catch (error) {
                dispose();
                if (!uiPatch) throw error;
                warn('Could not resolve Discord component: ' + method, error);
            }
            return dispose;
        }
        patch.await = function (method, promise, callback, once) {
            var epoch = generation;
            var cancelled = false;
            var remove;
            function dispose() {
                if (cancelled) return;
                cancelled = true;
                disposers.delete(dispose);
                remove?.();
            }
            if (!active) return dispose;
            disposers.add(dispose);
            Promise.resolve(promise).then(function (target) {
                if (!cancelled && active && epoch === generation) remove = patch(method, target, callback, once);
            }).catch(function (error) {
                warn('Deferred patch failed: ' + method, error);
                dispose();
            });
            return dispose;
        };
        return patch;
    }
    var guardedPatcher;
    function currentPatcher() {
        if (!guardedPatcher || raw !== api.patcher) {
            raw = api.patcher;
            guardedPatcher = Object.create(raw || null);
            ['before', 'after', 'instead'].forEach(function (kind) {
                if (typeof raw?.[kind] === 'function') Object.defineProperty(guardedPatcher, kind, { value: patchKind(kind), enumerable: true });
            });
        }
        return guardedPatcher;
    }
    var localAPI = Object.create(api);
    Object.defineProperty(localAPI, 'patcher', { get: currentPatcher, enumerable: true });
    // Discord's legacy JS toast bridge can queue a broken ToastContainer on
    // newer Android builds (useToastContainer reads .position of undefined).
    // Keep this adapter per-plugin. Never change api.ui or Discord's global UI.
    function safeToast(message) {
        var label = typeof message === 'string' || typeof message === 'number'
            ? String(message)
            : String(message?.message ?? message?.text ?? '');
        if (!label) return;
        try {
            var nativeToast = api.metro?.common?.ReactNative?.ToastAndroid;
            if (typeof nativeToast?.show === 'function') {
                return nativeToast.show(label, nativeToast.SHORT ?? 0);
            }
        } catch (error) {
            warn('Native Android notification failed.', error);
        }
        warn('Notification logged because the Discord toast bridge is unsafe: ' + label);
    }
    var lastUI, lastToasts, adaptedUI;
    function currentUI() {
        var ui = api.ui;
        if (!ui?.toasts) return ui;
        if (ui !== lastUI || ui.toasts !== lastToasts) {
            lastUI = ui;
            lastToasts = ui.toasts;
            adaptedUI = Object.create(ui);
            var toasts = Object.create(ui.toasts);
            Object.defineProperty(toasts, 'showToast', { value: safeToast, enumerable: true });
            Object.defineProperty(adaptedUI, 'toasts', { value: toasts, enumerable: true });
        }
        return adaptedUI;
    }
    Object.defineProperty(localAPI, 'ui', { get: currentUI, enumerable: true });
    var plugin;
    try { plugin = factory(localAPI); }
    catch (error) { clear(); throw error; }
    if (!plugin || typeof plugin !== 'object') { clear(); throw new Error(pluginName + ': invalid plugin exports'); }
    var result = Object.assign({}, plugin);
    result.onLoad = function () {
        active = true;
        var epoch = generation;
        function failed(error) {
            if (active && epoch === generation) {
                try { result.onUnload(); } catch (cleanupError) { warn('Startup cleanup failed.', cleanupError); }
            }
            throw error;
        }
        try {
            var pending = plugin.onLoad?.apply(this, arguments);
            if (pending && typeof pending.then === 'function') return Promise.resolve(pending).catch(failed);
            return pending;
        } catch (error) {
            return failed(error);
        }
    };
    result.onUnload = function () {
        clear();
        return plugin.onUnload?.apply(this, arguments);
    };
    return result;
}
return withRevengeCompatibility(vendetta, function(vendetta) {
return (() => {
  // Vendetta-compatible expression, evaluated with Revenge's per-plugin API.
  function createPlugin(V) {
    const BASE_LIMIT = 2000, NITRO_LIMIT = 4000;
    const storage = V.plugin.storage;
    let active = false, generation = 0;
    let disposers = [];
    const busy = new Map();
    const optional = fn => { try { return fn(); } catch { return undefined; } };
    const log = error => optional(() => V.logger?.error?.('Addon List', error));
    const find = (...props) => optional(() => V.metro.findByProps(...props));
    const toast = text => optional(() => V.ui?.toasts?.showToast?.(text));

    function notify(channelID, text) {
      const bot = find('sendBotMessage');
      if (channelID && typeof bot?.sendBotMessage === 'function') {
        try {
          const result = bot.sendBotMessage(channelID, text);
          Promise.resolve(result).catch(log);
          return;
        } catch (error) { log(error); }
      }
      toast(text);
    }

    function plain(value, fallback, max = 1500) {
      const text = typeof value === 'string' ? value : '';
      return (text.replace(/[\r\n\t]+/g, ' ').replace(/[\u0000-\u001f\u007f]/g, '').trim() || fallback).slice(0, max);
    }
    function markdown(value, fallback, max) {
      return plain(value, fallback, max).replace(/([\\`*_~>|\[\]])/g, '\\$1').replace(/@/g, '@\u200b');
    }
    function authors(value) {
      const names = (Array.isArray(value) ? value : value ? [value] : [])
        .slice(0, 20).map(author => markdown(typeof author === 'string' ? author : author?.name, '', 128)).filter(Boolean);
      return names.join(', ') || 'Unknown author';
    }
    function link(value) {
      if (typeof value !== 'string' || !/^https?:\/\/[^\s<>]+$/i.test(value)) return null;
      // Escape Markdown delimiters and prevent URL text from becoming mentions.
      return value.replace(/\(/g, '%28').replace(/\)/g, '%29').replace(/@/g, '%40');
    }
    function option(args, name, fallback = false) {
      const arg = (Array.isArray(args) ? args : []).find(item => item?.name === name);
      return arg ? arg.value === true || arg.value === 'true' : Boolean(fallback);
    }

    function messageLimit() {
      // Resolve at use time; Discord's current user may be unavailable on load.
      const userStore = optional(() => V.metro.findByStoreName?.('UserStore')) || find('getCurrentUser');
      const user = optional(() => userStore?.getCurrentUser?.());
      // Full Nitro only. Basic, Classic and unavailable stores use the base cap.
      return user?.premiumType === 2 ? NITRO_LIMIT : BASE_LIMIT;
    }

    async function listText(kind, detailed) {
      const registry = kind === 'Plugin' ? V.plugins?.plugins : V.themes?.themes;
      if (!registry || typeof registry !== 'object') throw new Error(`${kind} storage is unavailable in this Revenge version.`);
      if (typeof V.storage?.awaitSyncWrapper === 'function') await V.storage.awaitSyncWrapper(registry);
      const entries = Object.entries(registry).filter(([, entry]) => entry && typeof entry === 'object')
        .map(([id, entry]) => ({ id, entry, data: (kind === 'Plugin' ? entry.manifest : entry.data) || {} }));
      entries.sort((a, b) => plain(a.data.name, a.id, 128).localeCompare(plain(b.data.name, b.id, 128)));
      const lines = [`**My ${kind} List | ${entries.length} ${kind}${entries.length === 1 ? '' : 's'}**`, ''];
      for (const { id, entry, data } of entries) {
        const name = markdown(data.name, 'Unnamed ' + kind.toLowerCase(), 128);
        const state = kind === 'Plugin' ? (entry.enabled === undefined ? 'Installed' : entry.enabled ? 'Enabled' : 'Disabled') : ('Installed');
        if (detailed) {
          lines.push(`> **Name**: ${name}`, `> **${kind === 'Plugin' ? 'Status' : 'Selected'}**: ${state}`,
            `> **Description**: ${markdown(data.description, 'No description')}`, `> **Authors**: ${authors(data.authors)}`);
          const url = link(entry.id) || link(id);
          // Visible URL, without a link preview or a duplicated hidden target.
          if (url) lines.push(`> **URL**: <${url}>`);
          lines.push('');
        } else lines.push(`> **${name}** — ${state} — ${authors(data.authors)}`);
      }
      if (!entries.length) lines.push(`No ${kind.toLowerCase()}s installed.`);
      return lines.join('\n').trimEnd();
    }

    function split(text, limit) {
      // A URL must stay complete and clickable; never silently shorten it.
      if (text.split('\n').some(line => line.startsWith('> **URL**: <') && line.length > limit))
        throw new Error(`An install URL exceeds the ${limit}-character message limit.`);
      const chunks = [];
      let remaining = text;
      while (remaining.length > limit) {
        const block = remaining.lastIndexOf('\n\n', limit - 2);
        // Keep whole addon details together when practical, then whole lines.
        let end = block >= limit / 2 ? block + 2 : remaining.lastIndexOf('\n', limit - 1) + 1;
        if (end <= 0) end = limit;
        const code = remaining.charCodeAt(end - 1);
        if (code >= 0xd800 && code <= 0xdbff) end--;
        chunks.push(remaining.slice(0, end));
        remaining = remaining.slice(end);
      }
      if (remaining) chunks.push(remaining);
      return chunks;
    }

    async function copyText(text, label) {
      const clipboard = optional(() => V.metro.common.clipboard) || find('setString');
      if (typeof clipboard?.setString !== 'function') throw new Error('Clipboard is unavailable. Try the private preview option.');
      await clipboard.setString(text);
      toast(label || 'Addon list copied.');
    }

    async function copyList(text, limit, part, session = generation) {
      const chunks = split(text, limit);
      if (part !== undefined && (!Number.isInteger(part) || part < 1 || part > chunks.length))
        throw new Error(`Choose a copy part from 1 to ${chunks.length}.`);
      const index = part === undefined ? 0 : part - 1;
      const label = i => `Copied part ${i + 1}/${chunks.length} (${chunks[i].length}/${limit} characters).`;
      if (chunks.length === 1 || part !== undefined) {
        await copyText(chunks[index], label(index));
        return;
      }
      const confirm = V.ui?.alerts?.showConfirmationAlert;
      if (typeof confirm !== 'function')
        throw new Error(`This list needs ${chunks.length} messages. Use copy with part: 1, then part: 2, and so on.`);
      const { React, ReactNative: RN } = V.metro.common;
      const h = React.createElement;
      const dark = optional(() => RN.Appearance?.getColorScheme?.()) !== 'light';
      const color = dark ? '#f2f3f5' : '#202225';
      const content = h(RN.ScrollView, { style: { maxHeight: 320 } },
        h(RN.Text, { style: { color, marginBottom: 12 } },
          `Part 1 is copied. Choose a part, tap Done, then paste it into Discord. Reopen copy to choose the next part, or use the command's part option. Each part fits the ${limit}-character limit.`),
        ...chunks.map((chunk, i) => h(RN.TouchableOpacity, {
          key: String(i), accessibilityRole: 'button', accessibilityLabel: `Copy part ${i + 1} of ${chunks.length}`,
          style: { padding: 12, marginVertical: 4, borderRadius: 8, backgroundColor: dark ? '#35373c' : '#e3e5e8' },
          onPress: async () => {
            if (!active || session !== generation) return;
            try { await copyText(chunk, label(i)); }
            catch (error) { log(error); toast(plain(error?.message, 'Could not copy part.')); }
          }
        }, h(RN.Text, { style: { color } }, `Copy part ${i + 1}/${chunks.length} — ${chunk.length}/${limit} characters`))));
      await copyText(chunks[0], label(0));
      if (!active || session !== generation) return;
      confirm({ title: 'Copy addon list in parts', content, confirmText: 'Done', onConfirm: () => {} });
    }

    async function sendChunks(channelID, chunks, session) {
      if (!active || session !== generation) return;
      if (busy.has(channelID)) return notify(channelID, 'An addon list is already being sent.');
      const token = {};
      busy.set(channelID, token);
      let sent = 0;
      try {
        // Resolve only when needed: these Discord modules may not exist at startup.
        const actions = find('sendMessage', 'receiveMessage') || find('sendMessage');
        if (typeof actions?.sendMessage !== 'function') throw new Error('Discord message sending is unavailable. Use private preview or copy.');
        for (const content of chunks) {
          if (!active || session !== generation) return;
          const result = await actions.sendMessage(channelID, {
            content,
            // Never ping users or roles named in third-party addon metadata.
            allowedMentions: { parse: [], users: [], roles: [], repliedUser: false }
          });
          if (result === false || result?.ok === false || result?.success === false || result?.status >= 400)
            throw new Error('Discord rejected the message.');
          sent++;
        }
      } catch (error) {
        log(error);
        if (active && session === generation) notify(channelID,
          `Could not send the addon list (${sent}/${chunks.length} messages sent). ${plain(error?.message, 'Try again later.')}`);
      } finally {
        if (busy.get(channelID) === token) busy.delete(channelID);
      }
    }

    async function execute(kind, args, ctx, detailedDefault) {
      if (!active) return;
      const session = generation;
      const channelID = ctx?.channel?.id;
      try {
        const text = await listText(kind, option(args, 'detailed', detailedDefault ?? storage[kind === 'Plugin' ? 'pluginListAlwaysDetailed' : 'themeListAlwaysDetailed']));
        if (!active || session !== generation) return;
        const limit = messageLimit();
        if (option(args, 'copy')) {
          const part = (Array.isArray(args) ? args : []).find(item => item?.name === 'part');
          await copyList(text, limit, part ? Number(part.value) : undefined, session);
          return;
        }
        if (!channelID) throw new Error('Open a channel before using this command.');
        const chunks = split(text, limit);
        if (option(args, 'private', option(args, 'ephemeral', storage.privatePreview))) {
          const bot = find('sendBotMessage');
          if (typeof bot?.sendBotMessage !== 'function') throw new Error('Private preview is unavailable. Use copy instead.');
          for (const chunk of chunks) {
            if (!active || session !== generation) return;
            await bot.sendBotMessage(channelID, chunk);
          }
          return;
        }
        if (chunks.length === 1) { await sendChunks(channelID, chunks, session); return; }
        const confirm = V.ui?.alerts?.showConfirmationAlert;
        if (typeof confirm !== 'function') throw new Error('This list needs multiple messages. Use private preview or copy; confirmation is unavailable.');
        let used = false;
        confirm({
          title: 'Send addon list?',
          content: `Your list will send ${chunks.length} messages, each within ${limit} characters, to this channel. Everyone who can read the channel will see it.`,
          confirmText: 'Send list', cancelText: 'Cancel',
          onConfirm: () => {
            if (used) return;
            used = true;
            return sendChunks(channelID, chunks, session);
          },
          onCancel: () => { used = true; }
        });
      } catch (error) {
        log(error);
        if (active && session === generation) notify(channelID, `Could not create the addon list. ${plain(error?.message, 'Try again later.')}`);
      }
      // Do not return a message object: Revenge would send it a second time.
    }

    function listOptions() {
      return [
        { name: 'detailed', description: 'Include descriptions, authors and visible install URLs.', type: 5, required: false },
        { name: 'private', description: 'Show the list only to you in this channel.', type: 5, required: false },
        { name: 'copy', description: 'Copy message-sized parts instead of sending the list.', type: 5, required: false },
        { name: 'part', description: 'With copy: true, copy this part of a long list (starting at 1).', type: 4, required: false, minValue: 1 }
      ];
    }

    function enhanceCorePlugins() {
      if (typeof V.patcher?.after !== 'function') return;
      const module = optional(() => V.metro.common.commands) || find('getBuiltInCommands');
      if (typeof module?.getBuiltInCommands !== 'function') return;
      const session = generation;
      const replacements = new WeakMap();
      const dispose = V.patcher.after('getBuiltInCommands', module, (_args, commands) => {
        if (!active || session !== generation || !Array.isArray(commands)) return commands;
        return commands.map(command => {
          // Only Revenge's local command; leave server/application commands alone.
          if (command?.name !== 'plugins' || command.applicationId !== '-1') return command;
          let replacement = replacements.get(command);
          if (!replacement) {
            const description = 'Send, preview or copy installed plugins with URLs.';
            const options = [
              ...(Array.isArray(command.options) ? command.options.filter(opt => !['detailed', 'private', 'copy', 'part'].includes(opt.name)) : []),
              ...listOptions()
            ].map(opt => ({ ...opt, displayName: opt.displayName || opt.name, displayDescription: opt.displayDescription || opt.description }));
            replacement = { ...command, description, displayDescription: description, untranslatedDescription: description, options,
              execute: (args, ctx) => active && session === generation
                ? execute('Plugin', args, ctx, true)
                : command.execute(args, ctx)
            };
            replacements.set(command, replacement);
          }
          return replacement;
        });
      });
      if (typeof dispose === 'function') disposers.push(dispose);
    }

    function onUnload() {
      active = false;
      generation++;
      busy.clear();
      const old = disposers;
      disposers = [];
      for (const dispose of old.reverse()) { try { dispose(); } catch (error) { log(error); } }
    }
    function onLoad() {
      if (active) return;
      active = true;
      generation++;
      try {
        if (typeof V.commands?.registerCommand !== 'function') throw new Error('Revenge command API is unavailable.');
        for (const kind of ['Plugin', 'Theme']) {
          const dispose = V.commands.registerCommand({
            name: kind.toLowerCase() + '-list',
            displayName: kind.toLowerCase() + '-list',
            description: `Send, privately preview, or copy your ${kind.toLowerCase()} list.`,
            inputType: 1, type: 1, applicationId: '-1',
            options: listOptions(),
            execute: (args, ctx) => execute(kind, args, ctx)
          });
          if (typeof dispose !== 'function') throw new Error('Revenge did not return a command cleanup function.');
          disposers.push(dispose);
        }
        // Optional on older clients; /plugin-list remains available if absent.
        try { enhanceCorePlugins(); } catch (error) { log(error); }
      } catch (error) { onUnload(); throw error; }
    }

    function Settings() {
      const { React, ReactNative: RN } = V.metro.common;
      V.storage?.useProxy?.(storage);
      const dark = RN.useColorScheme?.() !== 'light';
      const color = dark ? '#f2f3f5' : '#202225';
      const muted = dark ? '#b5bac1' : '#4e5058';
      const h = React.createElement;
      const row = (key, label) => h(RN.View, { key, style: { flexDirection: 'row', alignItems: 'center', marginVertical: 12 } },
        h(RN.Text, { style: { flex: 1, color, fontSize: 16, marginRight: 8 } }, label),
        h(RN.Switch, { value: Boolean(storage[key]), onValueChange: value => { storage[key] = value; }, accessibilityLabel: label }));
      const button = kind => h(RN.TouchableOpacity, {
        key: kind, accessibilityRole: 'button', accessibilityLabel: `Copy ${kind.toLowerCase()} list`,
        style: { padding: 14, marginVertical: 6, borderRadius: 8, backgroundColor: dark ? '#35373c' : '#e3e5e8' },
        onPress: async () => {
          const session = generation;
          try {
            const text = await listText(kind, Boolean(storage[kind === 'Plugin' ? 'pluginListAlwaysDetailed' : 'themeListAlwaysDetailed']));
            if (active && session === generation) await copyList(text, messageLimit(), undefined, session);
          }
          catch (error) { log(error); toast(plain(error?.message, 'Could not copy list.')); }
        }
      }, h(RN.Text, { style: { color, fontSize: 16 } }, `Copy ${kind.toLowerCase()} list`));
      return h(RN.ScrollView, { style: { flex: 1 }, contentContainerStyle: { padding: 16 } },
        h(RN.Text, { style: { color, fontSize: 22, fontWeight: 'bold', marginBottom: 8 } }, 'Addon List'),
        h(RN.Text, { style: { color: muted, marginBottom: 12 } }, 'Use /plugins, /plugin-list or /theme-list. Revenge’s /plugins shows details and install URLs by default while Addon List is enabled. Copy splits long lists into parts with character counts: 2,000 normally, 4,000 with full Nitro. Long public lists ask before sending multiple messages.'),
        row('pluginListAlwaysDetailed', 'Detailed plugin lists by default'),
        row('themeListAlwaysDetailed', 'Detailed theme lists by default'),
        row('privatePreview', 'Private previews by default'),
        button('Plugin'), button('Theme'),
        h(RN.Text, { style: { color: muted, marginTop: 12 } }, 'The detailed and private command options override these defaults. Copy never posts to a channel.'));
    }

    return { onLoad, onUnload, settings: Settings };
  }
  return createPlugin(vendetta);
})()
}, "Addon List");
})()
); }, {"id": "dev.fluttershy2008.addon-list", "legacyManifest": {"name": "Addon List", "description": "Send, preview or copy plugin and theme lists with visible URLs and Discord/Nitro message-sized parts.", "authors": [{"name": "Kitomanari", "id": "437154602626973697"}, {"name": "fluttershy_simper"}], "version": "2.2.2", "main": "index.js", "hash": "444fd612d40ab1a270b66d87085739a2eafa13c8008bff3212df589184b1622f"}, "repository": "https://raw.githubusercontent.com/Fluttershy2008-mlp/lol/main/revenge-next/index.json"}) };
})()
